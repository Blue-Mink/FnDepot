const ph = `/*! tailwindcss v4.1.11 | MIT License | https://tailwindcss.com */@layer properties{@supports ((-webkit-hyphens:none) and (not (margin-trim:inline))) or ((-moz-orient:inline) and (not (color:rgb(from red r g b)))){*,:before,:after,::backdrop{--tw-translate-x:0;--tw-translate-y:0;--tw-translate-z:0;--tw-rotate-x:initial;--tw-rotate-y:initial;--tw-rotate-z:initial;--tw-skew-x:initial;--tw-skew-y:initial;--tw-space-y-reverse:0;--tw-space-x-reverse:0;--tw-border-style:solid;--tw-gradient-position:initial;--tw-gradient-from:#0000;--tw-gradient-via:#0000;--tw-gradient-to:#0000;--tw-gradient-stops:initial;--tw-gradient-via-stops:initial;--tw-gradient-from-position:0%;--tw-gradient-via-position:50%;--tw-gradient-to-position:100%;--tw-leading:initial;--tw-font-weight:initial;--tw-tracking:initial;--tw-ordinal:initial;--tw-slashed-zero:initial;--tw-numeric-figure:initial;--tw-numeric-spacing:initial;--tw-numeric-fraction:initial;--tw-shadow:0 0 #0000;--tw-shadow-color:initial;--tw-shadow-alpha:100%;--tw-inset-shadow:0 0 #0000;--tw-inset-shadow-color:initial;--tw-inset-shadow-alpha:100%;--tw-ring-color:initial;--tw-ring-shadow:0 0 #0000;--tw-inset-ring-color:initial;--tw-inset-ring-shadow:0 0 #0000;--tw-ring-inset:initial;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-offset-shadow:0 0 #0000;--tw-outline-style:solid;--tw-blur:initial;--tw-brightness:initial;--tw-contrast:initial;--tw-grayscale:initial;--tw-hue-rotate:initial;--tw-invert:initial;--tw-opacity:initial;--tw-saturate:initial;--tw-sepia:initial;--tw-drop-shadow:initial;--tw-drop-shadow-color:initial;--tw-drop-shadow-alpha:100%;--tw-drop-shadow-size:initial;--tw-backdrop-blur:initial;--tw-backdrop-brightness:initial;--tw-backdrop-contrast:initial;--tw-backdrop-grayscale:initial;--tw-backdrop-hue-rotate:initial;--tw-backdrop-invert:initial;--tw-backdrop-opacity:initial;--tw-backdrop-saturate:initial;--tw-backdrop-sepia:initial;--tw-duration:initial;--tw-ease:initial;--tw-content:"";--tw-animation-delay:0s;--tw-animation-direction:normal;--tw-animation-duration:initial;--tw-animation-fill-mode:none;--tw-animation-iteration-count:1;--tw-enter-opacity:1;--tw-enter-rotate:0;--tw-enter-scale:1;--tw-enter-translate-x:0;--tw-enter-translate-y:0;--tw-exit-opacity:1;--tw-exit-rotate:0;--tw-exit-scale:1;--tw-exit-translate-x:0;--tw-exit-translate-y:0}}}@layer theme{:root,:host{--font-sans:ui-sans-serif,system-ui,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";--font-mono:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace;--color-red-100:oklch(93.6% .032 17.717);--color-red-500:oklch(63.7% .237 25.331);--color-red-600:oklch(57.7% .245 27.325);--color-amber-100:oklch(96.2% .059 95.617);--color-amber-200:oklch(92.4% .12 95.746);--color-amber-400:oklch(82.8% .189 84.429);--color-amber-500:oklch(76.9% .188 70.08);--color-amber-600:oklch(66.6% .179 58.318);--color-yellow-500:oklch(79.5% .184 86.047);--color-green-100:oklch(96.2% .044 156.743);--color-green-200:oklch(92.5% .084 155.995);--color-green-400:oklch(79.2% .209 151.711);--color-green-500:oklch(72.3% .219 149.579);--color-green-600:oklch(62.7% .194 149.214);--color-emerald-50:oklch(97.9% .021 166.113);--color-emerald-400:oklch(76.5% .177 163.223);--color-emerald-500:oklch(69.6% .17 162.48);--color-emerald-950:oklch(26.2% .051 172.552);--color-sky-500:oklch(68.5% .169 237.323);--color-blue-400:oklch(70.7% .165 254.624);--color-blue-600:oklch(54.6% .245 262.881);--color-purple-800:oklch(43.8% .218 303.724);--color-slate-400:oklch(70.4% .04 256.788);--color-slate-700:oklch(37.2% .044 257.287);--color-slate-900:oklch(20.8% .042 265.755);--color-gray-100:oklch(96.7% .003 264.542);--color-gray-200:oklch(92.8% .006 264.531);--color-gray-400:oklch(70.7% .022 261.325);--color-gray-500:oklch(55.1% .027 264.364);--color-gray-700:oklch(37.3% .034 259.733);--color-neutral-400:oklch(70.8% 0 0);--color-black:#000;--color-white:#fff;--spacing:.25rem;--container-xs:20rem;--container-sm:24rem;--container-lg:32rem;--container-2xl:42rem;--container-3xl:48rem;--text-xs:.75rem;--text-xs--line-height:calc(1/.75);--text-sm:.875rem;--text-sm--line-height:calc(1.25/.875);--text-base:1rem;--text-base--line-height: 1.5 ;--text-lg:1.125rem;--text-lg--line-height:calc(1.75/1.125);--text-2xl:1.5rem;--text-2xl--line-height:calc(2/1.5);--text-3xl:1.875rem;--text-3xl--line-height: 1.2 ;--text-4xl:2.25rem;--text-4xl--line-height:calc(2.5/2.25);--font-weight-normal:400;--font-weight-medium:500;--font-weight-semibold:600;--font-weight-bold:700;--font-weight-extrabold:800;--tracking-tight:-.025em;--tracking-widest:.1em;--leading-tight:1.25;--leading-snug:1.375;--leading-normal:1.5;--leading-relaxed:1.625;--radius-xs:.125rem;--radius-2xl:1rem;--ease-in-out:cubic-bezier(.4,0,.2,1);--animate-spin:spin 1s linear infinite;--animate-pulse:pulse 2s cubic-bezier(.4,0,.6,1)infinite;--blur-xs:4px;--aspect-video:16/9;--default-transition-duration:.15s;--default-transition-timing-function:cubic-bezier(.4,0,.2,1);--default-font-family:var(--font-sans);--default-mono-font-family:var(--font-mono);--color-border:var(--border)}}@layer base{*,:after,:before,::backdrop{box-sizing:border-box;border:0 solid;margin:0;padding:0}::file-selector-button{box-sizing:border-box;border:0 solid;margin:0;padding:0}html,:host{-webkit-text-size-adjust:100%;-moz-tab-size:4;-o-tab-size:4;tab-size:4;line-height:1.5;font-family:var(--default-font-family,ui-sans-serif,system-ui,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji");font-feature-settings:var(--default-font-feature-settings,normal);font-variation-settings:var(--default-font-variation-settings,normal);-webkit-tap-highlight-color:transparent}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;-webkit-text-decoration:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,samp,pre{font-family:var(--default-mono-font-family,ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace);font-feature-settings:var(--default-mono-font-feature-settings,normal);font-variation-settings:var(--default-mono-font-variation-settings,normal);font-size:1em}small{font-size:80%}sub,sup{vertical-align:baseline;font-size:75%;line-height:0;position:relative}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}:-moz-focusring{outline:auto}progress{vertical-align:baseline}summary{display:list-item}ol,ul,menu{list-style:none}img,svg,video,canvas,audio,iframe,embed,object{vertical-align:middle;display:block}img,video{max-width:100%;height:auto}button,input,select,optgroup,textarea{font:inherit;font-feature-settings:inherit;font-variation-settings:inherit;letter-spacing:inherit;color:inherit;opacity:1;background-color:#0000;border-radius:0}::file-selector-button{font:inherit;font-feature-settings:inherit;font-variation-settings:inherit;letter-spacing:inherit;color:inherit;opacity:1;background-color:#0000;border-radius:0}:where(select:is([multiple],[size])) optgroup{font-weight:bolder}:where(select:is([multiple],[size])) optgroup option{padding-inline-start:20px}::file-selector-button{margin-inline-end:4px}::-moz-placeholder{opacity:1}::placeholder{opacity:1}@supports (not (-webkit-appearance:-apple-pay-button)) or (contain-intrinsic-size:1px){::-moz-placeholder{color:currentColor}::placeholder{color:currentColor}@supports (color:color-mix(in lab,red,red)){::-moz-placeholder{color:color-mix(in oklab,currentcolor 50%,transparent)}::placeholder{color:color-mix(in oklab,currentcolor 50%,transparent)}}}textarea{resize:vertical}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-date-and-time-value{min-height:1lh;text-align:inherit}::-webkit-datetime-edit{display:inline-flex}::-webkit-datetime-edit-fields-wrapper{padding:0}::-webkit-datetime-edit{padding-block:0}::-webkit-datetime-edit-year-field{padding-block:0}::-webkit-datetime-edit-month-field{padding-block:0}::-webkit-datetime-edit-day-field{padding-block:0}::-webkit-datetime-edit-hour-field{padding-block:0}::-webkit-datetime-edit-minute-field{padding-block:0}::-webkit-datetime-edit-second-field{padding-block:0}::-webkit-datetime-edit-millisecond-field{padding-block:0}::-webkit-datetime-edit-meridiem-field{padding-block:0}:-moz-ui-invalid{box-shadow:none}button,input:where([type=button],[type=reset],[type=submit]){-webkit-appearance:button;-moz-appearance:button;appearance:button}::file-selector-button{-webkit-appearance:button;-moz-appearance:button;appearance:button}::-webkit-inner-spin-button{height:auto}::-webkit-outer-spin-button{height:auto}[hidden]:where(:not([hidden=until-found])){display:none!important}*{border-color:var(--border);outline-color:var(--ring)}@supports (color:color-mix(in lab,red,red)){*{outline-color:color-mix(in oklab,var(--ring)50%,transparent)}}body{background-color:var(--background);color:var(--foreground)}}@layer components;@layer utilities{.\\@container\\/card-header{container:card-header/inline-size}.\\@container\\/field-group{container:field-group/inline-size}.pointer-events-none{pointer-events:none}.visible{visibility:visible}.sr-only{clip:rect(0,0,0,0);white-space:nowrap;border-width:0;width:1px;height:1px;margin:-1px;padding:0;position:absolute;overflow:hidden}.absolute{position:absolute}.fixed{position:fixed}.relative{position:relative}.static{position:static}.sticky{position:sticky}.inset-0{inset:calc(var(--spacing)*0)}.inset-x-0{inset-inline:calc(var(--spacing)*0)}.inset-y-0{inset-block:calc(var(--spacing)*0)}.-top-12{top:calc(var(--spacing)*-12)}.top-0{top:calc(var(--spacing)*0)}.top-1\\.5{top:calc(var(--spacing)*1.5)}.top-1\\/2{top:50%}.top-3\\.5{top:calc(var(--spacing)*3.5)}.top-4{top:calc(var(--spacing)*4)}.top-8{top:calc(var(--spacing)*8)}.top-\\[1px\\]{top:1px}.top-\\[50\\%\\]{top:50%}.top-\\[60\\%\\]{top:60%}.top-full{top:100%}.-right-12{right:calc(var(--spacing)*-12)}.right-0{right:calc(var(--spacing)*0)}.right-1{right:calc(var(--spacing)*1)}.right-2{right:calc(var(--spacing)*2)}.right-3{right:calc(var(--spacing)*3)}.right-3\\.5{right:calc(var(--spacing)*3.5)}.right-4{right:calc(var(--spacing)*4)}.-bottom-12{bottom:calc(var(--spacing)*-12)}.bottom-0{bottom:calc(var(--spacing)*0)}.bottom-2{bottom:calc(var(--spacing)*2)}.-left-12{left:calc(var(--spacing)*-12)}.left-0{left:calc(var(--spacing)*0)}.left-1{left:calc(var(--spacing)*1)}.left-1\\/2{left:50%}.left-2{left:calc(var(--spacing)*2)}.left-8{left:calc(var(--spacing)*8)}.left-\\[50\\%\\]{left:50%}.left-\\[var\\(--reka-navigation-menu-viewport-left\\)\\]{left:var(--reka-navigation-menu-viewport-left)}.isolate{isolation:isolate}.z-10{z-index:10}.z-20{z-index:20}.z-50{z-index:50}.z-\\[1\\]{z-index:1}.order-first{order:-9999}.order-last{order:9999}.col-start-2{grid-column-start:2}.row-span-2{grid-row:span 2/span 2}.row-start-1{grid-row-start:1}.\\!m-0{margin:calc(var(--spacing)*0)!important}.-mx-1{margin-inline:calc(var(--spacing)*-1)}.mx-2{margin-inline:calc(var(--spacing)*2)}.mx-3\\.5{margin-inline:calc(var(--spacing)*3.5)}.mx-auto{margin-inline:auto}.-my-2{margin-block:calc(var(--spacing)*-2)}.my-0{margin-block:calc(var(--spacing)*0)}.my-0\\.5{margin-block:calc(var(--spacing)*.5)}.my-1{margin-block:calc(var(--spacing)*1)}.my-2{margin-block:calc(var(--spacing)*2)}.my-8{margin-block:calc(var(--spacing)*8)}.-mt-4{margin-top:calc(var(--spacing)*-4)}.mt-1{margin-top:calc(var(--spacing)*1)}.mt-1\\.5{margin-top:calc(var(--spacing)*1.5)}.mt-2{margin-top:calc(var(--spacing)*2)}.mt-3{margin-top:calc(var(--spacing)*3)}.mt-4{margin-top:calc(var(--spacing)*4)}.mt-6{margin-top:calc(var(--spacing)*6)}.mt-8{margin-top:calc(var(--spacing)*8)}.mt-auto{margin-top:auto}.mr-1{margin-right:calc(var(--spacing)*1)}.mr-2{margin-right:calc(var(--spacing)*2)}.mb-2{margin-bottom:calc(var(--spacing)*2)}.mb-3{margin-bottom:calc(var(--spacing)*3)}.mb-4{margin-bottom:calc(var(--spacing)*4)}.mb-8{margin-bottom:calc(var(--spacing)*8)}.-ml-1{margin-left:calc(var(--spacing)*-1)}.-ml-4{margin-left:calc(var(--spacing)*-4)}.ml-1{margin-left:calc(var(--spacing)*1)}.ml-2{margin-left:calc(var(--spacing)*2)}.ml-4{margin-left:calc(var(--spacing)*4)}.ml-auto{margin-left:auto}.box-content{box-sizing:content-box}.line-clamp-1{-webkit-line-clamp:1;-webkit-box-orient:vertical;display:-webkit-box;overflow:hidden}.line-clamp-2{-webkit-line-clamp:2;-webkit-box-orient:vertical;display:-webkit-box;overflow:hidden}.block{display:block}.flex{display:flex}.grid{display:grid}.hidden{display:none}.inline-flex{display:inline-flex}.table{display:table}.table-caption{display:table-caption}.table-cell{display:table-cell}.table-row{display:table-row}.field-sizing-content{field-sizing:content}.aspect-square{aspect-ratio:1}.aspect-video{aspect-ratio:var(--aspect-video)}.size-2{width:calc(var(--spacing)*2);height:calc(var(--spacing)*2)}.size-2\\.5{width:calc(var(--spacing)*2.5);height:calc(var(--spacing)*2.5)}.size-3{width:calc(var(--spacing)*3);height:calc(var(--spacing)*3)}.size-3\\.5{width:calc(var(--spacing)*3.5);height:calc(var(--spacing)*3.5)}.size-4{width:calc(var(--spacing)*4);height:calc(var(--spacing)*4)}.size-6{width:calc(var(--spacing)*6);height:calc(var(--spacing)*6)}.size-7{width:calc(var(--spacing)*7);height:calc(var(--spacing)*7)}.size-8{width:calc(var(--spacing)*8);height:calc(var(--spacing)*8)}.size-9{width:calc(var(--spacing)*9);height:calc(var(--spacing)*9)}.size-10{width:calc(var(--spacing)*10);height:calc(var(--spacing)*10)}.size-full{width:100%;height:100%}.h-1\\.5{height:calc(var(--spacing)*1.5)}.h-2{height:calc(var(--spacing)*2)}.h-2\\.5{height:calc(var(--spacing)*2.5)}.h-3{height:calc(var(--spacing)*3)}.h-4{height:calc(var(--spacing)*4)}.h-5{height:calc(var(--spacing)*5)}.h-6{height:calc(var(--spacing)*6)}.h-7{height:calc(var(--spacing)*7)}.h-8{height:calc(var(--spacing)*8)}.h-9{height:calc(var(--spacing)*9)}.h-10{height:calc(var(--spacing)*10)}.h-12{height:calc(var(--spacing)*12)}.h-16{height:calc(var(--spacing)*16)}.h-48{height:calc(var(--spacing)*48)}.h-\\[1\\.15rem\\]{height:1.15rem}.h-\\[500px\\]{height:500px}.h-\\[calc\\(100\\%-1px\\)\\]{height:calc(100% - 1px)}.h-\\[var\\(--reka-navigation-menu-viewport-height\\)\\]{height:var(--reka-navigation-menu-viewport-height)}.h-\\[var\\(--reka-select-trigger-height\\)\\]{height:var(--reka-select-trigger-height)}.h-auto{height:auto}.h-full{height:100%}.h-max{height:-moz-max-content;height:max-content}.h-px{height:1px}.h-screen{height:100vh}.h-svh{height:100svh}.max-h-\\(--reka-context-menu-content-available-height\\){max-height:var(--reka-context-menu-content-available-height)}.max-h-\\(--reka-dropdown-menu-content-available-height\\){max-height:var(--reka-dropdown-menu-content-available-height)}.max-h-\\(--reka-select-content-available-height\\){max-height:var(--reka-select-content-available-height)}.max-h-\\[300px\\]{max-height:300px}.min-h-0{min-height:calc(var(--spacing)*0)}.min-h-4{min-height:calc(var(--spacing)*4)}.min-h-5{min-height:calc(var(--spacing)*5)}.min-h-16{min-height:calc(var(--spacing)*16)}.min-h-screen{min-height:100vh}.min-h-svh{min-height:100svh}.w-\\(--sidebar-width\\){width:var(--sidebar-width)}.w-0{width:calc(var(--spacing)*0)}.w-1{width:calc(var(--spacing)*1)}.w-2{width:calc(var(--spacing)*2)}.w-2\\.5{width:calc(var(--spacing)*2.5)}.w-3{width:calc(var(--spacing)*3)}.w-3\\/4{width:75%}.w-4{width:calc(var(--spacing)*4)}.w-5{width:calc(var(--spacing)*5)}.w-7{width:calc(var(--spacing)*7)}.w-8{width:calc(var(--spacing)*8)}.w-9{width:calc(var(--spacing)*9)}.w-10{width:calc(var(--spacing)*10)}.w-12{width:calc(var(--spacing)*12)}.w-16{width:calc(var(--spacing)*16)}.w-48{width:calc(var(--spacing)*48)}.w-56{width:calc(var(--spacing)*56)}.w-64{width:calc(var(--spacing)*64)}.w-72{width:calc(var(--spacing)*72)}.w-\\[--reka-dropdown-menu-trigger-width\\]{width:--reka-dropdown-menu-trigger-width}.w-\\[100px\\]{width:100px}.w-\\[200px\\]{width:200px}.w-auto{width:auto}.w-fit{width:-moz-fit-content;width:fit-content}.w-full{width:100%}.w-max{width:-moz-max-content;width:max-content}.w-px{width:1px}.max-w-\\(--skeleton-width\\){max-width:var(--skeleton-width)}.max-w-2xl{max-width:var(--container-2xl)}.max-w-3xl{max-width:var(--container-3xl)}.max-w-\\[72rem\\]{max-width:72rem}.max-w-\\[100rem\\]{max-width:100rem}.max-w-\\[200px\\]{max-width:200px}.max-w-\\[350px\\]{max-width:350px}.max-w-\\[900px\\]{max-width:900px}.max-w-\\[calc\\(100\\%-2rem\\)\\]{max-width:calc(100% - 2rem)}.max-w-lg{max-width:var(--container-lg)}.max-w-max{max-width:-moz-max-content;max-width:max-content}.max-w-sm{max-width:var(--container-sm)}.max-w-xs{max-width:var(--container-xs)}.min-w-0{min-width:calc(var(--spacing)*0)}.min-w-5{min-width:calc(var(--spacing)*5)}.min-w-8{min-width:calc(var(--spacing)*8)}.min-w-9{min-width:calc(var(--spacing)*9)}.min-w-10{min-width:calc(var(--spacing)*10)}.min-w-56{min-width:calc(var(--spacing)*56)}.min-w-\\[8rem\\]{min-width:8rem}.min-w-\\[12rem\\]{min-width:12rem}.min-w-\\[var\\(--reka-select-trigger-width\\)\\]{min-width:var(--reka-select-trigger-width)}.flex-1{flex:1}.flex-shrink-0,.shrink-0{flex-shrink:0}.grow{flex-grow:1}.grow-0{flex-grow:0}.basis-full{flex-basis:100%}.caption-bottom{caption-side:bottom}.border-collapse{border-collapse:collapse}.origin-\\(--reka-combobox-content-transform-origin\\){transform-origin:var(--reka-combobox-content-transform-origin)}.origin-\\(--reka-context-menu-content-transform-origin\\){transform-origin:var(--reka-context-menu-content-transform-origin)}.origin-\\(--reka-dropdown-menu-content-transform-origin\\){transform-origin:var(--reka-dropdown-menu-content-transform-origin)}.origin-\\(--reka-menubar-content-transform-origin\\){transform-origin:var(--reka-menubar-content-transform-origin)}.origin-\\(--reka-popover-content-transform-origin\\){transform-origin:var(--reka-popover-content-transform-origin)}.-translate-x-1\\/2{--tw-translate-x: -50% ;translate:var(--tw-translate-x)var(--tw-translate-y)}.-translate-x-px{--tw-translate-x:-1px;translate:var(--tw-translate-x)var(--tw-translate-y)}.translate-x-1\\/2{--tw-translate-x: 50% ;translate:var(--tw-translate-x)var(--tw-translate-y)}.translate-x-\\[-50\\%\\]{--tw-translate-x:-50%;translate:var(--tw-translate-x)var(--tw-translate-y)}.translate-x-px{--tw-translate-x:1px;translate:var(--tw-translate-x)var(--tw-translate-y)}.-translate-y-1\\/2{--tw-translate-y: -50% ;translate:var(--tw-translate-x)var(--tw-translate-y)}.translate-y-0\\.5{--tw-translate-y:calc(var(--spacing)*.5);translate:var(--tw-translate-x)var(--tw-translate-y)}.translate-y-1\\/2{--tw-translate-y: 50% ;translate:var(--tw-translate-x)var(--tw-translate-y)}.translate-y-\\[-50\\%\\]{--tw-translate-y:-50%;translate:var(--tw-translate-x)var(--tw-translate-y)}.translate-y-\\[calc\\(-50\\%_-_2px\\)\\]{--tw-translate-y: calc(-50% - 2px) ;translate:var(--tw-translate-x)var(--tw-translate-y)}.rotate-45{rotate:45deg}.rotate-90{rotate:90deg}.transform{transform:var(--tw-rotate-x,)var(--tw-rotate-y,)var(--tw-rotate-z,)var(--tw-skew-x,)var(--tw-skew-y,)}.animate-caret-blink{animation:1.25s ease-out infinite caret-blink}.animate-in{animation:enter var(--tw-animation-duration,var(--tw-duration,.15s))var(--tw-ease,ease)var(--tw-animation-delay,0s)var(--tw-animation-iteration-count,1)var(--tw-animation-direction,normal)var(--tw-animation-fill-mode,none)}.animate-pulse{animation:var(--animate-pulse)}.animate-spin{animation:var(--animate-spin)}.cursor-default{cursor:default}.cursor-pointer{cursor:pointer}.cursor-text{cursor:text}.touch-none{touch-action:none}.resize-none{resize:none}.scroll-my-1{scroll-margin-block:calc(var(--spacing)*1)}.scroll-py-1{scroll-padding-block:calc(var(--spacing)*1)}.list-disc{list-style-type:disc}.list-none{list-style-type:none}.appearance-none{-webkit-appearance:none;-moz-appearance:none;appearance:none}.auto-rows-min{grid-auto-rows:min-content}.grid-cols-1{grid-template-columns:repeat(1,minmax(0,1fr))}.grid-cols-\\[0_1fr\\]{grid-template-columns:0 1fr}.grid-rows-\\[auto_auto\\]{grid-template-rows:auto auto}.flex-col{flex-direction:column}.flex-col-reverse{flex-direction:column-reverse}.flex-row{flex-direction:row}.flex-wrap{flex-wrap:wrap}.place-content-center{place-content:center}.place-items-center{place-items:center}.items-center{align-items:center}.items-end{align-items:flex-end}.items-start{align-items:flex-start}.items-stretch{align-items:stretch}.justify-between{justify-content:space-between}.justify-center{justify-content:center}.justify-start{justify-content:flex-start}.justify-items-start{justify-items:start}.gap-1{gap:calc(var(--spacing)*1)}.gap-1\\.5{gap:calc(var(--spacing)*1.5)}.gap-2{gap:calc(var(--spacing)*2)}.gap-2\\.5{gap:calc(var(--spacing)*2.5)}.gap-3{gap:calc(var(--spacing)*3)}.gap-4{gap:calc(var(--spacing)*4)}.gap-6{gap:calc(var(--spacing)*6)}.gap-7{gap:calc(var(--spacing)*7)}.gap-\\[--spacing\\(var\\(--gap\\)\\)\\]{gap:calc(var(--spacing)*var(--gap))}:where(.space-y-1>:not(:last-child)){--tw-space-y-reverse:0;margin-block-start:calc(calc(var(--spacing)*1)*var(--tw-space-y-reverse));margin-block-end:calc(calc(var(--spacing)*1)*calc(1 - var(--tw-space-y-reverse)))}:where(.space-y-2>:not(:last-child)){--tw-space-y-reverse:0;margin-block-start:calc(calc(var(--spacing)*2)*var(--tw-space-y-reverse));margin-block-end:calc(calc(var(--spacing)*2)*calc(1 - var(--tw-space-y-reverse)))}:where(.space-y-3>:not(:last-child)){--tw-space-y-reverse:0;margin-block-start:calc(calc(var(--spacing)*3)*var(--tw-space-y-reverse));margin-block-end:calc(calc(var(--spacing)*3)*calc(1 - var(--tw-space-y-reverse)))}:where(.space-y-4>:not(:last-child)){--tw-space-y-reverse:0;margin-block-start:calc(calc(var(--spacing)*4)*var(--tw-space-y-reverse));margin-block-end:calc(calc(var(--spacing)*4)*calc(1 - var(--tw-space-y-reverse)))}:where(.space-y-6>:not(:last-child)){--tw-space-y-reverse:0;margin-block-start:calc(calc(var(--spacing)*6)*var(--tw-space-y-reverse));margin-block-end:calc(calc(var(--spacing)*6)*calc(1 - var(--tw-space-y-reverse)))}:where(.space-x-1>:not(:last-child)){--tw-space-x-reverse:0;margin-inline-start:calc(calc(var(--spacing)*1)*var(--tw-space-x-reverse));margin-inline-end:calc(calc(var(--spacing)*1)*calc(1 - var(--tw-space-x-reverse)))}:where(.space-x-2>:not(:last-child)){--tw-space-x-reverse:0;margin-inline-start:calc(calc(var(--spacing)*2)*var(--tw-space-x-reverse));margin-inline-end:calc(calc(var(--spacing)*2)*calc(1 - var(--tw-space-x-reverse)))}.gap-y-0\\.5{row-gap:calc(var(--spacing)*.5)}.gap-y-4{row-gap:calc(var(--spacing)*4)}.self-start{align-self:flex-start}.self-stretch{align-self:stretch}.justify-self-end{justify-self:flex-end}.truncate{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.overflow-auto{overflow:auto}.overflow-hidden{overflow:hidden}.overflow-x-auto{overflow-x:auto}.overflow-x-hidden{overflow-x:hidden}.overflow-y-auto{overflow-y:auto}.rounded{border-radius:.25rem}.rounded-2xl{border-radius:var(--radius-2xl)}.rounded-\\[2px\\]{border-radius:2px}.rounded-\\[4px\\]{border-radius:4px}.rounded-\\[calc\\(var\\(--radius\\)-5px\\)\\]{border-radius:calc(var(--radius) - 5px)}.rounded-\\[inherit\\]{border-radius:inherit}.rounded-full{border-radius:3.40282e38px}.rounded-lg{border-radius:var(--radius)}.rounded-md{border-radius:calc(var(--radius) - 2px)}.rounded-none{border-radius:0}.rounded-sm{border-radius:calc(var(--radius) - 4px)}.rounded-xl{border-radius:calc(var(--radius) + 4px)}.rounded-xs{border-radius:var(--radius-xs)}.rounded-tl-sm{border-top-left-radius:calc(var(--radius) - 4px)}.border{border-style:var(--tw-border-style);border-width:1px}.border-0{border-style:var(--tw-border-style);border-width:0}.border-\\[1\\.5px\\]{border-style:var(--tw-border-style);border-width:1.5px}.border-y{border-block-style:var(--tw-border-style);border-block-width:1px}.border-t{border-top-style:var(--tw-border-style);border-top-width:1px}.border-r{border-right-style:var(--tw-border-style);border-right-width:1px}.border-b,.border-b-1{border-bottom-style:var(--tw-border-style);border-bottom-width:1px}.border-l{border-left-style:var(--tw-border-style);border-left-width:1px}.border-dashed{--tw-border-style:dashed;border-style:dashed}.border-none{--tw-border-style:none;border-style:none}.border-\\(--color-border\\){border-color:var(--color-border)}.border-amber-200{border-color:var(--color-amber-200)}.border-border,.border-border\\/50{border-color:var(--border)}@supports (color:color-mix(in lab,red,red)){.border-border\\/50{border-color:color-mix(in oklab,var(--border)50%,transparent)}}.border-emerald-400\\/60{border-color:#00d29499}@supports (color:color-mix(in lab,red,red)){.border-emerald-400\\/60{border-color:color-mix(in oklab,var(--color-emerald-400)60%,transparent)}}.border-input{border-color:var(--input)}.border-muted\\/40{border-color:var(--muted)}@supports (color:color-mix(in lab,red,red)){.border-muted\\/40{border-color:color-mix(in oklab,var(--muted)40%,transparent)}}.border-primary{border-color:var(--primary)}.border-sidebar-border{border-color:var(--sidebar-border)}.border-slate-700{border-color:var(--color-slate-700)}.border-transparent{border-color:#0000}.border-t-transparent{border-top-color:#0000}.border-l-transparent{border-left-color:#0000}.bg-\\(--color-bg\\){background-color:var(--color-bg)}.bg-amber-100{background-color:var(--color-amber-100)}.bg-amber-400{background-color:var(--color-amber-400)}.bg-background,.bg-background\\/40{background-color:var(--background)}@supports (color:color-mix(in lab,red,red)){.bg-background\\/40{background-color:color-mix(in oklab,var(--background)40%,transparent)}}.bg-background\\/90{background-color:var(--background)}@supports (color:color-mix(in lab,red,red)){.bg-background\\/90{background-color:color-mix(in oklab,var(--background)90%,transparent)}}.bg-black\\/80{background-color:#000c}@supports (color:color-mix(in lab,red,red)){.bg-black\\/80{background-color:color-mix(in oklab,var(--color-black)80%,transparent)}}.bg-border{background-color:var(--border)}.bg-card,.bg-card\\/70{background-color:var(--card)}@supports (color:color-mix(in lab,red,red)){.bg-card\\/70{background-color:color-mix(in oklab,var(--card)70%,transparent)}}.bg-card\\/80{background-color:var(--card)}@supports (color:color-mix(in lab,red,red)){.bg-card\\/80{background-color:color-mix(in oklab,var(--card)80%,transparent)}}.bg-destructive{background-color:var(--destructive)}.bg-emerald-50\\/60{background-color:#ecfdf599}@supports (color:color-mix(in lab,red,red)){.bg-emerald-50\\/60{background-color:color-mix(in oklab,var(--color-emerald-50)60%,transparent)}}.bg-foreground{background-color:var(--foreground)}.bg-gray-100{background-color:var(--color-gray-100)}.bg-gray-200{background-color:var(--color-gray-200)}.bg-green-100{background-color:var(--color-green-100)}.bg-green-500{background-color:var(--color-green-500)}.bg-input{background-color:var(--input)}.bg-muted,.bg-muted\\/20{background-color:var(--muted)}@supports (color:color-mix(in lab,red,red)){.bg-muted\\/20{background-color:color-mix(in oklab,var(--muted)20%,transparent)}}.bg-muted\\/30{background-color:var(--muted)}@supports (color:color-mix(in lab,red,red)){.bg-muted\\/30{background-color:color-mix(in oklab,var(--muted)30%,transparent)}}.bg-muted\\/50{background-color:var(--muted)}@supports (color:color-mix(in lab,red,red)){.bg-muted\\/50{background-color:color-mix(in oklab,var(--muted)50%,transparent)}}.bg-popover{background-color:var(--popover)}.bg-primary,.bg-primary\\/10{background-color:var(--primary)}@supports (color:color-mix(in lab,red,red)){.bg-primary\\/10{background-color:color-mix(in oklab,var(--primary)10%,transparent)}}.bg-primary\\/20{background-color:var(--primary)}@supports (color:color-mix(in lab,red,red)){.bg-primary\\/20{background-color:color-mix(in oklab,var(--primary)20%,transparent)}}.bg-red-100{background-color:var(--color-red-100)}.bg-red-500{background-color:var(--color-red-500)}.bg-secondary{background-color:var(--secondary)}.bg-sidebar{background-color:var(--sidebar)}.bg-sidebar-border{background-color:var(--sidebar-border)}.bg-slate-900{background-color:var(--color-slate-900)}.bg-transparent{background-color:#0000}.bg-white{background-color:var(--color-white)}.bg-yellow-500{background-color:var(--color-yellow-500)}.bg-gradient-to-br{--tw-gradient-position:to bottom right in oklab;background-image:linear-gradient(var(--tw-gradient-stops))}.from-purple-800{--tw-gradient-from:var(--color-purple-800);--tw-gradient-stops:var(--tw-gradient-via-stops,var(--tw-gradient-position),var(--tw-gradient-from)var(--tw-gradient-from-position),var(--tw-gradient-to)var(--tw-gradient-to-position))}.to-blue-600{--tw-gradient-to:var(--color-blue-600);--tw-gradient-stops:var(--tw-gradient-via-stops,var(--tw-gradient-position),var(--tw-gradient-from)var(--tw-gradient-from-position),var(--tw-gradient-to)var(--tw-gradient-to-position))}.fill-current{fill:currentColor}.fill-foreground{fill:var(--foreground)}.fill-primary{fill:var(--primary)}.p-0{padding:calc(var(--spacing)*0)}.p-0\\.5{padding:calc(var(--spacing)*.5)}.p-1{padding:calc(var(--spacing)*1)}.p-2{padding:calc(var(--spacing)*2)}.p-3{padding:calc(var(--spacing)*3)}.p-4{padding:calc(var(--spacing)*4)}.p-6{padding:calc(var(--spacing)*6)}.p-12{padding:calc(var(--spacing)*12)}.p-\\[3px\\]{padding:3px}.p-px{padding:1px}.px-1{padding-inline:calc(var(--spacing)*1)}.px-1\\.5{padding-inline:calc(var(--spacing)*1.5)}.px-2{padding-inline:calc(var(--spacing)*2)}.px-2\\.5{padding-inline:calc(var(--spacing)*2.5)}.px-3{padding-inline:calc(var(--spacing)*3)}.px-4{padding-inline:calc(var(--spacing)*4)}.px-6{padding-inline:calc(var(--spacing)*6)}.px-8{padding-inline:calc(var(--spacing)*8)}.px-16{padding-inline:calc(var(--spacing)*16)}.py-0\\.5{padding-block:calc(var(--spacing)*.5)}.py-1{padding-block:calc(var(--spacing)*1)}.py-1\\.5{padding-block:calc(var(--spacing)*1.5)}.py-2{padding-block:calc(var(--spacing)*2)}.py-3{padding-block:calc(var(--spacing)*3)}.py-4{padding-block:calc(var(--spacing)*4)}.py-6{padding-block:calc(var(--spacing)*6)}.py-10{padding-block:calc(var(--spacing)*10)}.pt-0{padding-top:calc(var(--spacing)*0)}.pt-1{padding-top:calc(var(--spacing)*1)}.pt-3{padding-top:calc(var(--spacing)*3)}.pt-4{padding-top:calc(var(--spacing)*4)}.pr-2{padding-right:calc(var(--spacing)*2)}.pr-2\\.5{padding-right:calc(var(--spacing)*2.5)}.pr-3{padding-right:calc(var(--spacing)*3)}.pr-6{padding-right:calc(var(--spacing)*6)}.pr-8{padding-right:calc(var(--spacing)*8)}.pr-9{padding-right:calc(var(--spacing)*9)}.pb-2{padding-bottom:calc(var(--spacing)*2)}.pb-3{padding-bottom:calc(var(--spacing)*3)}.pb-4{padding-bottom:calc(var(--spacing)*4)}.pb-6{padding-bottom:calc(var(--spacing)*6)}.pl-2{padding-left:calc(var(--spacing)*2)}.pl-3{padding-left:calc(var(--spacing)*3)}.pl-4{padding-left:calc(var(--spacing)*4)}.pl-5{padding-left:calc(var(--spacing)*5)}.pl-8{padding-left:calc(var(--spacing)*8)}.text-center{text-align:center}.text-left{text-align:left}.align-middle{vertical-align:middle}.font-mono{font-family:var(--font-mono)}.font-sans{font-family:var(--font-sans)}.text-2xl{font-size:var(--text-2xl);line-height:var(--tw-leading,var(--text-2xl--line-height))}.text-3xl{font-size:var(--text-3xl);line-height:var(--tw-leading,var(--text-3xl--line-height))}.text-4xl{font-size:var(--text-4xl);line-height:var(--tw-leading,var(--text-4xl--line-height))}.text-base{font-size:var(--text-base);line-height:var(--tw-leading,var(--text-base--line-height))}.text-lg{font-size:var(--text-lg);line-height:var(--tw-leading,var(--text-lg--line-height))}.text-sm{font-size:var(--text-sm);line-height:var(--tw-leading,var(--text-sm--line-height))}.text-sm\\/relaxed{font-size:var(--text-sm);line-height:var(--leading-relaxed)}.text-xs{font-size:var(--text-xs);line-height:var(--tw-leading,var(--text-xs--line-height))}.text-\\[0\\.8rem\\]{font-size:.8rem}.text-\\[10px\\]{font-size:10px}.text-\\[11px\\]{font-size:11px}.leading-none{--tw-leading:1;line-height:1}.leading-normal{--tw-leading:var(--leading-normal);line-height:var(--leading-normal)}.leading-snug{--tw-leading:var(--leading-snug);line-height:var(--leading-snug)}.leading-tight{--tw-leading:var(--leading-tight);line-height:var(--leading-tight)}.font-bold{--tw-font-weight:var(--font-weight-bold);font-weight:var(--font-weight-bold)}.font-extrabold{--tw-font-weight:var(--font-weight-extrabold);font-weight:var(--font-weight-extrabold)}.font-medium{--tw-font-weight:var(--font-weight-medium);font-weight:var(--font-weight-medium)}.font-normal{--tw-font-weight:var(--font-weight-normal);font-weight:var(--font-weight-normal)}.font-semibold{--tw-font-weight:var(--font-weight-semibold);font-weight:var(--font-weight-semibold)}.tracking-\\[0\\.3em\\]{--tw-tracking:.3em;letter-spacing:.3em}.tracking-tight{--tw-tracking:var(--tracking-tight);letter-spacing:var(--tracking-tight)}.tracking-widest{--tw-tracking:var(--tracking-widest);letter-spacing:var(--tracking-widest)}.text-balance{text-wrap:balance}.break-words{overflow-wrap:break-word}.break-all{word-break:break-all}.whitespace-nowrap{white-space:nowrap}.whitespace-pre-wrap{white-space:pre-wrap}.text-amber-500{color:var(--color-amber-500)}.text-amber-600{color:var(--color-amber-600)}.text-background{color:var(--background)}.text-blue-400{color:var(--color-blue-400)}.text-card-foreground{color:var(--card-foreground)}.text-current{color:currentColor}.text-destructive{color:var(--destructive)}.text-emerald-500{color:var(--color-emerald-500)}.text-foreground,.text-foreground\\/90{color:var(--foreground)}@supports (color:color-mix(in lab,red,red)){.text-foreground\\/90{color:color-mix(in oklab,var(--foreground)90%,transparent)}}.text-gray-400{color:var(--color-gray-400)}.text-gray-500{color:var(--color-gray-500)}.text-gray-700{color:var(--color-gray-700)}.text-green-400{color:var(--color-green-400)}.text-green-600{color:var(--color-green-600)}.text-muted-foreground,.text-muted-foreground\\/50{color:var(--muted-foreground)}@supports (color:color-mix(in lab,red,red)){.text-muted-foreground\\/50{color:color-mix(in oklab,var(--muted-foreground)50%,transparent)}}.text-neutral-400{color:var(--color-neutral-400)}.text-popover-foreground{color:var(--popover-foreground)}.text-primary{color:var(--primary)}.text-primary-foreground{color:var(--primary-foreground)}.text-red-500{color:var(--color-red-500)}.text-red-600{color:var(--color-red-600)}.text-secondary-foreground{color:var(--secondary-foreground)}.text-sidebar-foreground,.text-sidebar-foreground\\/70{color:var(--sidebar-foreground)}@supports (color:color-mix(in lab,red,red)){.text-sidebar-foreground\\/70{color:color-mix(in oklab,var(--sidebar-foreground)70%,transparent)}}.text-sidebar-primary-foreground{color:var(--sidebar-primary-foreground)}.text-sky-500{color:var(--color-sky-500)}.text-sky-500\\/90{color:#00a5efe6}@supports (color:color-mix(in lab,red,red)){.text-sky-500\\/90{color:color-mix(in oklab,var(--color-sky-500)90%,transparent)}}.text-slate-400{color:var(--color-slate-400)}.text-transparent{color:#0000}.text-white{color:var(--color-white)}.uppercase{text-transform:uppercase}.tabular-nums{--tw-numeric-spacing:tabular-nums;font-variant-numeric:var(--tw-ordinal,)var(--tw-slashed-zero,)var(--tw-numeric-figure,)var(--tw-numeric-spacing,)var(--tw-numeric-fraction,)}.underline{text-decoration-line:underline}.underline-offset-4{text-underline-offset:4px}.accent-green-200{accent-color:var(--color-green-200)}.opacity-0{opacity:0}.opacity-50{opacity:.5}.opacity-60{opacity:.6}.opacity-70{opacity:.7}.opacity-80{opacity:.8}.shadow{--tw-shadow:0 1px 3px 0 var(--tw-shadow-color,#0000001a),0 1px 2px -1px var(--tw-shadow-color,#0000001a);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.shadow-\\[0_0_0_1px_hsl\\(var\\(--sidebar-border\\)\\)\\]{--tw-shadow:0 0 0 1px var(--tw-shadow-color,hsl(var(--sidebar-border)));box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.shadow-lg{--tw-shadow:0 10px 15px -3px var(--tw-shadow-color,#0000001a),0 4px 6px -4px var(--tw-shadow-color,#0000001a);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.shadow-md{--tw-shadow:0 4px 6px -1px var(--tw-shadow-color,#0000001a),0 2px 4px -2px var(--tw-shadow-color,#0000001a);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.shadow-none{--tw-shadow:0 0 #0000;box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.shadow-sm{--tw-shadow:0 1px 3px 0 var(--tw-shadow-color,#0000001a),0 1px 2px -1px var(--tw-shadow-color,#0000001a);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.shadow-xl{--tw-shadow:0 20px 25px -5px var(--tw-shadow-color,#0000001a),0 8px 10px -6px var(--tw-shadow-color,#0000001a);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.shadow-xs{--tw-shadow:0 1px 2px 0 var(--tw-shadow-color,#0000000d);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.ring-0{--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(0px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.ring-2{--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(2px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.ring-emerald-400\\/40{--tw-ring-color:#00d29466}@supports (color:color-mix(in lab,red,red)){.ring-emerald-400\\/40{--tw-ring-color:color-mix(in oklab,var(--color-emerald-400)40%,transparent)}}.ring-ring\\/10{--tw-ring-color:var(--ring)}@supports (color:color-mix(in lab,red,red)){.ring-ring\\/10{--tw-ring-color:color-mix(in oklab,var(--ring)10%,transparent)}}.ring-ring\\/50{--tw-ring-color:var(--ring)}@supports (color:color-mix(in lab,red,red)){.ring-ring\\/50{--tw-ring-color:color-mix(in oklab,var(--ring)50%,transparent)}}.ring-sidebar-ring{--tw-ring-color:var(--sidebar-ring)}.ring-offset-2{--tw-ring-offset-width:2px;--tw-ring-offset-shadow:var(--tw-ring-inset,)0 0 0 var(--tw-ring-offset-width)var(--tw-ring-offset-color)}.ring-offset-background{--tw-ring-offset-color:var(--background)}.outline-hidden{--tw-outline-style:none;outline-style:none}@media (forced-colors:active){.outline-hidden{outline-offset:2px;outline:2px solid #0000}}.outline{outline-style:var(--tw-outline-style);outline-width:1px}.outline-ring\\/50{outline-color:var(--ring)}@supports (color:color-mix(in lab,red,red)){.outline-ring\\/50{outline-color:color-mix(in oklab,var(--ring)50%,transparent)}}.blur-\\[2px\\]{--tw-blur:blur(2px);filter:var(--tw-blur,)var(--tw-brightness,)var(--tw-contrast,)var(--tw-grayscale,)var(--tw-hue-rotate,)var(--tw-invert,)var(--tw-saturate,)var(--tw-sepia,)var(--tw-drop-shadow,)}.filter{filter:var(--tw-blur,)var(--tw-brightness,)var(--tw-contrast,)var(--tw-grayscale,)var(--tw-hue-rotate,)var(--tw-invert,)var(--tw-saturate,)var(--tw-sepia,)var(--tw-drop-shadow,)}.backdrop-blur{--tw-backdrop-blur:blur(8px);-webkit-backdrop-filter:var(--tw-backdrop-blur,)var(--tw-backdrop-brightness,)var(--tw-backdrop-contrast,)var(--tw-backdrop-grayscale,)var(--tw-backdrop-hue-rotate,)var(--tw-backdrop-invert,)var(--tw-backdrop-opacity,)var(--tw-backdrop-saturate,)var(--tw-backdrop-sepia,);backdrop-filter:var(--tw-backdrop-blur,)var(--tw-backdrop-brightness,)var(--tw-backdrop-contrast,)var(--tw-backdrop-grayscale,)var(--tw-backdrop-hue-rotate,)var(--tw-backdrop-invert,)var(--tw-backdrop-opacity,)var(--tw-backdrop-saturate,)var(--tw-backdrop-sepia,)}.backdrop-blur-xs{--tw-backdrop-blur:blur(var(--blur-xs));-webkit-backdrop-filter:var(--tw-backdrop-blur,)var(--tw-backdrop-brightness,)var(--tw-backdrop-contrast,)var(--tw-backdrop-grayscale,)var(--tw-backdrop-hue-rotate,)var(--tw-backdrop-invert,)var(--tw-backdrop-opacity,)var(--tw-backdrop-saturate,)var(--tw-backdrop-sepia,);backdrop-filter:var(--tw-backdrop-blur,)var(--tw-backdrop-brightness,)var(--tw-backdrop-contrast,)var(--tw-backdrop-grayscale,)var(--tw-backdrop-hue-rotate,)var(--tw-backdrop-invert,)var(--tw-backdrop-opacity,)var(--tw-backdrop-saturate,)var(--tw-backdrop-sepia,)}.transition{transition-property:color,background-color,border-color,outline-color,text-decoration-color,fill,stroke,--tw-gradient-from,--tw-gradient-via,--tw-gradient-to,opacity,box-shadow,transform,translate,scale,rotate,filter,-webkit-backdrop-filter,backdrop-filter,display,visibility,content-visibility,overlay,pointer-events;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.transition-\\[color\\,box-shadow\\,background-color\\,border-color\\]{transition-property:color,box-shadow,background-color,border-color;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.transition-\\[color\\,box-shadow\\]{transition-property:color,box-shadow;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.transition-\\[left\\,right\\,width\\]{transition-property:left,right,width;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.transition-\\[margin\\,opacity\\]{transition-property:margin,opacity;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.transition-\\[width\\,height\\,padding\\]{transition-property:width,height,padding;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.transition-\\[width\\,height\\]{transition-property:width,height;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.transition-\\[width\\]{transition-property:width;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.transition-all{transition-property:all;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.transition-colors{transition-property:color,background-color,border-color,outline-color,text-decoration-color,fill,stroke,--tw-gradient-from,--tw-gradient-via,--tw-gradient-to;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.transition-opacity{transition-property:opacity;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.transition-shadow{transition-property:box-shadow;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.transition-transform{transition-property:transform,translate,scale,rotate;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.transition-none{transition-property:none}.duration-100{--tw-duration:.1s;transition-duration:.1s}.duration-200{--tw-duration:.2s;transition-duration:.2s}.duration-300{--tw-duration:.3s;transition-duration:.3s}.duration-1000{--tw-duration:1s;transition-duration:1s}.ease-in-out{--tw-ease:var(--ease-in-out);transition-timing-function:var(--ease-in-out)}.ease-linear{--tw-ease:linear;transition-timing-function:linear}.fade-in-0{--tw-enter-opacity:0}.outline-none{--tw-outline-style:none;outline-style:none}.select-none{-webkit-user-select:none;-moz-user-select:none;user-select:none}.select-text{-webkit-user-select:text;-moz-user-select:text;user-select:text}.zoom-in-95{--tw-enter-scale:.95}.running{animation-play-state:running}.group-focus-within\\/menu-item\\:opacity-100:is(:where(.group\\/menu-item):focus-within *){opacity:1}@media (hover:hover){.group-hover\\:opacity-100:is(:where(.group):hover *),.group-hover\\/menu-item\\:opacity-100:is(:where(.group\\/menu-item):hover *){opacity:1}}.group-has-data-\\[sidebar\\=menu-action\\]\\/menu-item\\:pr-8:is(:where(.group\\/menu-item):has([data-sidebar=menu-action]) *){padding-right:calc(var(--spacing)*8)}.group-has-\\[\\[data-collapsible\\=icon\\]\\]\\/sidebar-wrapper\\:h-12:is(:where(.group\\/sidebar-wrapper):has([data-collapsible=icon]) *){height:calc(var(--spacing)*12)}.group-has-\\[\\[data-orientation\\=horizontal\\]\\]\\/field\\:text-balance:is(:where(.group\\/field):has([data-orientation=horizontal]) *){text-wrap:balance}.group-has-\\[\\[data-slot\\=item-description\\]\\]\\/item\\:translate-y-0\\.5:is(:where(.group\\/item):has([data-slot=item-description]) *){--tw-translate-y:calc(var(--spacing)*.5);translate:var(--tw-translate-x)var(--tw-translate-y)}.group-has-\\[\\[data-slot\\=item-description\\]\\]\\/item\\:self-start:is(:where(.group\\/item):has([data-slot=item-description]) *){align-self:flex-start}.group-has-\\[\\>input\\]\\/input-group\\:pt-2\\.5:is(:where(.group\\/input-group):has(>input) *){padding-top:calc(var(--spacing)*2.5)}.group-has-\\[\\>input\\]\\/input-group\\:pb-2\\.5:is(:where(.group\\/input-group):has(>input) *){padding-bottom:calc(var(--spacing)*2.5)}.group-data-\\[collapsible\\=icon\\]\\:-mt-8:is(:where(.group)[data-collapsible=icon] *){margin-top:calc(var(--spacing)*-8)}.group-data-\\[collapsible\\=icon\\]\\:hidden:is(:where(.group)[data-collapsible=icon] *){display:none}.group-data-\\[collapsible\\=icon\\]\\:size-8\\!:is(:where(.group)[data-collapsible=icon] *){width:calc(var(--spacing)*8)!important;height:calc(var(--spacing)*8)!important}.group-data-\\[collapsible\\=icon\\]\\:w-\\(--sidebar-width-icon\\):is(:where(.group)[data-collapsible=icon] *){width:var(--sidebar-width-icon)}.group-data-\\[collapsible\\=icon\\]\\:w-\\[calc\\(var\\(--sidebar-width-icon\\)\\+\\(--spacing\\(4\\)\\)\\)\\]:is(:where(.group)[data-collapsible=icon] *){width:calc(var(--sidebar-width-icon) + (calc(var(--spacing)*4)))}.group-data-\\[collapsible\\=icon\\]\\:w-\\[calc\\(var\\(--sidebar-width-icon\\)\\+\\(--spacing\\(4\\)\\)\\+2px\\)\\]:is(:where(.group)[data-collapsible=icon] *){width:calc(var(--sidebar-width-icon) + (calc(var(--spacing)*4)) + 2px)}.group-data-\\[collapsible\\=icon\\]\\:overflow-hidden:is(:where(.group)[data-collapsible=icon] *){overflow:hidden}.group-data-\\[collapsible\\=icon\\]\\:p-0\\!:is(:where(.group)[data-collapsible=icon] *){padding:calc(var(--spacing)*0)!important}.group-data-\\[collapsible\\=icon\\]\\:p-2\\!:is(:where(.group)[data-collapsible=icon] *){padding:calc(var(--spacing)*2)!important}.group-data-\\[collapsible\\=icon\\]\\:opacity-0:is(:where(.group)[data-collapsible=icon] *){opacity:0}.group-data-\\[collapsible\\=offcanvas\\]\\:right-\\[calc\\(var\\(--sidebar-width\\)\\*-1\\)\\]:is(:where(.group)[data-collapsible=offcanvas] *){right:calc(var(--sidebar-width)*-1)}.group-data-\\[collapsible\\=offcanvas\\]\\:left-\\[calc\\(var\\(--sidebar-width\\)\\*-1\\)\\]:is(:where(.group)[data-collapsible=offcanvas] *){left:calc(var(--sidebar-width)*-1)}.group-data-\\[collapsible\\=offcanvas\\]\\:w-0:is(:where(.group)[data-collapsible=offcanvas] *){width:calc(var(--spacing)*0)}.group-data-\\[collapsible\\=offcanvas\\]\\:translate-x-0:is(:where(.group)[data-collapsible=offcanvas] *){--tw-translate-x:calc(var(--spacing)*0);translate:var(--tw-translate-x)var(--tw-translate-y)}.group-data-\\[disabled\\]\\:bg-muted:is(:where(.group)[data-disabled] *){background-color:var(--muted)}.group-data-\\[disabled\\]\\:text-muted-foreground:is(:where(.group)[data-disabled] *){color:var(--muted-foreground)}.group-data-\\[disabled\\]\\:opacity-50:is(:where(.group)[data-disabled] *){opacity:.5}.group-data-\\[disabled\\=true\\]\\:pointer-events-none:is(:where(.group)[data-disabled=true] *){pointer-events:none}.group-data-\\[disabled\\=true\\]\\:opacity-50:is(:where(.group)[data-disabled=true] *),.group-data-\\[disabled\\=true\\]\\/field\\:opacity-50:is(:where(.group\\/field)[data-disabled=true] *),.group-data-\\[disabled\\=true\\]\\/input-group\\:opacity-50:is(:where(.group\\/input-group)[data-disabled=true] *){opacity:.5}.group-data-\\[side\\=left\\]\\:-right-4:is(:where(.group)[data-side=left] *){right:calc(var(--spacing)*-4)}.group-data-\\[side\\=left\\]\\:border-r:is(:where(.group)[data-side=left] *){border-right-style:var(--tw-border-style);border-right-width:1px}.group-data-\\[side\\=right\\]\\:left-0:is(:where(.group)[data-side=right] *){left:calc(var(--spacing)*0)}.group-data-\\[side\\=right\\]\\:rotate-180:is(:where(.group)[data-side=right] *){rotate:180deg}.group-data-\\[side\\=right\\]\\:border-l:is(:where(.group)[data-side=right] *){border-left-style:var(--tw-border-style);border-left-width:1px}.group-data-\\[state\\=active\\]\\:bg-primary:is(:where(.group)[data-state=active] *){background-color:var(--primary)}.group-data-\\[state\\=active\\]\\:text-primary-foreground:is(:where(.group)[data-state=active] *){color:var(--primary-foreground)}.group-data-\\[state\\=completed\\]\\:bg-accent:is(:where(.group)[data-state=completed] *){background-color:var(--accent)}.group-data-\\[state\\=completed\\]\\:text-accent-foreground:is(:where(.group)[data-state=completed] *){color:var(--accent-foreground)}.group-data-\\[state\\=open\\]\\:rotate-180:is(:where(.group)[data-state=open] *){rotate:180deg}.group-data-\\[state\\=open\\]\\/collapsible\\:rotate-90:is(:where(.group\\/collapsible)[data-state=open] *){rotate:90deg}.group-data-\\[variant\\=floating\\]\\:rounded-lg:is(:where(.group)[data-variant=floating] *){border-radius:var(--radius)}.group-data-\\[variant\\=floating\\]\\:border:is(:where(.group)[data-variant=floating] *){border-style:var(--tw-border-style);border-width:1px}.group-data-\\[variant\\=floating\\]\\:border-sidebar-border:is(:where(.group)[data-variant=floating] *){border-color:var(--sidebar-border)}.group-data-\\[variant\\=floating\\]\\:shadow-sm:is(:where(.group)[data-variant=floating] *){--tw-shadow:0 1px 3px 0 var(--tw-shadow-color,#0000001a),0 1px 2px -1px var(--tw-shadow-color,#0000001a);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.group-data-\\[variant\\=outline\\]\\/field-group\\:-mb-2:is(:where(.group\\/field-group)[data-variant=outline] *){margin-bottom:calc(var(--spacing)*-2)}.group-data-\\[vaul-drawer-direction\\=bottom\\]\\/drawer-content\\:block:is(:where(.group\\/drawer-content)[data-vaul-drawer-direction=bottom] *){display:block}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:top-full:is(:where(.group\\/navigation-menu)[data-viewport=false] *){top:100%}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:mt-1\\.5:is(:where(.group\\/navigation-menu)[data-viewport=false] *){margin-top:calc(var(--spacing)*1.5)}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:overflow-hidden:is(:where(.group\\/navigation-menu)[data-viewport=false] *){overflow:hidden}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:rounded-md:is(:where(.group\\/navigation-menu)[data-viewport=false] *){border-radius:calc(var(--radius) - 2px)}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:border:is(:where(.group\\/navigation-menu)[data-viewport=false] *){border-style:var(--tw-border-style);border-width:1px}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:bg-popover:is(:where(.group\\/navigation-menu)[data-viewport=false] *){background-color:var(--popover)}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:text-popover-foreground:is(:where(.group\\/navigation-menu)[data-viewport=false] *){color:var(--popover-foreground)}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:shadow:is(:where(.group\\/navigation-menu)[data-viewport=false] *){--tw-shadow:0 1px 3px 0 var(--tw-shadow-color,#0000001a),0 1px 2px -1px var(--tw-shadow-color,#0000001a);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:duration-200:is(:where(.group\\/navigation-menu)[data-viewport=false] *){--tw-duration:.2s;transition-duration:.2s}@media (hover:hover){.peer-hover\\/menu-button\\:text-sidebar-accent-foreground:is(:where(.peer\\/menu-button):hover~*){color:var(--sidebar-accent-foreground)}}.peer-disabled\\:cursor-not-allowed:is(:where(.peer):disabled~*){cursor:not-allowed}.peer-disabled\\:opacity-50:is(:where(.peer):disabled~*){opacity:.5}.peer-data-\\[active\\=true\\]\\/menu-button\\:text-sidebar-accent-foreground:is(:where(.peer\\/menu-button)[data-active=true]~*){color:var(--sidebar-accent-foreground)}.peer-data-\\[size\\=default\\]\\/menu-button\\:top-1\\.5:is(:where(.peer\\/menu-button)[data-size=default]~*){top:calc(var(--spacing)*1.5)}.peer-data-\\[size\\=lg\\]\\/menu-button\\:top-2\\.5:is(:where(.peer\\/menu-button)[data-size=lg]~*){top:calc(var(--spacing)*2.5)}.peer-data-\\[size\\=sm\\]\\/menu-button\\:top-1:is(:where(.peer\\/menu-button)[data-size=sm]~*){top:calc(var(--spacing)*1)}.selection\\:bg-primary ::-moz-selection{background-color:var(--primary)}.selection\\:bg-primary ::selection{background-color:var(--primary)}.selection\\:bg-primary::-moz-selection{background-color:var(--primary)}.selection\\:bg-primary::selection{background-color:var(--primary)}.selection\\:text-primary-foreground ::-moz-selection{color:var(--primary-foreground)}.selection\\:text-primary-foreground ::selection{color:var(--primary-foreground)}.selection\\:text-primary-foreground::-moz-selection{color:var(--primary-foreground)}.selection\\:text-primary-foreground::selection{color:var(--primary-foreground)}.file\\:inline-flex::file-selector-button{display:inline-flex}.file\\:h-7::file-selector-button{height:calc(var(--spacing)*7)}.file\\:border-0::file-selector-button{border-style:var(--tw-border-style);border-width:0}.file\\:bg-transparent::file-selector-button{background-color:#0000}.file\\:text-sm::file-selector-button{font-size:var(--text-sm);line-height:var(--tw-leading,var(--text-sm--line-height))}.file\\:font-medium::file-selector-button{--tw-font-weight:var(--font-weight-medium);font-weight:var(--font-weight-medium)}.file\\:text-foreground::file-selector-button{color:var(--foreground)}.placeholder\\:text-muted-foreground::-moz-placeholder{color:var(--muted-foreground)}.placeholder\\:text-muted-foreground::placeholder{color:var(--muted-foreground)}.after\\:absolute:after{content:var(--tw-content);position:absolute}.after\\:-inset-2:after{content:var(--tw-content);inset:calc(var(--spacing)*-2)}.after\\:inset-y-0:after{content:var(--tw-content);inset-block:calc(var(--spacing)*0)}.after\\:left-1\\/2:after{content:var(--tw-content);left:50%}.after\\:w-1:after{content:var(--tw-content);width:calc(var(--spacing)*1)}.after\\:w-\\[2px\\]:after{content:var(--tw-content);width:2px}.after\\:-translate-x-1\\/2:after{content:var(--tw-content);--tw-translate-x: -50% ;translate:var(--tw-translate-x)var(--tw-translate-y)}.group-data-\\[collapsible\\=offcanvas\\]\\:after\\:left-full:is(:where(.group)[data-collapsible=offcanvas] *):after{content:var(--tw-content);left:100%}.first\\:rounded-l-md:first-child{border-top-left-radius:calc(var(--radius) - 2px);border-bottom-left-radius:calc(var(--radius) - 2px)}.first\\:border-l:first-child{border-left-style:var(--tw-border-style);border-left-width:1px}.last\\:mt-0:last-child{margin-top:calc(var(--spacing)*0)}.last\\:rounded-r-md:last-child{border-top-right-radius:calc(var(--radius) - 2px);border-bottom-right-radius:calc(var(--radius) - 2px)}.last\\:border-b-0:last-child{border-bottom-style:var(--tw-border-style);border-bottom-width:0}.focus-within\\:relative:focus-within{position:relative}.focus-within\\:z-20:focus-within{z-index:20}.focus-within\\:border-ring:focus-within{border-color:var(--ring)}.focus-within\\:ring-\\[3px\\]:focus-within{--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(3px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.focus-within\\:ring-ring\\/50:focus-within{--tw-ring-color:var(--ring)}@supports (color:color-mix(in lab,red,red)){.focus-within\\:ring-ring\\/50:focus-within{--tw-ring-color:color-mix(in oklab,var(--ring)50%,transparent)}}@media (hover:hover){.hover\\:bg-accent:hover{background-color:var(--accent)}.hover\\:bg-destructive\\/90:hover{background-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.hover\\:bg-destructive\\/90:hover{background-color:color-mix(in oklab,var(--destructive)90%,transparent)}}.hover\\:bg-muted:hover,.hover\\:bg-muted\\/50:hover{background-color:var(--muted)}@supports (color:color-mix(in lab,red,red)){.hover\\:bg-muted\\/50:hover{background-color:color-mix(in oklab,var(--muted)50%,transparent)}}.hover\\:bg-muted\\/60:hover{background-color:var(--muted)}@supports (color:color-mix(in lab,red,red)){.hover\\:bg-muted\\/60:hover{background-color:color-mix(in oklab,var(--muted)60%,transparent)}}.hover\\:bg-primary\\/90:hover{background-color:var(--primary)}@supports (color:color-mix(in lab,red,red)){.hover\\:bg-primary\\/90:hover{background-color:color-mix(in oklab,var(--primary)90%,transparent)}}.hover\\:bg-secondary:hover,.hover\\:bg-secondary\\/80:hover{background-color:var(--secondary)}@supports (color:color-mix(in lab,red,red)){.hover\\:bg-secondary\\/80:hover{background-color:color-mix(in oklab,var(--secondary)80%,transparent)}}.hover\\:bg-sidebar-accent:hover{background-color:var(--sidebar-accent)}.hover\\:text-accent-foreground:hover{color:var(--accent-foreground)}.hover\\:text-blue-400:hover{color:var(--color-blue-400)}.hover\\:text-foreground:hover{color:var(--foreground)}.hover\\:text-muted-foreground:hover{color:var(--muted-foreground)}.hover\\:text-sidebar-accent-foreground:hover{color:var(--sidebar-accent-foreground)}.hover\\:underline:hover{text-decoration-line:underline}.hover\\:opacity-100:hover{opacity:1}.hover\\:shadow-\\[0_0_0_1px_hsl\\(var\\(--sidebar-accent\\)\\)\\]:hover{--tw-shadow:0 0 0 1px var(--tw-shadow-color,hsl(var(--sidebar-accent)));box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.hover\\:shadow-lg:hover{--tw-shadow:0 10px 15px -3px var(--tw-shadow-color,#0000001a),0 4px 6px -4px var(--tw-shadow-color,#0000001a);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.hover\\:ring-4:hover{--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(4px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.hover\\:group-data-\\[collapsible\\=offcanvas\\]\\:bg-sidebar:hover:is(:where(.group)[data-collapsible=offcanvas] *){background-color:var(--sidebar)}.hover\\:after\\:bg-sidebar-border:hover:after{content:var(--tw-content);background-color:var(--sidebar-border)}}.focus\\:z-10:focus{z-index:10}.focus\\:border-ring:focus{border-color:var(--ring)}.focus\\:bg-accent:focus{background-color:var(--accent)}.focus\\:text-accent-foreground:focus{color:var(--accent-foreground)}.focus\\:ring-2:focus{--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(2px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.focus\\:ring-\\[3px\\]:focus{--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(3px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.focus\\:ring-ring:focus,.focus\\:ring-ring\\/50:focus{--tw-ring-color:var(--ring)}@supports (color:color-mix(in lab,red,red)){.focus\\:ring-ring\\/50:focus{--tw-ring-color:color-mix(in oklab,var(--ring)50%,transparent)}}.focus\\:ring-offset-2:focus{--tw-ring-offset-width:2px;--tw-ring-offset-shadow:var(--tw-ring-inset,)0 0 0 var(--tw-ring-offset-width)var(--tw-ring-offset-color)}.focus\\:outline-hidden:focus{--tw-outline-style:none;outline-style:none}@media (forced-colors:active){.focus\\:outline-hidden:focus{outline-offset:2px;outline:2px solid #0000}}.focus\\:outline-none:focus{--tw-outline-style:none;outline-style:none}.focus-visible\\:z-10:focus-visible{z-index:10}.focus-visible\\:border-ring:focus-visible{border-color:var(--ring)}.focus-visible\\:ring-0:focus-visible{--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(0px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.focus-visible\\:ring-1:focus-visible{--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(1px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.focus-visible\\:ring-2:focus-visible{--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(2px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.focus-visible\\:ring-4:focus-visible{--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(4px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.focus-visible\\:ring-\\[3px\\]:focus-visible{--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(3px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.focus-visible\\:ring-destructive\\/20:focus-visible{--tw-ring-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.focus-visible\\:ring-destructive\\/20:focus-visible{--tw-ring-color:color-mix(in oklab,var(--destructive)20%,transparent)}}.focus-visible\\:ring-ring:focus-visible,.focus-visible\\:ring-ring\\/50:focus-visible{--tw-ring-color:var(--ring)}@supports (color:color-mix(in lab,red,red)){.focus-visible\\:ring-ring\\/50:focus-visible{--tw-ring-color:color-mix(in oklab,var(--ring)50%,transparent)}}.focus-visible\\:ring-offset-1:focus-visible{--tw-ring-offset-width:1px;--tw-ring-offset-shadow:var(--tw-ring-inset,)0 0 0 var(--tw-ring-offset-width)var(--tw-ring-offset-color)}.focus-visible\\:outline-hidden:focus-visible{--tw-outline-style:none;outline-style:none}@media (forced-colors:active){.focus-visible\\:outline-hidden:focus-visible{outline-offset:2px;outline:2px solid #0000}}.focus-visible\\:outline-1:focus-visible{outline-style:var(--tw-outline-style);outline-width:1px}.focus-visible\\:outline-ring:focus-visible{outline-color:var(--ring)}.focus-visible\\:outline-none:focus-visible{--tw-outline-style:none;outline-style:none}.active\\:bg-sidebar-accent:active{background-color:var(--sidebar-accent)}.active\\:text-sidebar-accent-foreground:active{color:var(--sidebar-accent-foreground)}.disabled\\:pointer-events-none:disabled{pointer-events:none}.disabled\\:cursor-not-allowed:disabled{cursor:not-allowed}.disabled\\:opacity-20:disabled{opacity:.2}.disabled\\:opacity-50:disabled{opacity:.5}:where([data-side=left]) .in-data-\\[side\\=left\\]\\:cursor-w-resize{cursor:w-resize}:where([data-side=right]) .in-data-\\[side\\=right\\]\\:cursor-e-resize{cursor:e-resize}.has-disabled\\:opacity-50:has(:disabled){opacity:.5}.has-data-\\[slot\\=card-action\\]\\:grid-cols-\\[1fr_auto\\]:has([data-slot=card-action]){grid-template-columns:1fr auto}.has-data-\\[state\\=checked\\]\\:border-primary:has([data-state=checked]){border-color:var(--primary)}.has-data-\\[state\\=checked\\]\\:bg-primary\\/5:has([data-state=checked]){background-color:var(--primary)}@supports (color:color-mix(in lab,red,red)){.has-data-\\[state\\=checked\\]\\:bg-primary\\/5:has([data-state=checked]){background-color:color-mix(in oklab,var(--primary)5%,transparent)}}.has-data-\\[variant\\=inset\\]\\:bg-sidebar:has([data-variant=inset]){background-color:var(--sidebar)}.has-\\[\\[data-slot\\=input-group-control\\]\\:focus-visible\\]\\:border-ring:has([data-slot=input-group-control]:focus-visible){border-color:var(--ring)}.has-\\[\\[data-slot\\=input-group-control\\]\\:focus-visible\\]\\:ring-\\[3px\\]:has([data-slot=input-group-control]:focus-visible){--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(3px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.has-\\[\\[data-slot\\=input-group-control\\]\\:focus-visible\\]\\:ring-ring\\/50:has([data-slot=input-group-control]:focus-visible){--tw-ring-color:var(--ring)}@supports (color:color-mix(in lab,red,red)){.has-\\[\\[data-slot\\=input-group-control\\]\\:focus-visible\\]\\:ring-ring\\/50:has([data-slot=input-group-control]:focus-visible){--tw-ring-color:color-mix(in oklab,var(--ring)50%,transparent)}}.has-\\[\\[data-slot\\]\\[aria-invalid\\=true\\]\\]\\:border-destructive:has([data-slot][aria-invalid=true]){border-color:var(--destructive)}.has-\\[\\[data-slot\\]\\[aria-invalid\\=true\\]\\]\\:ring-destructive\\/20:has([data-slot][aria-invalid=true]){--tw-ring-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.has-\\[\\[data-slot\\]\\[aria-invalid\\=true\\]\\]\\:ring-destructive\\/20:has([data-slot][aria-invalid=true]){--tw-ring-color:color-mix(in oklab,var(--destructive)20%,transparent)}}.has-\\[select\\:disabled\\]\\:opacity-50:has(:is(select:disabled)){opacity:.5}.has-\\[\\>\\[data-align\\=block-end\\]\\]\\:h-auto:has(>[data-align=block-end]){height:auto}.has-\\[\\>\\[data-align\\=block-end\\]\\]\\:flex-col:has(>[data-align=block-end]){flex-direction:column}.has-\\[\\>\\[data-align\\=block-start\\]\\]\\:h-auto:has(>[data-align=block-start]){height:auto}.has-\\[\\>\\[data-align\\=block-start\\]\\]\\:flex-col:has(>[data-align=block-start]){flex-direction:column}.has-\\[\\>\\[data-slot\\=button-group\\]\\]\\:gap-2:has(>[data-slot=button-group]){gap:calc(var(--spacing)*2)}.has-\\[\\>\\[data-slot\\=checkbox-group\\]\\]\\:gap-3:has(>[data-slot=checkbox-group]){gap:calc(var(--spacing)*3)}.has-\\[\\>\\[data-slot\\=field-content\\]\\]\\:items-start:has(>[data-slot=field-content]){align-items:flex-start}.has-\\[\\>\\[data-slot\\=field\\]\\]\\:w-full:has(>[data-slot=field]){width:100%}.has-\\[\\>\\[data-slot\\=field\\]\\]\\:flex-col:has(>[data-slot=field]){flex-direction:column}.has-\\[\\>\\[data-slot\\=field\\]\\]\\:rounded-md:has(>[data-slot=field]){border-radius:calc(var(--radius) - 2px)}.has-\\[\\>\\[data-slot\\=field\\]\\]\\:border:has(>[data-slot=field]){border-style:var(--tw-border-style);border-width:1px}.has-\\[\\>\\[data-slot\\=radio-group\\]\\]\\:gap-3:has(>[data-slot=radio-group]){gap:calc(var(--spacing)*3)}.has-\\[\\>button\\]\\:mr-\\[-0\\.45rem\\]:has(>button){margin-right:-.45rem}.has-\\[\\>button\\]\\:ml-\\[-0\\.45rem\\]:has(>button){margin-left:-.45rem}.has-\\[\\>kbd\\]\\:mr-\\[-0\\.35rem\\]:has(>kbd){margin-right:-.35rem}.has-\\[\\>kbd\\]\\:ml-\\[-0\\.35rem\\]:has(>kbd){margin-left:-.35rem}.has-\\[\\>svg\\]\\:grid-cols-\\[calc\\(var\\(--spacing\\)\\*4\\)_1fr\\]:has(>svg){grid-template-columns:calc(var(--spacing)*4)1fr}.has-\\[\\>svg\\]\\:gap-x-3:has(>svg){-moz-column-gap:calc(var(--spacing)*3);column-gap:calc(var(--spacing)*3)}.has-\\[\\>svg\\]\\:p-0:has(>svg){padding:calc(var(--spacing)*0)}.has-\\[\\>svg\\]\\:px-2:has(>svg){padding-inline:calc(var(--spacing)*2)}.has-\\[\\>svg\\]\\:px-2\\.5:has(>svg){padding-inline:calc(var(--spacing)*2.5)}.has-\\[\\>svg\\]\\:px-3:has(>svg){padding-inline:calc(var(--spacing)*3)}.has-\\[\\>svg\\]\\:px-4:has(>svg){padding-inline:calc(var(--spacing)*4)}.has-\\[\\>textarea\\]\\:h-auto:has(>textarea){height:auto}.aria-disabled\\:pointer-events-none[aria-disabled=true]{pointer-events:none}.aria-disabled\\:opacity-50[aria-disabled=true]{opacity:.5}.aria-invalid\\:border-destructive[aria-invalid=true]{border-color:var(--destructive)}.aria-invalid\\:ring-destructive\\/20[aria-invalid=true]{--tw-ring-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.aria-invalid\\:ring-destructive\\/20[aria-invalid=true]{--tw-ring-color:color-mix(in oklab,var(--destructive)20%,transparent)}}.focus\\:aria-invalid\\:border-destructive:focus[aria-invalid=true]{border-color:var(--destructive)}.focus\\:aria-invalid\\:ring-destructive\\/20:focus[aria-invalid=true]{--tw-ring-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.focus\\:aria-invalid\\:ring-destructive\\/20:focus[aria-invalid=true]{--tw-ring-color:color-mix(in oklab,var(--destructive)20%,transparent)}}.aria-selected\\:opacity-100[aria-selected=true]{opacity:1}.data-active\\:bg-accent\\/50[data-active]{background-color:var(--accent)}@supports (color:color-mix(in lab,red,red)){.data-active\\:bg-accent\\/50[data-active]{background-color:color-mix(in oklab,var(--accent)50%,transparent)}}.data-active\\:text-accent-foreground[data-active]{color:var(--accent-foreground)}@media (hover:hover){.data-active\\:hover\\:bg-accent[data-active]:hover{background-color:var(--accent)}}.data-active\\:focus\\:bg-accent[data-active]:focus{background-color:var(--accent)}.data-\\[active\\=true\\]\\:z-10[data-active=true]{z-index:10}.data-\\[active\\=true\\]\\:border-ring[data-active=true]{border-color:var(--ring)}.data-\\[active\\=true\\]\\:bg-sidebar-accent[data-active=true]{background-color:var(--sidebar-accent)}.data-\\[active\\=true\\]\\:font-medium[data-active=true]{--tw-font-weight:var(--font-weight-medium);font-weight:var(--font-weight-medium)}.data-\\[active\\=true\\]\\:text-sidebar-accent-foreground[data-active=true]{color:var(--sidebar-accent-foreground)}.data-\\[active\\=true\\]\\:ring-\\[3px\\][data-active=true]{--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(3px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.data-\\[active\\=true\\]\\:ring-ring\\/50[data-active=true]{--tw-ring-color:var(--ring)}@supports (color:color-mix(in lab,red,red)){.data-\\[active\\=true\\]\\:ring-ring\\/50[data-active=true]{--tw-ring-color:color-mix(in oklab,var(--ring)50%,transparent)}}.data-\\[active\\=true\\]\\:aria-invalid\\:border-destructive[data-active=true][aria-invalid=true]{border-color:var(--destructive)}.data-\\[active\\=true\\]\\:aria-invalid\\:ring-destructive\\/20[data-active=true][aria-invalid=true]{--tw-ring-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.data-\\[active\\=true\\]\\:aria-invalid\\:ring-destructive\\/20[data-active=true][aria-invalid=true]{--tw-ring-color:color-mix(in oklab,var(--destructive)20%,transparent)}}.data-\\[disabled\\]\\:pointer-events-none[data-disabled]{pointer-events:none}.data-\\[disabled\\]\\:text-muted-foreground[data-disabled]{color:var(--muted-foreground)}.data-\\[disabled\\]\\:opacity-50[data-disabled]{opacity:.5}.data-\\[error\\=true\\]\\:text-destructive[data-error=true]{color:var(--destructive)}.data-\\[highlighted\\]\\:bg-accent[data-highlighted]{background-color:var(--accent)}.data-\\[highlighted\\]\\:text-accent-foreground[data-highlighted]{color:var(--accent-foreground)}.data-\\[inset\\]\\:pl-8[data-inset]{padding-left:calc(var(--spacing)*8)}.data-\\[invalid\\=true\\]\\:text-destructive[data-invalid=true]{color:var(--destructive)}.data-\\[motion\\=from-end\\]\\:slide-in-from-right-52[data-motion=from-end]{--tw-enter-translate-x:calc(52*var(--spacing))}.data-\\[motion\\=from-start\\]\\:slide-in-from-left-52[data-motion=from-start]{--tw-enter-translate-x:calc(52*var(--spacing)*-1)}.data-\\[motion\\=to-end\\]\\:slide-out-to-right-52[data-motion=to-end]{--tw-exit-translate-x:calc(52*var(--spacing))}.data-\\[motion\\=to-start\\]\\:slide-out-to-left-52[data-motion=to-start]{--tw-exit-translate-x:calc(52*var(--spacing)*-1)}.data-\\[motion\\^\\=from-\\]\\:animate-in[data-motion^=from-]{animation:enter var(--tw-animation-duration,var(--tw-duration,.15s))var(--tw-ease,ease)var(--tw-animation-delay,0s)var(--tw-animation-iteration-count,1)var(--tw-animation-direction,normal)var(--tw-animation-fill-mode,none)}.data-\\[motion\\^\\=from-\\]\\:fade-in[data-motion^=from-]{--tw-enter-opacity:0}.data-\\[motion\\^\\=to-\\]\\:animate-out[data-motion^=to-]{animation:exit var(--tw-animation-duration,var(--tw-duration,.15s))var(--tw-ease,ease)var(--tw-animation-delay,0s)var(--tw-animation-iteration-count,1)var(--tw-animation-direction,normal)var(--tw-animation-fill-mode,none)}.data-\\[motion\\^\\=to-\\]\\:fade-out[data-motion^=to-]{--tw-exit-opacity:0}.data-\\[orientation\\=horizontal\\]\\:h-1\\.5[data-orientation=horizontal]{height:calc(var(--spacing)*1.5)}.data-\\[orientation\\=horizontal\\]\\:h-full[data-orientation=horizontal]{height:100%}.data-\\[orientation\\=horizontal\\]\\:h-px[data-orientation=horizontal]{height:1px}.data-\\[orientation\\=horizontal\\]\\:w-full[data-orientation=horizontal]{width:100%}.data-\\[orientation\\=vertical\\]\\:h-auto[data-orientation=vertical]{height:auto}.data-\\[orientation\\=vertical\\]\\:h-full[data-orientation=vertical]{height:100%}.data-\\[orientation\\=vertical\\]\\:h-px[data-orientation=vertical]{height:1px}.data-\\[orientation\\=vertical\\]\\:min-h-44[data-orientation=vertical]{min-height:calc(var(--spacing)*44)}.data-\\[orientation\\=vertical\\]\\:w-1\\.5[data-orientation=vertical]{width:calc(var(--spacing)*1.5)}.data-\\[orientation\\=vertical\\]\\:w-auto[data-orientation=vertical]{width:auto}.data-\\[orientation\\=vertical\\]\\:w-full[data-orientation=vertical]{width:100%}.data-\\[orientation\\=vertical\\]\\:w-px[data-orientation=vertical]{width:1px}.data-\\[orientation\\=vertical\\]\\:flex-col[data-orientation=vertical]{flex-direction:column}.data-\\[orientation\\=vertical\\]\\:after\\:left-0[data-orientation=vertical]:after{content:var(--tw-content);left:calc(var(--spacing)*0)}.data-\\[orientation\\=vertical\\]\\:after\\:h-1[data-orientation=vertical]:after{content:var(--tw-content);height:calc(var(--spacing)*1)}.data-\\[orientation\\=vertical\\]\\:after\\:w-full[data-orientation=vertical]:after{content:var(--tw-content);width:100%}.data-\\[orientation\\=vertical\\]\\:after\\:translate-x-0[data-orientation=vertical]:after{content:var(--tw-content);--tw-translate-x:calc(var(--spacing)*0);translate:var(--tw-translate-x)var(--tw-translate-y)}.data-\\[orientation\\=vertical\\]\\:after\\:-translate-y-1\\/2[data-orientation=vertical]:after{content:var(--tw-content);--tw-translate-y: -50% ;translate:var(--tw-translate-x)var(--tw-translate-y)}.data-\\[outside-view\\]\\:text-muted-foreground[data-outside-view],.data-\\[placeholder\\]\\:text-muted-foreground[data-placeholder]{color:var(--muted-foreground)}.data-\\[selected\\]\\:bg-primary[data-selected]{background-color:var(--primary)}.data-\\[selected\\]\\:text-primary-foreground[data-selected]{color:var(--primary-foreground)}.data-\\[selected\\]\\:opacity-100[data-selected]{opacity:1}@media (hover:hover){.data-\\[selected\\]\\:hover\\:bg-primary[data-selected]:hover{background-color:var(--primary)}.data-\\[selected\\]\\:hover\\:text-primary-foreground[data-selected]:hover{color:var(--primary-foreground)}}.data-\\[selected\\]\\:focus\\:bg-primary[data-selected]:focus{background-color:var(--primary)}.data-\\[selected\\]\\:focus\\:text-primary-foreground[data-selected]:focus{color:var(--primary-foreground)}.data-\\[selection-end\\]\\:bg-primary[data-selection-end]{background-color:var(--primary)}.data-\\[selection-end\\]\\:text-primary-foreground[data-selection-end]{color:var(--primary-foreground)}@media (hover:hover){.data-\\[selection-end\\]\\:hover\\:bg-primary[data-selection-end]:hover{background-color:var(--primary)}.data-\\[selection-end\\]\\:hover\\:text-primary-foreground[data-selection-end]:hover{color:var(--primary-foreground)}}.data-\\[selection-end\\]\\:focus\\:bg-primary[data-selection-end]:focus{background-color:var(--primary)}.data-\\[selection-end\\]\\:focus\\:text-primary-foreground[data-selection-end]:focus{color:var(--primary-foreground)}.data-\\[selection-start\\]\\:bg-primary[data-selection-start]{background-color:var(--primary)}.data-\\[selection-start\\]\\:text-primary-foreground[data-selection-start]{color:var(--primary-foreground)}@media (hover:hover){.data-\\[selection-start\\]\\:hover\\:bg-primary[data-selection-start]:hover{background-color:var(--primary)}.data-\\[selection-start\\]\\:hover\\:text-primary-foreground[data-selection-start]:hover{color:var(--primary-foreground)}}.data-\\[selection-start\\]\\:focus\\:bg-primary[data-selection-start]:focus{background-color:var(--primary)}.data-\\[selection-start\\]\\:focus\\:text-primary-foreground[data-selection-start]:focus{color:var(--primary-foreground)}.data-\\[side\\=bottom\\]\\:translate-y-1[data-side=bottom]{--tw-translate-y:calc(var(--spacing)*1);translate:var(--tw-translate-x)var(--tw-translate-y)}.data-\\[side\\=bottom\\]\\:slide-in-from-top-2[data-side=bottom]{--tw-enter-translate-y:calc(2*var(--spacing)*-1)}.data-\\[side\\=left\\]\\:-translate-x-1[data-side=left]{--tw-translate-x:calc(var(--spacing)*-1);translate:var(--tw-translate-x)var(--tw-translate-y)}.data-\\[side\\=left\\]\\:slide-in-from-right-2[data-side=left]{--tw-enter-translate-x:calc(2*var(--spacing))}.data-\\[side\\=right\\]\\:translate-x-1[data-side=right]{--tw-translate-x:calc(var(--spacing)*1);translate:var(--tw-translate-x)var(--tw-translate-y)}.data-\\[side\\=right\\]\\:slide-in-from-left-2[data-side=right]{--tw-enter-translate-x:calc(2*var(--spacing)*-1)}.data-\\[side\\=top\\]\\:-translate-y-1[data-side=top]{--tw-translate-y:calc(var(--spacing)*-1);translate:var(--tw-translate-x)var(--tw-translate-y)}.data-\\[side\\=top\\]\\:slide-in-from-bottom-2[data-side=top]{--tw-enter-translate-y:calc(2*var(--spacing))}.data-\\[size\\=default\\]\\:h-9[data-size=default]{height:calc(var(--spacing)*9)}.data-\\[size\\=sm\\]\\:h-8[data-size=sm]{height:calc(var(--spacing)*8)}:is(.\\*\\:data-\\[slot\\=alert-description\\]\\:text-destructive\\/90>*)[data-slot=alert-description]{color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){:is(.\\*\\:data-\\[slot\\=alert-description\\]\\:text-destructive\\/90>*)[data-slot=alert-description]{color:color-mix(in oklab,var(--destructive)90%,transparent)}}.data-\\[slot\\=checkbox-group\\]\\:gap-3[data-slot=checkbox-group]{gap:calc(var(--spacing)*3)}:is(.\\*\\*\\:data-\\[slot\\=native-select-icon\\]\\:right-1 *)[data-slot=native-select-icon]{right:calc(var(--spacing)*1)}:is(.\\*\\*\\:data-\\[slot\\=navigation-menu-link\\]\\:focus\\:ring-0 *)[data-slot=navigation-menu-link]:focus{--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(0px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}:is(.\\*\\*\\:data-\\[slot\\=navigation-menu-link\\]\\:focus\\:outline-none *)[data-slot=navigation-menu-link]:focus{--tw-outline-style:none;outline-style:none}:is(.\\*\\:data-\\[slot\\=select-value\\]\\:line-clamp-1>*)[data-slot=select-value]{-webkit-line-clamp:1;-webkit-box-orient:vertical;display:-webkit-box;overflow:hidden}:is(.\\*\\:data-\\[slot\\=select-value\\]\\:flex>*)[data-slot=select-value]{display:flex}:is(.\\*\\:data-\\[slot\\=select-value\\]\\:items-center>*)[data-slot=select-value]{align-items:center}:is(.\\*\\:data-\\[slot\\=select-value\\]\\:gap-2>*)[data-slot=select-value]{gap:calc(var(--spacing)*2)}.data-\\[spacing\\=0\\]\\:rounded-none[data-spacing="0"]{border-radius:0}.data-\\[spacing\\=0\\]\\:shadow-none[data-spacing="0"]{--tw-shadow:0 0 #0000;box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.data-\\[spacing\\=0\\]\\:first\\:rounded-l-md[data-spacing="0"]:first-child{border-top-left-radius:calc(var(--radius) - 2px);border-bottom-left-radius:calc(var(--radius) - 2px)}.data-\\[spacing\\=0\\]\\:last\\:rounded-r-md[data-spacing="0"]:last-child{border-top-right-radius:calc(var(--radius) - 2px);border-bottom-right-radius:calc(var(--radius) - 2px)}.data-\\[state\\=active\\]\\:bg-background[data-state=active]{background-color:var(--background)}.data-\\[state\\=active\\]\\:shadow-sm[data-state=active]{--tw-shadow:0 1px 3px 0 var(--tw-shadow-color,#0000001a),0 1px 2px -1px var(--tw-shadow-color,#0000001a);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.data-\\[state\\=active\\]\\:ring-2[data-state=active]{--tw-ring-shadow:var(--tw-ring-inset,)0 0 0 calc(2px + var(--tw-ring-offset-width))var(--tw-ring-color,currentcolor);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.data-\\[state\\=active\\]\\:ring-ring[data-state=active]{--tw-ring-color:var(--ring)}.data-\\[state\\=active\\]\\:ring-offset-2[data-state=active]{--tw-ring-offset-width:2px;--tw-ring-offset-shadow:var(--tw-ring-inset,)0 0 0 var(--tw-ring-offset-width)var(--tw-ring-offset-color)}.data-\\[state\\=checked\\]\\:translate-x-\\[calc\\(100\\%-2px\\)\\][data-state=checked]{--tw-translate-x: calc(100% - 2px) ;translate:var(--tw-translate-x)var(--tw-translate-y)}.data-\\[state\\=checked\\]\\:border-primary[data-state=checked]{border-color:var(--primary)}.data-\\[state\\=checked\\]\\:bg-primary[data-state=checked]{background-color:var(--primary)}.data-\\[state\\=checked\\]\\:text-primary-foreground[data-state=checked]{color:var(--primary-foreground)}.data-\\[state\\=closed\\]\\:animate-accordion-up[data-state=closed]{animation:accordion-up var(--tw-animation-duration,var(--tw-duration,.2s))var(--tw-ease,ease-out)var(--tw-animation-delay,0s)var(--tw-animation-iteration-count,1)var(--tw-animation-direction,normal)var(--tw-animation-fill-mode,none)}.data-\\[state\\=closed\\]\\:animate-out[data-state=closed]{animation:exit var(--tw-animation-duration,var(--tw-duration,.15s))var(--tw-ease,ease)var(--tw-animation-delay,0s)var(--tw-animation-iteration-count,1)var(--tw-animation-direction,normal)var(--tw-animation-fill-mode,none)}.data-\\[state\\=closed\\]\\:duration-300[data-state=closed]{--tw-duration:.3s;transition-duration:.3s}.data-\\[state\\=closed\\]\\:fade-out-0[data-state=closed]{--tw-exit-opacity:0}.data-\\[state\\=closed\\]\\:zoom-out-95[data-state=closed]{--tw-exit-scale:.95}.data-\\[state\\=closed\\]\\:slide-out-to-bottom[data-state=closed]{--tw-exit-translate-y:100%}.data-\\[state\\=closed\\]\\:slide-out-to-left[data-state=closed]{--tw-exit-translate-x:-100%}.data-\\[state\\=closed\\]\\:slide-out-to-right[data-state=closed]{--tw-exit-translate-x:100%}.data-\\[state\\=closed\\]\\:slide-out-to-top[data-state=closed]{--tw-exit-translate-y:-100%}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:data-\\[state\\=closed\\]\\:animate-out:is(:where(.group\\/navigation-menu)[data-viewport=false] *)[data-state=closed]{animation:exit var(--tw-animation-duration,var(--tw-duration,.15s))var(--tw-ease,ease)var(--tw-animation-delay,0s)var(--tw-animation-iteration-count,1)var(--tw-animation-direction,normal)var(--tw-animation-fill-mode,none)}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:data-\\[state\\=closed\\]\\:fade-out-0:is(:where(.group\\/navigation-menu)[data-viewport=false] *)[data-state=closed]{--tw-exit-opacity:0}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:data-\\[state\\=closed\\]\\:zoom-out-95:is(:where(.group\\/navigation-menu)[data-viewport=false] *)[data-state=closed]{--tw-exit-scale:.95}.data-\\[state\\=hidden\\]\\:animate-out[data-state=hidden]{animation:exit var(--tw-animation-duration,var(--tw-duration,.15s))var(--tw-ease,ease)var(--tw-animation-delay,0s)var(--tw-animation-iteration-count,1)var(--tw-animation-direction,normal)var(--tw-animation-fill-mode,none)}.data-\\[state\\=hidden\\]\\:fade-out[data-state=hidden]{--tw-exit-opacity:0}.data-\\[state\\=on\\]\\:bg-accent[data-state=on]{background-color:var(--accent)}.data-\\[state\\=on\\]\\:text-accent-foreground[data-state=on]{color:var(--accent-foreground)}.data-\\[state\\=open\\]\\:animate-accordion-down[data-state=open]{animation:accordion-down var(--tw-animation-duration,var(--tw-duration,.2s))var(--tw-ease,ease-out)var(--tw-animation-delay,0s)var(--tw-animation-iteration-count,1)var(--tw-animation-direction,normal)var(--tw-animation-fill-mode,none)}.data-\\[state\\=open\\]\\:animate-in[data-state=open]{animation:enter var(--tw-animation-duration,var(--tw-duration,.15s))var(--tw-ease,ease)var(--tw-animation-delay,0s)var(--tw-animation-iteration-count,1)var(--tw-animation-direction,normal)var(--tw-animation-fill-mode,none)}.data-\\[state\\=open\\]\\:bg-accent[data-state=open],.data-\\[state\\=open\\]\\:bg-accent\\/50[data-state=open]{background-color:var(--accent)}@supports (color:color-mix(in lab,red,red)){.data-\\[state\\=open\\]\\:bg-accent\\/50[data-state=open]{background-color:color-mix(in oklab,var(--accent)50%,transparent)}}.data-\\[state\\=open\\]\\:bg-secondary[data-state=open]{background-color:var(--secondary)}.data-\\[state\\=open\\]\\:bg-sidebar-accent[data-state=open]{background-color:var(--sidebar-accent)}.data-\\[state\\=open\\]\\:text-accent-foreground[data-state=open]{color:var(--accent-foreground)}.data-\\[state\\=open\\]\\:text-muted-foreground[data-state=open]{color:var(--muted-foreground)}.data-\\[state\\=open\\]\\:text-sidebar-accent-foreground[data-state=open]{color:var(--sidebar-accent-foreground)}.data-\\[state\\=open\\]\\:opacity-100[data-state=open]{opacity:1}.data-\\[state\\=open\\]\\:duration-500[data-state=open]{--tw-duration:.5s;transition-duration:.5s}.data-\\[state\\=open\\]\\:fade-in-0[data-state=open]{--tw-enter-opacity:0}.data-\\[state\\=open\\]\\:zoom-in-90[data-state=open]{--tw-enter-scale:.9}.data-\\[state\\=open\\]\\:zoom-in-95[data-state=open]{--tw-enter-scale:.95}.data-\\[state\\=open\\]\\:slide-in-from-bottom[data-state=open]{--tw-enter-translate-y:100%}.data-\\[state\\=open\\]\\:slide-in-from-left[data-state=open]{--tw-enter-translate-x:-100%}.data-\\[state\\=open\\]\\:slide-in-from-right[data-state=open]{--tw-enter-translate-x:100%}.data-\\[state\\=open\\]\\:slide-in-from-top[data-state=open]{--tw-enter-translate-y:-100%}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:data-\\[state\\=open\\]\\:animate-in:is(:where(.group\\/navigation-menu)[data-viewport=false] *)[data-state=open]{animation:enter var(--tw-animation-duration,var(--tw-duration,.15s))var(--tw-ease,ease)var(--tw-animation-delay,0s)var(--tw-animation-iteration-count,1)var(--tw-animation-direction,normal)var(--tw-animation-fill-mode,none)}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:data-\\[state\\=open\\]\\:fade-in-0:is(:where(.group\\/navigation-menu)[data-viewport=false] *)[data-state=open]{--tw-enter-opacity:0}.group-data-\\[viewport\\=false\\]\\/navigation-menu\\:data-\\[state\\=open\\]\\:zoom-in-95:is(:where(.group\\/navigation-menu)[data-viewport=false] *)[data-state=open]{--tw-enter-scale:.95}@media (hover:hover){.data-\\[state\\=open\\]\\:hover\\:bg-accent[data-state=open]:hover{background-color:var(--accent)}.data-\\[state\\=open\\]\\:hover\\:bg-sidebar-accent[data-state=open]:hover{background-color:var(--sidebar-accent)}.data-\\[state\\=open\\]\\:hover\\:text-sidebar-accent-foreground[data-state=open]:hover{color:var(--sidebar-accent-foreground)}}.data-\\[state\\=open\\]\\:focus\\:bg-accent[data-state=open]:focus{background-color:var(--accent)}.data-\\[state\\=selected\\]\\:bg-muted[data-state=selected]{background-color:var(--muted)}.data-\\[state\\=unchecked\\]\\:translate-x-0[data-state=unchecked]{--tw-translate-x:calc(var(--spacing)*0);translate:var(--tw-translate-x)var(--tw-translate-y)}.data-\\[state\\=unchecked\\]\\:bg-input[data-state=unchecked]{background-color:var(--input)}.data-\\[state\\=visible\\]\\:animate-in[data-state=visible]{animation:enter var(--tw-animation-duration,var(--tw-duration,.15s))var(--tw-ease,ease)var(--tw-animation-delay,0s)var(--tw-animation-iteration-count,1)var(--tw-animation-direction,normal)var(--tw-animation-fill-mode,none)}.data-\\[state\\=visible\\]\\:fade-in[data-state=visible]{--tw-enter-opacity:0}.data-\\[unavailable\\]\\:text-destructive-foreground[data-unavailable]{color:var(--destructive-foreground)}.data-\\[unavailable\\]\\:line-through[data-unavailable]{text-decoration-line:line-through}.data-\\[variant\\=destructive\\]\\:text-destructive[data-variant=destructive]{color:var(--destructive)}.data-\\[variant\\=destructive\\]\\:text-destructive-foreground[data-variant=destructive]{color:var(--destructive-foreground)}.data-\\[variant\\=destructive\\]\\:focus\\:bg-destructive\\/10[data-variant=destructive]:focus{background-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.data-\\[variant\\=destructive\\]\\:focus\\:bg-destructive\\/10[data-variant=destructive]:focus{background-color:color-mix(in oklab,var(--destructive)10%,transparent)}}.data-\\[variant\\=destructive\\]\\:focus\\:text-destructive[data-variant=destructive]:focus{color:var(--destructive)}.data-\\[variant\\=destructive\\]\\:focus\\:text-destructive-foreground[data-variant=destructive]:focus{color:var(--destructive-foreground)}.data-\\[variant\\=label\\]\\:text-sm[data-variant=label]{font-size:var(--text-sm);line-height:var(--tw-leading,var(--text-sm--line-height))}.data-\\[variant\\=legend\\]\\:text-base[data-variant=legend]{font-size:var(--text-base);line-height:var(--tw-leading,var(--text-base--line-height))}.data-\\[spacing\\=0\\]\\:data-\\[variant\\=outline\\]\\:border-l-0[data-spacing="0"][data-variant=outline]{border-left-style:var(--tw-border-style);border-left-width:0}.data-\\[spacing\\=0\\]\\:data-\\[variant\\=outline\\]\\:first\\:border-l[data-spacing="0"][data-variant=outline]:first-child{border-left-style:var(--tw-border-style);border-left-width:1px}.data-\\[spacing\\=default\\]\\:data-\\[variant\\=outline\\]\\:shadow-xs[data-spacing=default][data-variant=outline]{--tw-shadow:0 1px 2px 0 var(--tw-shadow-color,#0000000d);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.data-\\[vaul-drawer-direction\\=bottom\\]\\:inset-x-0[data-vaul-drawer-direction=bottom]{inset-inline:calc(var(--spacing)*0)}.data-\\[vaul-drawer-direction\\=bottom\\]\\:bottom-0[data-vaul-drawer-direction=bottom]{bottom:calc(var(--spacing)*0)}.data-\\[vaul-drawer-direction\\=bottom\\]\\:mt-24[data-vaul-drawer-direction=bottom]{margin-top:calc(var(--spacing)*24)}.data-\\[vaul-drawer-direction\\=bottom\\]\\:max-h-\\[80vh\\][data-vaul-drawer-direction=bottom]{max-height:80vh}.data-\\[vaul-drawer-direction\\=bottom\\]\\:rounded-t-lg[data-vaul-drawer-direction=bottom]{border-top-left-radius:var(--radius);border-top-right-radius:var(--radius)}.data-\\[vaul-drawer-direction\\=left\\]\\:inset-y-0[data-vaul-drawer-direction=left]{inset-block:calc(var(--spacing)*0)}.data-\\[vaul-drawer-direction\\=left\\]\\:left-0[data-vaul-drawer-direction=left]{left:calc(var(--spacing)*0)}.data-\\[vaul-drawer-direction\\=left\\]\\:w-3\\/4[data-vaul-drawer-direction=left]{width:75%}.data-\\[vaul-drawer-direction\\=right\\]\\:inset-y-0[data-vaul-drawer-direction=right]{inset-block:calc(var(--spacing)*0)}.data-\\[vaul-drawer-direction\\=right\\]\\:right-0[data-vaul-drawer-direction=right]{right:calc(var(--spacing)*0)}.data-\\[vaul-drawer-direction\\=right\\]\\:w-3\\/4[data-vaul-drawer-direction=right]{width:75%}.data-\\[vaul-drawer-direction\\=top\\]\\:inset-x-0[data-vaul-drawer-direction=top]{inset-inline:calc(var(--spacing)*0)}.data-\\[vaul-drawer-direction\\=top\\]\\:top-0[data-vaul-drawer-direction=top]{top:calc(var(--spacing)*0)}.data-\\[vaul-drawer-direction\\=top\\]\\:mb-24[data-vaul-drawer-direction=top]{margin-bottom:calc(var(--spacing)*24)}.data-\\[vaul-drawer-direction\\=top\\]\\:max-h-\\[80vh\\][data-vaul-drawer-direction=top]{max-height:80vh}.data-\\[vaul-drawer-direction\\=top\\]\\:rounded-b-lg[data-vaul-drawer-direction=top]{border-bottom-right-radius:var(--radius);border-bottom-left-radius:var(--radius)}.nth-last-2\\:-mt-1:nth-last-child(2){margin-top:calc(var(--spacing)*-1)}@media (min-width:40rem){.sm\\:mt-0{margin-top:calc(var(--spacing)*0)}.sm\\:block{display:block}.sm\\:flex{display:flex}.sm\\:max-w-lg{max-width:var(--container-lg)}.sm\\:max-w-sm{max-width:var(--container-sm)}.sm\\:grid-cols-3{grid-template-columns:repeat(3,minmax(0,1fr))}.sm\\:flex-row{flex-direction:row}.sm\\:justify-end{justify-content:flex-end}.sm\\:gap-2\\.5{gap:calc(var(--spacing)*2.5)}.sm\\:gap-x-4{-moz-column-gap:calc(var(--spacing)*4);column-gap:calc(var(--spacing)*4)}.sm\\:gap-y-0{row-gap:calc(var(--spacing)*0)}.sm\\:rounded-lg{border-radius:var(--radius)}.sm\\:pr-2\\.5{padding-right:calc(var(--spacing)*2.5)}.sm\\:text-left{text-align:left}.data-\\[vaul-drawer-direction\\=left\\]\\:sm\\:max-w-sm[data-vaul-drawer-direction=left],.data-\\[vaul-drawer-direction\\=right\\]\\:sm\\:max-w-sm[data-vaul-drawer-direction=right]{max-width:var(--container-sm)}}@media (min-width:48rem){.md\\:absolute{position:absolute}.md\\:block{display:block}.md\\:flex{display:flex}.md\\:w-1\\/2{width:50%}.md\\:w-\\[var\\(--reka-navigation-menu-viewport-width\\)\\]{width:var(--reka-navigation-menu-viewport-width)}.md\\:w-auto{width:auto}.md\\:w-full{width:100%}.md\\:grid-cols-3{grid-template-columns:repeat(3,minmax(0,1fr))}.md\\:flex-row{flex-direction:row}.md\\:items-center{align-items:center}.md\\:items-end{align-items:flex-end}.md\\:justify-between{justify-content:space-between}.md\\:p-12{padding:calc(var(--spacing)*12)}.md\\:text-sm{font-size:var(--text-sm);line-height:var(--tw-leading,var(--text-sm--line-height))}.md\\:opacity-0{opacity:0}.md\\:peer-data-\\[variant\\=inset\\]\\:m-2:is(:where(.peer)[data-variant=inset]~*){margin:calc(var(--spacing)*2)}.md\\:peer-data-\\[variant\\=inset\\]\\:ml-0:is(:where(.peer)[data-variant=inset]~*){margin-left:calc(var(--spacing)*0)}.md\\:peer-data-\\[variant\\=inset\\]\\:rounded-xl:is(:where(.peer)[data-variant=inset]~*){border-radius:calc(var(--radius) + 4px)}.md\\:peer-data-\\[variant\\=inset\\]\\:shadow-sm:is(:where(.peer)[data-variant=inset]~*){--tw-shadow:0 1px 3px 0 var(--tw-shadow-color,#0000001a),0 1px 2px -1px var(--tw-shadow-color,#0000001a);box-shadow:var(--tw-inset-shadow),var(--tw-inset-ring-shadow),var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow)}.md\\:peer-data-\\[variant\\=inset\\]\\:peer-data-\\[state\\=collapsed\\]\\:ml-2:is(:where(.peer)[data-variant=inset]~*):is(:where(.peer)[data-state=collapsed]~*){margin-left:calc(var(--spacing)*2)}.md\\:after\\:hidden:after{content:var(--tw-content);display:none}}@container field-group (min-width:28rem){.\\@md\\/field-group\\:flex-row{flex-direction:row}.\\@md\\/field-group\\:items-center{align-items:center}.\\@md\\/field-group\\:has-\\[\\>\\[data-slot\\=field-content\\]\\]\\:items-start:has(>[data-slot=field-content]){align-items:flex-start}}.dark\\:border-emerald-400\\/30:is(.dark *){border-color:#00d2944d}@supports (color:color-mix(in lab,red,red)){.dark\\:border-emerald-400\\/30:is(.dark *){border-color:color-mix(in oklab,var(--color-emerald-400)30%,transparent)}}.dark\\:border-input:is(.dark *){border-color:var(--input)}.dark\\:bg-destructive\\/60:is(.dark *){background-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.dark\\:bg-destructive\\/60:is(.dark *){background-color:color-mix(in oklab,var(--destructive)60%,transparent)}}.dark\\:bg-emerald-950\\/20:is(.dark *){background-color:#002c2233}@supports (color:color-mix(in lab,red,red)){.dark\\:bg-emerald-950\\/20:is(.dark *){background-color:color-mix(in oklab,var(--color-emerald-950)20%,transparent)}}.dark\\:bg-input\\/30:is(.dark *){background-color:var(--input)}@supports (color:color-mix(in lab,red,red)){.dark\\:bg-input\\/30:is(.dark *){background-color:color-mix(in oklab,var(--input)30%,transparent)}}.dark\\:bg-transparent:is(.dark *){background-color:#0000}.dark\\:text-muted-foreground:is(.dark *){color:var(--muted-foreground)}.dark\\:ring-ring\\/20:is(.dark *){--tw-ring-color:var(--ring)}@supports (color:color-mix(in lab,red,red)){.dark\\:ring-ring\\/20:is(.dark *){--tw-ring-color:color-mix(in oklab,var(--ring)20%,transparent)}}.dark\\:outline-ring\\/40:is(.dark *){outline-color:var(--ring)}@supports (color:color-mix(in lab,red,red)){.dark\\:outline-ring\\/40:is(.dark *){outline-color:color-mix(in oklab,var(--ring)40%,transparent)}}@media (hover:hover){.dark\\:hover\\:bg-accent\\/50:is(.dark *):hover{background-color:var(--accent)}@supports (color:color-mix(in lab,red,red)){.dark\\:hover\\:bg-accent\\/50:is(.dark *):hover{background-color:color-mix(in oklab,var(--accent)50%,transparent)}}.dark\\:hover\\:bg-input\\/50:is(.dark *):hover{background-color:var(--input)}@supports (color:color-mix(in lab,red,red)){.dark\\:hover\\:bg-input\\/50:is(.dark *):hover{background-color:color-mix(in oklab,var(--input)50%,transparent)}}}.dark\\:focus-visible\\:ring-destructive\\/40:is(.dark *):focus-visible{--tw-ring-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.dark\\:focus-visible\\:ring-destructive\\/40:is(.dark *):focus-visible{--tw-ring-color:color-mix(in oklab,var(--destructive)40%,transparent)}}.dark\\:has-data-\\[state\\=checked\\]\\:bg-primary\\/10:is(.dark *):has([data-state=checked]){background-color:var(--primary)}@supports (color:color-mix(in lab,red,red)){.dark\\:has-data-\\[state\\=checked\\]\\:bg-primary\\/10:is(.dark *):has([data-state=checked]){background-color:color-mix(in oklab,var(--primary)10%,transparent)}}.dark\\:has-\\[\\[data-slot\\]\\[aria-invalid\\=true\\]\\]\\:ring-destructive\\/40:is(.dark *):has([data-slot][aria-invalid=true]){--tw-ring-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.dark\\:has-\\[\\[data-slot\\]\\[aria-invalid\\=true\\]\\]\\:ring-destructive\\/40:is(.dark *):has([data-slot][aria-invalid=true]){--tw-ring-color:color-mix(in oklab,var(--destructive)40%,transparent)}}.dark\\:aria-invalid\\:ring-destructive\\/40:is(.dark *)[aria-invalid=true]{--tw-ring-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.dark\\:aria-invalid\\:ring-destructive\\/40:is(.dark *)[aria-invalid=true]{--tw-ring-color:color-mix(in oklab,var(--destructive)40%,transparent)}}.dark\\:focus\\:aria-invalid\\:ring-destructive\\/40:is(.dark *):focus[aria-invalid=true]{--tw-ring-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.dark\\:focus\\:aria-invalid\\:ring-destructive\\/40:is(.dark *):focus[aria-invalid=true]{--tw-ring-color:color-mix(in oklab,var(--destructive)40%,transparent)}}.dark\\:data-\\[active\\=true\\]\\:aria-invalid\\:ring-destructive\\/40:is(.dark *)[data-active=true][aria-invalid=true]{--tw-ring-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.dark\\:data-\\[active\\=true\\]\\:aria-invalid\\:ring-destructive\\/40:is(.dark *)[data-active=true][aria-invalid=true]{--tw-ring-color:color-mix(in oklab,var(--destructive)40%,transparent)}}.dark\\:data-\\[state\\=active\\]\\:border-input:is(.dark *)[data-state=active]{border-color:var(--input)}.dark\\:data-\\[state\\=active\\]\\:bg-input\\/30:is(.dark *)[data-state=active]{background-color:var(--input)}@supports (color:color-mix(in lab,red,red)){.dark\\:data-\\[state\\=active\\]\\:bg-input\\/30:is(.dark *)[data-state=active]{background-color:color-mix(in oklab,var(--input)30%,transparent)}}.dark\\:data-\\[state\\=active\\]\\:text-foreground:is(.dark *)[data-state=active]{color:var(--foreground)}.dark\\:data-\\[state\\=checked\\]\\:bg-primary-foreground:is(.dark *)[data-state=checked]{background-color:var(--primary-foreground)}.dark\\:data-\\[state\\=unchecked\\]\\:bg-foreground:is(.dark *)[data-state=unchecked]{background-color:var(--foreground)}.dark\\:data-\\[state\\=unchecked\\]\\:bg-input\\/80:is(.dark *)[data-state=unchecked]{background-color:var(--input)}@supports (color:color-mix(in lab,red,red)){.dark\\:data-\\[state\\=unchecked\\]\\:bg-input\\/80:is(.dark *)[data-state=unchecked]{background-color:color-mix(in oklab,var(--input)80%,transparent)}}.dark\\:data-\\[variant\\=destructive\\]\\:focus\\:bg-destructive\\/20:is(.dark *)[data-variant=destructive]:focus{background-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.dark\\:data-\\[variant\\=destructive\\]\\:focus\\:bg-destructive\\/20:is(.dark *)[data-variant=destructive]:focus{background-color:color-mix(in oklab,var(--destructive)20%,transparent)}}.dark\\:data-\\[variant\\=destructive\\]\\:focus\\:bg-destructive\\/40:is(.dark *)[data-variant=destructive]:focus{background-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){.dark\\:data-\\[variant\\=destructive\\]\\:focus\\:bg-destructive\\/40:is(.dark *)[data-variant=destructive]:focus{background-color:color-mix(in oklab,var(--destructive)40%,transparent)}}.\\[\\&_\\.recharts-curve\\.recharts-tooltip-cursor\\]\\:stroke-border .recharts-curve.recharts-tooltip-cursor{stroke:var(--border)}.\\[\\&_\\.recharts-dot\\[stroke\\=\\'\\#fff\\'\\]\\]\\:stroke-transparent .recharts-dot[stroke="#fff"]{stroke:#0000}.\\[\\&_\\.recharts-layer\\]\\:outline-hidden .recharts-layer{--tw-outline-style:none;outline-style:none}@media (forced-colors:active){.\\[\\&_\\.recharts-layer\\]\\:outline-hidden .recharts-layer{outline-offset:2px;outline:2px solid #0000}}.\\[\\&_\\.recharts-polar-grid_\\[stroke\\=\\'\\#ccc\\'\\]\\]\\:stroke-border .recharts-polar-grid [stroke="#ccc"]{stroke:var(--border)}.\\[\\&_\\.recharts-radial-bar-background-sector\\]\\:fill-muted .recharts-radial-bar-background-sector,.\\[\\&_\\.recharts-rectangle\\.recharts-tooltip-cursor\\]\\:fill-muted .recharts-rectangle.recharts-tooltip-cursor{fill:var(--muted)}.\\[\\&_\\.recharts-reference-line_\\[stroke\\=\\'\\#ccc\\'\\]\\]\\:stroke-border .recharts-reference-line [stroke="#ccc"]{stroke:var(--border)}.\\[\\&_\\.recharts-sector\\]\\:outline-hidden .recharts-sector{--tw-outline-style:none;outline-style:none}@media (forced-colors:active){.\\[\\&_\\.recharts-sector\\]\\:outline-hidden .recharts-sector{outline-offset:2px;outline:2px solid #0000}}.\\[\\&_\\.recharts-sector\\[stroke\\=\\'\\#fff\\'\\]\\]\\:stroke-transparent .recharts-sector[stroke="#fff"]{stroke:#0000}.\\[\\&_\\.recharts-surface\\]\\:outline-hidden .recharts-surface{--tw-outline-style:none;outline-style:none}@media (forced-colors:active){.\\[\\&_\\.recharts-surface\\]\\:outline-hidden .recharts-surface{outline-offset:2px;outline:2px solid #0000}}.\\[\\&_\\.tick_line\\]\\:\\!stroke-border\\/50 .tick line{stroke:var(--border)!important}@supports (color:color-mix(in lab,red,red)){.\\[\\&_\\.tick_line\\]\\:\\!stroke-border\\/50 .tick line{stroke:color-mix(in oklab,var(--border)50%,transparent)!important}}.\\[\\&_\\.tick_text\\]\\:\\!fill-muted-foreground .tick text{fill:var(--muted-foreground)!important}.\\[\\&_\\[data-vis-single-container\\]\\]\\:h-full [data-vis-single-container]{height:100%}.\\[\\&_\\[data-vis-single-container\\]\\]\\:w-full [data-vis-single-container]{width:100%}.\\[\\&_\\[data-vis-xy-container\\]\\]\\:h-full [data-vis-xy-container]{height:100%}.\\[\\&_\\[data-vis-xy-container\\]\\]\\:w-full [data-vis-xy-container]{width:100%}.\\[\\&_img\\]\\:size-full img{width:100%;height:100%}.\\[\\&_img\\]\\:object-cover img{-o-object-fit:cover;object-fit:cover}.\\[\\&_p\\]\\:leading-relaxed p{--tw-leading:var(--leading-relaxed);line-height:var(--leading-relaxed)}.\\[\\&_svg\\]\\:pointer-events-none svg{pointer-events:none}.\\[\\&_svg\\]\\:shrink-0 svg{flex-shrink:0}.\\[\\&_svg\\:not\\(\\[class\\*\\=\\'size-\\'\\]\\)\\]\\:size-4 svg:not([class*=size-]){width:calc(var(--spacing)*4);height:calc(var(--spacing)*4)}.\\[\\&_svg\\:not\\(\\[class\\*\\=\\'size-\\'\\]\\)\\]\\:size-6 svg:not([class*=size-]){width:calc(var(--spacing)*6);height:calc(var(--spacing)*6)}.\\[\\&_svg\\:not\\(\\[class\\*\\=\\\\\\'size-\\\\\\'\\]\\)\\]\\:size-3 svg:not([class*="'size-'"]){width:calc(var(--spacing)*3);height:calc(var(--spacing)*3)}.\\[\\&_svg\\:not\\(\\[class\\*\\=\\\\\\'size-\\\\\\'\\]\\)\\]\\:size-4 svg:not([class*="'size-'"]){width:calc(var(--spacing)*4);height:calc(var(--spacing)*4)}.\\[\\&_svg\\:not\\(\\[class\\*\\=\\\\\\'text-\\\\\\'\\]\\)\\]\\:text-muted-foreground svg:not([class*="'text-'"]){color:var(--muted-foreground)}.\\[\\&_tr\\]\\:border-b tr{border-bottom-style:var(--tw-border-style);border-bottom-width:1px}.\\[\\&_tr\\:last-child\\]\\:border-0 tr:last-child{border-style:var(--tw-border-style);border-width:0}.\\[\\&\\+\\[data-slot\\=item-content\\]\\]\\:flex-none+[data-slot=item-content]{flex:none}.\\[\\&\\:has\\(\\[data-selected\\]\\)\\]\\:rounded-md:has([data-selected]){border-radius:calc(var(--radius) - 2px)}.\\[\\&\\:has\\(\\[data-selected\\]\\)\\]\\:bg-accent:has([data-selected]){background-color:var(--accent)}.first\\:\\[\\&\\:has\\(\\[data-selected\\]\\)\\]\\:rounded-l-md:first-child:has([data-selected]){border-top-left-radius:calc(var(--radius) - 2px);border-bottom-left-radius:calc(var(--radius) - 2px)}.last\\:\\[\\&\\:has\\(\\[data-selected\\]\\)\\]\\:rounded-r-md:last-child:has([data-selected]),.\\[\\&\\:has\\(\\[data-selected\\]\\[data-selection-end\\]\\)\\]\\:rounded-r-md:has([data-selected][data-selection-end]){border-top-right-radius:calc(var(--radius) - 2px);border-bottom-right-radius:calc(var(--radius) - 2px)}.\\[\\&\\:has\\(\\[data-selected\\]\\[data-selection-start\\]\\)\\]\\:rounded-l-md:has([data-selected][data-selection-start]){border-top-left-radius:calc(var(--radius) - 2px);border-bottom-left-radius:calc(var(--radius) - 2px)}.\\[\\&\\:has\\(\\[role\\=checkbox\\]\\)\\]\\:pr-0:has([role=checkbox]){padding-right:calc(var(--spacing)*0)}.\\[\\.border-b\\]\\:pb-3.border-b{padding-bottom:calc(var(--spacing)*3)}.\\[\\.border-b\\]\\:pb-6.border-b{padding-bottom:calc(var(--spacing)*6)}.\\[\\.border-t\\]\\:pt-3.border-t{padding-top:calc(var(--spacing)*3)}.\\[\\.border-t\\]\\:pt-6.border-t{padding-top:calc(var(--spacing)*6)}.\\[a\\]\\:transition-colors:is(a){transition-property:color,background-color,border-color,outline-color,text-decoration-color,fill,stroke,--tw-gradient-from,--tw-gradient-via,--tw-gradient-to;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}@media (hover:hover){.\\[a\\]\\:hover\\:bg-accent\\/50:is(a):hover{background-color:var(--accent)}@supports (color:color-mix(in lab,red,red)){.\\[a\\]\\:hover\\:bg-accent\\/50:is(a):hover{background-color:color-mix(in oklab,var(--accent)50%,transparent)}}}:is(.\\*\\:\\[span\\]\\:last\\:flex>*):is(span):last-child{display:flex}:is(.\\*\\:\\[span\\]\\:last\\:items-center>*):is(span):last-child{align-items:center}:is(.\\*\\:\\[span\\]\\:last\\:gap-2>*):is(span):last-child{gap:calc(var(--spacing)*2)}:is(.data-\\[variant\\=destructive\\]\\:\\*\\:\\[svg\\]\\:\\!text-destructive[data-variant=destructive]>*):is(svg){color:var(--destructive)!important}:is(.data-\\[variant\\=destructive\\]\\:\\*\\:\\[svg\\]\\:\\!text-destructive-foreground[data-variant=destructive]>*):is(svg){color:var(--destructive-foreground)!important}.\\[\\&\\>\\*\\]\\:w-full>*{width:100%}.\\[\\&\\>\\*\\]\\:focus-visible\\:relative>:focus-visible{position:relative}.\\[\\&\\>\\*\\]\\:focus-visible\\:z-10>:focus-visible{z-index:10}.\\[\\&\\>\\*\\]\\:data-\\[slot\\=field\\]\\:p-4>[data-slot=field]{padding:calc(var(--spacing)*4)}@container field-group (min-width:28rem){.\\@md\\/field-group\\:\\[\\&\\>\\*\\]\\:w-auto>*{width:auto}}.\\[\\&\\>\\*\\:not\\(\\:first-child\\)\\]\\:rounded-t-none>:not(:first-child){border-top-left-radius:0;border-top-right-radius:0}.\\[\\&\\>\\*\\:not\\(\\:first-child\\)\\]\\:rounded-l-none>:not(:first-child){border-top-left-radius:0;border-bottom-left-radius:0}.\\[\\&\\>\\*\\:not\\(\\:first-child\\)\\]\\:border-t-0>:not(:first-child){border-top-style:var(--tw-border-style);border-top-width:0}.\\[\\&\\>\\*\\:not\\(\\:first-child\\)\\]\\:border-l-0>:not(:first-child){border-left-style:var(--tw-border-style);border-left-width:0}.\\[\\&\\>\\*\\:not\\(\\:last-child\\)\\]\\:rounded-r-none>:not(:last-child){border-top-right-radius:0;border-bottom-right-radius:0}.\\[\\&\\>\\*\\:not\\(\\:last-child\\)\\]\\:rounded-b-none>:not(:last-child){border-bottom-right-radius:0;border-bottom-left-radius:0}.\\[\\&\\>\\.sr-only\\]\\:w-auto>.sr-only{width:auto}.\\[\\&\\>\\[data-slot\\=field-group\\]\\]\\:gap-4>[data-slot=field-group]{gap:calc(var(--spacing)*4)}.\\[\\&\\>\\[data-slot\\=field-label\\]\\]\\:flex-auto>[data-slot=field-label]{flex:auto}@container field-group (min-width:28rem){.\\@md\\/field-group\\:\\[\\&\\>\\[data-slot\\=field-label\\]\\]\\:flex-auto>[data-slot=field-label]{flex:auto}}.\\[\\&\\>\\[data-slot\\=input\\]\\]\\:has-\\[\\[data-slot\\=decrement\\]\\]\\:pl-5>[data-slot=input]:has([data-slot=decrement]){padding-left:calc(var(--spacing)*5)}.\\[\\&\\>\\[data-slot\\=input\\]\\]\\:has-\\[\\[data-slot\\=increment\\]\\]\\:pr-5>[data-slot=input]:has([data-slot=increment]){padding-right:calc(var(--spacing)*5)}.has-\\[select\\[aria-hidden\\=true\\]\\:last-child\\]\\:\\[\\&\\>\\[data-slot\\=select-trigger\\]\\:last-of-type\\]\\:rounded-r-md:has(:is(select[aria-hidden=true]:last-child))>[data-slot=select-trigger]:last-of-type{border-top-right-radius:calc(var(--radius) - 2px);border-bottom-right-radius:calc(var(--radius) - 2px)}.\\[\\&\\>\\[data-slot\\=select-trigger\\]\\:not\\(\\[class\\*\\=\\'w-\\'\\]\\)\\]\\:w-fit>[data-slot=select-trigger]:not([class*=w-]){width:-moz-fit-content;width:fit-content}.\\[\\&\\>\\[role\\=checkbox\\]\\]\\:translate-y-\\[2px\\]>[role=checkbox]{--tw-translate-y:2px;translate:var(--tw-translate-x)var(--tw-translate-y)}.has-\\[\\>\\[data-slot\\=field-content\\]\\]\\:\\[\\&\\>\\[role\\=checkbox\\]\\,\\[role\\=radio\\]\\]\\:mt-px:has(>[data-slot=field-content])>[role=checkbox],.has-\\[\\>\\[data-slot\\=field-content\\]\\]\\:\\[\\&\\>\\[role\\=checkbox\\]\\,\\[role\\=radio\\]\\]\\:mt-px:has(>[data-slot=field-content]) [role=radio]{margin-top:1px}@container field-group (min-width:28rem){.\\@md\\/field-group\\:has-\\[\\>\\[data-slot\\=field-content\\]\\]\\:\\[\\&\\>\\[role\\=checkbox\\]\\,\\[role\\=radio\\]\\]\\:mt-px:has(>[data-slot=field-content])>[role=checkbox],.\\@md\\/field-group\\:has-\\[\\>\\[data-slot\\=field-content\\]\\]\\:\\[\\&\\>\\[role\\=checkbox\\]\\,\\[role\\=radio\\]\\]\\:mt-px:has(>[data-slot=field-content]) [role=radio]{margin-top:1px}}.\\[\\&\\>a\\]\\:underline>a{text-decoration-line:underline}.\\[\\&\\>a\\]\\:underline-offset-4>a{text-underline-offset:4px}.\\[\\&\\>a\\:hover\\]\\:text-primary>a:hover{color:var(--primary)}.\\[\\&\\>button\\]\\:hidden>button{display:none}.\\[\\&\\>input\\]\\:flex-1>input{flex:1}.has-\\[\\>\\[data-align\\=block-end\\]\\]\\:\\[\\&\\>input\\]\\:pt-3:has(>[data-align=block-end])>input{padding-top:calc(var(--spacing)*3)}.has-\\[\\>\\[data-align\\=block-start\\]\\]\\:\\[\\&\\>input\\]\\:pb-3:has(>[data-align=block-start])>input{padding-bottom:calc(var(--spacing)*3)}.has-\\[\\>\\[data-align\\=inline-end\\]\\]\\:\\[\\&\\>input\\]\\:pr-2:has(>[data-align=inline-end])>input{padding-right:calc(var(--spacing)*2)}.has-\\[\\>\\[data-align\\=inline-start\\]\\]\\:\\[\\&\\>input\\]\\:pl-2:has(>[data-align=inline-start])>input{padding-left:calc(var(--spacing)*2)}.\\[\\&\\>kbd\\]\\:rounded-\\[calc\\(var\\(--radius\\)-5px\\)\\]>kbd{border-radius:calc(var(--radius) - 5px)}.\\[\\&\\>span\\:last-child\\]\\:truncate>span:last-child{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.\\[\\&\\>svg\\]\\:pointer-events-none>svg{pointer-events:none}.\\[\\&\\>svg\\]\\:size-3>svg{width:calc(var(--spacing)*3);height:calc(var(--spacing)*3)}.\\[\\&\\>svg\\]\\:size-3\\.5>svg{width:calc(var(--spacing)*3.5);height:calc(var(--spacing)*3.5)}.\\[\\&\\>svg\\]\\:size-4>svg{width:calc(var(--spacing)*4);height:calc(var(--spacing)*4)}.\\[\\&\\>svg\\]\\:h-2\\.5>svg{height:calc(var(--spacing)*2.5)}.\\[\\&\\>svg\\]\\:h-3>svg{height:calc(var(--spacing)*3)}.\\[\\&\\>svg\\]\\:w-2\\.5>svg{width:calc(var(--spacing)*2.5)}.\\[\\&\\>svg\\]\\:w-3>svg{width:calc(var(--spacing)*3)}.\\[\\&\\>svg\\]\\:shrink-0>svg{flex-shrink:0}.\\[\\&\\>svg\\]\\:translate-y-0\\.5>svg{--tw-translate-y:calc(var(--spacing)*.5);translate:var(--tw-translate-x)var(--tw-translate-y)}.\\[\\&\\>svg\\]\\:text-current>svg{color:currentColor}.\\[\\&\\>svg\\]\\:text-muted-foreground>svg{color:var(--muted-foreground)}.\\[\\&\\>svg\\]\\:text-sidebar-accent-foreground>svg{color:var(--sidebar-accent-foreground)}.\\[\\&\\>svg\\:not\\(\\[class\\*\\=\\'size-\\'\\]\\)\\]\\:size-3\\.5>svg:not([class*=size-]){width:calc(var(--spacing)*3.5);height:calc(var(--spacing)*3.5)}.\\[\\&\\>svg\\:not\\(\\[class\\*\\=\\'size-\\'\\]\\)\\]\\:size-4>svg:not([class*=size-]){width:calc(var(--spacing)*4);height:calc(var(--spacing)*4)}.\\[\\&\\>tr\\]\\:last\\:border-b-0>tr:last-child{border-bottom-style:var(--tw-border-style);border-bottom-width:0}.\\[\\&\\[data-orientation\\=vertical\\]\\>div\\]\\:rotate-90[data-orientation=vertical]>div{rotate:90deg}.\\[\\&\\[data-state\\=open\\]\\>svg\\]\\:rotate-180[data-state=open]>svg{rotate:180deg}.\\[\\&\\[data-today\\]\\:not\\(\\[data-selected\\]\\)\\]\\:bg-accent[data-today]:not([data-selected]){background-color:var(--accent)}.\\[\\&\\[data-today\\]\\:not\\(\\[data-selected\\]\\)\\]\\:text-accent-foreground[data-today]:not([data-selected]){color:var(--accent-foreground)}[data-side=left][data-collapsible=offcanvas] .\\[\\[data-side\\=left\\]\\[data-collapsible\\=offcanvas\\]_\\&\\]\\:-right-2{right:calc(var(--spacing)*-2)}[data-side=left][data-state=collapsed] .\\[\\[data-side\\=left\\]\\[data-state\\=collapsed\\]_\\&\\]\\:cursor-e-resize{cursor:e-resize}[data-side=right][data-collapsible=offcanvas] .\\[\\[data-side\\=right\\]\\[data-collapsible\\=offcanvas\\]_\\&\\]\\:-left-2{left:calc(var(--spacing)*-2)}[data-side=right][data-state=collapsed] .\\[\\[data-side\\=right\\]\\[data-state\\=collapsed\\]_\\&\\]\\:cursor-w-resize{cursor:w-resize}[data-slot=tooltip-content] .\\[\\[data-slot\\=tooltip-content\\]_\\&\\]\\:bg-background\\/20{background-color:var(--background)}@supports (color:color-mix(in lab,red,red)){[data-slot=tooltip-content] .\\[\\[data-slot\\=tooltip-content\\]_\\&\\]\\:bg-background\\/20{background-color:color-mix(in oklab,var(--background)20%,transparent)}}[data-slot=tooltip-content] .\\[\\[data-slot\\=tooltip-content\\]_\\&\\]\\:text-background{color:var(--background)}[data-slot=tooltip-content] .dark\\:\\[\\[data-slot\\=tooltip-content\\]_\\&\\]\\:bg-background\\/10:is(.dark *){background-color:var(--background)}@supports (color:color-mix(in lab,red,red)){[data-slot=tooltip-content] .dark\\:\\[\\[data-slot\\=tooltip-content\\]_\\&\\]\\:bg-background\\/10:is(.dark *){background-color:color-mix(in oklab,var(--background)10%,transparent)}}[data-variant=legend]+.\\[\\[data-variant\\=legend\\]\\+\\&\\]\\:-mt-1\\.5{margin-top:calc(var(--spacing)*-1.5)}@media (hover:hover){a.\\[a\\&\\]\\:hover\\:bg-accent:hover{background-color:var(--accent)}a.\\[a\\&\\]\\:hover\\:bg-destructive\\/90:hover{background-color:var(--destructive)}@supports (color:color-mix(in lab,red,red)){a.\\[a\\&\\]\\:hover\\:bg-destructive\\/90:hover{background-color:color-mix(in oklab,var(--destructive)90%,transparent)}}a.\\[a\\&\\]\\:hover\\:bg-primary\\/90:hover{background-color:var(--primary)}@supports (color:color-mix(in lab,red,red)){a.\\[a\\&\\]\\:hover\\:bg-primary\\/90:hover{background-color:color-mix(in oklab,var(--primary)90%,transparent)}}a.\\[a\\&\\]\\:hover\\:bg-secondary\\/90:hover{background-color:var(--secondary)}@supports (color:color-mix(in lab,red,red)){a.\\[a\\&\\]\\:hover\\:bg-secondary\\/90:hover{background-color:color-mix(in oklab,var(--secondary)90%,transparent)}}a.\\[a\\&\\]\\:hover\\:text-accent-foreground:hover{color:var(--accent-foreground)}}}@property --tw-animation-delay{syntax:"*";inherits:false;initial-value:0s}@property --tw-animation-direction{syntax:"*";inherits:false;initial-value:normal}@property --tw-animation-duration{syntax:"*";inherits:false}@property --tw-animation-fill-mode{syntax:"*";inherits:false;initial-value:none}@property --tw-animation-iteration-count{syntax:"*";inherits:false;initial-value:1}@property --tw-enter-opacity{syntax:"*";inherits:false;initial-value:1}@property --tw-enter-rotate{syntax:"*";inherits:false;initial-value:0}@property --tw-enter-scale{syntax:"*";inherits:false;initial-value:1}@property --tw-enter-translate-x{syntax:"*";inherits:false;initial-value:0}@property --tw-enter-translate-y{syntax:"*";inherits:false;initial-value:0}@property --tw-exit-opacity{syntax:"*";inherits:false;initial-value:1}@property --tw-exit-rotate{syntax:"*";inherits:false;initial-value:0}@property --tw-exit-scale{syntax:"*";inherits:false;initial-value:1}@property --tw-exit-translate-x{syntax:"*";inherits:false;initial-value:0}@property --tw-exit-translate-y{syntax:"*";inherits:false;initial-value:0}:root{--background:oklch(100% 0 0);--foreground:oklch(14.1% .005 285.823);--card:oklch(100% 0 0);--card-foreground:oklch(14.1% .005 285.823);--popover:oklch(100% 0 0);--popover-foreground:oklch(14.1% .005 285.823);--primary:oklch(21% .006 285.885);--primary-foreground:oklch(98.5% 0 0);--secondary:oklch(96.7% .001 286.375);--secondary-foreground:oklch(21% .006 285.885);--muted:oklch(96.7% .001 286.375);--muted-foreground:oklch(55.2% .016 285.938);--accent:oklch(96.7% .001 286.375);--accent-foreground:oklch(21% .006 285.885);--destructive:oklch(57.7% .245 27.325);--destructive-foreground:oklch(57.7% .245 27.325);--border:oklch(92% .004 286.32);--input:oklch(92% .004 286.32);--ring:oklch(70.5% .015 286.067);--chart-1:oklch(64.6% .222 41.116);--chart-2:oklch(60% .118 184.704);--chart-3:oklch(39.8% .07 227.392);--chart-4:oklch(82.8% .189 84.429);--chart-5:oklch(76.9% .188 70.08);--radius:.625rem;--sidebar:oklch(98.5% 0 0);--sidebar-foreground:oklch(14.1% .005 285.823);--sidebar-primary:oklch(21% .006 285.885);--sidebar-primary-foreground:oklch(98.5% 0 0);--sidebar-accent:oklch(96.7% .001 286.375);--sidebar-accent-foreground:oklch(21% .006 285.885);--sidebar-border:oklch(92% .004 286.32);--sidebar-ring:oklch(70.5% .015 286.067)}.dark{--background:oklch(14.1% .005 285.823);--foreground:oklch(98.5% 0 0);--card:oklch(14.1% .005 285.823);--card-foreground:oklch(98.5% 0 0);--popover:oklch(14.1% .005 285.823);--popover-foreground:oklch(98.5% 0 0);--primary:oklch(98.5% 0 0);--primary-foreground:oklch(21% .006 285.885);--secondary:oklch(27.4% .006 286.033);--secondary-foreground:oklch(98.5% 0 0);--muted:oklch(27.4% .006 286.033);--muted-foreground:oklch(70.5% .015 286.067);--accent:oklch(27.4% .006 286.033);--accent-foreground:oklch(98.5% 0 0);--destructive:oklch(39.6% .141 25.723);--destructive-foreground:oklch(63.7% .237 25.331);--border:oklch(27.4% .006 286.033);--input:oklch(27.4% .006 286.033);--ring:oklch(44.2% .017 285.786);--chart-1:oklch(48.8% .243 264.376);--chart-2:oklch(69.6% .17 162.48);--chart-3:oklch(76.9% .188 70.08);--chart-4:oklch(62.7% .265 303.9);--chart-5:oklch(64.5% .246 16.439);--sidebar:oklch(21% .006 285.885);--sidebar-foreground:oklch(98.5% 0 0);--sidebar-primary:oklch(48.8% .243 264.376);--sidebar-primary-foreground:oklch(98.5% 0 0);--sidebar-accent:oklch(27.4% .006 286.033);--sidebar-accent-foreground:oklch(98.5% 0 0);--sidebar-border:oklch(27.4% .006 286.033);--sidebar-ring:oklch(44.2% .017 285.786)}@property --tw-translate-x{syntax:"*";inherits:false;initial-value:0}@property --tw-translate-y{syntax:"*";inherits:false;initial-value:0}@property --tw-translate-z{syntax:"*";inherits:false;initial-value:0}@property --tw-rotate-x{syntax:"*";inherits:false}@property --tw-rotate-y{syntax:"*";inherits:false}@property --tw-rotate-z{syntax:"*";inherits:false}@property --tw-skew-x{syntax:"*";inherits:false}@property --tw-skew-y{syntax:"*";inherits:false}@property --tw-space-y-reverse{syntax:"*";inherits:false;initial-value:0}@property --tw-space-x-reverse{syntax:"*";inherits:false;initial-value:0}@property --tw-border-style{syntax:"*";inherits:false;initial-value:solid}@property --tw-gradient-position{syntax:"*";inherits:false}@property --tw-gradient-from{syntax:"<color>";inherits:false;initial-value:#0000}@property --tw-gradient-via{syntax:"<color>";inherits:false;initial-value:#0000}@property --tw-gradient-to{syntax:"<color>";inherits:false;initial-value:#0000}@property --tw-gradient-stops{syntax:"*";inherits:false}@property --tw-gradient-via-stops{syntax:"*";inherits:false}@property --tw-gradient-from-position{syntax:"<length-percentage>";inherits:false;initial-value:0%}@property --tw-gradient-via-position{syntax:"<length-percentage>";inherits:false;initial-value:50%}@property --tw-gradient-to-position{syntax:"<length-percentage>";inherits:false;initial-value:100%}@property --tw-leading{syntax:"*";inherits:false}@property --tw-font-weight{syntax:"*";inherits:false}@property --tw-tracking{syntax:"*";inherits:false}@property --tw-ordinal{syntax:"*";inherits:false}@property --tw-slashed-zero{syntax:"*";inherits:false}@property --tw-numeric-figure{syntax:"*";inherits:false}@property --tw-numeric-spacing{syntax:"*";inherits:false}@property --tw-numeric-fraction{syntax:"*";inherits:false}@property --tw-shadow{syntax:"*";inherits:false;initial-value:0 0 #0000}@property --tw-shadow-color{syntax:"*";inherits:false}@property --tw-shadow-alpha{syntax:"<percentage>";inherits:false;initial-value:100%}@property --tw-inset-shadow{syntax:"*";inherits:false;initial-value:0 0 #0000}@property --tw-inset-shadow-color{syntax:"*";inherits:false}@property --tw-inset-shadow-alpha{syntax:"<percentage>";inherits:false;initial-value:100%}@property --tw-ring-color{syntax:"*";inherits:false}@property --tw-ring-shadow{syntax:"*";inherits:false;initial-value:0 0 #0000}@property --tw-inset-ring-color{syntax:"*";inherits:false}@property --tw-inset-ring-shadow{syntax:"*";inherits:false;initial-value:0 0 #0000}@property --tw-ring-inset{syntax:"*";inherits:false}@property --tw-ring-offset-width{syntax:"<length>";inherits:false;initial-value:0}@property --tw-ring-offset-color{syntax:"*";inherits:false;initial-value:#fff}@property --tw-ring-offset-shadow{syntax:"*";inherits:false;initial-value:0 0 #0000}@property --tw-outline-style{syntax:"*";inherits:false;initial-value:solid}@property --tw-blur{syntax:"*";inherits:false}@property --tw-brightness{syntax:"*";inherits:false}@property --tw-contrast{syntax:"*";inherits:false}@property --tw-grayscale{syntax:"*";inherits:false}@property --tw-hue-rotate{syntax:"*";inherits:false}@property --tw-invert{syntax:"*";inherits:false}@property --tw-opacity{syntax:"*";inherits:false}@property --tw-saturate{syntax:"*";inherits:false}@property --tw-sepia{syntax:"*";inherits:false}@property --tw-drop-shadow{syntax:"*";inherits:false}@property --tw-drop-shadow-color{syntax:"*";inherits:false}@property --tw-drop-shadow-alpha{syntax:"<percentage>";inherits:false;initial-value:100%}@property --tw-drop-shadow-size{syntax:"*";inherits:false}@property --tw-backdrop-blur{syntax:"*";inherits:false}@property --tw-backdrop-brightness{syntax:"*";inherits:false}@property --tw-backdrop-contrast{syntax:"*";inherits:false}@property --tw-backdrop-grayscale{syntax:"*";inherits:false}@property --tw-backdrop-hue-rotate{syntax:"*";inherits:false}@property --tw-backdrop-invert{syntax:"*";inherits:false}@property --tw-backdrop-opacity{syntax:"*";inherits:false}@property --tw-backdrop-saturate{syntax:"*";inherits:false}@property --tw-backdrop-sepia{syntax:"*";inherits:false}@property --tw-duration{syntax:"*";inherits:false}@property --tw-ease{syntax:"*";inherits:false}@property --tw-content{syntax:"*";inherits:false;initial-value:""}@keyframes spin{to{transform:rotate(360deg)}}@keyframes pulse{50%{opacity:.5}}@keyframes enter{0%{opacity:var(--tw-enter-opacity,1);transform:translate3d(var(--tw-enter-translate-x,0),var(--tw-enter-translate-y,0),0)scale3d(var(--tw-enter-scale,1),var(--tw-enter-scale,1),var(--tw-enter-scale,1))rotate(var(--tw-enter-rotate,0))}}@keyframes exit{to{opacity:var(--tw-exit-opacity,1);transform:translate3d(var(--tw-exit-translate-x,0),var(--tw-exit-translate-y,0),0)scale3d(var(--tw-exit-scale,1),var(--tw-exit-scale,1),var(--tw-exit-scale,1))rotate(var(--tw-exit-rotate,0))}}@keyframes accordion-down{0%{height:0}to{height:var(--radix-accordion-content-height,var(--bits-accordion-content-height,var(--reka-accordion-content-height,var(--kb-accordion-content-height,auto))))}}@keyframes accordion-up{0%{height:var(--radix-accordion-content-height,var(--bits-accordion-content-height,var(--reka-accordion-content-height,var(--kb-accordion-content-height,auto))))}to{height:0}}@keyframes caret-blink{0%,70%,to{opacity:1}20%,50%{opacity:0}}`;
/**
* @vue/shared v3.5.18
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function rl(e) {
  const t = /* @__PURE__ */ Object.create(null);
  for (const r of e.split(",")) t[r] = 1;
  return (r) => r in t;
}
const je = {}, Ca = [], rr = () => {
}, hh = () => !1, Tn = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // uppercase letter
(e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97), al = (e) => e.startsWith("onUpdate:"), pt = Object.assign, ol = (e, t) => {
  const r = e.indexOf(t);
  r > -1 && e.splice(r, 1);
}, gh = Object.prototype.hasOwnProperty, Ne = (e, t) => gh.call(e, t), Ce = Array.isArray, Aa = (e) => Mn(e) === "[object Map]", qd = (e) => Mn(e) === "[object Set]", Se = (e) => typeof e == "function", Qe = (e) => typeof e == "string", Sr = (e) => typeof e == "symbol", We = (e) => e !== null && typeof e == "object", Ld = (e) => (We(e) || Se(e)) && Se(e.then) && Se(e.catch), Nd = Object.prototype.toString, Mn = (e) => Nd.call(e), mh = (e) => Mn(e).slice(8, -1), Vd = (e) => Mn(e) === "[object Object]", nl = (e) => Qe(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, to = /* @__PURE__ */ rl(
  // the leading comma is intentional so empty string "" is also included
  ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
), Rn = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return (r) => t[r] || (t[r] = e(r));
}, vh = /-(\w)/g, At = Rn(
  (e) => e.replace(vh, (t, r) => r ? r.toUpperCase() : "")
), bh = /\B([A-Z])/g, Wr = Rn(
  (e) => e.replace(bh, "-$1").toLowerCase()
), On = Rn((e) => e.charAt(0).toUpperCase() + e.slice(1)), ro = Rn(
  (e) => e ? `on${On(e)}` : ""
), Fr = (e, t) => !Object.is(e, t), rn = (e, ...t) => {
  for (let r = 0; r < e.length; r++)
    e[r](...t);
}, ui = (e, t, r, a = !1) => {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    writable: a,
    value: r
  });
}, di = (e) => {
  const t = parseFloat(e);
  return isNaN(t) ? e : t;
};
let sc;
const Bn = () => sc || (sc = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});
function Tt(e) {
  if (Ce(e)) {
    const t = {};
    for (let r = 0; r < e.length; r++) {
      const a = e[r], o = Qe(a) ? _h(a) : Tt(a);
      if (o)
        for (const n in o)
          t[n] = o[n];
    }
    return t;
  } else if (Qe(e) || We(e))
    return e;
}
const yh = /;(?![^(]*\))/g, wh = /:([^]+)/, xh = /\/\*[^]*?\*\//g;
function _h(e) {
  const t = {};
  return e.replace(xh, "").split(yh).forEach((r) => {
    if (r) {
      const a = r.split(wh);
      a.length > 1 && (t[a[0].trim()] = a[1].trim());
    }
  }), t;
}
function ke(e) {
  let t = "";
  if (Qe(e))
    t = e;
  else if (Ce(e))
    for (let r = 0; r < e.length; r++) {
      const a = ke(e[r]);
      a && (t += a + " ");
    }
  else if (We(e))
    for (const r in e)
      e[r] && (t += r + " ");
  return t.trim();
}
function De(e) {
  if (!e) return null;
  let { class: t, style: r } = e;
  return t && !Qe(t) && (e.class = ke(t)), r && (e.style = Tt(r)), e;
}
const kh = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", Ch = /* @__PURE__ */ rl(kh);
function Hd(e) {
  return !!e || e === "";
}
const Fd = (e) => !!(e && e.__v_isRef === !0), ue = (e) => Qe(e) ? e : e == null ? "" : Ce(e) || We(e) && (e.toString === Nd || !Se(e.toString)) ? Fd(e) ? ue(e.value) : JSON.stringify(e, zd, 2) : String(e), zd = (e, t) => Fd(t) ? zd(e, t.value) : Aa(t) ? {
  [`Map(${t.size})`]: [...t.entries()].reduce(
    (r, [a, o], n) => (r[ps(a, n) + " =>"] = o, r),
    {}
  )
} : qd(t) ? {
  [`Set(${t.size})`]: [...t.values()].map((r) => ps(r))
} : Sr(t) ? ps(t) : We(t) && !Ce(t) && !Vd(t) ? String(t) : t, ps = (e, t = "") => {
  var r;
  return (
    // Symbol.description in es2019+ so we need to cast here to pass
    // the lib: es2016 check
    Sr(e) ? `Symbol(${(r = e.description) != null ? r : t})` : e
  );
};
/**
* @vue/reactivity v3.5.18
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let lt;
class jd {
  constructor(t = !1) {
    this.detached = t, this._active = !0, this._on = 0, this.effects = [], this.cleanups = [], this._isPaused = !1, this.parent = lt, !t && lt && (this.index = (lt.scopes || (lt.scopes = [])).push(
      this
    ) - 1);
  }
  get active() {
    return this._active;
  }
  pause() {
    if (this._active) {
      this._isPaused = !0;
      let t, r;
      if (this.scopes)
        for (t = 0, r = this.scopes.length; t < r; t++)
          this.scopes[t].pause();
      for (t = 0, r = this.effects.length; t < r; t++)
        this.effects[t].pause();
    }
  }
  /**
   * Resumes the effect scope, including all child scopes and effects.
   */
  resume() {
    if (this._active && this._isPaused) {
      this._isPaused = !1;
      let t, r;
      if (this.scopes)
        for (t = 0, r = this.scopes.length; t < r; t++)
          this.scopes[t].resume();
      for (t = 0, r = this.effects.length; t < r; t++)
        this.effects[t].resume();
    }
  }
  run(t) {
    if (this._active) {
      const r = lt;
      try {
        return lt = this, t();
      } finally {
        lt = r;
      }
    }
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  on() {
    ++this._on === 1 && (this.prevScope = lt, lt = this);
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  off() {
    this._on > 0 && --this._on === 0 && (lt = this.prevScope, this.prevScope = void 0);
  }
  stop(t) {
    if (this._active) {
      this._active = !1;
      let r, a;
      for (r = 0, a = this.effects.length; r < a; r++)
        this.effects[r].stop();
      for (this.effects.length = 0, r = 0, a = this.cleanups.length; r < a; r++)
        this.cleanups[r]();
      if (this.cleanups.length = 0, this.scopes) {
        for (r = 0, a = this.scopes.length; r < a; r++)
          this.scopes[r].stop(!0);
        this.scopes.length = 0;
      }
      if (!this.detached && this.parent && !t) {
        const o = this.parent.scopes.pop();
        o && o !== this && (this.parent.scopes[this.index] = o, o.index = this.index);
      }
      this.parent = void 0;
    }
  }
}
function Dn(e) {
  return new jd(e);
}
function $o() {
  return lt;
}
function In(e, t = !1) {
  lt && lt.cleanups.push(e);
}
let Ze;
const hs = /* @__PURE__ */ new WeakSet();
class Ud {
  constructor(t) {
    this.fn = t, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, lt && lt.active && lt.effects.push(this);
  }
  pause() {
    this.flags |= 64;
  }
  resume() {
    this.flags & 64 && (this.flags &= -65, hs.has(this) && (hs.delete(this), this.trigger()));
  }
  /**
   * @internal
   */
  notify() {
    this.flags & 2 && !(this.flags & 32) || this.flags & 8 || Kd(this);
  }
  run() {
    if (!(this.flags & 1))
      return this.fn();
    this.flags |= 2, ic(this), Wd(this);
    const t = Ze, r = Lt;
    Ze = this, Lt = !0;
    try {
      return this.fn();
    } finally {
      Gd(this), Ze = t, Lt = r, this.flags &= -3;
    }
  }
  stop() {
    if (this.flags & 1) {
      for (let t = this.deps; t; t = t.nextDep)
        ll(t);
      this.deps = this.depsTail = void 0, ic(this), this.onStop && this.onStop(), this.flags &= -2;
    }
  }
  trigger() {
    this.flags & 64 ? hs.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty();
  }
  /**
   * @internal
   */
  runIfDirty() {
    fi(this) && this.run();
  }
  get dirty() {
    return fi(this);
  }
}
let Zd = 0, ao, oo;
function Kd(e, t = !1) {
  if (e.flags |= 8, t) {
    e.next = oo, oo = e;
    return;
  }
  e.next = ao, ao = e;
}
function sl() {
  Zd++;
}
function il() {
  if (--Zd > 0)
    return;
  if (oo) {
    let t = oo;
    for (oo = void 0; t; ) {
      const r = t.next;
      t.next = void 0, t.flags &= -9, t = r;
    }
  }
  let e;
  for (; ao; ) {
    let t = ao;
    for (ao = void 0; t; ) {
      const r = t.next;
      if (t.next = void 0, t.flags &= -9, t.flags & 1)
        try {
          t.trigger();
        } catch (a) {
          e || (e = a);
        }
      t = r;
    }
  }
  if (e) throw e;
}
function Wd(e) {
  for (let t = e.deps; t; t = t.nextDep)
    t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t;
}
function Gd(e) {
  let t, r = e.depsTail, a = r;
  for (; a; ) {
    const o = a.prevDep;
    a.version === -1 ? (a === r && (r = o), ll(a), Ah(a)) : t = a, a.dep.activeLink = a.prevActiveLink, a.prevActiveLink = void 0, a = o;
  }
  e.deps = t, e.depsTail = r;
}
function fi(e) {
  for (let t = e.deps; t; t = t.nextDep)
    if (t.dep.version !== t.version || t.dep.computed && (Jd(t.dep.computed) || t.dep.version !== t.version))
      return !0;
  return !!e._dirty;
}
function Jd(e) {
  if (e.flags & 4 && !(e.flags & 16) || (e.flags &= -17, e.globalVersion === go) || (e.globalVersion = go, !e.isSSR && e.flags & 128 && (!e.deps && !e._dirty || !fi(e))))
    return;
  e.flags |= 2;
  const t = e.dep, r = Ze, a = Lt;
  Ze = e, Lt = !0;
  try {
    Wd(e);
    const o = e.fn(e._value);
    (t.version === 0 || Fr(o, e._value)) && (e.flags |= 128, e._value = o, t.version++);
  } catch (o) {
    throw t.version++, o;
  } finally {
    Ze = r, Lt = a, Gd(e), e.flags &= -3;
  }
}
function ll(e, t = !1) {
  const { dep: r, prevSub: a, nextSub: o } = e;
  if (a && (a.nextSub = o, e.prevSub = void 0), o && (o.prevSub = a, e.nextSub = void 0), r.subs === e && (r.subs = a, !a && r.computed)) {
    r.computed.flags &= -5;
    for (let n = r.computed.deps; n; n = n.nextDep)
      ll(n, !0);
  }
  !t && !--r.sc && r.map && r.map.delete(r.key);
}
function Ah(e) {
  const { prevDep: t, nextDep: r } = e;
  t && (t.nextDep = r, e.prevDep = void 0), r && (r.prevDep = t, e.nextDep = void 0);
}
let Lt = !0;
const Yd = [];
function _r() {
  Yd.push(Lt), Lt = !1;
}
function kr() {
  const e = Yd.pop();
  Lt = e === void 0 ? !0 : e;
}
function ic(e) {
  const { cleanup: t } = e;
  if (e.cleanup = void 0, t) {
    const r = Ze;
    Ze = void 0;
    try {
      t();
    } finally {
      Ze = r;
    }
  }
}
let go = 0;
class Sh {
  constructor(t, r) {
    this.sub = t, this.dep = r, this.version = r.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
  }
}
class qn {
  // TODO isolatedDeclarations "__v_skip"
  constructor(t) {
    this.computed = t, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.__v_skip = !0;
  }
  track(t) {
    if (!Ze || !Lt || Ze === this.computed)
      return;
    let r = this.activeLink;
    if (r === void 0 || r.sub !== Ze)
      r = this.activeLink = new Sh(Ze, this), Ze.deps ? (r.prevDep = Ze.depsTail, Ze.depsTail.nextDep = r, Ze.depsTail = r) : Ze.deps = Ze.depsTail = r, Xd(r);
    else if (r.version === -1 && (r.version = this.version, r.nextDep)) {
      const a = r.nextDep;
      a.prevDep = r.prevDep, r.prevDep && (r.prevDep.nextDep = a), r.prevDep = Ze.depsTail, r.nextDep = void 0, Ze.depsTail.nextDep = r, Ze.depsTail = r, Ze.deps === r && (Ze.deps = a);
    }
    return r;
  }
  trigger(t) {
    this.version++, go++, this.notify(t);
  }
  notify(t) {
    sl();
    try {
      for (let r = this.subs; r; r = r.prevSub)
        r.sub.notify() && r.sub.dep.notify();
    } finally {
      il();
    }
  }
}
function Xd(e) {
  if (e.dep.sc++, e.sub.flags & 4) {
    const t = e.dep.computed;
    if (t && !e.dep.subs) {
      t.flags |= 20;
      for (let a = t.deps; a; a = a.nextDep)
        Xd(a);
    }
    const r = e.dep.subs;
    r !== e && (e.prevSub = r, r && (r.nextSub = e)), e.dep.subs = e;
  }
}
const gn = /* @__PURE__ */ new WeakMap(), aa = Symbol(
  ""
), pi = Symbol(
  ""
), mo = Symbol(
  ""
);
function ct(e, t, r) {
  if (Lt && Ze) {
    let a = gn.get(e);
    a || gn.set(e, a = /* @__PURE__ */ new Map());
    let o = a.get(r);
    o || (a.set(r, o = new qn()), o.map = a, o.key = r), o.track();
  }
}
function vr(e, t, r, a, o, n) {
  const s = gn.get(e);
  if (!s) {
    go++;
    return;
  }
  const i = (l) => {
    l && l.trigger();
  };
  if (sl(), t === "clear")
    s.forEach(i);
  else {
    const l = Ce(e), c = l && nl(r);
    if (l && r === "length") {
      const u = Number(a);
      s.forEach((f, p) => {
        (p === "length" || p === mo || !Sr(p) && p >= u) && i(f);
      });
    } else
      switch ((r !== void 0 || s.has(void 0)) && i(s.get(r)), c && i(s.get(mo)), t) {
        case "add":
          l ? c && i(s.get("length")) : (i(s.get(aa)), Aa(e) && i(s.get(pi)));
          break;
        case "delete":
          l || (i(s.get(aa)), Aa(e) && i(s.get(pi)));
          break;
        case "set":
          Aa(e) && i(s.get(aa));
          break;
      }
  }
  il();
}
function Eh(e, t) {
  const r = gn.get(e);
  return r && r.get(t);
}
function pa(e) {
  const t = qe(e);
  return t === e ? t : (ct(t, "iterate", mo), Bt(e) ? t : t.map(nt));
}
function Ln(e) {
  return ct(e = qe(e), "iterate", mo), e;
}
const $h = {
  __proto__: null,
  [Symbol.iterator]() {
    return gs(this, Symbol.iterator, nt);
  },
  concat(...e) {
    return pa(this).concat(
      ...e.map((t) => Ce(t) ? pa(t) : t)
    );
  },
  entries() {
    return gs(this, "entries", (e) => (e[1] = nt(e[1]), e));
  },
  every(e, t) {
    return pr(this, "every", e, t, void 0, arguments);
  },
  filter(e, t) {
    return pr(this, "filter", e, t, (r) => r.map(nt), arguments);
  },
  find(e, t) {
    return pr(this, "find", e, t, nt, arguments);
  },
  findIndex(e, t) {
    return pr(this, "findIndex", e, t, void 0, arguments);
  },
  findLast(e, t) {
    return pr(this, "findLast", e, t, nt, arguments);
  },
  findLastIndex(e, t) {
    return pr(this, "findLastIndex", e, t, void 0, arguments);
  },
  // flat, flatMap could benefit from ARRAY_ITERATE but are not straight-forward to implement
  forEach(e, t) {
    return pr(this, "forEach", e, t, void 0, arguments);
  },
  includes(...e) {
    return ms(this, "includes", e);
  },
  indexOf(...e) {
    return ms(this, "indexOf", e);
  },
  join(e) {
    return pa(this).join(e);
  },
  // keys() iterator only reads `length`, no optimisation required
  lastIndexOf(...e) {
    return ms(this, "lastIndexOf", e);
  },
  map(e, t) {
    return pr(this, "map", e, t, void 0, arguments);
  },
  pop() {
    return Ua(this, "pop");
  },
  push(...e) {
    return Ua(this, "push", e);
  },
  reduce(e, ...t) {
    return lc(this, "reduce", e, t);
  },
  reduceRight(e, ...t) {
    return lc(this, "reduceRight", e, t);
  },
  shift() {
    return Ua(this, "shift");
  },
  // slice could use ARRAY_ITERATE but also seems to beg for range tracking
  some(e, t) {
    return pr(this, "some", e, t, void 0, arguments);
  },
  splice(...e) {
    return Ua(this, "splice", e);
  },
  toReversed() {
    return pa(this).toReversed();
  },
  toSorted(e) {
    return pa(this).toSorted(e);
  },
  toSpliced(...e) {
    return pa(this).toSpliced(...e);
  },
  unshift(...e) {
    return Ua(this, "unshift", e);
  },
  values() {
    return gs(this, "values", nt);
  }
};
function gs(e, t, r) {
  const a = Ln(e), o = a[t]();
  return a !== e && !Bt(e) && (o._next = o.next, o.next = () => {
    const n = o._next();
    return n.value && (n.value = r(n.value)), n;
  }), o;
}
const Ph = Array.prototype;
function pr(e, t, r, a, o, n) {
  const s = Ln(e), i = s !== e && !Bt(e), l = s[t];
  if (l !== Ph[t]) {
    const f = l.apply(e, n);
    return i ? nt(f) : f;
  }
  let c = r;
  s !== e && (i ? c = function(f, p) {
    return r.call(this, nt(f), p, e);
  } : r.length > 2 && (c = function(f, p) {
    return r.call(this, f, p, e);
  }));
  const u = l.call(s, c, a);
  return i && o ? o(u) : u;
}
function lc(e, t, r, a) {
  const o = Ln(e);
  let n = r;
  return o !== e && (Bt(e) ? r.length > 3 && (n = function(s, i, l) {
    return r.call(this, s, i, l, e);
  }) : n = function(s, i, l) {
    return r.call(this, s, nt(i), l, e);
  }), o[t](n, ...a);
}
function ms(e, t, r) {
  const a = qe(e);
  ct(a, "iterate", mo);
  const o = a[t](...r);
  return (o === -1 || o === !1) && ul(r[0]) ? (r[0] = qe(r[0]), a[t](...r)) : o;
}
function Ua(e, t, r = []) {
  _r(), sl();
  const a = qe(e)[t].apply(e, r);
  return il(), kr(), a;
}
const Th = /* @__PURE__ */ rl("__proto__,__v_isRef,__isVue"), Qd = new Set(
  /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(Sr)
);
function Mh(e) {
  Sr(e) || (e = String(e));
  const t = qe(this);
  return ct(t, "has", e), t.hasOwnProperty(e);
}
class ef {
  constructor(t = !1, r = !1) {
    this._isReadonly = t, this._isShallow = r;
  }
  get(t, r, a) {
    if (r === "__v_skip") return t.__v_skip;
    const o = this._isReadonly, n = this._isShallow;
    if (r === "__v_isReactive")
      return !o;
    if (r === "__v_isReadonly")
      return o;
    if (r === "__v_isShallow")
      return n;
    if (r === "__v_raw")
      return a === (o ? n ? sf : nf : n ? of : af).get(t) || // receiver is not the reactive proxy, but has the same prototype
      // this means the receiver is a user proxy of the reactive proxy
      Object.getPrototypeOf(t) === Object.getPrototypeOf(a) ? t : void 0;
    const s = Ce(t);
    if (!o) {
      let l;
      if (s && (l = $h[r]))
        return l;
      if (r === "hasOwnProperty")
        return Mh;
    }
    const i = Reflect.get(
      t,
      r,
      // if this is a proxy wrapping a ref, return methods using the raw ref
      // as receiver so that we don't have to call `toRaw` on the ref in all
      // its class methods
      Ve(t) ? t : a
    );
    return (Sr(r) ? Qd.has(r) : Th(r)) || (o || ct(t, "get", r), n) ? i : Ve(i) ? s && nl(r) ? i : i.value : We(i) ? o ? cl(i) : Rt(i) : i;
  }
}
class tf extends ef {
  constructor(t = !1) {
    super(!1, t);
  }
  set(t, r, a, o) {
    let n = t[r];
    if (!this._isShallow) {
      const l = Ur(n);
      if (!Bt(a) && !Ur(a) && (n = qe(n), a = qe(a)), !Ce(t) && Ve(n) && !Ve(a))
        return l ? !1 : (n.value = a, !0);
    }
    const s = Ce(t) && nl(r) ? Number(r) < t.length : Ne(t, r), i = Reflect.set(
      t,
      r,
      a,
      Ve(t) ? t : o
    );
    return t === qe(o) && (s ? Fr(a, n) && vr(t, "set", r, a) : vr(t, "add", r, a)), i;
  }
  deleteProperty(t, r) {
    const a = Ne(t, r);
    t[r];
    const o = Reflect.deleteProperty(t, r);
    return o && a && vr(t, "delete", r, void 0), o;
  }
  has(t, r) {
    const a = Reflect.has(t, r);
    return (!Sr(r) || !Qd.has(r)) && ct(t, "has", r), a;
  }
  ownKeys(t) {
    return ct(
      t,
      "iterate",
      Ce(t) ? "length" : aa
    ), Reflect.ownKeys(t);
  }
}
class rf extends ef {
  constructor(t = !1) {
    super(!0, t);
  }
  set(t, r) {
    return !0;
  }
  deleteProperty(t, r) {
    return !0;
  }
}
const Rh = /* @__PURE__ */ new tf(), Oh = /* @__PURE__ */ new rf(), Bh = /* @__PURE__ */ new tf(!0), Dh = /* @__PURE__ */ new rf(!0), hi = (e) => e, Ho = (e) => Reflect.getPrototypeOf(e);
function Ih(e, t, r) {
  return function(...a) {
    const o = this.__v_raw, n = qe(o), s = Aa(n), i = e === "entries" || e === Symbol.iterator && s, l = e === "keys" && s, c = o[e](...a), u = r ? hi : t ? mn : nt;
    return !t && ct(
      n,
      "iterate",
      l ? pi : aa
    ), {
      // iterator protocol
      next() {
        const { value: f, done: p } = c.next();
        return p ? { value: f, done: p } : {
          value: i ? [u(f[0]), u(f[1])] : u(f),
          done: p
        };
      },
      // iterable protocol
      [Symbol.iterator]() {
        return this;
      }
    };
  };
}
function Fo(e) {
  return function(...t) {
    return e === "delete" ? !1 : e === "clear" ? void 0 : this;
  };
}
function qh(e, t) {
  const r = {
    get(o) {
      const n = this.__v_raw, s = qe(n), i = qe(o);
      e || (Fr(o, i) && ct(s, "get", o), ct(s, "get", i));
      const { has: l } = Ho(s), c = t ? hi : e ? mn : nt;
      if (l.call(s, o))
        return c(n.get(o));
      if (l.call(s, i))
        return c(n.get(i));
      n !== s && n.get(o);
    },
    get size() {
      const o = this.__v_raw;
      return !e && ct(qe(o), "iterate", aa), Reflect.get(o, "size", o);
    },
    has(o) {
      const n = this.__v_raw, s = qe(n), i = qe(o);
      return e || (Fr(o, i) && ct(s, "has", o), ct(s, "has", i)), o === i ? n.has(o) : n.has(o) || n.has(i);
    },
    forEach(o, n) {
      const s = this, i = s.__v_raw, l = qe(i), c = t ? hi : e ? mn : nt;
      return !e && ct(l, "iterate", aa), i.forEach((u, f) => o.call(n, c(u), c(f), s));
    }
  };
  return pt(
    r,
    e ? {
      add: Fo("add"),
      set: Fo("set"),
      delete: Fo("delete"),
      clear: Fo("clear")
    } : {
      add(o) {
        !t && !Bt(o) && !Ur(o) && (o = qe(o));
        const n = qe(this);
        return Ho(n).has.call(n, o) || (n.add(o), vr(n, "add", o, o)), this;
      },
      set(o, n) {
        !t && !Bt(n) && !Ur(n) && (n = qe(n));
        const s = qe(this), { has: i, get: l } = Ho(s);
        let c = i.call(s, o);
        c || (o = qe(o), c = i.call(s, o));
        const u = l.call(s, o);
        return s.set(o, n), c ? Fr(n, u) && vr(s, "set", o, n) : vr(s, "add", o, n), this;
      },
      delete(o) {
        const n = qe(this), { has: s, get: i } = Ho(n);
        let l = s.call(n, o);
        l || (o = qe(o), l = s.call(n, o)), i && i.call(n, o);
        const c = n.delete(o);
        return l && vr(n, "delete", o, void 0), c;
      },
      clear() {
        const o = qe(this), n = o.size !== 0, s = o.clear();
        return n && vr(
          o,
          "clear",
          void 0,
          void 0
        ), s;
      }
    }
  ), [
    "keys",
    "values",
    "entries",
    Symbol.iterator
  ].forEach((o) => {
    r[o] = Ih(o, e, t);
  }), r;
}
function Nn(e, t) {
  const r = qh(e, t);
  return (a, o, n) => o === "__v_isReactive" ? !e : o === "__v_isReadonly" ? e : o === "__v_raw" ? a : Reflect.get(
    Ne(r, o) && o in a ? r : a,
    o,
    n
  );
}
const Lh = {
  get: /* @__PURE__ */ Nn(!1, !1)
}, Nh = {
  get: /* @__PURE__ */ Nn(!1, !0)
}, Vh = {
  get: /* @__PURE__ */ Nn(!0, !1)
}, Hh = {
  get: /* @__PURE__ */ Nn(!0, !0)
}, af = /* @__PURE__ */ new WeakMap(), of = /* @__PURE__ */ new WeakMap(), nf = /* @__PURE__ */ new WeakMap(), sf = /* @__PURE__ */ new WeakMap();
function Fh(e) {
  switch (e) {
    case "Object":
    case "Array":
      return 1;
    case "Map":
    case "Set":
    case "WeakMap":
    case "WeakSet":
      return 2;
    default:
      return 0;
  }
}
function zh(e) {
  return e.__v_skip || !Object.isExtensible(e) ? 0 : Fh(mh(e));
}
function Rt(e) {
  return Ur(e) ? e : Vn(
    e,
    !1,
    Rh,
    Lh,
    af
  );
}
function lf(e) {
  return Vn(
    e,
    !1,
    Bh,
    Nh,
    of
  );
}
function cl(e) {
  return Vn(
    e,
    !0,
    Oh,
    Vh,
    nf
  );
}
function ea(e) {
  return Vn(
    e,
    !0,
    Dh,
    Hh,
    sf
  );
}
function Vn(e, t, r, a, o) {
  if (!We(e) || e.__v_raw && !(t && e.__v_isReactive))
    return e;
  const n = zh(e);
  if (n === 0)
    return e;
  const s = o.get(e);
  if (s)
    return s;
  const i = new Proxy(
    e,
    n === 2 ? a : r
  );
  return o.set(e, i), i;
}
function zr(e) {
  return Ur(e) ? zr(e.__v_raw) : !!(e && e.__v_isReactive);
}
function Ur(e) {
  return !!(e && e.__v_isReadonly);
}
function Bt(e) {
  return !!(e && e.__v_isShallow);
}
function ul(e) {
  return e ? !!e.__v_raw : !1;
}
function qe(e) {
  const t = e && e.__v_raw;
  return t ? qe(t) : e;
}
function Hn(e) {
  return !Ne(e, "__v_skip") && Object.isExtensible(e) && ui(e, "__v_skip", !0), e;
}
const nt = (e) => We(e) ? Rt(e) : e, mn = (e) => We(e) ? cl(e) : e;
function Ve(e) {
  return e ? e.__v_isRef === !0 : !1;
}
function K(e) {
  return cf(e, !1);
}
function ar(e) {
  return cf(e, !0);
}
function cf(e, t) {
  return Ve(e) ? e : new jh(e, t);
}
class jh {
  constructor(t, r) {
    this.dep = new qn(), this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = r ? t : qe(t), this._value = r ? t : nt(t), this.__v_isShallow = r;
  }
  get value() {
    return this.dep.track(), this._value;
  }
  set value(t) {
    const r = this._rawValue, a = this.__v_isShallow || Bt(t) || Ur(t);
    t = a ? t : qe(t), Fr(t, r) && (this._rawValue = t, this._value = a ? t : nt(t), this.dep.trigger());
  }
}
function d(e) {
  return Ve(e) ? e.value : e;
}
function Je(e) {
  return Se(e) ? e() : d(e);
}
const Uh = {
  get: (e, t, r) => t === "__v_raw" ? e : d(Reflect.get(e, t, r)),
  set: (e, t, r, a) => {
    const o = e[t];
    return Ve(o) && !Ve(r) ? (o.value = r, !0) : Reflect.set(e, t, r, a);
  }
};
function uf(e) {
  return zr(e) ? e : new Proxy(e, Uh);
}
class Zh {
  constructor(t) {
    this.__v_isRef = !0, this._value = void 0;
    const r = this.dep = new qn(), { get: a, set: o } = t(r.track.bind(r), r.trigger.bind(r));
    this._get = a, this._set = o;
  }
  get value() {
    return this._value = this._get();
  }
  set value(t) {
    this._set(t);
  }
}
function Kh(e) {
  return new Zh(e);
}
function ht(e) {
  const t = Ce(e) ? new Array(e.length) : {};
  for (const r in e)
    t[r] = df(e, r);
  return t;
}
class Wh {
  constructor(t, r, a) {
    this._object = t, this._key = r, this._defaultValue = a, this.__v_isRef = !0, this._value = void 0;
  }
  get value() {
    const t = this._object[this._key];
    return this._value = t === void 0 ? this._defaultValue : t;
  }
  set value(t) {
    this._object[this._key] = t;
  }
  get dep() {
    return Eh(qe(this._object), this._key);
  }
}
class Gh {
  constructor(t) {
    this._getter = t, this.__v_isRef = !0, this.__v_isReadonly = !0, this._value = void 0;
  }
  get value() {
    return this._value = this._getter();
  }
}
function Jh(e, t, r) {
  return Ve(e) ? e : Se(e) ? new Gh(e) : We(e) && arguments.length > 1 ? df(e, t, r) : K(e);
}
function df(e, t, r) {
  const a = e[t];
  return Ve(a) ? a : new Wh(e, t, r);
}
class Yh {
  constructor(t, r, a) {
    this.fn = t, this.setter = r, this._value = void 0, this.dep = new qn(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = go - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !r, this.isSSR = a;
  }
  /**
   * @internal
   */
  notify() {
    if (this.flags |= 16, !(this.flags & 8) && // avoid infinite self recursion
    Ze !== this)
      return Kd(this, !0), !0;
  }
  get value() {
    const t = this.dep.track();
    return Jd(this), t && (t.version = this.dep.version), this._value;
  }
  set value(t) {
    this.setter && this.setter(t);
  }
}
function Xh(e, t, r = !1) {
  let a, o;
  return Se(e) ? a = e : (a = e.get, o = e.set), new Yh(a, o, r);
}
const zo = {}, vn = /* @__PURE__ */ new WeakMap();
let ta;
function Qh(e, t = !1, r = ta) {
  if (r) {
    let a = vn.get(r);
    a || vn.set(r, a = []), a.push(e);
  }
}
function eg(e, t, r = je) {
  const { immediate: a, deep: o, once: n, scheduler: s, augmentJob: i, call: l } = r, c = (T) => o ? T : Bt(T) || o === !1 || o === 0 ? br(T, 1) : br(T);
  let u, f, p, h, m = !1, v = !1;
  if (Ve(e) ? (f = () => e.value, m = Bt(e)) : zr(e) ? (f = () => c(e), m = !0) : Ce(e) ? (v = !0, m = e.some((T) => zr(T) || Bt(T)), f = () => e.map((T) => {
    if (Ve(T))
      return T.value;
    if (zr(T))
      return c(T);
    if (Se(T))
      return l ? l(T, 2) : T();
  })) : Se(e) ? t ? f = l ? () => l(e, 2) : e : f = () => {
    if (p) {
      _r();
      try {
        p();
      } finally {
        kr();
      }
    }
    const T = ta;
    ta = u;
    try {
      return l ? l(e, 3, [h]) : e(h);
    } finally {
      ta = T;
    }
  } : f = rr, t && o) {
    const T = f, F = o === !0 ? 1 / 0 : o;
    f = () => br(T(), F);
  }
  const x = $o(), C = () => {
    u.stop(), x && x.active && ol(x.effects, u);
  };
  if (n && t) {
    const T = t;
    t = (...F) => {
      T(...F), C();
    };
  }
  let S = v ? new Array(e.length).fill(zo) : zo;
  const E = (T) => {
    if (!(!(u.flags & 1) || !u.dirty && !T))
      if (t) {
        const F = u.run();
        if (o || m || (v ? F.some((j, H) => Fr(j, S[H])) : Fr(F, S))) {
          p && p();
          const j = ta;
          ta = u;
          try {
            const H = [
              F,
              // pass undefined as the old value when it's changed for the first time
              S === zo ? void 0 : v && S[0] === zo ? [] : S,
              h
            ];
            S = F, l ? l(t, 3, H) : (
              // @ts-expect-error
              t(...H)
            );
          } finally {
            ta = j;
          }
        }
      } else
        u.run();
  };
  return i && i(E), u = new Ud(f), u.scheduler = s ? () => s(E, !1) : E, h = (T) => Qh(T, !1, u), p = u.onStop = () => {
    const T = vn.get(u);
    if (T) {
      if (l)
        l(T, 4);
      else
        for (const F of T) F();
      vn.delete(u);
    }
  }, t ? a ? E(!0) : S = u.run() : s ? s(E.bind(null, !0), !0) : u.run(), C.pause = u.pause.bind(u), C.resume = u.resume.bind(u), C.stop = C, C;
}
function br(e, t = 1 / 0, r) {
  if (t <= 0 || !We(e) || e.__v_skip || (r = r || /* @__PURE__ */ new Set(), r.has(e)))
    return e;
  if (r.add(e), t--, Ve(e))
    br(e.value, t, r);
  else if (Ce(e))
    for (let a = 0; a < e.length; a++)
      br(e[a], t, r);
  else if (qd(e) || Aa(e))
    e.forEach((a) => {
      br(a, t, r);
    });
  else if (Vd(e)) {
    for (const a in e)
      br(e[a], t, r);
    for (const a of Object.getOwnPropertySymbols(e))
      Object.prototype.propertyIsEnumerable.call(e, a) && br(e[a], t, r);
  }
  return e;
}
/**
* @vue/runtime-core v3.5.18
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
function Po(e, t, r, a) {
  try {
    return a ? e(...a) : e();
  } catch (o) {
    Fn(o, t, r);
  }
}
function nr(e, t, r, a) {
  if (Se(e)) {
    const o = Po(e, t, r, a);
    return o && Ld(o) && o.catch((n) => {
      Fn(n, t, r);
    }), o;
  }
  if (Ce(e)) {
    const o = [];
    for (let n = 0; n < e.length; n++)
      o.push(nr(e[n], t, r, a));
    return o;
  }
}
function Fn(e, t, r, a = !0) {
  const o = t ? t.vnode : null, { errorHandler: n, throwUnhandledErrorInProduction: s } = t && t.appContext.config || je;
  if (t) {
    let i = t.parent;
    const l = t.proxy, c = `https://vuejs.org/error-reference/#runtime-${r}`;
    for (; i; ) {
      const u = i.ec;
      if (u) {
        for (let f = 0; f < u.length; f++)
          if (u[f](e, l, c) === !1)
            return;
      }
      i = i.parent;
    }
    if (n) {
      _r(), Po(n, null, 10, [
        e,
        l,
        c
      ]), kr();
      return;
    }
  }
  tg(e, r, o, a, s);
}
function tg(e, t, r, a = !0, o = !1) {
  if (o)
    throw e;
  console.error(e);
}
const vt = [];
let Jt = -1;
const Sa = [];
let Lr = null, ya = 0;
const ff = /* @__PURE__ */ Promise.resolve();
let bn = null;
function et(e) {
  const t = bn || ff;
  return e ? t.then(this ? e.bind(this) : e) : t;
}
function rg(e) {
  let t = Jt + 1, r = vt.length;
  for (; t < r; ) {
    const a = t + r >>> 1, o = vt[a], n = vo(o);
    n < e || n === e && o.flags & 2 ? t = a + 1 : r = a;
  }
  return t;
}
function dl(e) {
  if (!(e.flags & 1)) {
    const t = vo(e), r = vt[vt.length - 1];
    !r || // fast path when the job id is larger than the tail
    !(e.flags & 2) && t >= vo(r) ? vt.push(e) : vt.splice(rg(t), 0, e), e.flags |= 1, pf();
  }
}
function pf() {
  bn || (bn = ff.then(gf));
}
function ag(e) {
  Ce(e) ? Sa.push(...e) : Lr && e.id === -1 ? Lr.splice(ya + 1, 0, e) : e.flags & 1 || (Sa.push(e), e.flags |= 1), pf();
}
function cc(e, t, r = Jt + 1) {
  for (; r < vt.length; r++) {
    const a = vt[r];
    if (a && a.flags & 2) {
      if (e && a.id !== e.uid)
        continue;
      vt.splice(r, 1), r--, a.flags & 4 && (a.flags &= -2), a(), a.flags & 4 || (a.flags &= -2);
    }
  }
}
function hf(e) {
  if (Sa.length) {
    const t = [...new Set(Sa)].sort(
      (r, a) => vo(r) - vo(a)
    );
    if (Sa.length = 0, Lr) {
      Lr.push(...t);
      return;
    }
    for (Lr = t, ya = 0; ya < Lr.length; ya++) {
      const r = Lr[ya];
      r.flags & 4 && (r.flags &= -2), r.flags & 8 || r(), r.flags &= -2;
    }
    Lr = null, ya = 0;
  }
}
const vo = (e) => e.id == null ? e.flags & 2 ? -1 : 1 / 0 : e.id;
function gf(e) {
  try {
    for (Jt = 0; Jt < vt.length; Jt++) {
      const t = vt[Jt];
      t && !(t.flags & 8) && (t.flags & 4 && (t.flags &= -2), Po(
        t,
        t.i,
        t.i ? 15 : 14
      ), t.flags & 4 || (t.flags &= -2));
    }
  } finally {
    for (; Jt < vt.length; Jt++) {
      const t = vt[Jt];
      t && (t.flags &= -2);
    }
    Jt = -1, vt.length = 0, hf(), bn = null, (vt.length || Sa.length) && gf();
  }
}
let st = null, mf = null;
function yn(e) {
  const t = st;
  return st = e, mf = e && e.type.__scopeId || null, t;
}
function b(e, t = st, r) {
  if (!t || e._n)
    return e;
  const a = (...o) => {
    a._d && xc(-1);
    const n = yn(t);
    let s;
    try {
      s = e(...o);
    } finally {
      yn(n), a._d && xc(1);
    }
    return s;
  };
  return a._n = !0, a._c = !0, a._d = !0, a;
}
function og(e, t) {
  if (st === null)
    return e;
  const r = Wn(st), a = e.dirs || (e.dirs = []);
  for (let o = 0; o < t.length; o++) {
    let [n, s, i, l = je] = t[o];
    n && (Se(n) && (n = {
      mounted: n,
      updated: n
    }), n.deep && br(s), a.push({
      dir: n,
      instance: r,
      value: s,
      oldValue: void 0,
      arg: i,
      modifiers: l
    }));
  }
  return e;
}
function Jr(e, t, r, a) {
  const o = e.dirs, n = t && t.dirs;
  for (let s = 0; s < o.length; s++) {
    const i = o[s];
    n && (i.oldValue = n[s].value);
    let l = i.dir[a];
    l && (_r(), nr(l, r, 8, [
      e.el,
      i,
      e,
      t
    ]), kr());
  }
}
const vf = Symbol("_vte"), ng = (e) => e.__isTeleport, no = (e) => e && (e.disabled || e.disabled === ""), uc = (e) => e && (e.defer || e.defer === ""), dc = (e) => typeof SVGElement < "u" && e instanceof SVGElement, fc = (e) => typeof MathMLElement == "function" && e instanceof MathMLElement, gi = (e, t) => {
  const r = e && e.to;
  return Qe(r) ? t ? t(r) : null : r;
}, bf = {
  name: "Teleport",
  __isTeleport: !0,
  process(e, t, r, a, o, n, s, i, l, c) {
    const {
      mc: u,
      pc: f,
      pbc: p,
      o: { insert: h, querySelector: m, createText: v, createComment: x }
    } = c, C = no(t.props);
    let { shapeFlag: S, children: E, dynamicChildren: T } = t;
    if (e == null) {
      const F = t.el = v(""), j = t.anchor = v("");
      h(F, r, a), h(j, r, a);
      const H = (P, $) => {
        S & 16 && (o && o.isCE && (o.ce._teleportTarget = P), u(
          E,
          P,
          $,
          o,
          n,
          s,
          i,
          l
        ));
      }, B = () => {
        const P = t.target = gi(t.props, m), $ = yf(P, t, v, h);
        P && (s !== "svg" && dc(P) ? s = "svg" : s !== "mathml" && fc(P) && (s = "mathml"), C || (H(P, $), an(t, !1)));
      };
      C && (H(r, j), an(t, !0)), uc(t.props) ? (t.el.__isMounted = !1, mt(() => {
        B(), delete t.el.__isMounted;
      }, n)) : B();
    } else {
      if (uc(t.props) && e.el.__isMounted === !1) {
        mt(() => {
          bf.process(
            e,
            t,
            r,
            a,
            o,
            n,
            s,
            i,
            l,
            c
          );
        }, n);
        return;
      }
      t.el = e.el, t.targetStart = e.targetStart;
      const F = t.anchor = e.anchor, j = t.target = e.target, H = t.targetAnchor = e.targetAnchor, B = no(e.props), P = B ? r : j, $ = B ? F : H;
      if (s === "svg" || dc(j) ? s = "svg" : (s === "mathml" || fc(j)) && (s = "mathml"), T ? (p(
        e.dynamicChildren,
        T,
        P,
        o,
        n,
        s,
        i
      ), vl(e, t, !0)) : l || f(
        e,
        t,
        P,
        $,
        o,
        n,
        s,
        i,
        !1
      ), C)
        B ? t.props && e.props && t.props.to !== e.props.to && (t.props.to = e.props.to) : jo(
          t,
          r,
          F,
          c,
          1
        );
      else if ((t.props && t.props.to) !== (e.props && e.props.to)) {
        const V = t.target = gi(
          t.props,
          m
        );
        V && jo(
          t,
          V,
          null,
          c,
          0
        );
      } else B && jo(
        t,
        j,
        H,
        c,
        1
      );
      an(t, C);
    }
  },
  remove(e, t, r, { um: a, o: { remove: o } }, n) {
    const {
      shapeFlag: s,
      children: i,
      anchor: l,
      targetStart: c,
      targetAnchor: u,
      target: f,
      props: p
    } = e;
    if (f && (o(c), o(u)), n && o(l), s & 16) {
      const h = n || !no(p);
      for (let m = 0; m < i.length; m++) {
        const v = i[m];
        a(
          v,
          t,
          r,
          h,
          !!v.dynamicChildren
        );
      }
    }
  },
  move: jo,
  hydrate: sg
};
function jo(e, t, r, { o: { insert: a }, m: o }, n = 2) {
  n === 0 && a(e.targetAnchor, t, r);
  const { el: s, anchor: i, shapeFlag: l, children: c, props: u } = e, f = n === 2;
  if (f && a(s, t, r), (!f || no(u)) && l & 16)
    for (let p = 0; p < c.length; p++)
      o(
        c[p],
        t,
        r,
        2
      );
  f && a(i, t, r);
}
function sg(e, t, r, a, o, n, {
  o: { nextSibling: s, parentNode: i, querySelector: l, insert: c, createText: u }
}, f) {
  const p = t.target = gi(
    t.props,
    l
  );
  if (p) {
    const h = no(t.props), m = p._lpa || p.firstChild;
    if (t.shapeFlag & 16)
      if (h)
        t.anchor = f(
          s(e),
          t,
          i(e),
          r,
          a,
          o,
          n
        ), t.targetStart = m, t.targetAnchor = m && s(m);
      else {
        t.anchor = s(e);
        let v = m;
        for (; v; ) {
          if (v && v.nodeType === 8) {
            if (v.data === "teleport start anchor")
              t.targetStart = v;
            else if (v.data === "teleport anchor") {
              t.targetAnchor = v, p._lpa = t.targetAnchor && s(t.targetAnchor);
              break;
            }
          }
          v = s(v);
        }
        t.targetAnchor || yf(p, t, u, c), f(
          m && s(m),
          t,
          p,
          r,
          a,
          o,
          n
        );
      }
    an(t, h);
  }
  return t.anchor && s(t.anchor);
}
const ig = bf;
function an(e, t) {
  const r = e.ctx;
  if (r && r.ut) {
    let a, o;
    for (t ? (a = e.el, o = e.anchor) : (a = e.targetStart, o = e.targetAnchor); a && a !== o; )
      a.nodeType === 1 && a.setAttribute("data-v-owner", r.uid), a = a.nextSibling;
    r.ut();
  }
}
function yf(e, t, r, a) {
  const o = t.targetStart = r(""), n = t.targetAnchor = r("");
  return o[vf] = n, e && (a(o, e), a(n, e)), n;
}
function fl(e, t) {
  e.shapeFlag & 6 && e.component ? (e.transition = t, fl(e.component.subTree, t)) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function D(e, t) {
  return Se(e) ? (
    // #8236: extend call and options.name access are considered side-effects
    // by Rollup, so we have to wrap it in a pure-annotated IIFE.
    pt({ name: e.name }, t, { setup: e })
  ) : e;
}
function lg() {
  const e = bt();
  return e ? (e.appContext.config.idPrefix || "v") + "-" + e.ids[0] + e.ids[1]++ : "";
}
function wf(e) {
  e.ids = [e.ids[0] + e.ids[2]++ + "-", 0, 0];
}
function so(e, t, r, a, o = !1) {
  if (Ce(e)) {
    e.forEach(
      (m, v) => so(
        m,
        t && (Ce(t) ? t[v] : t),
        r,
        a,
        o
      )
    );
    return;
  }
  if (Ea(a) && !o) {
    a.shapeFlag & 512 && a.type.__asyncResolved && a.component.subTree.component && so(e, t, r, a.component.subTree);
    return;
  }
  const n = a.shapeFlag & 4 ? Wn(a.component) : a.el, s = o ? null : n, { i, r: l } = e, c = t && t.r, u = i.refs === je ? i.refs = {} : i.refs, f = i.setupState, p = qe(f), h = f === je ? () => !1 : (m) => Ne(p, m);
  if (c != null && c !== l && (Qe(c) ? (u[c] = null, h(c) && (f[c] = null)) : Ve(c) && (c.value = null)), Se(l))
    Po(l, i, 12, [s, u]);
  else {
    const m = Qe(l), v = Ve(l);
    if (m || v) {
      const x = () => {
        if (e.f) {
          const C = m ? h(l) ? f[l] : u[l] : l.value;
          o ? Ce(C) && ol(C, n) : Ce(C) ? C.includes(n) || C.push(n) : m ? (u[l] = [n], h(l) && (f[l] = u[l])) : (l.value = [n], e.k && (u[e.k] = l.value));
        } else m ? (u[l] = s, h(l) && (f[l] = s)) : v && (l.value = s, e.k && (u[e.k] = s));
      };
      s ? (x.id = -1, mt(x, r)) : x();
    }
  }
}
Bn().requestIdleCallback;
Bn().cancelIdleCallback;
const Ea = (e) => !!e.type.__asyncLoader, xf = (e) => e.type.__isKeepAlive;
function cg(e, t) {
  _f(e, "a", t);
}
function ug(e, t) {
  _f(e, "da", t);
}
function _f(e, t, r = dt) {
  const a = e.__wdc || (e.__wdc = () => {
    let o = r;
    for (; o; ) {
      if (o.isDeactivated)
        return;
      o = o.parent;
    }
    return e();
  });
  if (zn(t, a, r), r) {
    let o = r.parent;
    for (; o && o.parent; )
      xf(o.parent.vnode) && dg(a, t, r, o), o = o.parent;
  }
}
function dg(e, t, r, a) {
  const o = zn(
    t,
    e,
    a,
    !0
    /* prepend */
  );
  $r(() => {
    ol(a[t], o);
  }, r);
}
function zn(e, t, r = dt, a = !1) {
  if (r) {
    const o = r[e] || (r[e] = []), n = t.__weh || (t.__weh = (...s) => {
      _r();
      const i = To(r), l = nr(t, r, e, s);
      return i(), kr(), l;
    });
    return a ? o.unshift(n) : o.push(n), n;
  }
}
const Er = (e) => (t, r = dt) => {
  (!yo || e === "sp") && zn(e, (...a) => t(...a), r);
}, fg = Er("bm"), at = Er("m"), pg = Er(
  "bu"
), hg = Er("u"), jn = Er(
  "bum"
), $r = Er("um"), gg = Er(
  "sp"
), mg = Er("rtg"), vg = Er("rtc");
function bg(e, t = dt) {
  zn("ec", e, t);
}
const kf = "components";
function pl(e, t) {
  return Af(kf, e, !0, t) || e;
}
const Cf = Symbol.for("v-ndc");
function Qt(e) {
  return Qe(e) ? Af(kf, e, !1) || e : e || Cf;
}
function Af(e, t, r = !0, a = !1) {
  const o = st || dt;
  if (o) {
    const n = o.type;
    {
      const i = o1(
        n,
        !1
      );
      if (i && (i === t || i === At(t) || i === On(At(t))))
        return n;
    }
    const s = (
      // local registration
      // check instance[type] first which is resolved for options API
      pc(o[e] || n[e], t) || // global registration
      pc(o.appContext[e], t)
    );
    return !s && a ? n : s;
  }
}
function pc(e, t) {
  return e && (e[t] || e[At(t)] || e[On(At(t))]);
}
function qt(e, t, r, a) {
  let o;
  const n = r, s = Ce(e);
  if (s || Qe(e)) {
    const i = s && zr(e);
    let l = !1, c = !1;
    i && (l = !Bt(e), c = Ur(e), e = Ln(e)), o = new Array(e.length);
    for (let u = 0, f = e.length; u < f; u++)
      o[u] = t(
        l ? c ? mn(nt(e[u])) : nt(e[u]) : e[u],
        u,
        void 0,
        n
      );
  } else if (typeof e == "number") {
    o = new Array(e);
    for (let i = 0; i < e; i++)
      o[i] = t(i + 1, i, void 0, n);
  } else if (We(e))
    if (e[Symbol.iterator])
      o = Array.from(
        e,
        (i, l) => t(i, l, void 0, n)
      );
    else {
      const i = Object.keys(e);
      o = new Array(i.length);
      for (let l = 0, c = i.length; l < c; l++) {
        const u = i[l];
        o[l] = t(e[u], u, l, n);
      }
    }
  else
    o = [];
  return o;
}
function q(e, t, r = {}, a, o) {
  if (st.ce || st.parent && Ea(st.parent) && st.parent.ce)
    return t !== "default" && (r.name = t), g(), N(
      Be,
      null,
      [k("slot", r, a && a())],
      64
    );
  let n = e[t];
  n && n._c && (n._d = !1), g();
  const s = n && Sf(n(r)), i = r.key || // slot content array of a dynamic conditional slot may have a branch
  // key attached in the `createSlots` helper, respect that
  s && s.key, l = N(
    Be,
    {
      key: (i && !Sr(i) ? i : `_${t}`) + // #7256 force differentiate fallback content from actual content
      (!s && a ? "_fb" : "")
    },
    s || (a ? a() : []),
    s && e._ === 1 ? 64 : -2
  );
  return l.scopeId && (l.slotScopeIds = [l.scopeId + "-s"]), n && n._c && (n._d = !0), l;
}
function Sf(e) {
  return e.some((t) => er(t) ? !(t.type === sr || t.type === Be && !Sf(t.children)) : !0) ? e : null;
}
function yg(e, t) {
  const r = {};
  for (const a in e)
    r[ro(a)] = e[a];
  return r;
}
const mi = (e) => e ? Zf(e) ? Wn(e) : mi(e.parent) : null, io = (
  // Move PURE marker to new line to workaround compiler discarding it
  // due to type annotation
  /* @__PURE__ */ pt(/* @__PURE__ */ Object.create(null), {
    $: (e) => e,
    $el: (e) => e.vnode.el,
    $data: (e) => e.data,
    $props: (e) => e.props,
    $attrs: (e) => e.attrs,
    $slots: (e) => e.slots,
    $refs: (e) => e.refs,
    $parent: (e) => mi(e.parent),
    $root: (e) => mi(e.root),
    $host: (e) => e.ce,
    $emit: (e) => e.emit,
    $options: (e) => Pf(e),
    $forceUpdate: (e) => e.f || (e.f = () => {
      dl(e.update);
    }),
    $nextTick: (e) => e.n || (e.n = et.bind(e.proxy)),
    $watch: (e) => Fg.bind(e)
  })
), vs = (e, t) => e !== je && !e.__isScriptSetup && Ne(e, t), wg = {
  get({ _: e }, t) {
    if (t === "__v_skip")
      return !0;
    const { ctx: r, setupState: a, data: o, props: n, accessCache: s, type: i, appContext: l } = e;
    let c;
    if (t[0] !== "$") {
      const h = s[t];
      if (h !== void 0)
        switch (h) {
          case 1:
            return a[t];
          case 2:
            return o[t];
          case 4:
            return r[t];
          case 3:
            return n[t];
        }
      else {
        if (vs(a, t))
          return s[t] = 1, a[t];
        if (o !== je && Ne(o, t))
          return s[t] = 2, o[t];
        if (
          // only cache other properties when instance has declared (thus stable)
          // props
          (c = e.propsOptions[0]) && Ne(c, t)
        )
          return s[t] = 3, n[t];
        if (r !== je && Ne(r, t))
          return s[t] = 4, r[t];
        bi && (s[t] = 0);
      }
    }
    const u = io[t];
    let f, p;
    if (u)
      return t === "$attrs" && ct(e.attrs, "get", ""), u(e);
    if (
      // css module (injected by vue-loader)
      (f = i.__cssModules) && (f = f[t])
    )
      return f;
    if (r !== je && Ne(r, t))
      return s[t] = 4, r[t];
    if (
      // global properties
      p = l.config.globalProperties, Ne(p, t)
    )
      return p[t];
  },
  set({ _: e }, t, r) {
    const { data: a, setupState: o, ctx: n } = e;
    return vs(o, t) ? (o[t] = r, !0) : a !== je && Ne(a, t) ? (a[t] = r, !0) : Ne(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (n[t] = r, !0);
  },
  has({
    _: { data: e, setupState: t, accessCache: r, ctx: a, appContext: o, propsOptions: n }
  }, s) {
    let i;
    return !!r[s] || e !== je && Ne(e, s) || vs(t, s) || (i = n[0]) && Ne(i, s) || Ne(a, s) || Ne(io, s) || Ne(o.config.globalProperties, s);
  },
  defineProperty(e, t, r) {
    return r.get != null ? e._.accessCache[t] = 0 : Ne(r, "value") && this.set(e, t, r.value, null), Reflect.defineProperty(e, t, r);
  }
};
function xg() {
  return _g().attrs;
}
function _g(e) {
  const t = bt();
  return t.setupContext || (t.setupContext = Wf(t));
}
function vi(e) {
  return Ce(e) ? e.reduce(
    (t, r) => (t[r] = null, t),
    {}
  ) : e;
}
function Ef(e, t) {
  const r = vi(e);
  for (const a in t) {
    if (a.startsWith("__skip")) continue;
    let o = r[a];
    o ? Ce(o) || Se(o) ? o = r[a] = { type: o, default: t[a] } : o.default = t[a] : o === null && (o = r[a] = { default: t[a] }), o && t[`__skip_${a}`] && (o.skipFactory = !0);
  }
  return r;
}
let bi = !0;
function kg(e) {
  const t = Pf(e), r = e.proxy, a = e.ctx;
  bi = !1, t.beforeCreate && hc(t.beforeCreate, e, "bc");
  const {
    // state
    data: o,
    computed: n,
    methods: s,
    watch: i,
    provide: l,
    inject: c,
    // lifecycle
    created: u,
    beforeMount: f,
    mounted: p,
    beforeUpdate: h,
    updated: m,
    activated: v,
    deactivated: x,
    beforeDestroy: C,
    beforeUnmount: S,
    destroyed: E,
    unmounted: T,
    render: F,
    renderTracked: j,
    renderTriggered: H,
    errorCaptured: B,
    serverPrefetch: P,
    // public API
    expose: $,
    inheritAttrs: V,
    // assets
    components: z,
    directives: G,
    filters: ee
  } = t;
  if (c && Cg(c, a, null), s)
    for (const W in s) {
      const M = s[W];
      Se(M) && (a[W] = M.bind(r));
    }
  if (o) {
    const W = o.call(r, r);
    We(W) && (e.data = Rt(W));
  }
  if (bi = !0, n)
    for (const W in n) {
      const M = n[W], ge = Se(M) ? M.bind(r, r) : Se(M.get) ? M.get.bind(r, r) : rr, Me = !Se(M) && Se(M.set) ? M.set.bind(r) : rr, Ie = L({
        get: ge,
        set: Me
      });
      Object.defineProperty(a, W, {
        enumerable: !0,
        configurable: !0,
        get: () => Ie.value,
        set: (ze) => Ie.value = ze
      });
    }
  if (i)
    for (const W in i)
      $f(i[W], a, r, W);
  if (l) {
    const W = Se(l) ? l.call(r) : l;
    Reflect.ownKeys(W).forEach((M) => {
      $a(M, W[M]);
    });
  }
  u && hc(u, e, "c");
  function de(W, M) {
    Ce(M) ? M.forEach((ge) => W(ge.bind(r))) : M && W(M.bind(r));
  }
  if (de(fg, f), de(at, p), de(pg, h), de(hg, m), de(cg, v), de(ug, x), de(bg, B), de(vg, j), de(mg, H), de(jn, S), de($r, T), de(gg, P), Ce($))
    if ($.length) {
      const W = e.exposed || (e.exposed = {});
      $.forEach((M) => {
        Object.defineProperty(W, M, {
          get: () => r[M],
          set: (ge) => r[M] = ge,
          enumerable: !0
        });
      });
    } else e.exposed || (e.exposed = {});
  F && e.render === rr && (e.render = F), V != null && (e.inheritAttrs = V), z && (e.components = z), G && (e.directives = G), P && wf(e);
}
function Cg(e, t, r = rr) {
  Ce(e) && (e = yi(e));
  for (const a in e) {
    const o = e[a];
    let n;
    We(o) ? "default" in o ? n = he(
      o.from || a,
      o.default,
      !0
    ) : n = he(o.from || a) : n = he(o), Ve(n) ? Object.defineProperty(t, a, {
      enumerable: !0,
      configurable: !0,
      get: () => n.value,
      set: (s) => n.value = s
    }) : t[a] = n;
  }
}
function hc(e, t, r) {
  nr(
    Ce(e) ? e.map((a) => a.bind(t.proxy)) : e.bind(t.proxy),
    t,
    r
  );
}
function $f(e, t, r, a) {
  let o = a.includes(".") ? Hf(r, a) : () => r[a];
  if (Qe(e)) {
    const n = t[e];
    Se(n) && Ke(o, n);
  } else if (Se(e))
    Ke(o, e.bind(r));
  else if (We(e))
    if (Ce(e))
      e.forEach((n) => $f(n, t, r, a));
    else {
      const n = Se(e.handler) ? e.handler.bind(r) : t[e.handler];
      Se(n) && Ke(o, n, e);
    }
}
function Pf(e) {
  const t = e.type, { mixins: r, extends: a } = t, {
    mixins: o,
    optionsCache: n,
    config: { optionMergeStrategies: s }
  } = e.appContext, i = n.get(t);
  let l;
  return i ? l = i : !o.length && !r && !a ? l = t : (l = {}, o.length && o.forEach(
    (c) => wn(l, c, s, !0)
  ), wn(l, t, s)), We(t) && n.set(t, l), l;
}
function wn(e, t, r, a = !1) {
  const { mixins: o, extends: n } = t;
  n && wn(e, n, r, !0), o && o.forEach(
    (s) => wn(e, s, r, !0)
  );
  for (const s in t)
    if (!(a && s === "expose")) {
      const i = Ag[s] || r && r[s];
      e[s] = i ? i(e[s], t[s]) : t[s];
    }
  return e;
}
const Ag = {
  data: gc,
  props: mc,
  emits: mc,
  // objects
  methods: Qa,
  computed: Qa,
  // lifecycle
  beforeCreate: gt,
  created: gt,
  beforeMount: gt,
  mounted: gt,
  beforeUpdate: gt,
  updated: gt,
  beforeDestroy: gt,
  beforeUnmount: gt,
  destroyed: gt,
  unmounted: gt,
  activated: gt,
  deactivated: gt,
  errorCaptured: gt,
  serverPrefetch: gt,
  // assets
  components: Qa,
  directives: Qa,
  // watch
  watch: Eg,
  // provide / inject
  provide: gc,
  inject: Sg
};
function gc(e, t) {
  return t ? e ? function() {
    return pt(
      Se(e) ? e.call(this, this) : e,
      Se(t) ? t.call(this, this) : t
    );
  } : t : e;
}
function Sg(e, t) {
  return Qa(yi(e), yi(t));
}
function yi(e) {
  if (Ce(e)) {
    const t = {};
    for (let r = 0; r < e.length; r++)
      t[e[r]] = e[r];
    return t;
  }
  return e;
}
function gt(e, t) {
  return e ? [...new Set([].concat(e, t))] : t;
}
function Qa(e, t) {
  return e ? pt(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function mc(e, t) {
  return e ? Ce(e) && Ce(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : pt(
    /* @__PURE__ */ Object.create(null),
    vi(e),
    vi(t ?? {})
  ) : t;
}
function Eg(e, t) {
  if (!e) return t;
  if (!t) return e;
  const r = pt(/* @__PURE__ */ Object.create(null), e);
  for (const a in t)
    r[a] = gt(e[a], t[a]);
  return r;
}
function Tf() {
  return {
    app: null,
    config: {
      isNativeTag: hh,
      performance: !1,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {}
    },
    mixins: [],
    components: {},
    directives: {},
    provides: /* @__PURE__ */ Object.create(null),
    optionsCache: /* @__PURE__ */ new WeakMap(),
    propsCache: /* @__PURE__ */ new WeakMap(),
    emitsCache: /* @__PURE__ */ new WeakMap()
  };
}
let $g = 0;
function Pg(e, t) {
  return function(a, o = null) {
    Se(a) || (a = pt({}, a)), o != null && !We(o) && (o = null);
    const n = Tf(), s = /* @__PURE__ */ new WeakSet(), i = [];
    let l = !1;
    const c = n.app = {
      _uid: $g++,
      _component: a,
      _props: o,
      _container: null,
      _context: n,
      _instance: null,
      version: s1,
      get config() {
        return n.config;
      },
      set config(u) {
      },
      use(u, ...f) {
        return s.has(u) || (u && Se(u.install) ? (s.add(u), u.install(c, ...f)) : Se(u) && (s.add(u), u(c, ...f))), c;
      },
      mixin(u) {
        return n.mixins.includes(u) || n.mixins.push(u), c;
      },
      component(u, f) {
        return f ? (n.components[u] = f, c) : n.components[u];
      },
      directive(u, f) {
        return f ? (n.directives[u] = f, c) : n.directives[u];
      },
      mount(u, f, p) {
        if (!l) {
          const h = c._ceVNode || k(a, o);
          return h.appContext = n, p === !0 ? p = "svg" : p === !1 && (p = void 0), e(h, u, p), l = !0, c._container = u, u.__vue_app__ = c, Wn(h.component);
        }
      },
      onUnmount(u) {
        i.push(u);
      },
      unmount() {
        l && (nr(
          i,
          c._instance,
          16
        ), e(null, c._container), delete c._container.__vue_app__);
      },
      provide(u, f) {
        return n.provides[u] = f, c;
      },
      runWithContext(u) {
        const f = oa;
        oa = c;
        try {
          return u();
        } finally {
          oa = f;
        }
      }
    };
    return c;
  };
}
let oa = null;
function $a(e, t) {
  if (dt) {
    let r = dt.provides;
    const a = dt.parent && dt.parent.provides;
    a === r && (r = dt.provides = Object.create(a)), r[e] = t;
  }
}
function he(e, t, r = !1) {
  const a = bt();
  if (a || oa) {
    let o = oa ? oa._context.provides : a ? a.parent == null || a.ce ? a.vnode.appContext && a.vnode.appContext.provides : a.parent.provides : void 0;
    if (o && e in o)
      return o[e];
    if (arguments.length > 1)
      return r && Se(t) ? t.call(a && a.proxy) : t;
  }
}
function hl() {
  return !!(bt() || oa);
}
const Mf = {}, Rf = () => Object.create(Mf), Of = (e) => Object.getPrototypeOf(e) === Mf;
function Tg(e, t, r, a = !1) {
  const o = {}, n = Rf();
  e.propsDefaults = /* @__PURE__ */ Object.create(null), Bf(e, t, o, n);
  for (const s in e.propsOptions[0])
    s in o || (o[s] = void 0);
  r ? e.props = a ? o : lf(o) : e.type.props ? e.props = o : e.props = n, e.attrs = n;
}
function Mg(e, t, r, a) {
  const {
    props: o,
    attrs: n,
    vnode: { patchFlag: s }
  } = e, i = qe(o), [l] = e.propsOptions;
  let c = !1;
  if (
    // always force full diff in dev
    // - #1942 if hmr is enabled with sfc component
    // - vite#872 non-sfc component used by sfc component
    (a || s > 0) && !(s & 16)
  ) {
    if (s & 8) {
      const u = e.vnode.dynamicProps;
      for (let f = 0; f < u.length; f++) {
        let p = u[f];
        if (Zn(e.emitsOptions, p))
          continue;
        const h = t[p];
        if (l)
          if (Ne(n, p))
            h !== n[p] && (n[p] = h, c = !0);
          else {
            const m = At(p);
            o[m] = wi(
              l,
              i,
              m,
              h,
              e,
              !1
            );
          }
        else
          h !== n[p] && (n[p] = h, c = !0);
      }
    }
  } else {
    Bf(e, t, o, n) && (c = !0);
    let u;
    for (const f in i)
      (!t || // for camelCase
      !Ne(t, f) && // it's possible the original props was passed in as kebab-case
      // and converted to camelCase (#955)
      ((u = Wr(f)) === f || !Ne(t, u))) && (l ? r && // for camelCase
      (r[f] !== void 0 || // for kebab-case
      r[u] !== void 0) && (o[f] = wi(
        l,
        i,
        f,
        void 0,
        e,
        !0
      )) : delete o[f]);
    if (n !== i)
      for (const f in n)
        (!t || !Ne(t, f)) && (delete n[f], c = !0);
  }
  c && vr(e.attrs, "set", "");
}
function Bf(e, t, r, a) {
  const [o, n] = e.propsOptions;
  let s = !1, i;
  if (t)
    for (let l in t) {
      if (to(l))
        continue;
      const c = t[l];
      let u;
      o && Ne(o, u = At(l)) ? !n || !n.includes(u) ? r[u] = c : (i || (i = {}))[u] = c : Zn(e.emitsOptions, l) || (!(l in a) || c !== a[l]) && (a[l] = c, s = !0);
    }
  if (n) {
    const l = qe(r), c = i || je;
    for (let u = 0; u < n.length; u++) {
      const f = n[u];
      r[f] = wi(
        o,
        l,
        f,
        c[f],
        e,
        !Ne(c, f)
      );
    }
  }
  return s;
}
function wi(e, t, r, a, o, n) {
  const s = e[r];
  if (s != null) {
    const i = Ne(s, "default");
    if (i && a === void 0) {
      const l = s.default;
      if (s.type !== Function && !s.skipFactory && Se(l)) {
        const { propsDefaults: c } = o;
        if (r in c)
          a = c[r];
        else {
          const u = To(o);
          a = c[r] = l.call(
            null,
            t
          ), u();
        }
      } else
        a = l;
      o.ce && o.ce._setProp(r, a);
    }
    s[
      0
      /* shouldCast */
    ] && (n && !i ? a = !1 : s[
      1
      /* shouldCastTrue */
    ] && (a === "" || a === Wr(r)) && (a = !0));
  }
  return a;
}
const Rg = /* @__PURE__ */ new WeakMap();
function Df(e, t, r = !1) {
  const a = r ? Rg : t.propsCache, o = a.get(e);
  if (o)
    return o;
  const n = e.props, s = {}, i = [];
  let l = !1;
  if (!Se(e)) {
    const u = (f) => {
      l = !0;
      const [p, h] = Df(f, t, !0);
      pt(s, p), h && i.push(...h);
    };
    !r && t.mixins.length && t.mixins.forEach(u), e.extends && u(e.extends), e.mixins && e.mixins.forEach(u);
  }
  if (!n && !l)
    return We(e) && a.set(e, Ca), Ca;
  if (Ce(n))
    for (let u = 0; u < n.length; u++) {
      const f = At(n[u]);
      vc(f) && (s[f] = je);
    }
  else if (n)
    for (const u in n) {
      const f = At(u);
      if (vc(f)) {
        const p = n[u], h = s[f] = Ce(p) || Se(p) ? { type: p } : pt({}, p), m = h.type;
        let v = !1, x = !0;
        if (Ce(m))
          for (let C = 0; C < m.length; ++C) {
            const S = m[C], E = Se(S) && S.name;
            if (E === "Boolean") {
              v = !0;
              break;
            } else E === "String" && (x = !1);
          }
        else
          v = Se(m) && m.name === "Boolean";
        h[
          0
          /* shouldCast */
        ] = v, h[
          1
          /* shouldCastTrue */
        ] = x, (v || Ne(h, "default")) && i.push(f);
      }
    }
  const c = [s, i];
  return We(e) && a.set(e, c), c;
}
function vc(e) {
  return e[0] !== "$" && !to(e);
}
const gl = (e) => e === "_" || e === "__" || e === "_ctx" || e === "$stable", ml = (e) => Ce(e) ? e.map(Xt) : [Xt(e)], Og = (e, t, r) => {
  if (t._n)
    return t;
  const a = b((...o) => ml(t(...o)), r);
  return a._c = !1, a;
}, If = (e, t, r) => {
  const a = e._ctx;
  for (const o in e) {
    if (gl(o)) continue;
    const n = e[o];
    if (Se(n))
      t[o] = Og(o, n, a);
    else if (n != null) {
      const s = ml(n);
      t[o] = () => s;
    }
  }
}, qf = (e, t) => {
  const r = ml(t);
  e.slots.default = () => r;
}, Lf = (e, t, r) => {
  for (const a in t)
    (r || !gl(a)) && (e[a] = t[a]);
}, Bg = (e, t, r) => {
  const a = e.slots = Rf();
  if (e.vnode.shapeFlag & 32) {
    const o = t.__;
    o && ui(a, "__", o, !0);
    const n = t._;
    n ? (Lf(a, t, r), r && ui(a, "_", n, !0)) : If(t, a);
  } else t && qf(e, t);
}, Dg = (e, t, r) => {
  const { vnode: a, slots: o } = e;
  let n = !0, s = je;
  if (a.shapeFlag & 32) {
    const i = t._;
    i ? r && i === 1 ? n = !1 : Lf(o, t, r) : (n = !t.$stable, If(t, o)), s = t;
  } else t && (qf(e, t), s = { default: 1 });
  if (n)
    for (const i in o)
      !gl(i) && s[i] == null && delete o[i];
}, mt = Gg;
function Ig(e) {
  return qg(e);
}
function qg(e, t) {
  const r = Bn();
  r.__VUE__ = !0;
  const {
    insert: a,
    remove: o,
    patchProp: n,
    createElement: s,
    createText: i,
    createComment: l,
    setText: c,
    setElementText: u,
    parentNode: f,
    nextSibling: p,
    setScopeId: h = rr,
    insertStaticContent: m
  } = e, v = (_, A, I, J = null, Y = null, X = null, le = void 0, ie = null, se = !!A.dynamicChildren) => {
    if (_ === A)
      return;
    _ && !Za(_, A) && (J = y(_), ze(_, Y, X, !0), _ = null), A.patchFlag === -2 && (se = !1, A.dynamicChildren = null);
    const { type: oe, ref: ye, shapeFlag: ce } = A;
    switch (oe) {
      case Kn:
        x(_, A, I, J);
        break;
      case sr:
        C(_, A, I, J);
        break;
      case on:
        _ == null && S(A, I, J, le);
        break;
      case Be:
        z(
          _,
          A,
          I,
          J,
          Y,
          X,
          le,
          ie,
          se
        );
        break;
      default:
        ce & 1 ? F(
          _,
          A,
          I,
          J,
          Y,
          X,
          le,
          ie,
          se
        ) : ce & 6 ? G(
          _,
          A,
          I,
          J,
          Y,
          X,
          le,
          ie,
          se
        ) : (ce & 64 || ce & 128) && oe.process(
          _,
          A,
          I,
          J,
          Y,
          X,
          le,
          ie,
          se,
          te
        );
    }
    ye != null && Y ? so(ye, _ && _.ref, X, A || _, !A) : ye == null && _ && _.ref != null && so(_.ref, null, X, _, !0);
  }, x = (_, A, I, J) => {
    if (_ == null)
      a(
        A.el = i(A.children),
        I,
        J
      );
    else {
      const Y = A.el = _.el;
      A.children !== _.children && c(Y, A.children);
    }
  }, C = (_, A, I, J) => {
    _ == null ? a(
      A.el = l(A.children || ""),
      I,
      J
    ) : A.el = _.el;
  }, S = (_, A, I, J) => {
    [_.el, _.anchor] = m(
      _.children,
      A,
      I,
      J,
      _.el,
      _.anchor
    );
  }, E = ({ el: _, anchor: A }, I, J) => {
    let Y;
    for (; _ && _ !== A; )
      Y = p(_), a(_, I, J), _ = Y;
    a(A, I, J);
  }, T = ({ el: _, anchor: A }) => {
    let I;
    for (; _ && _ !== A; )
      I = p(_), o(_), _ = I;
    o(A);
  }, F = (_, A, I, J, Y, X, le, ie, se) => {
    A.type === "svg" ? le = "svg" : A.type === "math" && (le = "mathml"), _ == null ? j(
      A,
      I,
      J,
      Y,
      X,
      le,
      ie,
      se
    ) : P(
      _,
      A,
      Y,
      X,
      le,
      ie,
      se
    );
  }, j = (_, A, I, J, Y, X, le, ie) => {
    let se, oe;
    const { props: ye, shapeFlag: ce, transition: me, dirs: Ee } = _;
    if (se = _.el = s(
      _.type,
      X,
      ye && ye.is,
      ye
    ), ce & 8 ? u(se, _.children) : ce & 16 && B(
      _.children,
      se,
      null,
      J,
      Y,
      bs(_, X),
      le,
      ie
    ), Ee && Jr(_, null, J, "created"), H(se, _, _.scopeId, le, J), ye) {
      for (const Ue in ye)
        Ue !== "value" && !to(Ue) && n(se, Ue, null, ye[Ue], X, J);
      "value" in ye && n(se, "value", null, ye.value, X), (oe = ye.onVnodeBeforeMount) && Kt(oe, J, _);
    }
    Ee && Jr(_, null, J, "beforeMount");
    const Oe = Lg(Y, me);
    Oe && me.beforeEnter(se), a(se, A, I), ((oe = ye && ye.onVnodeMounted) || Oe || Ee) && mt(() => {
      oe && Kt(oe, J, _), Oe && me.enter(se), Ee && Jr(_, null, J, "mounted");
    }, Y);
  }, H = (_, A, I, J, Y) => {
    if (I && h(_, I), J)
      for (let X = 0; X < J.length; X++)
        h(_, J[X]);
    if (Y) {
      let X = Y.subTree;
      if (A === X || zf(X.type) && (X.ssContent === A || X.ssFallback === A)) {
        const le = Y.vnode;
        H(
          _,
          le,
          le.scopeId,
          le.slotScopeIds,
          Y.parent
        );
      }
    }
  }, B = (_, A, I, J, Y, X, le, ie, se = 0) => {
    for (let oe = se; oe < _.length; oe++) {
      const ye = _[oe] = ie ? Nr(_[oe]) : Xt(_[oe]);
      v(
        null,
        ye,
        A,
        I,
        J,
        Y,
        X,
        le,
        ie
      );
    }
  }, P = (_, A, I, J, Y, X, le) => {
    const ie = A.el = _.el;
    let { patchFlag: se, dynamicChildren: oe, dirs: ye } = A;
    se |= _.patchFlag & 16;
    const ce = _.props || je, me = A.props || je;
    let Ee;
    if (I && Yr(I, !1), (Ee = me.onVnodeBeforeUpdate) && Kt(Ee, I, A, _), ye && Jr(A, _, I, "beforeUpdate"), I && Yr(I, !0), (ce.innerHTML && me.innerHTML == null || ce.textContent && me.textContent == null) && u(ie, ""), oe ? $(
      _.dynamicChildren,
      oe,
      ie,
      I,
      J,
      bs(A, Y),
      X
    ) : le || M(
      _,
      A,
      ie,
      null,
      I,
      J,
      bs(A, Y),
      X,
      !1
    ), se > 0) {
      if (se & 16)
        V(ie, ce, me, I, Y);
      else if (se & 2 && ce.class !== me.class && n(ie, "class", null, me.class, Y), se & 4 && n(ie, "style", ce.style, me.style, Y), se & 8) {
        const Oe = A.dynamicProps;
        for (let Ue = 0; Ue < Oe.length; Ue++) {
          const He = Oe[Ue], yt = ce[He], wt = me[He];
          (wt !== yt || He === "value") && n(ie, He, yt, wt, Y, I);
        }
      }
      se & 1 && _.children !== A.children && u(ie, A.children);
    } else !le && oe == null && V(ie, ce, me, I, Y);
    ((Ee = me.onVnodeUpdated) || ye) && mt(() => {
      Ee && Kt(Ee, I, A, _), ye && Jr(A, _, I, "updated");
    }, J);
  }, $ = (_, A, I, J, Y, X, le) => {
    for (let ie = 0; ie < A.length; ie++) {
      const se = _[ie], oe = A[ie], ye = (
        // oldVNode may be an errored async setup() component inside Suspense
        // which will not have a mounted element
        se.el && // - In the case of a Fragment, we need to provide the actual parent
        // of the Fragment itself so it can move its children.
        (se.type === Be || // - In the case of different nodes, there is going to be a replacement
        // which also requires the correct parent container
        !Za(se, oe) || // - In the case of a component, it could contain anything.
        se.shapeFlag & 198) ? f(se.el) : (
          // In other cases, the parent container is not actually used so we
          // just pass the block element here to avoid a DOM parentNode call.
          I
        )
      );
      v(
        se,
        oe,
        ye,
        null,
        J,
        Y,
        X,
        le,
        !0
      );
    }
  }, V = (_, A, I, J, Y) => {
    if (A !== I) {
      if (A !== je)
        for (const X in A)
          !to(X) && !(X in I) && n(
            _,
            X,
            A[X],
            null,
            Y,
            J
          );
      for (const X in I) {
        if (to(X)) continue;
        const le = I[X], ie = A[X];
        le !== ie && X !== "value" && n(_, X, ie, le, Y, J);
      }
      "value" in I && n(_, "value", A.value, I.value, Y);
    }
  }, z = (_, A, I, J, Y, X, le, ie, se) => {
    const oe = A.el = _ ? _.el : i(""), ye = A.anchor = _ ? _.anchor : i("");
    let { patchFlag: ce, dynamicChildren: me, slotScopeIds: Ee } = A;
    Ee && (ie = ie ? ie.concat(Ee) : Ee), _ == null ? (a(oe, I, J), a(ye, I, J), B(
      // #10007
      // such fragment like `<></>` will be compiled into
      // a fragment which doesn't have a children.
      // In this case fallback to an empty array
      A.children || [],
      I,
      ye,
      Y,
      X,
      le,
      ie,
      se
    )) : ce > 0 && ce & 64 && me && // #2715 the previous fragment could've been a BAILed one as a result
    // of renderSlot() with no valid children
    _.dynamicChildren ? ($(
      _.dynamicChildren,
      me,
      I,
      Y,
      X,
      le,
      ie
    ), // #2080 if the stable fragment has a key, it's a <template v-for> that may
    //  get moved around. Make sure all root level vnodes inherit el.
    // #2134 or if it's a component root, it may also get moved around
    // as the component is being moved.
    (A.key != null || Y && A === Y.subTree) && vl(
      _,
      A,
      !0
      /* shallow */
    )) : M(
      _,
      A,
      I,
      ye,
      Y,
      X,
      le,
      ie,
      se
    );
  }, G = (_, A, I, J, Y, X, le, ie, se) => {
    A.slotScopeIds = ie, _ == null ? A.shapeFlag & 512 ? Y.ctx.activate(
      A,
      I,
      J,
      le,
      se
    ) : ee(
      A,
      I,
      J,
      Y,
      X,
      le,
      se
    ) : xe(_, A, se);
  }, ee = (_, A, I, J, Y, X, le) => {
    const ie = _.component = e1(
      _,
      J,
      Y
    );
    if (xf(_) && (ie.ctx.renderer = te), t1(ie, !1, le), ie.asyncDep) {
      if (Y && Y.registerDep(ie, de, le), !_.el) {
        const se = ie.subTree = k(sr);
        C(null, se, A, I), _.placeholder = se.el;
      }
    } else
      de(
        ie,
        _,
        A,
        I,
        Y,
        X,
        le
      );
  }, xe = (_, A, I) => {
    const J = A.component = _.component;
    if (Kg(_, A, I))
      if (J.asyncDep && !J.asyncResolved) {
        W(J, A, I);
        return;
      } else
        J.next = A, J.update();
    else
      A.el = _.el, J.vnode = A;
  }, de = (_, A, I, J, Y, X, le) => {
    const ie = () => {
      if (_.isMounted) {
        let { next: ce, bu: me, u: Ee, parent: Oe, vnode: Ue } = _;
        {
          const Ut = Nf(_);
          if (Ut) {
            ce && (ce.el = Ue.el, W(_, ce, le)), Ut.asyncDep.then(() => {
              _.isUnmounted || ie();
            });
            return;
          }
        }
        let He = ce, yt;
        Yr(_, !1), ce ? (ce.el = Ue.el, W(_, ce, le)) : ce = Ue, me && rn(me), (yt = ce.props && ce.props.onVnodeBeforeUpdate) && Kt(yt, Oe, ce, Ue), Yr(_, !0);
        const wt = yc(_), jt = _.subTree;
        _.subTree = wt, v(
          jt,
          wt,
          // parent may have changed if it's in a teleport
          f(jt.el),
          // anchor may have changed if it's in a fragment
          y(jt),
          _,
          Y,
          X
        ), ce.el = wt.el, He === null && Wg(_, wt.el), Ee && mt(Ee, Y), (yt = ce.props && ce.props.onVnodeUpdated) && mt(
          () => Kt(yt, Oe, ce, Ue),
          Y
        );
      } else {
        let ce;
        const { el: me, props: Ee } = A, { bm: Oe, m: Ue, parent: He, root: yt, type: wt } = _, jt = Ea(A);
        Yr(_, !1), Oe && rn(Oe), !jt && (ce = Ee && Ee.onVnodeBeforeMount) && Kt(ce, He, A), Yr(_, !0);
        {
          yt.ce && // @ts-expect-error _def is private
          yt.ce._def.shadowRoot !== !1 && yt.ce._injectChildStyle(wt);
          const Ut = _.subTree = yc(_);
          v(
            null,
            Ut,
            I,
            J,
            _,
            Y,
            X
          ), A.el = Ut.el;
        }
        if (Ue && mt(Ue, Y), !jt && (ce = Ee && Ee.onVnodeMounted)) {
          const Ut = A;
          mt(
            () => Kt(ce, He, Ut),
            Y
          );
        }
        (A.shapeFlag & 256 || He && Ea(He.vnode) && He.vnode.shapeFlag & 256) && _.a && mt(_.a, Y), _.isMounted = !0, A = I = J = null;
      }
    };
    _.scope.on();
    const se = _.effect = new Ud(ie);
    _.scope.off();
    const oe = _.update = se.run.bind(se), ye = _.job = se.runIfDirty.bind(se);
    ye.i = _, ye.id = _.uid, se.scheduler = () => dl(ye), Yr(_, !0), oe();
  }, W = (_, A, I) => {
    A.component = _;
    const J = _.vnode.props;
    _.vnode = A, _.next = null, Mg(_, A.props, J, I), Dg(_, A.children, I), _r(), cc(_), kr();
  }, M = (_, A, I, J, Y, X, le, ie, se = !1) => {
    const oe = _ && _.children, ye = _ ? _.shapeFlag : 0, ce = A.children, { patchFlag: me, shapeFlag: Ee } = A;
    if (me > 0) {
      if (me & 128) {
        Me(
          oe,
          ce,
          I,
          J,
          Y,
          X,
          le,
          ie,
          se
        );
        return;
      } else if (me & 256) {
        ge(
          oe,
          ce,
          I,
          J,
          Y,
          X,
          le,
          ie,
          se
        );
        return;
      }
    }
    Ee & 8 ? (ye & 16 && _e(oe, Y, X), ce !== oe && u(I, ce)) : ye & 16 ? Ee & 16 ? Me(
      oe,
      ce,
      I,
      J,
      Y,
      X,
      le,
      ie,
      se
    ) : _e(oe, Y, X, !0) : (ye & 8 && u(I, ""), Ee & 16 && B(
      ce,
      I,
      J,
      Y,
      X,
      le,
      ie,
      se
    ));
  }, ge = (_, A, I, J, Y, X, le, ie, se) => {
    _ = _ || Ca, A = A || Ca;
    const oe = _.length, ye = A.length, ce = Math.min(oe, ye);
    let me;
    for (me = 0; me < ce; me++) {
      const Ee = A[me] = se ? Nr(A[me]) : Xt(A[me]);
      v(
        _[me],
        Ee,
        I,
        null,
        Y,
        X,
        le,
        ie,
        se
      );
    }
    oe > ye ? _e(
      _,
      Y,
      X,
      !0,
      !1,
      ce
    ) : B(
      A,
      I,
      J,
      Y,
      X,
      le,
      ie,
      se,
      ce
    );
  }, Me = (_, A, I, J, Y, X, le, ie, se) => {
    let oe = 0;
    const ye = A.length;
    let ce = _.length - 1, me = ye - 1;
    for (; oe <= ce && oe <= me; ) {
      const Ee = _[oe], Oe = A[oe] = se ? Nr(A[oe]) : Xt(A[oe]);
      if (Za(Ee, Oe))
        v(
          Ee,
          Oe,
          I,
          null,
          Y,
          X,
          le,
          ie,
          se
        );
      else
        break;
      oe++;
    }
    for (; oe <= ce && oe <= me; ) {
      const Ee = _[ce], Oe = A[me] = se ? Nr(A[me]) : Xt(A[me]);
      if (Za(Ee, Oe))
        v(
          Ee,
          Oe,
          I,
          null,
          Y,
          X,
          le,
          ie,
          se
        );
      else
        break;
      ce--, me--;
    }
    if (oe > ce) {
      if (oe <= me) {
        const Ee = me + 1, Oe = Ee < ye ? A[Ee].el : J;
        for (; oe <= me; )
          v(
            null,
            A[oe] = se ? Nr(A[oe]) : Xt(A[oe]),
            I,
            Oe,
            Y,
            X,
            le,
            ie,
            se
          ), oe++;
      }
    } else if (oe > me)
      for (; oe <= ce; )
        ze(_[oe], Y, X, !0), oe++;
    else {
      const Ee = oe, Oe = oe, Ue = /* @__PURE__ */ new Map();
      for (oe = Oe; oe <= me; oe++) {
        const Et = A[oe] = se ? Nr(A[oe]) : Xt(A[oe]);
        Et.key != null && Ue.set(Et.key, oe);
      }
      let He, yt = 0;
      const wt = me - Oe + 1;
      let jt = !1, Ut = 0;
      const ja = new Array(wt);
      for (oe = 0; oe < wt; oe++) ja[oe] = 0;
      for (oe = Ee; oe <= ce; oe++) {
        const Et = _[oe];
        if (yt >= wt) {
          ze(Et, Y, X, !0);
          continue;
        }
        let Zt;
        if (Et.key != null)
          Zt = Ue.get(Et.key);
        else
          for (He = Oe; He <= me; He++)
            if (ja[He - Oe] === 0 && Za(Et, A[He])) {
              Zt = He;
              break;
            }
        Zt === void 0 ? ze(Et, Y, X, !0) : (ja[Zt - Oe] = oe + 1, Zt >= Ut ? Ut = Zt : jt = !0, v(
          Et,
          A[Zt],
          I,
          null,
          Y,
          X,
          le,
          ie,
          se
        ), yt++);
      }
      const ac = jt ? Ng(ja) : Ca;
      for (He = ac.length - 1, oe = wt - 1; oe >= 0; oe--) {
        const Et = Oe + oe, Zt = A[Et], oc = A[Et + 1], nc = Et + 1 < ye ? (
          // #13559, fallback to el placeholder for unresolved async component
          oc.el || oc.placeholder
        ) : J;
        ja[oe] === 0 ? v(
          null,
          Zt,
          I,
          nc,
          Y,
          X,
          le,
          ie,
          se
        ) : jt && (He < 0 || oe !== ac[He] ? Ie(Zt, I, nc, 2) : He--);
      }
    }
  }, Ie = (_, A, I, J, Y = null) => {
    const { el: X, type: le, transition: ie, children: se, shapeFlag: oe } = _;
    if (oe & 6) {
      Ie(_.component.subTree, A, I, J);
      return;
    }
    if (oe & 128) {
      _.suspense.move(A, I, J);
      return;
    }
    if (oe & 64) {
      le.move(_, A, I, te);
      return;
    }
    if (le === Be) {
      a(X, A, I);
      for (let ce = 0; ce < se.length; ce++)
        Ie(se[ce], A, I, J);
      a(_.anchor, A, I);
      return;
    }
    if (le === on) {
      E(_, A, I);
      return;
    }
    if (J !== 2 && oe & 1 && ie)
      if (J === 0)
        ie.beforeEnter(X), a(X, A, I), mt(() => ie.enter(X), Y);
      else {
        const { leave: ce, delayLeave: me, afterLeave: Ee } = ie, Oe = () => {
          _.ctx.isUnmounted ? o(X) : a(X, A, I);
        }, Ue = () => {
          ce(X, () => {
            Oe(), Ee && Ee();
          });
        };
        me ? me(X, Oe, Ue) : Ue();
      }
    else
      a(X, A, I);
  }, ze = (_, A, I, J = !1, Y = !1) => {
    const {
      type: X,
      props: le,
      ref: ie,
      children: se,
      dynamicChildren: oe,
      shapeFlag: ye,
      patchFlag: ce,
      dirs: me,
      cacheIndex: Ee
    } = _;
    if (ce === -2 && (Y = !1), ie != null && (_r(), so(ie, null, I, _, !0), kr()), Ee != null && (A.renderCache[Ee] = void 0), ye & 256) {
      A.ctx.deactivate(_);
      return;
    }
    const Oe = ye & 1 && me, Ue = !Ea(_);
    let He;
    if (Ue && (He = le && le.onVnodeBeforeUnmount) && Kt(He, A, _), ye & 6)
      Ae(_.component, I, J);
    else {
      if (ye & 128) {
        _.suspense.unmount(I, J);
        return;
      }
      Oe && Jr(_, null, A, "beforeUnmount"), ye & 64 ? _.type.remove(
        _,
        A,
        I,
        te,
        J
      ) : oe && // #5154
      // when v-once is used inside a block, setBlockTracking(-1) marks the
      // parent block with hasOnce: true
      // so that it doesn't take the fast path during unmount - otherwise
      // components nested in v-once are never unmounted.
      !oe.hasOnce && // #1153: fast path should not be taken for non-stable (v-for) fragments
      (X !== Be || ce > 0 && ce & 64) ? _e(
        oe,
        A,
        I,
        !1,
        !0
      ) : (X === Be && ce & 384 || !Y && ye & 16) && _e(se, A, I), J && ae(_);
    }
    (Ue && (He = le && le.onVnodeUnmounted) || Oe) && mt(() => {
      He && Kt(He, A, _), Oe && Jr(_, null, A, "unmounted");
    }, I);
  }, ae = (_) => {
    const { type: A, el: I, anchor: J, transition: Y } = _;
    if (A === Be) {
      O(I, J);
      return;
    }
    if (A === on) {
      T(_);
      return;
    }
    const X = () => {
      o(I), Y && !Y.persisted && Y.afterLeave && Y.afterLeave();
    };
    if (_.shapeFlag & 1 && Y && !Y.persisted) {
      const { leave: le, delayLeave: ie } = Y, se = () => le(I, X);
      ie ? ie(_.el, X, se) : se();
    } else
      X();
  }, O = (_, A) => {
    let I;
    for (; _ !== A; )
      I = p(_), o(_), _ = I;
    o(A);
  }, Ae = (_, A, I) => {
    const {
      bum: J,
      scope: Y,
      job: X,
      subTree: le,
      um: ie,
      m: se,
      a: oe,
      parent: ye,
      slots: { __: ce }
    } = _;
    bc(se), bc(oe), J && rn(J), ye && Ce(ce) && ce.forEach((me) => {
      ye.renderCache[me] = void 0;
    }), Y.stop(), X && (X.flags |= 8, ze(le, _, A, I)), ie && mt(ie, A), mt(() => {
      _.isUnmounted = !0;
    }, A), A && A.pendingBranch && !A.isUnmounted && _.asyncDep && !_.asyncResolved && _.suspenseId === A.pendingId && (A.deps--, A.deps === 0 && A.resolve());
  }, _e = (_, A, I, J = !1, Y = !1, X = 0) => {
    for (let le = X; le < _.length; le++)
      ze(_[le], A, I, J, Y);
  }, y = (_) => {
    if (_.shapeFlag & 6)
      return y(_.component.subTree);
    if (_.shapeFlag & 128)
      return _.suspense.next();
    const A = p(_.anchor || _.el), I = A && A[vf];
    return I ? p(I) : A;
  };
  let Q = !1;
  const Z = (_, A, I) => {
    _ == null ? A._vnode && ze(A._vnode, null, null, !0) : v(
      A._vnode || null,
      _,
      A,
      null,
      null,
      null,
      I
    ), A._vnode = _, Q || (Q = !0, cc(), hf(), Q = !1);
  }, te = {
    p: v,
    um: ze,
    m: Ie,
    r: ae,
    mt: ee,
    mc: B,
    pc: M,
    pbc: $,
    n: y,
    o: e
  };
  return {
    render: Z,
    hydrate: void 0,
    createApp: Pg(Z)
  };
}
function bs({ type: e, props: t }, r) {
  return r === "svg" && e === "foreignObject" || r === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : r;
}
function Yr({ effect: e, job: t }, r) {
  r ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5);
}
function Lg(e, t) {
  return (!e || e && !e.pendingBranch) && t && !t.persisted;
}
function vl(e, t, r = !1) {
  const a = e.children, o = t.children;
  if (Ce(a) && Ce(o))
    for (let n = 0; n < a.length; n++) {
      const s = a[n];
      let i = o[n];
      i.shapeFlag & 1 && !i.dynamicChildren && ((i.patchFlag <= 0 || i.patchFlag === 32) && (i = o[n] = Nr(o[n]), i.el = s.el), !r && i.patchFlag !== -2 && vl(s, i)), i.type === Kn && (i.el = s.el), i.type === sr && !i.el && (i.el = s.el);
    }
}
function Ng(e) {
  const t = e.slice(), r = [0];
  let a, o, n, s, i;
  const l = e.length;
  for (a = 0; a < l; a++) {
    const c = e[a];
    if (c !== 0) {
      if (o = r[r.length - 1], e[o] < c) {
        t[a] = o, r.push(a);
        continue;
      }
      for (n = 0, s = r.length - 1; n < s; )
        i = n + s >> 1, e[r[i]] < c ? n = i + 1 : s = i;
      c < e[r[n]] && (n > 0 && (t[a] = r[n - 1]), r[n] = a);
    }
  }
  for (n = r.length, s = r[n - 1]; n-- > 0; )
    r[n] = s, s = t[s];
  return r;
}
function Nf(e) {
  const t = e.subTree.component;
  if (t)
    return t.asyncDep && !t.asyncResolved ? t : Nf(t);
}
function bc(e) {
  if (e)
    for (let t = 0; t < e.length; t++)
      e[t].flags |= 8;
}
const Vg = Symbol.for("v-scx"), Hg = () => he(Vg);
function Xe(e, t) {
  return Un(e, null, t);
}
function Vf(e, t) {
  return Un(
    e,
    null,
    { flush: "post" }
  );
}
function Ke(e, t, r) {
  return Un(e, t, r);
}
function Un(e, t, r = je) {
  const { immediate: a, deep: o, flush: n, once: s } = r, i = pt({}, r), l = t && a || !t && n !== "post";
  let c;
  if (yo) {
    if (n === "sync") {
      const h = Hg();
      c = h.__watcherHandles || (h.__watcherHandles = []);
    } else if (!l) {
      const h = () => {
      };
      return h.stop = rr, h.resume = rr, h.pause = rr, h;
    }
  }
  const u = dt;
  i.call = (h, m, v) => nr(h, u, m, v);
  let f = !1;
  n === "post" ? i.scheduler = (h) => {
    mt(h, u && u.suspense);
  } : n !== "sync" && (f = !0, i.scheduler = (h, m) => {
    m ? h() : dl(h);
  }), i.augmentJob = (h) => {
    t && (h.flags |= 4), f && (h.flags |= 2, u && (h.id = u.uid, h.i = u));
  };
  const p = eg(e, t, i);
  return yo && (c ? c.push(p) : l && p()), p;
}
function Fg(e, t, r) {
  const a = this.proxy, o = Qe(e) ? e.includes(".") ? Hf(a, e) : () => a[e] : e.bind(a, a);
  let n;
  Se(t) ? n = t : (n = t.handler, r = t);
  const s = To(this), i = Un(o, n.bind(a), r);
  return s(), i;
}
function Hf(e, t) {
  const r = t.split(".");
  return () => {
    let a = e;
    for (let o = 0; o < r.length && a; o++)
      a = a[r[o]];
    return a;
  };
}
const zg = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${At(t)}Modifiers`] || e[`${Wr(t)}Modifiers`];
function jg(e, t, ...r) {
  if (e.isUnmounted) return;
  const a = e.vnode.props || je;
  let o = r;
  const n = t.startsWith("update:"), s = n && zg(a, t.slice(7));
  s && (s.trim && (o = r.map((u) => Qe(u) ? u.trim() : u)), s.number && (o = r.map(di)));
  let i, l = a[i = ro(t)] || // also try camelCase event handler (#2249)
  a[i = ro(At(t))];
  !l && n && (l = a[i = ro(Wr(t))]), l && nr(
    l,
    e,
    6,
    o
  );
  const c = a[i + "Once"];
  if (c) {
    if (!e.emitted)
      e.emitted = {};
    else if (e.emitted[i])
      return;
    e.emitted[i] = !0, nr(
      c,
      e,
      6,
      o
    );
  }
}
function Ff(e, t, r = !1) {
  const a = t.emitsCache, o = a.get(e);
  if (o !== void 0)
    return o;
  const n = e.emits;
  let s = {}, i = !1;
  if (!Se(e)) {
    const l = (c) => {
      const u = Ff(c, t, !0);
      u && (i = !0, pt(s, u));
    };
    !r && t.mixins.length && t.mixins.forEach(l), e.extends && l(e.extends), e.mixins && e.mixins.forEach(l);
  }
  return !n && !i ? (We(e) && a.set(e, null), null) : (Ce(n) ? n.forEach((l) => s[l] = null) : pt(s, n), We(e) && a.set(e, s), s);
}
function Zn(e, t) {
  return !e || !Tn(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), Ne(e, t[0].toLowerCase() + t.slice(1)) || Ne(e, Wr(t)) || Ne(e, t));
}
function yc(e) {
  const {
    type: t,
    vnode: r,
    proxy: a,
    withProxy: o,
    propsOptions: [n],
    slots: s,
    attrs: i,
    emit: l,
    render: c,
    renderCache: u,
    props: f,
    data: p,
    setupState: h,
    ctx: m,
    inheritAttrs: v
  } = e, x = yn(e);
  let C, S;
  try {
    if (r.shapeFlag & 4) {
      const T = o || a, F = T;
      C = Xt(
        c.call(
          F,
          T,
          u,
          f,
          h,
          p,
          m
        )
      ), S = i;
    } else {
      const T = t;
      C = Xt(
        T.length > 1 ? T(
          f,
          { attrs: i, slots: s, emit: l }
        ) : T(
          f,
          null
        )
      ), S = t.props ? i : Ug(i);
    }
  } catch (T) {
    lo.length = 0, Fn(T, e, 1), C = k(sr);
  }
  let E = C;
  if (S && v !== !1) {
    const T = Object.keys(S), { shapeFlag: F } = E;
    T.length && F & 7 && (n && T.some(al) && (S = Zg(
      S,
      n
    )), E = sa(E, S, !1, !0));
  }
  return r.dirs && (E = sa(E, null, !1, !0), E.dirs = E.dirs ? E.dirs.concat(r.dirs) : r.dirs), r.transition && fl(E, r.transition), C = E, yn(x), C;
}
const Ug = (e) => {
  let t;
  for (const r in e)
    (r === "class" || r === "style" || Tn(r)) && ((t || (t = {}))[r] = e[r]);
  return t;
}, Zg = (e, t) => {
  const r = {};
  for (const a in e)
    (!al(a) || !(a.slice(9) in t)) && (r[a] = e[a]);
  return r;
};
function Kg(e, t, r) {
  const { props: a, children: o, component: n } = e, { props: s, children: i, patchFlag: l } = t, c = n.emitsOptions;
  if (t.dirs || t.transition)
    return !0;
  if (r && l >= 0) {
    if (l & 1024)
      return !0;
    if (l & 16)
      return a ? wc(a, s, c) : !!s;
    if (l & 8) {
      const u = t.dynamicProps;
      for (let f = 0; f < u.length; f++) {
        const p = u[f];
        if (s[p] !== a[p] && !Zn(c, p))
          return !0;
      }
    }
  } else
    return (o || i) && (!i || !i.$stable) ? !0 : a === s ? !1 : a ? s ? wc(a, s, c) : !0 : !!s;
  return !1;
}
function wc(e, t, r) {
  const a = Object.keys(t);
  if (a.length !== Object.keys(e).length)
    return !0;
  for (let o = 0; o < a.length; o++) {
    const n = a[o];
    if (t[n] !== e[n] && !Zn(r, n))
      return !0;
  }
  return !1;
}
function Wg({ vnode: e, parent: t }, r) {
  for (; t; ) {
    const a = t.subTree;
    if (a.suspense && a.suspense.activeBranch === e && (a.el = e.el), a === e)
      (e = t.vnode).el = r, t = t.parent;
    else
      break;
  }
}
const zf = (e) => e.__isSuspense;
function Gg(e, t) {
  t && t.pendingBranch ? Ce(e) ? t.effects.push(...e) : t.effects.push(e) : ag(e);
}
const Be = Symbol.for("v-fgt"), Kn = Symbol.for("v-txt"), sr = Symbol.for("v-cmt"), on = Symbol.for("v-stc"), lo = [];
let Pt = null;
function g(e = !1) {
  lo.push(Pt = e ? null : []);
}
function Jg() {
  lo.pop(), Pt = lo[lo.length - 1] || null;
}
let bo = 1;
function xc(e, t = !1) {
  bo += e, e < 0 && Pt && t && (Pt.hasOnce = !0);
}
function jf(e) {
  return e.dynamicChildren = bo > 0 ? Pt || Ca : null, Jg(), bo > 0 && Pt && Pt.push(e), e;
}
function R(e, t, r, a, o, n) {
  return jf(
    w(
      e,
      t,
      r,
      a,
      o,
      n,
      !0
    )
  );
}
function N(e, t, r, a, o) {
  return jf(
    k(
      e,
      t,
      r,
      a,
      o,
      !0
    )
  );
}
function er(e) {
  return e ? e.__v_isVNode === !0 : !1;
}
function Za(e, t) {
  return e.type === t.type && e.key === t.key;
}
const Uf = ({ key: e }) => e ?? null, nn = ({
  ref: e,
  ref_key: t,
  ref_for: r
}) => (typeof e == "number" && (e = "" + e), e != null ? Qe(e) || Ve(e) || Se(e) ? { i: st, r: e, k: t, f: !!r } : e : null);
function w(e, t = null, r = null, a = 0, o = null, n = e === Be ? 0 : 1, s = !1, i = !1) {
  const l = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e,
    props: t,
    key: t && Uf(t),
    ref: t && nn(t),
    scopeId: mf,
    slotScopeIds: null,
    children: r,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetStart: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag: n,
    patchFlag: a,
    dynamicProps: o,
    dynamicChildren: null,
    appContext: null,
    ctx: st
  };
  return i ? (yl(l, r), n & 128 && e.normalize(l)) : r && (l.shapeFlag |= Qe(r) ? 8 : 16), bo > 0 && // avoid a block node from tracking itself
  !s && // has current parent block
  Pt && // presence of a patch flag indicates this node needs patching on updates.
  // component nodes also should always be patched, because even if the
  // component doesn't need to update, it needs to persist the instance on to
  // the next vnode so that it can be properly unmounted later.
  (l.patchFlag > 0 || n & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
  // vnode should not be considered dynamic due to handler caching.
  l.patchFlag !== 32 && Pt.push(l), l;
}
const k = Yg;
function Yg(e, t = null, r = null, a = 0, o = null, n = !1) {
  if ((!e || e === Cf) && (e = sr), er(e)) {
    const i = sa(
      e,
      t,
      !0
      /* mergeRef: true */
    );
    return r && yl(i, r), bo > 0 && !n && Pt && (i.shapeFlag & 6 ? Pt[Pt.indexOf(e)] = i : Pt.push(i)), i.patchFlag = -2, i;
  }
  if (n1(e) && (e = e.__vccOpts), t) {
    t = Fe(t);
    let { class: i, style: l } = t;
    i && !Qe(i) && (t.class = ke(i)), We(l) && (ul(l) && !Ce(l) && (l = pt({}, l)), t.style = Tt(l));
  }
  const s = Qe(e) ? 1 : zf(e) ? 128 : ng(e) ? 64 : We(e) ? 4 : Se(e) ? 2 : 0;
  return w(
    e,
    t,
    r,
    a,
    o,
    s,
    n,
    !0
  );
}
function Fe(e) {
  return e ? ul(e) || Of(e) ? pt({}, e) : e : null;
}
function sa(e, t, r = !1, a = !1) {
  const { props: o, ref: n, patchFlag: s, children: i, transition: l } = e, c = t ? re(o || {}, t) : o, u = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e.type,
    props: c,
    key: c && Uf(c),
    ref: t && t.ref ? (
      // #2078 in the case of <component :is="vnode" ref="extra"/>
      // if the vnode itself already has a ref, cloneVNode will need to merge
      // the refs so the single vnode can be set on multiple refs
      r && n ? Ce(n) ? n.concat(nn(t)) : [n, nn(t)] : nn(t)
    ) : n,
    scopeId: e.scopeId,
    slotScopeIds: e.slotScopeIds,
    children: i,
    target: e.target,
    targetStart: e.targetStart,
    targetAnchor: e.targetAnchor,
    staticCount: e.staticCount,
    shapeFlag: e.shapeFlag,
    // if the vnode is cloned with extra props, we can no longer assume its
    // existing patch flag to be reliable and need to add the FULL_PROPS flag.
    // note: preserve flag for fragments since they use the flag for children
    // fast paths only.
    patchFlag: t && e.type !== Be ? s === -1 ? 16 : s | 16 : s,
    dynamicProps: e.dynamicProps,
    dynamicChildren: e.dynamicChildren,
    appContext: e.appContext,
    dirs: e.dirs,
    transition: l,
    // These should technically only be non-null on mounted VNodes. However,
    // they *should* be copied for kept-alive vnodes. So we just always copy
    // them since them being non-null during a mount doesn't affect the logic as
    // they will simply be overwritten.
    component: e.component,
    suspense: e.suspense,
    ssContent: e.ssContent && sa(e.ssContent),
    ssFallback: e.ssFallback && sa(e.ssFallback),
    placeholder: e.placeholder,
    el: e.el,
    anchor: e.anchor,
    ctx: e.ctx,
    ce: e.ce
  };
  return l && a && fl(
    u,
    l.clone(u)
  ), u;
}
function ne(e = " ", t = 0) {
  return k(Kn, null, e, t);
}
function bl(e, t) {
  const r = k(on, null, e);
  return r.staticCount = t, r;
}
function $e(e = "", t = !1) {
  return t ? (g(), N(sr, null, e)) : k(sr, null, e);
}
function Xt(e) {
  return e == null || typeof e == "boolean" ? k(sr) : Ce(e) ? k(
    Be,
    null,
    // #3666, avoid reference pollution when reusing vnode
    e.slice()
  ) : er(e) ? Nr(e) : k(Kn, null, String(e));
}
function Nr(e) {
  return e.el === null && e.patchFlag !== -1 || e.memo ? e : sa(e);
}
function yl(e, t) {
  let r = 0;
  const { shapeFlag: a } = e;
  if (t == null)
    t = null;
  else if (Ce(t))
    r = 16;
  else if (typeof t == "object")
    if (a & 65) {
      const o = t.default;
      o && (o._c && (o._d = !1), yl(e, o()), o._c && (o._d = !0));
      return;
    } else {
      r = 32;
      const o = t._;
      !o && !Of(t) ? t._ctx = st : o === 3 && st && (st.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
    }
  else Se(t) ? (t = { default: t, _ctx: st }, r = 32) : (t = String(t), a & 64 ? (r = 16, t = [ne(t)]) : r = 8);
  e.children = t, e.shapeFlag |= r;
}
function re(...e) {
  const t = {};
  for (let r = 0; r < e.length; r++) {
    const a = e[r];
    for (const o in a)
      if (o === "class")
        t.class !== a.class && (t.class = ke([t.class, a.class]));
      else if (o === "style")
        t.style = Tt([t.style, a.style]);
      else if (Tn(o)) {
        const n = t[o], s = a[o];
        s && n !== s && !(Ce(n) && n.includes(s)) && (t[o] = n ? [].concat(n, s) : s);
      } else o !== "" && (t[o] = a[o]);
  }
  return t;
}
function Kt(e, t, r, a = null) {
  nr(e, t, 7, [
    r,
    a
  ]);
}
const Xg = Tf();
let Qg = 0;
function e1(e, t, r) {
  const a = e.type, o = (t ? t.appContext : e.appContext) || Xg, n = {
    uid: Qg++,
    vnode: e,
    type: a,
    parent: t,
    appContext: o,
    root: null,
    // to be immediately set
    next: null,
    subTree: null,
    // will be set synchronously right after creation
    effect: null,
    update: null,
    // will be set synchronously right after creation
    job: null,
    scope: new jd(
      !0
      /* detached */
    ),
    render: null,
    proxy: null,
    exposed: null,
    exposeProxy: null,
    withProxy: null,
    provides: t ? t.provides : Object.create(o.provides),
    ids: t ? t.ids : ["", 0, 0],
    accessCache: null,
    renderCache: [],
    // local resolved assets
    components: null,
    directives: null,
    // resolved props and emits options
    propsOptions: Df(a, o),
    emitsOptions: Ff(a, o),
    // emit
    emit: null,
    // to be set immediately
    emitted: null,
    // props default value
    propsDefaults: je,
    // inheritAttrs
    inheritAttrs: a.inheritAttrs,
    // state
    ctx: je,
    data: je,
    props: je,
    attrs: je,
    slots: je,
    refs: je,
    setupState: je,
    setupContext: null,
    // suspense related
    suspense: r,
    suspenseId: r ? r.pendingId : 0,
    asyncDep: null,
    asyncResolved: !1,
    // lifecycle hooks
    // not using enums here because it results in computed properties
    isMounted: !1,
    isUnmounted: !1,
    isDeactivated: !1,
    bc: null,
    c: null,
    bm: null,
    m: null,
    bu: null,
    u: null,
    um: null,
    bum: null,
    da: null,
    a: null,
    rtg: null,
    rtc: null,
    ec: null,
    sp: null
  };
  return n.ctx = { _: n }, n.root = t ? t.root : n, n.emit = jg.bind(null, n), e.ce && e.ce(n), n;
}
let dt = null;
const bt = () => dt || st;
let xn, xi;
{
  const e = Bn(), t = (r, a) => {
    let o;
    return (o = e[r]) || (o = e[r] = []), o.push(a), (n) => {
      o.length > 1 ? o.forEach((s) => s(n)) : o[0](n);
    };
  };
  xn = t(
    "__VUE_INSTANCE_SETTERS__",
    (r) => dt = r
  ), xi = t(
    "__VUE_SSR_SETTERS__",
    (r) => yo = r
  );
}
const To = (e) => {
  const t = dt;
  return xn(e), e.scope.on(), () => {
    e.scope.off(), xn(t);
  };
}, _c = () => {
  dt && dt.scope.off(), xn(null);
};
function Zf(e) {
  return e.vnode.shapeFlag & 4;
}
let yo = !1;
function t1(e, t = !1, r = !1) {
  t && xi(t);
  const { props: a, children: o } = e.vnode, n = Zf(e);
  Tg(e, a, n, t), Bg(e, o, r || t);
  const s = n ? r1(e, t) : void 0;
  return t && xi(!1), s;
}
function r1(e, t) {
  const r = e.type;
  e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = new Proxy(e.ctx, wg);
  const { setup: a } = r;
  if (a) {
    _r();
    const o = e.setupContext = a.length > 1 ? Wf(e) : null, n = To(e), s = Po(
      a,
      e,
      0,
      [
        e.props,
        o
      ]
    ), i = Ld(s);
    if (kr(), n(), (i || e.sp) && !Ea(e) && wf(e), i) {
      if (s.then(_c, _c), t)
        return s.then((l) => {
          kc(e, l);
        }).catch((l) => {
          Fn(l, e, 0);
        });
      e.asyncDep = s;
    } else
      kc(e, s);
  } else
    Kf(e);
}
function kc(e, t, r) {
  Se(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : We(t) && (e.setupState = uf(t)), Kf(e);
}
function Kf(e, t, r) {
  const a = e.type;
  e.render || (e.render = a.render || rr);
  {
    const o = To(e);
    _r();
    try {
      kg(e);
    } finally {
      kr(), o();
    }
  }
}
const a1 = {
  get(e, t) {
    return ct(e, "get", ""), e[t];
  }
};
function Wf(e) {
  const t = (r) => {
    e.exposed = r || {};
  };
  return {
    attrs: new Proxy(e.attrs, a1),
    slots: e.slots,
    emit: e.emit,
    expose: t
  };
}
function Wn(e) {
  return e.exposed ? e.exposeProxy || (e.exposeProxy = new Proxy(uf(Hn(e.exposed)), {
    get(t, r) {
      if (r in t)
        return t[r];
      if (r in io)
        return io[r](e);
    },
    has(t, r) {
      return r in t || r in io;
    }
  })) : e.proxy;
}
function o1(e, t = !0) {
  return Se(e) ? e.displayName || e.name : e.name || t && e.__name;
}
function n1(e) {
  return Se(e) && "__vccOpts" in e;
}
const L = (e, t) => Xh(e, t, yo);
function Nt(e, t, r) {
  const a = arguments.length;
  return a === 2 ? We(t) && !Ce(t) ? er(t) ? k(e, null, [t]) : k(e, t) : k(e, null, t) : (a > 3 ? r = Array.prototype.slice.call(arguments, 2) : a === 3 && er(r) && (r = [r]), k(e, t, r));
}
const s1 = "3.5.18";
/**
* @vue/runtime-dom v3.5.18
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let _i;
const Cc = typeof window < "u" && window.trustedTypes;
if (Cc)
  try {
    _i = /* @__PURE__ */ Cc.createPolicy("vue", {
      createHTML: (e) => e
    });
  } catch {
  }
const Gf = _i ? (e) => _i.createHTML(e) : (e) => e, i1 = "http://www.w3.org/2000/svg", l1 = "http://www.w3.org/1998/Math/MathML", mr = typeof document < "u" ? document : null, Ac = mr && /* @__PURE__ */ mr.createElement("template"), c1 = {
  insert: (e, t, r) => {
    t.insertBefore(e, r || null);
  },
  remove: (e) => {
    const t = e.parentNode;
    t && t.removeChild(e);
  },
  createElement: (e, t, r, a) => {
    const o = t === "svg" ? mr.createElementNS(i1, e) : t === "mathml" ? mr.createElementNS(l1, e) : r ? mr.createElement(e, { is: r }) : mr.createElement(e);
    return e === "select" && a && a.multiple != null && o.setAttribute("multiple", a.multiple), o;
  },
  createText: (e) => mr.createTextNode(e),
  createComment: (e) => mr.createComment(e),
  setText: (e, t) => {
    e.nodeValue = t;
  },
  setElementText: (e, t) => {
    e.textContent = t;
  },
  parentNode: (e) => e.parentNode,
  nextSibling: (e) => e.nextSibling,
  querySelector: (e) => mr.querySelector(e),
  setScopeId(e, t) {
    e.setAttribute(t, "");
  },
  // __UNSAFE__
  // Reason: innerHTML.
  // Static content here can only come from compiled templates.
  // As long as the user only uses trusted templates, this is safe.
  insertStaticContent(e, t, r, a, o, n) {
    const s = r ? r.previousSibling : t.lastChild;
    if (o && (o === n || o.nextSibling))
      for (; t.insertBefore(o.cloneNode(!0), r), !(o === n || !(o = o.nextSibling)); )
        ;
    else {
      Ac.innerHTML = Gf(
        a === "svg" ? `<svg>${e}</svg>` : a === "mathml" ? `<math>${e}</math>` : e
      );
      const i = Ac.content;
      if (a === "svg" || a === "mathml") {
        const l = i.firstChild;
        for (; l.firstChild; )
          i.appendChild(l.firstChild);
        i.removeChild(l);
      }
      t.insertBefore(i, r);
    }
    return [
      // first
      s ? s.nextSibling : t.firstChild,
      // last
      r ? r.previousSibling : t.lastChild
    ];
  }
}, u1 = Symbol("_vtc");
function d1(e, t, r) {
  const a = e[u1];
  a && (t = (t ? [t, ...a] : [...a]).join(" ")), t == null ? e.removeAttribute("class") : r ? e.setAttribute("class", t) : e.className = t;
}
const Sc = Symbol("_vod"), f1 = Symbol("_vsh"), p1 = Symbol(""), h1 = /(^|;)\s*display\s*:/;
function g1(e, t, r) {
  const a = e.style, o = Qe(r);
  let n = !1;
  if (r && !o) {
    if (t)
      if (Qe(t))
        for (const s of t.split(";")) {
          const i = s.slice(0, s.indexOf(":")).trim();
          r[i] == null && sn(a, i, "");
        }
      else
        for (const s in t)
          r[s] == null && sn(a, s, "");
    for (const s in r)
      s === "display" && (n = !0), sn(a, s, r[s]);
  } else if (o) {
    if (t !== r) {
      const s = a[p1];
      s && (r += ";" + s), a.cssText = r, n = h1.test(r);
    }
  } else t && e.removeAttribute("style");
  Sc in e && (e[Sc] = n ? a.display : "", e[f1] && (a.display = "none"));
}
const Ec = /\s*!important$/;
function sn(e, t, r) {
  if (Ce(r))
    r.forEach((a) => sn(e, t, a));
  else if (r == null && (r = ""), t.startsWith("--"))
    e.setProperty(t, r);
  else {
    const a = m1(e, t);
    Ec.test(r) ? e.setProperty(
      Wr(a),
      r.replace(Ec, ""),
      "important"
    ) : e[a] = r;
  }
}
const $c = ["Webkit", "Moz", "ms"], ys = {};
function m1(e, t) {
  const r = ys[t];
  if (r)
    return r;
  let a = At(t);
  if (a !== "filter" && a in e)
    return ys[t] = a;
  a = On(a);
  for (let o = 0; o < $c.length; o++) {
    const n = $c[o] + a;
    if (n in e)
      return ys[t] = n;
  }
  return t;
}
const Pc = "http://www.w3.org/1999/xlink";
function Tc(e, t, r, a, o, n = Ch(t)) {
  a && t.startsWith("xlink:") ? r == null ? e.removeAttributeNS(Pc, t.slice(6, t.length)) : e.setAttributeNS(Pc, t, r) : r == null || n && !Hd(r) ? e.removeAttribute(t) : e.setAttribute(
    t,
    n ? "" : Sr(r) ? String(r) : r
  );
}
function Mc(e, t, r, a, o) {
  if (t === "innerHTML" || t === "textContent") {
    r != null && (e[t] = t === "innerHTML" ? Gf(r) : r);
    return;
  }
  const n = e.tagName;
  if (t === "value" && n !== "PROGRESS" && // custom elements may use _value internally
  !n.includes("-")) {
    const i = n === "OPTION" ? e.getAttribute("value") || "" : e.value, l = r == null ? (
      // #11647: value should be set as empty string for null and undefined,
      // but <input type="checkbox"> should be set as 'on'.
      e.type === "checkbox" ? "on" : ""
    ) : String(r);
    (i !== l || !("_value" in e)) && (e.value = l), r == null && e.removeAttribute(t), e._value = r;
    return;
  }
  let s = !1;
  if (r === "" || r == null) {
    const i = typeof e[t];
    i === "boolean" ? r = Hd(r) : r == null && i === "string" ? (r = "", s = !0) : i === "number" && (r = 0, s = !0);
  }
  try {
    e[t] = r;
  } catch {
  }
  s && e.removeAttribute(o || t);
}
function wa(e, t, r, a) {
  e.addEventListener(t, r, a);
}
function v1(e, t, r, a) {
  e.removeEventListener(t, r, a);
}
const Rc = Symbol("_vei");
function b1(e, t, r, a, o = null) {
  const n = e[Rc] || (e[Rc] = {}), s = n[t];
  if (a && s)
    s.value = a;
  else {
    const [i, l] = y1(t);
    if (a) {
      const c = n[t] = _1(
        a,
        o
      );
      wa(e, i, c, l);
    } else s && (v1(e, i, s, l), n[t] = void 0);
  }
}
const Oc = /(?:Once|Passive|Capture)$/;
function y1(e) {
  let t;
  if (Oc.test(e)) {
    t = {};
    let a;
    for (; a = e.match(Oc); )
      e = e.slice(0, e.length - a[0].length), t[a[0].toLowerCase()] = !0;
  }
  return [e[2] === ":" ? e.slice(3) : Wr(e.slice(2)), t];
}
let ws = 0;
const w1 = /* @__PURE__ */ Promise.resolve(), x1 = () => ws || (w1.then(() => ws = 0), ws = Date.now());
function _1(e, t) {
  const r = (a) => {
    if (!a._vts)
      a._vts = Date.now();
    else if (a._vts <= r.attached)
      return;
    nr(
      k1(a, r.value),
      t,
      5,
      [a]
    );
  };
  return r.value = e, r.attached = x1(), r;
}
function k1(e, t) {
  if (Ce(t)) {
    const r = e.stopImmediatePropagation;
    return e.stopImmediatePropagation = () => {
      r.call(e), e._stopped = !0;
    }, t.map(
      (a) => (o) => !o._stopped && a && a(o)
    );
  } else
    return t;
}
const Bc = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // lowercase letter
e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, C1 = (e, t, r, a, o, n) => {
  const s = o === "svg";
  t === "class" ? d1(e, a, s) : t === "style" ? g1(e, r, a) : Tn(t) ? al(t) || b1(e, t, r, a, n) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : A1(e, t, a, s)) ? (Mc(e, t, a), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && Tc(e, t, a, s, n, t !== "value")) : /* #11081 force set props for possible async custom element */ e._isVueCE && (/[A-Z]/.test(t) || !Qe(a)) ? Mc(e, At(t), a, n, t) : (t === "true-value" ? e._trueValue = a : t === "false-value" && (e._falseValue = a), Tc(e, t, a, s));
};
function A1(e, t, r, a) {
  if (a)
    return !!(t === "innerHTML" || t === "textContent" || t in e && Bc(t) && Se(r));
  if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "autocorrect" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA")
    return !1;
  if (t === "width" || t === "height") {
    const o = e.tagName;
    if (o === "IMG" || o === "VIDEO" || o === "CANVAS" || o === "SOURCE")
      return !1;
  }
  return Bc(t) && Qe(r) ? !1 : t in e;
}
const Dc = (e) => {
  const t = e.props["onUpdate:modelValue"] || !1;
  return Ce(t) ? (r) => rn(t, r) : t;
};
function S1(e) {
  e.target.composing = !0;
}
function Ic(e) {
  const t = e.target;
  t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")));
}
const xs = Symbol("_assign"), E1 = {
  created(e, { modifiers: { lazy: t, trim: r, number: a } }, o) {
    e[xs] = Dc(o);
    const n = a || o.props && o.props.type === "number";
    wa(e, t ? "change" : "input", (s) => {
      if (s.target.composing) return;
      let i = e.value;
      r && (i = i.trim()), n && (i = di(i)), e[xs](i);
    }), r && wa(e, "change", () => {
      e.value = e.value.trim();
    }), t || (wa(e, "compositionstart", S1), wa(e, "compositionend", Ic), wa(e, "change", Ic));
  },
  // set value on mounted so it's after min/max for type="range"
  mounted(e, { value: t }) {
    e.value = t ?? "";
  },
  beforeUpdate(e, { value: t, oldValue: r, modifiers: { lazy: a, trim: o, number: n } }, s) {
    if (e[xs] = Dc(s), e.composing) return;
    const i = (n || e.type === "number") && !/^0\d/.test(e.value) ? di(e.value) : e.value, l = t ?? "";
    i !== l && (document.activeElement === e && e.type !== "range" && (a && t === r || o && e.value.trim() === l) || (e.value = l));
  }
}, $1 = ["ctrl", "shift", "alt", "meta"], P1 = {
  stop: (e) => e.stopPropagation(),
  prevent: (e) => e.preventDefault(),
  self: (e) => e.target !== e.currentTarget,
  ctrl: (e) => !e.ctrlKey,
  shift: (e) => !e.shiftKey,
  alt: (e) => !e.altKey,
  meta: (e) => !e.metaKey,
  left: (e) => "button" in e && e.button !== 0,
  middle: (e) => "button" in e && e.button !== 1,
  right: (e) => "button" in e && e.button !== 2,
  exact: (e, t) => $1.some((r) => e[`${r}Key`] && !t.includes(r))
}, ir = (e, t) => {
  const r = e._withMods || (e._withMods = {}), a = t.join(".");
  return r[a] || (r[a] = (o, ...n) => {
    for (let s = 0; s < t.length; s++) {
      const i = P1[t[s]];
      if (i && i(o, t)) return;
    }
    return e(o, ...n);
  });
}, T1 = {
  esc: "escape",
  space: " ",
  up: "arrow-up",
  left: "arrow-left",
  right: "arrow-right",
  down: "arrow-down",
  delete: "backspace"
}, wl = (e, t) => {
  const r = e._withKeys || (e._withKeys = {}), a = t.join(".");
  return r[a] || (r[a] = (o) => {
    if (!("key" in o))
      return;
    const n = Wr(o.key);
    if (t.some(
      (s) => s === n || T1[s] === n
    ))
      return e(o);
  });
}, M1 = /* @__PURE__ */ pt({ patchProp: C1 }, c1);
let qc;
function R1() {
  return qc || (qc = Ig(M1));
}
const O1 = (...e) => {
  const t = R1().createApp(...e), { mount: r } = t;
  return t.mount = (a) => {
    const o = D1(a);
    if (!o) return;
    const n = t._component;
    !Se(n) && !n.render && !n.template && (n.template = o.innerHTML), o.nodeType === 1 && (o.textContent = "");
    const s = r(o, !1, B1(o));
    return o instanceof Element && (o.removeAttribute("v-cloak"), o.setAttribute("data-v-app", "")), s;
  }, t;
};
function B1(e) {
  if (e instanceof SVGElement)
    return "svg";
  if (typeof MathMLElement == "function" && e instanceof MathMLElement)
    return "mathml";
}
function D1(e) {
  return Qe(e) ? document.querySelector(e) : e;
}
/*!
 * pinia v3.0.3
 * (c) 2025 Eduardo San Martin Morote
 * @license MIT
 */
let Jf;
const Gn = (e) => Jf = e, Yf = (
  /* istanbul ignore next */
  Symbol()
);
function ki(e) {
  return e && typeof e == "object" && Object.prototype.toString.call(e) === "[object Object]" && typeof e.toJSON != "function";
}
var co;
(function(e) {
  e.direct = "direct", e.patchObject = "patch object", e.patchFunction = "patch function";
})(co || (co = {}));
function I1() {
  const e = Dn(!0), t = e.run(() => K({}));
  let r = [], a = [];
  const o = Hn({
    install(n) {
      Gn(o), o._a = n, n.provide(Yf, o), n.config.globalProperties.$pinia = o, a.forEach((s) => r.push(s)), a = [];
    },
    use(n) {
      return this._a ? r.push(n) : a.push(n), this;
    },
    _p: r,
    // it's actually undefined here
    // @ts-expect-error
    _a: null,
    _e: e,
    _s: /* @__PURE__ */ new Map(),
    state: t
  });
  return o;
}
const Xf = () => {
};
function Lc(e, t, r, a = Xf) {
  e.push(t);
  const o = () => {
    const n = e.indexOf(t);
    n > -1 && (e.splice(n, 1), a());
  };
  return !r && $o() && In(o), o;
}
function ha(e, ...t) {
  e.slice().forEach((r) => {
    r(...t);
  });
}
const q1 = (e) => e(), Nc = Symbol(), _s = Symbol();
function Ci(e, t) {
  e instanceof Map && t instanceof Map ? t.forEach((r, a) => e.set(a, r)) : e instanceof Set && t instanceof Set && t.forEach(e.add, e);
  for (const r in t) {
    if (!t.hasOwnProperty(r))
      continue;
    const a = t[r], o = e[r];
    ki(o) && ki(a) && e.hasOwnProperty(r) && !Ve(a) && !zr(a) ? e[r] = Ci(o, a) : e[r] = a;
  }
  return e;
}
const L1 = (
  /* istanbul ignore next */
  Symbol()
);
function N1(e) {
  return !ki(e) || !Object.prototype.hasOwnProperty.call(e, L1);
}
const { assign: Dr } = Object;
function V1(e) {
  return !!(Ve(e) && e.effect);
}
function H1(e, t, r, a) {
  const { state: o, actions: n, getters: s } = t, i = r.state.value[e];
  let l;
  function c() {
    i || (r.state.value[e] = o ? o() : {});
    const u = ht(r.state.value[e]);
    return Dr(u, n, Object.keys(s || {}).reduce((f, p) => (f[p] = Hn(L(() => {
      Gn(r);
      const h = r._s.get(e);
      return s[p].call(h, h);
    })), f), {}));
  }
  return l = Qf(e, c, t, r, a, !0), l;
}
function Qf(e, t, r = {}, a, o, n) {
  let s;
  const i = Dr({ actions: {} }, r), l = { deep: !0 };
  let c, u, f = [], p = [], h;
  const m = a.state.value[e];
  !n && !m && (a.state.value[e] = {}), K({});
  let v;
  function x(B) {
    let P;
    c = u = !1, typeof B == "function" ? (B(a.state.value[e]), P = {
      type: co.patchFunction,
      storeId: e,
      events: h
    }) : (Ci(a.state.value[e], B), P = {
      type: co.patchObject,
      payload: B,
      storeId: e,
      events: h
    });
    const $ = v = Symbol();
    et().then(() => {
      v === $ && (c = !0);
    }), u = !0, ha(f, P, a.state.value[e]);
  }
  const C = n ? function() {
    const { state: P } = r, $ = P ? P() : {};
    this.$patch((V) => {
      Dr(V, $);
    });
  } : (
    /* istanbul ignore next */
    Xf
  );
  function S() {
    s.stop(), f = [], p = [], a._s.delete(e);
  }
  const E = (B, P = "") => {
    if (Nc in B)
      return B[_s] = P, B;
    const $ = function() {
      Gn(a);
      const V = Array.from(arguments), z = [], G = [];
      function ee(W) {
        z.push(W);
      }
      function xe(W) {
        G.push(W);
      }
      ha(p, {
        args: V,
        name: $[_s],
        store: F,
        after: ee,
        onError: xe
      });
      let de;
      try {
        de = B.apply(this && this.$id === e ? this : F, V);
      } catch (W) {
        throw ha(G, W), W;
      }
      return de instanceof Promise ? de.then((W) => (ha(z, W), W)).catch((W) => (ha(G, W), Promise.reject(W))) : (ha(z, de), de);
    };
    return $[Nc] = !0, $[_s] = P, $;
  }, T = {
    _p: a,
    // _s: scope,
    $id: e,
    $onAction: Lc.bind(null, p),
    $patch: x,
    $reset: C,
    $subscribe(B, P = {}) {
      const $ = Lc(f, B, P.detached, () => V()), V = s.run(() => Ke(() => a.state.value[e], (z) => {
        (P.flush === "sync" ? u : c) && B({
          storeId: e,
          type: co.direct,
          events: h
        }, z);
      }, Dr({}, l, P)));
      return $;
    },
    $dispose: S
  }, F = Rt(T);
  a._s.set(e, F);
  const H = (a._a && a._a.runWithContext || q1)(() => a._e.run(() => (s = Dn()).run(() => t({ action: E }))));
  for (const B in H) {
    const P = H[B];
    if (Ve(P) && !V1(P) || zr(P))
      n || (m && N1(P) && (Ve(P) ? P.value = m[B] : Ci(P, m[B])), a.state.value[e][B] = P);
    else if (typeof P == "function") {
      const $ = E(P, B);
      H[B] = $, i.actions[B] = P;
    }
  }
  return Dr(F, H), Dr(qe(F), H), Object.defineProperty(F, "$state", {
    get: () => a.state.value[e],
    set: (B) => {
      x((P) => {
        Dr(P, B);
      });
    }
  }), a._p.forEach((B) => {
    Dr(F, s.run(() => B({
      store: F,
      app: a._a,
      pinia: a,
      options: i
    })));
  }), m && n && r.hydrate && r.hydrate(F.$state, m), c = !0, u = !0, F;
}
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function ep(e, t, r) {
  let a;
  const o = typeof t == "function";
  a = o ? r : t;
  function n(s, i) {
    const l = hl();
    return s = // in test mode, ignore the argument provided as we can always retrieve a
    // pinia instance with getActivePinia()
    s || (l ? he(Yf, null) : null), s && Gn(s), s = Jf, s._s.has(e) || (o ? Qf(e, t, a, s) : H1(e, a, s)), s._s.get(e);
  }
  return n.$id = e, n;
}
/*!
  * vue-router v4.5.1
  * (c) 2025 Eduardo San Martin Morote
  * @license MIT
  */
const xa = typeof document < "u";
function tp(e) {
  return typeof e == "object" || "displayName" in e || "props" in e || "__vccOpts" in e;
}
function F1(e) {
  return e.__esModule || e[Symbol.toStringTag] === "Module" || // support CF with dynamic imports that do not
  // add the Module string tag
  e.default && tp(e.default);
}
const Le = Object.assign;
function ks(e, t) {
  const r = {};
  for (const a in t) {
    const o = t[a];
    r[a] = Vt(o) ? o.map(e) : e(o);
  }
  return r;
}
const uo = () => {
}, Vt = Array.isArray, rp = /#/g, z1 = /&/g, j1 = /\//g, U1 = /=/g, Z1 = /\?/g, ap = /\+/g, K1 = /%5B/g, W1 = /%5D/g, op = /%5E/g, G1 = /%60/g, np = /%7B/g, J1 = /%7C/g, sp = /%7D/g, Y1 = /%20/g;
function xl(e) {
  return encodeURI("" + e).replace(J1, "|").replace(K1, "[").replace(W1, "]");
}
function X1(e) {
  return xl(e).replace(np, "{").replace(sp, "}").replace(op, "^");
}
function Ai(e) {
  return xl(e).replace(ap, "%2B").replace(Y1, "+").replace(rp, "%23").replace(z1, "%26").replace(G1, "`").replace(np, "{").replace(sp, "}").replace(op, "^");
}
function Q1(e) {
  return Ai(e).replace(U1, "%3D");
}
function em(e) {
  return xl(e).replace(rp, "%23").replace(Z1, "%3F");
}
function tm(e) {
  return e == null ? "" : em(e).replace(j1, "%2F");
}
function wo(e) {
  try {
    return decodeURIComponent("" + e);
  } catch {
  }
  return "" + e;
}
const rm = /\/$/, am = (e) => e.replace(rm, "");
function Cs(e, t, r = "/") {
  let a, o = {}, n = "", s = "";
  const i = t.indexOf("#");
  let l = t.indexOf("?");
  return i < l && i >= 0 && (l = -1), l > -1 && (a = t.slice(0, l), n = t.slice(l + 1, i > -1 ? i : t.length), o = e(n)), i > -1 && (a = a || t.slice(0, i), s = t.slice(i, t.length)), a = im(a ?? t, r), {
    fullPath: a + (n && "?") + n + s,
    path: a,
    query: o,
    hash: wo(s)
  };
}
function om(e, t) {
  const r = t.query ? e(t.query) : "";
  return t.path + (r && "?") + r + (t.hash || "");
}
function Vc(e, t) {
  return !t || !e.toLowerCase().startsWith(t.toLowerCase()) ? e : e.slice(t.length) || "/";
}
function nm(e, t, r) {
  const a = t.matched.length - 1, o = r.matched.length - 1;
  return a > -1 && a === o && Ta(t.matched[a], r.matched[o]) && ip(t.params, r.params) && e(t.query) === e(r.query) && t.hash === r.hash;
}
function Ta(e, t) {
  return (e.aliasOf || e) === (t.aliasOf || t);
}
function ip(e, t) {
  if (Object.keys(e).length !== Object.keys(t).length)
    return !1;
  for (const r in e)
    if (!sm(e[r], t[r]))
      return !1;
  return !0;
}
function sm(e, t) {
  return Vt(e) ? Hc(e, t) : Vt(t) ? Hc(t, e) : e === t;
}
function Hc(e, t) {
  return Vt(t) ? e.length === t.length && e.every((r, a) => r === t[a]) : e.length === 1 && e[0] === t;
}
function im(e, t) {
  if (e.startsWith("/"))
    return e;
  if (!e)
    return t;
  const r = t.split("/"), a = e.split("/"), o = a[a.length - 1];
  (o === ".." || o === ".") && a.push("");
  let n = r.length - 1, s, i;
  for (s = 0; s < a.length; s++)
    if (i = a[s], i !== ".")
      if (i === "..")
        n > 1 && n--;
      else
        break;
  return r.slice(0, n).join("/") + "/" + a.slice(s).join("/");
}
const Pr = {
  path: "/",
  // TODO: could we use a symbol in the future?
  name: void 0,
  params: {},
  query: {},
  hash: "",
  fullPath: "/",
  matched: [],
  meta: {},
  redirectedFrom: void 0
};
var xo;
(function(e) {
  e.pop = "pop", e.push = "push";
})(xo || (xo = {}));
var fo;
(function(e) {
  e.back = "back", e.forward = "forward", e.unknown = "";
})(fo || (fo = {}));
function lm(e) {
  if (!e)
    if (xa) {
      const t = document.querySelector("base");
      e = t && t.getAttribute("href") || "/", e = e.replace(/^\w+:\/\/[^\/]+/, "");
    } else
      e = "/";
  return e[0] !== "/" && e[0] !== "#" && (e = "/" + e), am(e);
}
const cm = /^[^#]+#/;
function um(e, t) {
  return e.replace(cm, "#") + t;
}
function dm(e, t) {
  const r = document.documentElement.getBoundingClientRect(), a = e.getBoundingClientRect();
  return {
    behavior: t.behavior,
    left: a.left - r.left - (t.left || 0),
    top: a.top - r.top - (t.top || 0)
  };
}
const Jn = () => ({
  left: window.scrollX,
  top: window.scrollY
});
function fm(e) {
  let t;
  if ("el" in e) {
    const r = e.el, a = typeof r == "string" && r.startsWith("#"), o = typeof r == "string" ? a ? document.getElementById(r.slice(1)) : document.querySelector(r) : r;
    if (!o)
      return;
    t = dm(o, e);
  } else
    t = e;
  "scrollBehavior" in document.documentElement.style ? window.scrollTo(t) : window.scrollTo(t.left != null ? t.left : window.scrollX, t.top != null ? t.top : window.scrollY);
}
function Fc(e, t) {
  return (history.state ? history.state.position - t : -1) + e;
}
const Si = /* @__PURE__ */ new Map();
function pm(e, t) {
  Si.set(e, t);
}
function hm(e) {
  const t = Si.get(e);
  return Si.delete(e), t;
}
let gm = () => location.protocol + "//" + location.host;
function lp(e, t) {
  const { pathname: r, search: a, hash: o } = t, n = e.indexOf("#");
  if (n > -1) {
    let i = o.includes(e.slice(n)) ? e.slice(n).length : 1, l = o.slice(i);
    return l[0] !== "/" && (l = "/" + l), Vc(l, "");
  }
  return Vc(r, e) + a + o;
}
function mm(e, t, r, a) {
  let o = [], n = [], s = null;
  const i = ({ state: p }) => {
    const h = lp(e, location), m = r.value, v = t.value;
    let x = 0;
    if (p) {
      if (r.value = h, t.value = p, s && s === m) {
        s = null;
        return;
      }
      x = v ? p.position - v.position : 0;
    } else
      a(h);
    o.forEach((C) => {
      C(r.value, m, {
        delta: x,
        type: xo.pop,
        direction: x ? x > 0 ? fo.forward : fo.back : fo.unknown
      });
    });
  };
  function l() {
    s = r.value;
  }
  function c(p) {
    o.push(p);
    const h = () => {
      const m = o.indexOf(p);
      m > -1 && o.splice(m, 1);
    };
    return n.push(h), h;
  }
  function u() {
    const { history: p } = window;
    p.state && p.replaceState(Le({}, p.state, { scroll: Jn() }), "");
  }
  function f() {
    for (const p of n)
      p();
    n = [], window.removeEventListener("popstate", i), window.removeEventListener("beforeunload", u);
  }
  return window.addEventListener("popstate", i), window.addEventListener("beforeunload", u, {
    passive: !0
  }), {
    pauseListeners: l,
    listen: c,
    destroy: f
  };
}
function zc(e, t, r, a = !1, o = !1) {
  return {
    back: e,
    current: t,
    forward: r,
    replaced: a,
    position: window.history.length,
    scroll: o ? Jn() : null
  };
}
function vm(e) {
  const { history: t, location: r } = window, a = {
    value: lp(e, r)
  }, o = { value: t.state };
  o.value || n(a.value, {
    back: null,
    current: a.value,
    forward: null,
    // the length is off by one, we need to decrease it
    position: t.length - 1,
    replaced: !0,
    // don't add a scroll as the user may have an anchor, and we want
    // scrollBehavior to be triggered without a saved position
    scroll: null
  }, !0);
  function n(l, c, u) {
    const f = e.indexOf("#"), p = f > -1 ? (r.host && document.querySelector("base") ? e : e.slice(f)) + l : gm() + e + l;
    try {
      t[u ? "replaceState" : "pushState"](c, "", p), o.value = c;
    } catch (h) {
      console.error(h), r[u ? "replace" : "assign"](p);
    }
  }
  function s(l, c) {
    const u = Le({}, t.state, zc(
      o.value.back,
      // keep back and forward entries but override current position
      l,
      o.value.forward,
      !0
    ), c, { position: o.value.position });
    n(l, u, !0), a.value = l;
  }
  function i(l, c) {
    const u = Le(
      {},
      // use current history state to gracefully handle a wrong call to
      // history.replaceState
      // https://github.com/vuejs/router/issues/366
      o.value,
      t.state,
      {
        forward: l,
        scroll: Jn()
      }
    );
    n(u.current, u, !0);
    const f = Le({}, zc(a.value, l, null), { position: u.position + 1 }, c);
    n(l, f, !1), a.value = l;
  }
  return {
    location: a,
    state: o,
    push: i,
    replace: s
  };
}
function bm(e) {
  e = lm(e);
  const t = vm(e), r = mm(e, t.state, t.location, t.replace);
  function a(n, s = !0) {
    s || r.pauseListeners(), history.go(n);
  }
  const o = Le({
    // it's overridden right after
    location: "",
    base: e,
    go: a,
    createHref: um.bind(null, e)
  }, t, r);
  return Object.defineProperty(o, "location", {
    enumerable: !0,
    get: () => t.location.value
  }), Object.defineProperty(o, "state", {
    enumerable: !0,
    get: () => t.state.value
  }), o;
}
function ym(e) {
  return e = location.host ? e || location.pathname + location.search : "", e.includes("#") || (e += "#"), bm(e);
}
function wm(e) {
  return typeof e == "string" || e && typeof e == "object";
}
function cp(e) {
  return typeof e == "string" || typeof e == "symbol";
}
const up = Symbol("");
var jc;
(function(e) {
  e[e.aborted = 4] = "aborted", e[e.cancelled = 8] = "cancelled", e[e.duplicated = 16] = "duplicated";
})(jc || (jc = {}));
function Ma(e, t) {
  return Le(new Error(), {
    type: e,
    [up]: !0
  }, t);
}
function hr(e, t) {
  return e instanceof Error && up in e && (t == null || !!(e.type & t));
}
const Uc = "[^/]+?", xm = {
  sensitive: !1,
  strict: !1,
  start: !0,
  end: !0
}, _m = /[.+*?^${}()[\]/\\]/g;
function km(e, t) {
  const r = Le({}, xm, t), a = [];
  let o = r.start ? "^" : "";
  const n = [];
  for (const c of e) {
    const u = c.length ? [] : [
      90
      /* PathScore.Root */
    ];
    r.strict && !c.length && (o += "/");
    for (let f = 0; f < c.length; f++) {
      const p = c[f];
      let h = 40 + (r.sensitive ? 0.25 : 0);
      if (p.type === 0)
        f || (o += "/"), o += p.value.replace(_m, "\\$&"), h += 40;
      else if (p.type === 1) {
        const { value: m, repeatable: v, optional: x, regexp: C } = p;
        n.push({
          name: m,
          repeatable: v,
          optional: x
        });
        const S = C || Uc;
        if (S !== Uc) {
          h += 10;
          try {
            new RegExp(`(${S})`);
          } catch (T) {
            throw new Error(`Invalid custom RegExp for param "${m}" (${S}): ` + T.message);
          }
        }
        let E = v ? `((?:${S})(?:/(?:${S}))*)` : `(${S})`;
        f || (E = // avoid an optional / if there are more segments e.g. /:p?-static
        // or /:p?-:p2
        x && c.length < 2 ? `(?:/${E})` : "/" + E), x && (E += "?"), o += E, h += 20, x && (h += -8), v && (h += -20), S === ".*" && (h += -50);
      }
      u.push(h);
    }
    a.push(u);
  }
  if (r.strict && r.end) {
    const c = a.length - 1;
    a[c][a[c].length - 1] += 0.7000000000000001;
  }
  r.strict || (o += "/?"), r.end ? o += "$" : r.strict && !o.endsWith("/") && (o += "(?:/|$)");
  const s = new RegExp(o, r.sensitive ? "" : "i");
  function i(c) {
    const u = c.match(s), f = {};
    if (!u)
      return null;
    for (let p = 1; p < u.length; p++) {
      const h = u[p] || "", m = n[p - 1];
      f[m.name] = h && m.repeatable ? h.split("/") : h;
    }
    return f;
  }
  function l(c) {
    let u = "", f = !1;
    for (const p of e) {
      (!f || !u.endsWith("/")) && (u += "/"), f = !1;
      for (const h of p)
        if (h.type === 0)
          u += h.value;
        else if (h.type === 1) {
          const { value: m, repeatable: v, optional: x } = h, C = m in c ? c[m] : "";
          if (Vt(C) && !v)
            throw new Error(`Provided param "${m}" is an array but it is not repeatable (* or + modifiers)`);
          const S = Vt(C) ? C.join("/") : C;
          if (!S)
            if (x)
              p.length < 2 && (u.endsWith("/") ? u = u.slice(0, -1) : f = !0);
            else
              throw new Error(`Missing required param "${m}"`);
          u += S;
        }
    }
    return u || "/";
  }
  return {
    re: s,
    score: a,
    keys: n,
    parse: i,
    stringify: l
  };
}
function Cm(e, t) {
  let r = 0;
  for (; r < e.length && r < t.length; ) {
    const a = t[r] - e[r];
    if (a)
      return a;
    r++;
  }
  return e.length < t.length ? e.length === 1 && e[0] === 80 ? -1 : 1 : e.length > t.length ? t.length === 1 && t[0] === 80 ? 1 : -1 : 0;
}
function dp(e, t) {
  let r = 0;
  const a = e.score, o = t.score;
  for (; r < a.length && r < o.length; ) {
    const n = Cm(a[r], o[r]);
    if (n)
      return n;
    r++;
  }
  if (Math.abs(o.length - a.length) === 1) {
    if (Zc(a))
      return 1;
    if (Zc(o))
      return -1;
  }
  return o.length - a.length;
}
function Zc(e) {
  const t = e[e.length - 1];
  return e.length > 0 && t[t.length - 1] < 0;
}
const Am = {
  type: 0,
  value: ""
}, Sm = /[a-zA-Z0-9_]/;
function Em(e) {
  if (!e)
    return [[]];
  if (e === "/")
    return [[Am]];
  if (!e.startsWith("/"))
    throw new Error(`Invalid path "${e}"`);
  function t(h) {
    throw new Error(`ERR (${r})/"${c}": ${h}`);
  }
  let r = 0, a = r;
  const o = [];
  let n;
  function s() {
    n && o.push(n), n = [];
  }
  let i = 0, l, c = "", u = "";
  function f() {
    c && (r === 0 ? n.push({
      type: 0,
      value: c
    }) : r === 1 || r === 2 || r === 3 ? (n.length > 1 && (l === "*" || l === "+") && t(`A repeatable param (${c}) must be alone in its segment. eg: '/:ids+.`), n.push({
      type: 1,
      value: c,
      regexp: u,
      repeatable: l === "*" || l === "+",
      optional: l === "*" || l === "?"
    })) : t("Invalid state to consume buffer"), c = "");
  }
  function p() {
    c += l;
  }
  for (; i < e.length; ) {
    if (l = e[i++], l === "\\" && r !== 2) {
      a = r, r = 4;
      continue;
    }
    switch (r) {
      case 0:
        l === "/" ? (c && f(), s()) : l === ":" ? (f(), r = 1) : p();
        break;
      case 4:
        p(), r = a;
        break;
      case 1:
        l === "(" ? r = 2 : Sm.test(l) ? p() : (f(), r = 0, l !== "*" && l !== "?" && l !== "+" && i--);
        break;
      case 2:
        l === ")" ? u[u.length - 1] == "\\" ? u = u.slice(0, -1) + l : r = 3 : u += l;
        break;
      case 3:
        f(), r = 0, l !== "*" && l !== "?" && l !== "+" && i--, u = "";
        break;
      default:
        t("Unknown state");
        break;
    }
  }
  return r === 2 && t(`Unfinished custom RegExp for param "${c}"`), f(), s(), o;
}
function $m(e, t, r) {
  const a = km(Em(e.path), r), o = Le(a, {
    record: e,
    parent: t,
    // these needs to be populated by the parent
    children: [],
    alias: []
  });
  return t && !o.record.aliasOf == !t.record.aliasOf && t.children.push(o), o;
}
function Pm(e, t) {
  const r = [], a = /* @__PURE__ */ new Map();
  t = Jc({ strict: !1, end: !0, sensitive: !1 }, t);
  function o(f) {
    return a.get(f);
  }
  function n(f, p, h) {
    const m = !h, v = Wc(f);
    v.aliasOf = h && h.record;
    const x = Jc(t, f), C = [v];
    if ("alias" in f) {
      const T = typeof f.alias == "string" ? [f.alias] : f.alias;
      for (const F of T)
        C.push(
          // we need to normalize again to ensure the `mods` property
          // being non enumerable
          Wc(Le({}, v, {
            // this allows us to hold a copy of the `components` option
            // so that async components cache is hold on the original record
            components: h ? h.record.components : v.components,
            path: F,
            // we might be the child of an alias
            aliasOf: h ? h.record : v
            // the aliases are always of the same kind as the original since they
            // are defined on the same record
          }))
        );
    }
    let S, E;
    for (const T of C) {
      const { path: F } = T;
      if (p && F[0] !== "/") {
        const j = p.record.path, H = j[j.length - 1] === "/" ? "" : "/";
        T.path = p.record.path + (F && H + F);
      }
      if (S = $m(T, p, x), h ? h.alias.push(S) : (E = E || S, E !== S && E.alias.push(S), m && f.name && !Gc(S) && s(f.name)), fp(S) && l(S), v.children) {
        const j = v.children;
        for (let H = 0; H < j.length; H++)
          n(j[H], S, h && h.children[H]);
      }
      h = h || S;
    }
    return E ? () => {
      s(E);
    } : uo;
  }
  function s(f) {
    if (cp(f)) {
      const p = a.get(f);
      p && (a.delete(f), r.splice(r.indexOf(p), 1), p.children.forEach(s), p.alias.forEach(s));
    } else {
      const p = r.indexOf(f);
      p > -1 && (r.splice(p, 1), f.record.name && a.delete(f.record.name), f.children.forEach(s), f.alias.forEach(s));
    }
  }
  function i() {
    return r;
  }
  function l(f) {
    const p = Rm(f, r);
    r.splice(p, 0, f), f.record.name && !Gc(f) && a.set(f.record.name, f);
  }
  function c(f, p) {
    let h, m = {}, v, x;
    if ("name" in f && f.name) {
      if (h = a.get(f.name), !h)
        throw Ma(1, {
          location: f
        });
      x = h.record.name, m = Le(
        // paramsFromLocation is a new object
        Kc(
          p.params,
          // only keep params that exist in the resolved location
          // only keep optional params coming from a parent record
          h.keys.filter((E) => !E.optional).concat(h.parent ? h.parent.keys.filter((E) => E.optional) : []).map((E) => E.name)
        ),
        // discard any existing params in the current location that do not exist here
        // #1497 this ensures better active/exact matching
        f.params && Kc(f.params, h.keys.map((E) => E.name))
      ), v = h.stringify(m);
    } else if (f.path != null)
      v = f.path, h = r.find((E) => E.re.test(v)), h && (m = h.parse(v), x = h.record.name);
    else {
      if (h = p.name ? a.get(p.name) : r.find((E) => E.re.test(p.path)), !h)
        throw Ma(1, {
          location: f,
          currentLocation: p
        });
      x = h.record.name, m = Le({}, p.params, f.params), v = h.stringify(m);
    }
    const C = [];
    let S = h;
    for (; S; )
      C.unshift(S.record), S = S.parent;
    return {
      name: x,
      path: v,
      params: m,
      matched: C,
      meta: Mm(C)
    };
  }
  e.forEach((f) => n(f));
  function u() {
    r.length = 0, a.clear();
  }
  return {
    addRoute: n,
    resolve: c,
    removeRoute: s,
    clearRoutes: u,
    getRoutes: i,
    getRecordMatcher: o
  };
}
function Kc(e, t) {
  const r = {};
  for (const a of t)
    a in e && (r[a] = e[a]);
  return r;
}
function Wc(e) {
  const t = {
    path: e.path,
    redirect: e.redirect,
    name: e.name,
    meta: e.meta || {},
    aliasOf: e.aliasOf,
    beforeEnter: e.beforeEnter,
    props: Tm(e),
    children: e.children || [],
    instances: {},
    leaveGuards: /* @__PURE__ */ new Set(),
    updateGuards: /* @__PURE__ */ new Set(),
    enterCallbacks: {},
    // must be declared afterwards
    // mods: {},
    components: "components" in e ? e.components || null : e.component && { default: e.component }
  };
  return Object.defineProperty(t, "mods", {
    value: {}
  }), t;
}
function Tm(e) {
  const t = {}, r = e.props || !1;
  if ("component" in e)
    t.default = r;
  else
    for (const a in e.components)
      t[a] = typeof r == "object" ? r[a] : r;
  return t;
}
function Gc(e) {
  for (; e; ) {
    if (e.record.aliasOf)
      return !0;
    e = e.parent;
  }
  return !1;
}
function Mm(e) {
  return e.reduce((t, r) => Le(t, r.meta), {});
}
function Jc(e, t) {
  const r = {};
  for (const a in e)
    r[a] = a in t ? t[a] : e[a];
  return r;
}
function Rm(e, t) {
  let r = 0, a = t.length;
  for (; r !== a; ) {
    const n = r + a >> 1;
    dp(e, t[n]) < 0 ? a = n : r = n + 1;
  }
  const o = Om(e);
  return o && (a = t.lastIndexOf(o, a - 1)), a;
}
function Om(e) {
  let t = e;
  for (; t = t.parent; )
    if (fp(t) && dp(e, t) === 0)
      return t;
}
function fp({ record: e }) {
  return !!(e.name || e.components && Object.keys(e.components).length || e.redirect);
}
function Bm(e) {
  const t = {};
  if (e === "" || e === "?")
    return t;
  const a = (e[0] === "?" ? e.slice(1) : e).split("&");
  for (let o = 0; o < a.length; ++o) {
    const n = a[o].replace(ap, " "), s = n.indexOf("="), i = wo(s < 0 ? n : n.slice(0, s)), l = s < 0 ? null : wo(n.slice(s + 1));
    if (i in t) {
      let c = t[i];
      Vt(c) || (c = t[i] = [c]), c.push(l);
    } else
      t[i] = l;
  }
  return t;
}
function Yc(e) {
  let t = "";
  for (let r in e) {
    const a = e[r];
    if (r = Q1(r), a == null) {
      a !== void 0 && (t += (t.length ? "&" : "") + r);
      continue;
    }
    (Vt(a) ? a.map((n) => n && Ai(n)) : [a && Ai(a)]).forEach((n) => {
      n !== void 0 && (t += (t.length ? "&" : "") + r, n != null && (t += "=" + n));
    });
  }
  return t;
}
function Dm(e) {
  const t = {};
  for (const r in e) {
    const a = e[r];
    a !== void 0 && (t[r] = Vt(a) ? a.map((o) => o == null ? null : "" + o) : a == null ? a : "" + a);
  }
  return t;
}
const Im = Symbol(""), Xc = Symbol(""), Yn = Symbol(""), _l = Symbol(""), Ei = Symbol("");
function Ka() {
  let e = [];
  function t(a) {
    return e.push(a), () => {
      const o = e.indexOf(a);
      o > -1 && e.splice(o, 1);
    };
  }
  function r() {
    e = [];
  }
  return {
    add: t,
    list: () => e.slice(),
    reset: r
  };
}
function Vr(e, t, r, a, o, n = (s) => s()) {
  const s = a && // name is defined if record is because of the function overload
  (a.enterCallbacks[o] = a.enterCallbacks[o] || []);
  return () => new Promise((i, l) => {
    const c = (p) => {
      p === !1 ? l(Ma(4, {
        from: r,
        to: t
      })) : p instanceof Error ? l(p) : wm(p) ? l(Ma(2, {
        from: t,
        to: p
      })) : (s && // since enterCallbackArray is truthy, both record and name also are
      a.enterCallbacks[o] === s && typeof p == "function" && s.push(p), i());
    }, u = n(() => e.call(a && a.instances[o], t, r, c));
    let f = Promise.resolve(u);
    e.length < 3 && (f = f.then(c)), f.catch((p) => l(p));
  });
}
function As(e, t, r, a, o = (n) => n()) {
  const n = [];
  for (const s of e)
    for (const i in s.components) {
      let l = s.components[i];
      if (!(t !== "beforeRouteEnter" && !s.instances[i]))
        if (tp(l)) {
          const u = (l.__vccOpts || l)[t];
          u && n.push(Vr(u, r, a, s, i, o));
        } else {
          let c = l();
          n.push(() => c.then((u) => {
            if (!u)
              throw new Error(`Couldn't resolve component "${i}" at "${s.path}"`);
            const f = F1(u) ? u.default : u;
            s.mods[i] = u, s.components[i] = f;
            const h = (f.__vccOpts || f)[t];
            return h && Vr(h, r, a, s, i, o)();
          }));
        }
    }
  return n;
}
function Qc(e) {
  const t = he(Yn), r = he(_l), a = L(() => {
    const l = d(e.to);
    return t.resolve(l);
  }), o = L(() => {
    const { matched: l } = a.value, { length: c } = l, u = l[c - 1], f = r.matched;
    if (!u || !f.length)
      return -1;
    const p = f.findIndex(Ta.bind(null, u));
    if (p > -1)
      return p;
    const h = eu(l[c - 2]);
    return (
      // we are dealing with nested routes
      c > 1 && // if the parent and matched route have the same path, this link is
      // referring to the empty child. Or we currently are on a different
      // child of the same parent
      eu(u) === h && // avoid comparing the child with its parent
      f[f.length - 1].path !== h ? f.findIndex(Ta.bind(null, l[c - 2])) : p
    );
  }), n = L(() => o.value > -1 && Hm(r.params, a.value.params)), s = L(() => o.value > -1 && o.value === r.matched.length - 1 && ip(r.params, a.value.params));
  function i(l = {}) {
    if (Vm(l)) {
      const c = t[d(e.replace) ? "replace" : "push"](
        d(e.to)
        // avoid uncaught errors are they are logged anyway
      ).catch(uo);
      return e.viewTransition && typeof document < "u" && "startViewTransition" in document && document.startViewTransition(() => c), c;
    }
    return Promise.resolve();
  }
  return {
    route: a,
    href: L(() => a.value.href),
    isActive: n,
    isExactActive: s,
    navigate: i
  };
}
function qm(e) {
  return e.length === 1 ? e[0] : e;
}
const Lm = /* @__PURE__ */ D({
  name: "RouterLink",
  compatConfig: { MODE: 3 },
  props: {
    to: {
      type: [String, Object],
      required: !0
    },
    replace: Boolean,
    activeClass: String,
    // inactiveClass: String,
    exactActiveClass: String,
    custom: Boolean,
    ariaCurrentValue: {
      type: String,
      default: "page"
    },
    viewTransition: Boolean
  },
  useLink: Qc,
  setup(e, { slots: t }) {
    const r = Rt(Qc(e)), { options: a } = he(Yn), o = L(() => ({
      [tu(e.activeClass, a.linkActiveClass, "router-link-active")]: r.isActive,
      // [getLinkClass(
      //   props.inactiveClass,
      //   options.linkInactiveClass,
      //   'router-link-inactive'
      // )]: !link.isExactActive,
      [tu(e.exactActiveClass, a.linkExactActiveClass, "router-link-exact-active")]: r.isExactActive
    }));
    return () => {
      const n = t.default && qm(t.default(r));
      return e.custom ? n : Nt("a", {
        "aria-current": r.isExactActive ? e.ariaCurrentValue : null,
        href: r.href,
        // this would override user added attrs but Vue will still add
        // the listener, so we end up triggering both
        onClick: r.navigate,
        class: o.value
      }, n);
    };
  }
}), Nm = Lm;
function Vm(e) {
  if (!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) && !e.defaultPrevented && !(e.button !== void 0 && e.button !== 0)) {
    if (e.currentTarget && e.currentTarget.getAttribute) {
      const t = e.currentTarget.getAttribute("target");
      if (/\b_blank\b/i.test(t))
        return;
    }
    return e.preventDefault && e.preventDefault(), !0;
  }
}
function Hm(e, t) {
  for (const r in t) {
    const a = t[r], o = e[r];
    if (typeof a == "string") {
      if (a !== o)
        return !1;
    } else if (!Vt(o) || o.length !== a.length || a.some((n, s) => n !== o[s]))
      return !1;
  }
  return !0;
}
function eu(e) {
  return e ? e.aliasOf ? e.aliasOf.path : e.path : "";
}
const tu = (e, t, r) => e ?? t ?? r, Fm = /* @__PURE__ */ D({
  name: "RouterView",
  // #674 we manually inherit them
  inheritAttrs: !1,
  props: {
    name: {
      type: String,
      default: "default"
    },
    route: Object
  },
  // Better compat for @vue/compat users
  // https://github.com/vuejs/router/issues/1315
  compatConfig: { MODE: 3 },
  setup(e, { attrs: t, slots: r }) {
    const a = he(Ei), o = L(() => e.route || a.value), n = he(Xc, 0), s = L(() => {
      let c = d(n);
      const { matched: u } = o.value;
      let f;
      for (; (f = u[c]) && !f.components; )
        c++;
      return c;
    }), i = L(() => o.value.matched[s.value]);
    $a(Xc, L(() => s.value + 1)), $a(Im, i), $a(Ei, o);
    const l = K();
    return Ke(() => [l.value, i.value, e.name], ([c, u, f], [p, h, m]) => {
      u && (u.instances[f] = c, h && h !== u && c && c === p && (u.leaveGuards.size || (u.leaveGuards = h.leaveGuards), u.updateGuards.size || (u.updateGuards = h.updateGuards))), c && u && // if there is no instance but to and from are the same this might be
      // the first visit
      (!h || !Ta(u, h) || !p) && (u.enterCallbacks[f] || []).forEach((v) => v(c));
    }, { flush: "post" }), () => {
      const c = o.value, u = e.name, f = i.value, p = f && f.components[u];
      if (!p)
        return ru(r.default, { Component: p, route: c });
      const h = f.props[u], m = h ? h === !0 ? c.params : typeof h == "function" ? h(c) : h : null, x = Nt(p, Le({}, m, t, {
        onVnodeUnmounted: (C) => {
          C.component.isUnmounted && (f.instances[u] = null);
        },
        ref: l
      }));
      return (
        // pass the vnode to the slot as a prop.
        // h and <component :is="..."> both accept vnodes
        ru(r.default, { Component: x, route: c }) || x
      );
    };
  }
});
function ru(e, t) {
  if (!e)
    return null;
  const r = e(t);
  return r.length === 1 ? r[0] : r;
}
const kl = Fm;
function zm(e) {
  const t = Pm(e.routes, e), r = e.parseQuery || Bm, a = e.stringifyQuery || Yc, o = e.history, n = Ka(), s = Ka(), i = Ka(), l = ar(Pr);
  let c = Pr;
  xa && e.scrollBehavior && "scrollRestoration" in history && (history.scrollRestoration = "manual");
  const u = ks.bind(null, (y) => "" + y), f = ks.bind(null, tm), p = (
    // @ts-expect-error: intentionally avoid the type check
    ks.bind(null, wo)
  );
  function h(y, Q) {
    let Z, te;
    return cp(y) ? (Z = t.getRecordMatcher(y), te = Q) : te = y, t.addRoute(te, Z);
  }
  function m(y) {
    const Q = t.getRecordMatcher(y);
    Q && t.removeRoute(Q);
  }
  function v() {
    return t.getRoutes().map((y) => y.record);
  }
  function x(y) {
    return !!t.getRecordMatcher(y);
  }
  function C(y, Q) {
    if (Q = Le({}, Q || l.value), typeof y == "string") {
      const I = Cs(r, y, Q.path), J = t.resolve({ path: I.path }, Q), Y = o.createHref(I.fullPath);
      return Le(I, J, {
        params: p(J.params),
        hash: wo(I.hash),
        redirectedFrom: void 0,
        href: Y
      });
    }
    let Z;
    if (y.path != null)
      Z = Le({}, y, {
        path: Cs(r, y.path, Q.path).path
      });
    else {
      const I = Le({}, y.params);
      for (const J in I)
        I[J] == null && delete I[J];
      Z = Le({}, y, {
        params: f(I)
      }), Q.params = f(Q.params);
    }
    const te = t.resolve(Z, Q), we = y.hash || "";
    te.params = u(p(te.params));
    const _ = om(a, Le({}, y, {
      hash: X1(we),
      path: te.path
    })), A = o.createHref(_);
    return Le({
      fullPath: _,
      // keep the hash encoded so fullPath is effectively path + encodedQuery +
      // hash
      hash: we,
      query: (
        // if the user is using a custom query lib like qs, we might have
        // nested objects, so we keep the query as is, meaning it can contain
        // numbers at `$route.query`, but at the point, the user will have to
        // use their own type anyway.
        // https://github.com/vuejs/router/issues/328#issuecomment-649481567
        a === Yc ? Dm(y.query) : y.query || {}
      )
    }, te, {
      redirectedFrom: void 0,
      href: A
    });
  }
  function S(y) {
    return typeof y == "string" ? Cs(r, y, l.value.path) : Le({}, y);
  }
  function E(y, Q) {
    if (c !== y)
      return Ma(8, {
        from: Q,
        to: y
      });
  }
  function T(y) {
    return H(y);
  }
  function F(y) {
    return T(Le(S(y), { replace: !0 }));
  }
  function j(y) {
    const Q = y.matched[y.matched.length - 1];
    if (Q && Q.redirect) {
      const { redirect: Z } = Q;
      let te = typeof Z == "function" ? Z(y) : Z;
      return typeof te == "string" && (te = te.includes("?") || te.includes("#") ? te = S(te) : (
        // force empty params
        { path: te }
      ), te.params = {}), Le({
        query: y.query,
        hash: y.hash,
        // avoid transferring params if the redirect has a path
        params: te.path != null ? {} : y.params
      }, te);
    }
  }
  function H(y, Q) {
    const Z = c = C(y), te = l.value, we = y.state, _ = y.force, A = y.replace === !0, I = j(Z);
    if (I)
      return H(
        Le(S(I), {
          state: typeof I == "object" ? Le({}, we, I.state) : we,
          force: _,
          replace: A
        }),
        // keep original redirectedFrom if it exists
        Q || Z
      );
    const J = Z;
    J.redirectedFrom = Q;
    let Y;
    return !_ && nm(a, te, Z) && (Y = Ma(16, { to: J, from: te }), Ie(
      te,
      te,
      // this is a push, the only way for it to be triggered from a
      // history.listen is with a redirect, which makes it become a push
      !0,
      // This cannot be the first navigation because the initial location
      // cannot be manually navigated to
      !1
    )), (Y ? Promise.resolve(Y) : $(J, te)).catch((X) => hr(X) ? (
      // navigation redirects still mark the router as ready
      hr(
        X,
        2
        /* ErrorTypes.NAVIGATION_GUARD_REDIRECT */
      ) ? X : Me(X)
    ) : (
      // reject any unknown error
      M(X, J, te)
    )).then((X) => {
      if (X) {
        if (hr(
          X,
          2
          /* ErrorTypes.NAVIGATION_GUARD_REDIRECT */
        ))
          return H(
            // keep options
            Le({
              // preserve an existing replacement but allow the redirect to override it
              replace: A
            }, S(X.to), {
              state: typeof X.to == "object" ? Le({}, we, X.to.state) : we,
              force: _
            }),
            // preserve the original redirectedFrom if any
            Q || J
          );
      } else
        X = z(J, te, !0, A, we);
      return V(J, te, X), X;
    });
  }
  function B(y, Q) {
    const Z = E(y, Q);
    return Z ? Promise.reject(Z) : Promise.resolve();
  }
  function P(y) {
    const Q = O.values().next().value;
    return Q && typeof Q.runWithContext == "function" ? Q.runWithContext(y) : y();
  }
  function $(y, Q) {
    let Z;
    const [te, we, _] = jm(y, Q);
    Z = As(te.reverse(), "beforeRouteLeave", y, Q);
    for (const I of te)
      I.leaveGuards.forEach((J) => {
        Z.push(Vr(J, y, Q));
      });
    const A = B.bind(null, y, Q);
    return Z.push(A), _e(Z).then(() => {
      Z = [];
      for (const I of n.list())
        Z.push(Vr(I, y, Q));
      return Z.push(A), _e(Z);
    }).then(() => {
      Z = As(we, "beforeRouteUpdate", y, Q);
      for (const I of we)
        I.updateGuards.forEach((J) => {
          Z.push(Vr(J, y, Q));
        });
      return Z.push(A), _e(Z);
    }).then(() => {
      Z = [];
      for (const I of _)
        if (I.beforeEnter)
          if (Vt(I.beforeEnter))
            for (const J of I.beforeEnter)
              Z.push(Vr(J, y, Q));
          else
            Z.push(Vr(I.beforeEnter, y, Q));
      return Z.push(A), _e(Z);
    }).then(() => (y.matched.forEach((I) => I.enterCallbacks = {}), Z = As(_, "beforeRouteEnter", y, Q, P), Z.push(A), _e(Z))).then(() => {
      Z = [];
      for (const I of s.list())
        Z.push(Vr(I, y, Q));
      return Z.push(A), _e(Z);
    }).catch((I) => hr(
      I,
      8
      /* ErrorTypes.NAVIGATION_CANCELLED */
    ) ? I : Promise.reject(I));
  }
  function V(y, Q, Z) {
    i.list().forEach((te) => P(() => te(y, Q, Z)));
  }
  function z(y, Q, Z, te, we) {
    const _ = E(y, Q);
    if (_)
      return _;
    const A = Q === Pr, I = xa ? history.state : {};
    Z && (te || A ? o.replace(y.fullPath, Le({
      scroll: A && I && I.scroll
    }, we)) : o.push(y.fullPath, we)), l.value = y, Ie(y, Q, Z, A), Me();
  }
  let G;
  function ee() {
    G || (G = o.listen((y, Q, Z) => {
      if (!Ae.listening)
        return;
      const te = C(y), we = j(te);
      if (we) {
        H(Le(we, { replace: !0, force: !0 }), te).catch(uo);
        return;
      }
      c = te;
      const _ = l.value;
      xa && pm(Fc(_.fullPath, Z.delta), Jn()), $(te, _).catch((A) => hr(
        A,
        12
        /* ErrorTypes.NAVIGATION_CANCELLED */
      ) ? A : hr(
        A,
        2
        /* ErrorTypes.NAVIGATION_GUARD_REDIRECT */
      ) ? (H(
        Le(S(A.to), {
          force: !0
        }),
        te
        // avoid an uncaught rejection, let push call triggerError
      ).then((I) => {
        hr(
          I,
          20
          /* ErrorTypes.NAVIGATION_DUPLICATED */
        ) && !Z.delta && Z.type === xo.pop && o.go(-1, !1);
      }).catch(uo), Promise.reject()) : (Z.delta && o.go(-Z.delta, !1), M(A, te, _))).then((A) => {
        A = A || z(
          // after navigation, all matched components are resolved
          te,
          _,
          !1
        ), A && (Z.delta && // a new navigation has been triggered, so we do not want to revert, that will change the current history
        // entry while a different route is displayed
        !hr(
          A,
          8
          /* ErrorTypes.NAVIGATION_CANCELLED */
        ) ? o.go(-Z.delta, !1) : Z.type === xo.pop && hr(
          A,
          20
          /* ErrorTypes.NAVIGATION_DUPLICATED */
        ) && o.go(-1, !1)), V(te, _, A);
      }).catch(uo);
    }));
  }
  let xe = Ka(), de = Ka(), W;
  function M(y, Q, Z) {
    Me(y);
    const te = de.list();
    return te.length ? te.forEach((we) => we(y, Q, Z)) : console.error(y), Promise.reject(y);
  }
  function ge() {
    return W && l.value !== Pr ? Promise.resolve() : new Promise((y, Q) => {
      xe.add([y, Q]);
    });
  }
  function Me(y) {
    return W || (W = !y, ee(), xe.list().forEach(([Q, Z]) => y ? Z(y) : Q()), xe.reset()), y;
  }
  function Ie(y, Q, Z, te) {
    const { scrollBehavior: we } = e;
    if (!xa || !we)
      return Promise.resolve();
    const _ = !Z && hm(Fc(y.fullPath, 0)) || (te || !Z) && history.state && history.state.scroll || null;
    return et().then(() => we(y, Q, _)).then((A) => A && fm(A)).catch((A) => M(A, y, Q));
  }
  const ze = (y) => o.go(y);
  let ae;
  const O = /* @__PURE__ */ new Set(), Ae = {
    currentRoute: l,
    listening: !0,
    addRoute: h,
    removeRoute: m,
    clearRoutes: t.clearRoutes,
    hasRoute: x,
    getRoutes: v,
    resolve: C,
    options: e,
    push: T,
    replace: F,
    go: ze,
    back: () => ze(-1),
    forward: () => ze(1),
    beforeEach: n.add,
    beforeResolve: s.add,
    afterEach: i.add,
    onError: de.add,
    isReady: ge,
    install(y) {
      const Q = this;
      y.component("RouterLink", Nm), y.component("RouterView", kl), y.config.globalProperties.$router = Q, Object.defineProperty(y.config.globalProperties, "$route", {
        enumerable: !0,
        get: () => d(l)
      }), xa && // used for the initial navigation client side to avoid pushing
      // multiple times when the router is used in multiple apps
      !ae && l.value === Pr && (ae = !0, T(o.location).catch((we) => {
      }));
      const Z = {};
      for (const we in Pr)
        Object.defineProperty(Z, we, {
          get: () => l.value[we],
          enumerable: !0
        });
      y.provide(Yn, Q), y.provide(_l, lf(Z)), y.provide(Ei, l);
      const te = y.unmount;
      O.add(y), y.unmount = function() {
        O.delete(y), O.size < 1 && (c = Pr, G && G(), G = null, l.value = Pr, ae = !1, W = !1), te();
      };
    }
  };
  function _e(y) {
    return y.reduce((Q, Z) => Q.then(() => P(Z)), Promise.resolve());
  }
  return Ae;
}
function jm(e, t) {
  const r = [], a = [], o = [], n = Math.max(t.matched.length, e.matched.length);
  for (let s = 0; s < n; s++) {
    const i = t.matched[s];
    i && (e.matched.find((c) => Ta(c, i)) ? a.push(i) : r.push(i));
    const l = e.matched[s];
    l && (t.matched.find((c) => Ta(c, l)) || o.push(l));
  }
  return [r, a, o];
}
function Cl() {
  return he(Yn);
}
function pp(e) {
  return he(_l);
}
function Xn() {
  return typeof window > "u" || typeof document > "u";
}
async function Um(e, t) {
  return new Promise((r, a) => {
    if (Xn()) return r();
    let o = document.head, n = document.createElement("script");
    if (n.async = !0, n.src = e, n.type = t?.type ?? "text/javascript", t?.defer && (n.defer = !0), t?.nonce && n.setAttribute("nonce", t.nonce), t?.preconnect) {
      let s = document.createElement("link"), i = new URL(e);
      s.href = i.origin, s.rel = "preconnect", o.appendChild(s);
    }
    o.appendChild(n), n.onload = () => r(), n.onerror = (s) => a(s);
  });
}
function au(e) {
  return typeof e == "object" && !!e && !Array.isArray(e);
}
function hp(e, t) {
  let r = { ...e };
  for (let a in t) if (Object.prototype.hasOwnProperty.call(t, a)) {
    let o = t[a], n = e[a];
    au(o) && au(n) ? r[a] = hp(n, o) : r[a] = o;
  }
  return r;
}
function Zm(e) {
  if (Xn()) return;
  let t = new URL(window.location.href);
  t.search = "";
  for (let [r, a] of Object.entries(e)) t.searchParams.set(r, a);
  window.history.replaceState({}, "", t.toString());
}
const $i = "utm_";
function Km(e) {
  let t = new URL(e), r = {}, a = [], o = {};
  t.searchParams.forEach((n, s) => {
    s.includes($i) ? (r[s.replace($i, "").replace("campaign", "id")] = n, a.push(s)) : o[s] = n;
  });
  for (let n of a) t.searchParams.delete(n);
  return { utmParams: r, cleanQueryParams: o, cleanUrl: t.toString() };
}
function Wm(e) {
  let t = RegExp(`[?&]${$i}`);
  return !!e.match(t);
}
function Gm(e, t) {
  let r = t.endsWith("/") ? t : `${t}/`, a = e.startsWith("/") ? e.substring(1) : e;
  return `${r}${a}`;
}
const Jm = { resource: { url: "https://www.googletagmanager.com/gtag/js", inject: !0 }, dataLayerName: "dataLayer", gtagName: "gtag", groupName: "default", initMode: "auto" };
let Pi = { ...Jm };
function It() {
  return Pi;
}
function Ym(e) {
  Pi = hp(Pi, e);
}
function Dt(...e) {
  let { dataLayerName: t, gtagName: r } = It();
  Xn() || (window[t] = window[t] || [], window[r] = function() {
    window[t].push(arguments);
  }, window[r](...e));
}
function gp(e) {
  let { tagId: t, additionalAccounts: r } = It();
  if (t && (Dt("config", t, e), r)) for (let a of r) Dt("config", a.tagId, e);
}
function Al(e, t) {
  Dt("consent", e, t);
}
function mp(e = "default") {
  Al(e, { ad_user_data: "granted", ad_personalization: "granted", ad_storage: "granted", analytics_storage: "granted" });
}
function vp(e = "default") {
  Al(e, { ad_user_data: "denied", ad_personalization: "denied", ad_storage: "denied", analytics_storage: "denied" });
}
function Xm(e) {
  gp({ custom_map: e });
}
function Mo(e, t) {
  let { groupName: r, additionalAccounts: a } = It();
  t.send_to === void 0 && a?.length && (t.send_to = r), Dt("event", e, t);
}
function Qm(e, t) {
  Mo(e, t);
}
function ev(e) {
  Mo("exception", e);
}
function bp(e) {
  Dt("set", "linker", e);
}
function ou(e, t) {
  t ? window[e] = t : delete window[e];
}
function yp(e, t) {
  let { tagId: r, additionalAccounts: a } = It();
  if (!Xn() && (ou(`ga-disable-${e ?? r}`, t), !(!a?.length || e))) for (let o of a) ou(`ga-disable-${o.tagId}`, t);
}
function tv(e) {
  yp(e, !0);
}
function rv(e) {
  yp(e, void 0);
}
function wp(...e) {
  Dt("set", ...e);
}
function xp(e) {
  let { pageTracker: t } = It(), r;
  if (typeof e == "string") r = { page_path: e };
  else if ("path" in e) {
    let a = t?.router.options.history.base ?? "", o = t?.useRouteFullPath ? e.fullPath : e.path;
    r = { ...e.name ? { page_title: e.name.toString() } : {}, page_path: t?.useRouterBasePath ? Gm(o, a) : o };
  } else r = e;
  if (r.page_location === void 0 && (r.page_location = window.location.href), r.send_page_view === void 0 && (r.send_page_view = t?.sendPageView ?? !0), r.page_path !== "/" && r.page_path?.endsWith("/") && (r.page_path = r.page_path.slice(0, -1)), Wm(r.page_location)) {
    let { utmParams: a, cleanUrl: o, cleanQueryParams: n } = Km(r.page_location);
    r.page_location = o, Zm(n), wp("campaign", a);
  }
  Dt("event", "page_view", r);
}
function _p(e) {
  let { appName: t } = It(), r = {};
  typeof e == "string" ? r.screen_name = e : "path" in e ? r.screen_name = e.name ?? e.path : r = e, t && r?.app_name === void 0 && (r.app_name = t), Dt("event", "screen_view", r);
}
function av(e) {
  Mo("timing_complete", e);
}
function nu(e = {}) {
  return { send_page_view: !1, anonymize_ip: !0, ...e };
}
function ov() {
  let { tagId: e, config: t, groupName: r, linker: a, additionalAccounts: o, hooks: n, consentMode: s } = It();
  if (e) {
    if (n?.["config:init:before"]?.(), s === "granted" ? mp() : s === "denied" && vp(), a && bp(a), Dt("js", /* @__PURE__ */ new Date()), Dt("config", e, nu(t)), o) for (let i of o) Dt("config", i.tagId, nu({ groups: r, ...i.config }));
    n?.["config:init:after"]?.();
  }
}
function nv(e) {
  let { pageTracker: t } = It();
  return t?.exclude ? typeof t.exclude == "function" ? t.exclude(e) : t.exclude?.some(({ name: r, path: a } = {}) => r && r === e.name || a && a === e.path) : !1;
}
function su(e) {
  let { pageTracker: t, hooks: r } = It();
  if (nv(e)) return;
  r?.["router:track:before"]?.(e);
  let a;
  if (t?.template && (a = typeof t.template == "function" ? t.template(e) : t.template), t?.useScreenview) {
    let o = a && "screen_name" in a ? a : e;
    _p(o);
  } else {
    let o = a && "page_path" in a ? a : e;
    xp(o);
  }
  r?.["router:track:after"]?.(e);
}
async function sv() {
  let { pageTracker: e } = It();
  if (!e?.router) return;
  let { router: t } = e;
  await t.isReady(), su(t.currentRoute.value), t.afterEach((r, a) => {
    r.path !== a.path && su(r);
  });
}
async function iv() {
  let { resource: e, dataLayerName: t, tagId: r, pageTracker: a, hooks: o } = It();
  if (r && (ov(), a?.router && sv(), e.inject)) try {
    await Um(`${e.url}?id=${r}&l=${t}`, { preconnect: e.preconnect, defer: e.defer, nonce: e.nonce }), o?.["script:loaded"]?.();
  } catch (n) {
    o?.["script:error"]?.(n);
  }
}
function lv() {
  let { initMode: e } = It();
  e !== "manual" && iv();
}
function cv(e) {
  Ym(e), lv();
}
const uv = { config: gp, consent: Al, consentDeniedAll: vp, consentGrantedAll: mp, customMap: Xm, ecommerce: Qm, event: Mo, exception: ev, linker: bp, optIn: rv, optOut: tv, pageview: xp, screenview: _p, set: wp, time: av, query: Dt };
function dv(e) {
  return cv(e), (t) => {
    t.config.globalProperties.$gtag = uv;
  };
}
function kp(e, t) {
  return function() {
    return e.apply(t, arguments);
  };
}
const { toString: fv } = Object.prototype, { getPrototypeOf: Sl } = Object, { iterator: Qn, toStringTag: Cp } = Symbol, es = /* @__PURE__ */ ((e) => (t) => {
  const r = fv.call(t);
  return e[r] || (e[r] = r.slice(8, -1).toLowerCase());
})(/* @__PURE__ */ Object.create(null)), zt = (e) => (e = e.toLowerCase(), (t) => es(t) === e), ts = (e) => (t) => typeof t === e, { isArray: Da } = Array, _o = ts("undefined");
function Ro(e) {
  return e !== null && !_o(e) && e.constructor !== null && !_o(e.constructor) && _t(e.constructor.isBuffer) && e.constructor.isBuffer(e);
}
const Ap = zt("ArrayBuffer");
function pv(e) {
  let t;
  return typeof ArrayBuffer < "u" && ArrayBuffer.isView ? t = ArrayBuffer.isView(e) : t = e && e.buffer && Ap(e.buffer), t;
}
const hv = ts("string"), _t = ts("function"), Sp = ts("number"), Oo = (e) => e !== null && typeof e == "object", gv = (e) => e === !0 || e === !1, ln = (e) => {
  if (es(e) !== "object")
    return !1;
  const t = Sl(e);
  return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Cp in e) && !(Qn in e);
}, mv = (e) => {
  if (!Oo(e) || Ro(e))
    return !1;
  try {
    return Object.keys(e).length === 0 && Object.getPrototypeOf(e) === Object.prototype;
  } catch {
    return !1;
  }
}, vv = zt("Date"), bv = zt("File"), yv = zt("Blob"), wv = zt("FileList"), xv = (e) => Oo(e) && _t(e.pipe), _v = (e) => {
  let t;
  return e && (typeof FormData == "function" && e instanceof FormData || _t(e.append) && ((t = es(e)) === "formdata" || // detect form-data instance
  t === "object" && _t(e.toString) && e.toString() === "[object FormData]"));
}, kv = zt("URLSearchParams"), [Cv, Av, Sv, Ev] = ["ReadableStream", "Request", "Response", "Headers"].map(zt), $v = (e) => e.trim ? e.trim() : e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
function Bo(e, t, { allOwnKeys: r = !1 } = {}) {
  if (e === null || typeof e > "u")
    return;
  let a, o;
  if (typeof e != "object" && (e = [e]), Da(e))
    for (a = 0, o = e.length; a < o; a++)
      t.call(null, e[a], a, e);
  else {
    if (Ro(e))
      return;
    const n = r ? Object.getOwnPropertyNames(e) : Object.keys(e), s = n.length;
    let i;
    for (a = 0; a < s; a++)
      i = n[a], t.call(null, e[i], i, e);
  }
}
function Ep(e, t) {
  if (Ro(e))
    return null;
  t = t.toLowerCase();
  const r = Object.keys(e);
  let a = r.length, o;
  for (; a-- > 0; )
    if (o = r[a], t === o.toLowerCase())
      return o;
  return null;
}
const ra = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global, $p = (e) => !_o(e) && e !== ra;
function Ti() {
  const { caseless: e } = $p(this) && this || {}, t = {}, r = (a, o) => {
    const n = e && Ep(t, o) || o;
    ln(t[n]) && ln(a) ? t[n] = Ti(t[n], a) : ln(a) ? t[n] = Ti({}, a) : Da(a) ? t[n] = a.slice() : t[n] = a;
  };
  for (let a = 0, o = arguments.length; a < o; a++)
    arguments[a] && Bo(arguments[a], r);
  return t;
}
const Pv = (e, t, r, { allOwnKeys: a } = {}) => (Bo(t, (o, n) => {
  r && _t(o) ? e[n] = kp(o, r) : e[n] = o;
}, { allOwnKeys: a }), e), Tv = (e) => (e.charCodeAt(0) === 65279 && (e = e.slice(1)), e), Mv = (e, t, r, a) => {
  e.prototype = Object.create(t.prototype, a), e.prototype.constructor = e, Object.defineProperty(e, "super", {
    value: t.prototype
  }), r && Object.assign(e.prototype, r);
}, Rv = (e, t, r, a) => {
  let o, n, s;
  const i = {};
  if (t = t || {}, e == null) return t;
  do {
    for (o = Object.getOwnPropertyNames(e), n = o.length; n-- > 0; )
      s = o[n], (!a || a(s, e, t)) && !i[s] && (t[s] = e[s], i[s] = !0);
    e = r !== !1 && Sl(e);
  } while (e && (!r || r(e, t)) && e !== Object.prototype);
  return t;
}, Ov = (e, t, r) => {
  e = String(e), (r === void 0 || r > e.length) && (r = e.length), r -= t.length;
  const a = e.indexOf(t, r);
  return a !== -1 && a === r;
}, Bv = (e) => {
  if (!e) return null;
  if (Da(e)) return e;
  let t = e.length;
  if (!Sp(t)) return null;
  const r = new Array(t);
  for (; t-- > 0; )
    r[t] = e[t];
  return r;
}, Dv = /* @__PURE__ */ ((e) => (t) => e && t instanceof e)(typeof Uint8Array < "u" && Sl(Uint8Array)), Iv = (e, t) => {
  const a = (e && e[Qn]).call(e);
  let o;
  for (; (o = a.next()) && !o.done; ) {
    const n = o.value;
    t.call(e, n[0], n[1]);
  }
}, qv = (e, t) => {
  let r;
  const a = [];
  for (; (r = e.exec(t)) !== null; )
    a.push(r);
  return a;
}, Lv = zt("HTMLFormElement"), Nv = (e) => e.toLowerCase().replace(
  /[-_\s]([a-z\d])(\w*)/g,
  function(r, a, o) {
    return a.toUpperCase() + o;
  }
), iu = (({ hasOwnProperty: e }) => (t, r) => e.call(t, r))(Object.prototype), Vv = zt("RegExp"), Pp = (e, t) => {
  const r = Object.getOwnPropertyDescriptors(e), a = {};
  Bo(r, (o, n) => {
    let s;
    (s = t(o, n, e)) !== !1 && (a[n] = s || o);
  }), Object.defineProperties(e, a);
}, Hv = (e) => {
  Pp(e, (t, r) => {
    if (_t(e) && ["arguments", "caller", "callee"].indexOf(r) !== -1)
      return !1;
    const a = e[r];
    if (_t(a)) {
      if (t.enumerable = !1, "writable" in t) {
        t.writable = !1;
        return;
      }
      t.set || (t.set = () => {
        throw Error("Can not rewrite read-only method '" + r + "'");
      });
    }
  });
}, Fv = (e, t) => {
  const r = {}, a = (o) => {
    o.forEach((n) => {
      r[n] = !0;
    });
  };
  return Da(e) ? a(e) : a(String(e).split(t)), r;
}, zv = () => {
}, jv = (e, t) => e != null && Number.isFinite(e = +e) ? e : t;
function Uv(e) {
  return !!(e && _t(e.append) && e[Cp] === "FormData" && e[Qn]);
}
const Zv = (e) => {
  const t = new Array(10), r = (a, o) => {
    if (Oo(a)) {
      if (t.indexOf(a) >= 0)
        return;
      if (Ro(a))
        return a;
      if (!("toJSON" in a)) {
        t[o] = a;
        const n = Da(a) ? [] : {};
        return Bo(a, (s, i) => {
          const l = r(s, o + 1);
          !_o(l) && (n[i] = l);
        }), t[o] = void 0, n;
      }
    }
    return a;
  };
  return r(e, 0);
}, Kv = zt("AsyncFunction"), Wv = (e) => e && (Oo(e) || _t(e)) && _t(e.then) && _t(e.catch), Tp = ((e, t) => e ? setImmediate : t ? ((r, a) => (ra.addEventListener("message", ({ source: o, data: n }) => {
  o === ra && n === r && a.length && a.shift()();
}, !1), (o) => {
  a.push(o), ra.postMessage(r, "*");
}))(`axios@${Math.random()}`, []) : (r) => setTimeout(r))(
  typeof setImmediate == "function",
  _t(ra.postMessage)
), Gv = typeof queueMicrotask < "u" ? queueMicrotask.bind(ra) : Tp, Jv = (e) => e != null && _t(e[Qn]), U = {
  isArray: Da,
  isArrayBuffer: Ap,
  isBuffer: Ro,
  isFormData: _v,
  isArrayBufferView: pv,
  isString: hv,
  isNumber: Sp,
  isBoolean: gv,
  isObject: Oo,
  isPlainObject: ln,
  isEmptyObject: mv,
  isReadableStream: Cv,
  isRequest: Av,
  isResponse: Sv,
  isHeaders: Ev,
  isUndefined: _o,
  isDate: vv,
  isFile: bv,
  isBlob: yv,
  isRegExp: Vv,
  isFunction: _t,
  isStream: xv,
  isURLSearchParams: kv,
  isTypedArray: Dv,
  isFileList: wv,
  forEach: Bo,
  merge: Ti,
  extend: Pv,
  trim: $v,
  stripBOM: Tv,
  inherits: Mv,
  toFlatObject: Rv,
  kindOf: es,
  kindOfTest: zt,
  endsWith: Ov,
  toArray: Bv,
  forEachEntry: Iv,
  matchAll: qv,
  isHTMLForm: Lv,
  hasOwnProperty: iu,
  hasOwnProp: iu,
  // an alias to avoid ESLint no-prototype-builtins detection
  reduceDescriptors: Pp,
  freezeMethods: Hv,
  toObjectSet: Fv,
  toCamelCase: Nv,
  noop: zv,
  toFiniteNumber: jv,
  findKey: Ep,
  global: ra,
  isContextDefined: $p,
  isSpecCompliantForm: Uv,
  toJSONObject: Zv,
  isAsyncFn: Kv,
  isThenable: Wv,
  setImmediate: Tp,
  asap: Gv,
  isIterable: Jv
};
function Pe(e, t, r, a, o) {
  Error.call(this), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack, this.message = e, this.name = "AxiosError", t && (this.code = t), r && (this.config = r), a && (this.request = a), o && (this.response = o, this.status = o.status ? o.status : null);
}
U.inherits(Pe, Error, {
  toJSON: function() {
    return {
      // Standard
      message: this.message,
      name: this.name,
      // Microsoft
      description: this.description,
      number: this.number,
      // Mozilla
      fileName: this.fileName,
      lineNumber: this.lineNumber,
      columnNumber: this.columnNumber,
      stack: this.stack,
      // Axios
      config: U.toJSONObject(this.config),
      code: this.code,
      status: this.status
    };
  }
});
const Mp = Pe.prototype, Rp = {};
[
  "ERR_BAD_OPTION_VALUE",
  "ERR_BAD_OPTION",
  "ECONNABORTED",
  "ETIMEDOUT",
  "ERR_NETWORK",
  "ERR_FR_TOO_MANY_REDIRECTS",
  "ERR_DEPRECATED",
  "ERR_BAD_RESPONSE",
  "ERR_BAD_REQUEST",
  "ERR_CANCELED",
  "ERR_NOT_SUPPORT",
  "ERR_INVALID_URL"
  // eslint-disable-next-line func-names
].forEach((e) => {
  Rp[e] = { value: e };
});
Object.defineProperties(Pe, Rp);
Object.defineProperty(Mp, "isAxiosError", { value: !0 });
Pe.from = (e, t, r, a, o, n) => {
  const s = Object.create(Mp);
  return U.toFlatObject(e, s, function(l) {
    return l !== Error.prototype;
  }, (i) => i !== "isAxiosError"), Pe.call(s, e.message, t, r, a, o), s.cause = e, s.name = e.name, n && Object.assign(s, n), s;
};
const Yv = null;
function Mi(e) {
  return U.isPlainObject(e) || U.isArray(e);
}
function Op(e) {
  return U.endsWith(e, "[]") ? e.slice(0, -2) : e;
}
function lu(e, t, r) {
  return e ? e.concat(t).map(function(o, n) {
    return o = Op(o), !r && n ? "[" + o + "]" : o;
  }).join(r ? "." : "") : t;
}
function Xv(e) {
  return U.isArray(e) && !e.some(Mi);
}
const Qv = U.toFlatObject(U, {}, null, function(t) {
  return /^is[A-Z]/.test(t);
});
function rs(e, t, r) {
  if (!U.isObject(e))
    throw new TypeError("target must be an object");
  t = t || new FormData(), r = U.toFlatObject(r, {
    metaTokens: !0,
    dots: !1,
    indexes: !1
  }, !1, function(v, x) {
    return !U.isUndefined(x[v]);
  });
  const a = r.metaTokens, o = r.visitor || u, n = r.dots, s = r.indexes, l = (r.Blob || typeof Blob < "u" && Blob) && U.isSpecCompliantForm(t);
  if (!U.isFunction(o))
    throw new TypeError("visitor must be a function");
  function c(m) {
    if (m === null) return "";
    if (U.isDate(m))
      return m.toISOString();
    if (U.isBoolean(m))
      return m.toString();
    if (!l && U.isBlob(m))
      throw new Pe("Blob is not supported. Use a Buffer instead.");
    return U.isArrayBuffer(m) || U.isTypedArray(m) ? l && typeof Blob == "function" ? new Blob([m]) : Buffer.from(m) : m;
  }
  function u(m, v, x) {
    let C = m;
    if (m && !x && typeof m == "object") {
      if (U.endsWith(v, "{}"))
        v = a ? v : v.slice(0, -2), m = JSON.stringify(m);
      else if (U.isArray(m) && Xv(m) || (U.isFileList(m) || U.endsWith(v, "[]")) && (C = U.toArray(m)))
        return v = Op(v), C.forEach(function(E, T) {
          !(U.isUndefined(E) || E === null) && t.append(
            // eslint-disable-next-line no-nested-ternary
            s === !0 ? lu([v], T, n) : s === null ? v : v + "[]",
            c(E)
          );
        }), !1;
    }
    return Mi(m) ? !0 : (t.append(lu(x, v, n), c(m)), !1);
  }
  const f = [], p = Object.assign(Qv, {
    defaultVisitor: u,
    convertValue: c,
    isVisitable: Mi
  });
  function h(m, v) {
    if (!U.isUndefined(m)) {
      if (f.indexOf(m) !== -1)
        throw Error("Circular reference detected in " + v.join("."));
      f.push(m), U.forEach(m, function(C, S) {
        (!(U.isUndefined(C) || C === null) && o.call(
          t,
          C,
          U.isString(S) ? S.trim() : S,
          v,
          p
        )) === !0 && h(C, v ? v.concat(S) : [S]);
      }), f.pop();
    }
  }
  if (!U.isObject(e))
    throw new TypeError("data must be an object");
  return h(e), t;
}
function cu(e) {
  const t = {
    "!": "%21",
    "'": "%27",
    "(": "%28",
    ")": "%29",
    "~": "%7E",
    "%20": "+",
    "%00": "\0"
  };
  return encodeURIComponent(e).replace(/[!'()~]|%20|%00/g, function(a) {
    return t[a];
  });
}
function El(e, t) {
  this._pairs = [], e && rs(e, this, t);
}
const Bp = El.prototype;
Bp.append = function(t, r) {
  this._pairs.push([t, r]);
};
Bp.toString = function(t) {
  const r = t ? function(a) {
    return t.call(this, a, cu);
  } : cu;
  return this._pairs.map(function(o) {
    return r(o[0]) + "=" + r(o[1]);
  }, "").join("&");
};
function eb(e) {
  return encodeURIComponent(e).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]");
}
function Dp(e, t, r) {
  if (!t)
    return e;
  const a = r && r.encode || eb;
  U.isFunction(r) && (r = {
    serialize: r
  });
  const o = r && r.serialize;
  let n;
  if (o ? n = o(t, r) : n = U.isURLSearchParams(t) ? t.toString() : new El(t, r).toString(a), n) {
    const s = e.indexOf("#");
    s !== -1 && (e = e.slice(0, s)), e += (e.indexOf("?") === -1 ? "?" : "&") + n;
  }
  return e;
}
class uu {
  constructor() {
    this.handlers = [];
  }
  /**
   * Add a new interceptor to the stack
   *
   * @param {Function} fulfilled The function to handle `then` for a `Promise`
   * @param {Function} rejected The function to handle `reject` for a `Promise`
   *
   * @return {Number} An ID used to remove interceptor later
   */
  use(t, r, a) {
    return this.handlers.push({
      fulfilled: t,
      rejected: r,
      synchronous: a ? a.synchronous : !1,
      runWhen: a ? a.runWhen : null
    }), this.handlers.length - 1;
  }
  /**
   * Remove an interceptor from the stack
   *
   * @param {Number} id The ID that was returned by `use`
   *
   * @returns {Boolean} `true` if the interceptor was removed, `false` otherwise
   */
  eject(t) {
    this.handlers[t] && (this.handlers[t] = null);
  }
  /**
   * Clear all interceptors from the stack
   *
   * @returns {void}
   */
  clear() {
    this.handlers && (this.handlers = []);
  }
  /**
   * Iterate over all the registered interceptors
   *
   * This method is particularly useful for skipping over any
   * interceptors that may have become `null` calling `eject`.
   *
   * @param {Function} fn The function to call for each interceptor
   *
   * @returns {void}
   */
  forEach(t) {
    U.forEach(this.handlers, function(a) {
      a !== null && t(a);
    });
  }
}
const Ip = {
  silentJSONParsing: !0,
  forcedJSONParsing: !0,
  clarifyTimeoutError: !1
}, tb = typeof URLSearchParams < "u" ? URLSearchParams : El, rb = typeof FormData < "u" ? FormData : null, ab = typeof Blob < "u" ? Blob : null, ob = {
  isBrowser: !0,
  classes: {
    URLSearchParams: tb,
    FormData: rb,
    Blob: ab
  },
  protocols: ["http", "https", "file", "blob", "url", "data"]
}, $l = typeof window < "u" && typeof document < "u", Ri = typeof navigator == "object" && navigator || void 0, nb = $l && (!Ri || ["ReactNative", "NativeScript", "NS"].indexOf(Ri.product) < 0), sb = typeof WorkerGlobalScope < "u" && // eslint-disable-next-line no-undef
self instanceof WorkerGlobalScope && typeof self.importScripts == "function", ib = $l && window.location.href || "http://localhost", lb = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  hasBrowserEnv: $l,
  hasStandardBrowserEnv: nb,
  hasStandardBrowserWebWorkerEnv: sb,
  navigator: Ri,
  origin: ib
}, Symbol.toStringTag, { value: "Module" })), ft = {
  ...lb,
  ...ob
};
function cb(e, t) {
  return rs(e, new ft.classes.URLSearchParams(), {
    visitor: function(r, a, o, n) {
      return ft.isNode && U.isBuffer(r) ? (this.append(a, r.toString("base64")), !1) : n.defaultVisitor.apply(this, arguments);
    },
    ...t
  });
}
function ub(e) {
  return U.matchAll(/\w+|\[(\w*)]/g, e).map((t) => t[0] === "[]" ? "" : t[1] || t[0]);
}
function db(e) {
  const t = {}, r = Object.keys(e);
  let a;
  const o = r.length;
  let n;
  for (a = 0; a < o; a++)
    n = r[a], t[n] = e[n];
  return t;
}
function qp(e) {
  function t(r, a, o, n) {
    let s = r[n++];
    if (s === "__proto__") return !0;
    const i = Number.isFinite(+s), l = n >= r.length;
    return s = !s && U.isArray(o) ? o.length : s, l ? (U.hasOwnProp(o, s) ? o[s] = [o[s], a] : o[s] = a, !i) : ((!o[s] || !U.isObject(o[s])) && (o[s] = []), t(r, a, o[s], n) && U.isArray(o[s]) && (o[s] = db(o[s])), !i);
  }
  if (U.isFormData(e) && U.isFunction(e.entries)) {
    const r = {};
    return U.forEachEntry(e, (a, o) => {
      t(ub(a), o, r, 0);
    }), r;
  }
  return null;
}
function fb(e, t, r) {
  if (U.isString(e))
    try {
      return (t || JSON.parse)(e), U.trim(e);
    } catch (a) {
      if (a.name !== "SyntaxError")
        throw a;
    }
  return (r || JSON.stringify)(e);
}
const Do = {
  transitional: Ip,
  adapter: ["xhr", "http", "fetch"],
  transformRequest: [function(t, r) {
    const a = r.getContentType() || "", o = a.indexOf("application/json") > -1, n = U.isObject(t);
    if (n && U.isHTMLForm(t) && (t = new FormData(t)), U.isFormData(t))
      return o ? JSON.stringify(qp(t)) : t;
    if (U.isArrayBuffer(t) || U.isBuffer(t) || U.isStream(t) || U.isFile(t) || U.isBlob(t) || U.isReadableStream(t))
      return t;
    if (U.isArrayBufferView(t))
      return t.buffer;
    if (U.isURLSearchParams(t))
      return r.setContentType("application/x-www-form-urlencoded;charset=utf-8", !1), t.toString();
    let i;
    if (n) {
      if (a.indexOf("application/x-www-form-urlencoded") > -1)
        return cb(t, this.formSerializer).toString();
      if ((i = U.isFileList(t)) || a.indexOf("multipart/form-data") > -1) {
        const l = this.env && this.env.FormData;
        return rs(
          i ? { "files[]": t } : t,
          l && new l(),
          this.formSerializer
        );
      }
    }
    return n || o ? (r.setContentType("application/json", !1), fb(t)) : t;
  }],
  transformResponse: [function(t) {
    const r = this.transitional || Do.transitional, a = r && r.forcedJSONParsing, o = this.responseType === "json";
    if (U.isResponse(t) || U.isReadableStream(t))
      return t;
    if (t && U.isString(t) && (a && !this.responseType || o)) {
      const s = !(r && r.silentJSONParsing) && o;
      try {
        return JSON.parse(t);
      } catch (i) {
        if (s)
          throw i.name === "SyntaxError" ? Pe.from(i, Pe.ERR_BAD_RESPONSE, this, null, this.response) : i;
      }
    }
    return t;
  }],
  /**
   * A timeout in milliseconds to abort a request. If set to 0 (default) a
   * timeout is not created.
   */
  timeout: 0,
  xsrfCookieName: "XSRF-TOKEN",
  xsrfHeaderName: "X-XSRF-TOKEN",
  maxContentLength: -1,
  maxBodyLength: -1,
  env: {
    FormData: ft.classes.FormData,
    Blob: ft.classes.Blob
  },
  validateStatus: function(t) {
    return t >= 200 && t < 300;
  },
  headers: {
    common: {
      Accept: "application/json, text/plain, */*",
      "Content-Type": void 0
    }
  }
};
U.forEach(["delete", "get", "head", "post", "put", "patch"], (e) => {
  Do.headers[e] = {};
});
const pb = U.toObjectSet([
  "age",
  "authorization",
  "content-length",
  "content-type",
  "etag",
  "expires",
  "from",
  "host",
  "if-modified-since",
  "if-unmodified-since",
  "last-modified",
  "location",
  "max-forwards",
  "proxy-authorization",
  "referer",
  "retry-after",
  "user-agent"
]), hb = (e) => {
  const t = {};
  let r, a, o;
  return e && e.split(`
`).forEach(function(s) {
    o = s.indexOf(":"), r = s.substring(0, o).trim().toLowerCase(), a = s.substring(o + 1).trim(), !(!r || t[r] && pb[r]) && (r === "set-cookie" ? t[r] ? t[r].push(a) : t[r] = [a] : t[r] = t[r] ? t[r] + ", " + a : a);
  }), t;
}, du = Symbol("internals");
function Wa(e) {
  return e && String(e).trim().toLowerCase();
}
function cn(e) {
  return e === !1 || e == null ? e : U.isArray(e) ? e.map(cn) : String(e);
}
function gb(e) {
  const t = /* @__PURE__ */ Object.create(null), r = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
  let a;
  for (; a = r.exec(e); )
    t[a[1]] = a[2];
  return t;
}
const mb = (e) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(e.trim());
function Ss(e, t, r, a, o) {
  if (U.isFunction(a))
    return a.call(this, t, r);
  if (o && (t = r), !!U.isString(t)) {
    if (U.isString(a))
      return t.indexOf(a) !== -1;
    if (U.isRegExp(a))
      return a.test(t);
  }
}
function vb(e) {
  return e.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (t, r, a) => r.toUpperCase() + a);
}
function bb(e, t) {
  const r = U.toCamelCase(" " + t);
  ["get", "set", "has"].forEach((a) => {
    Object.defineProperty(e, a + r, {
      value: function(o, n, s) {
        return this[a].call(this, t, o, n, s);
      },
      configurable: !0
    });
  });
}
let kt = class {
  constructor(t) {
    t && this.set(t);
  }
  set(t, r, a) {
    const o = this;
    function n(i, l, c) {
      const u = Wa(l);
      if (!u)
        throw new Error("header name must be a non-empty string");
      const f = U.findKey(o, u);
      (!f || o[f] === void 0 || c === !0 || c === void 0 && o[f] !== !1) && (o[f || l] = cn(i));
    }
    const s = (i, l) => U.forEach(i, (c, u) => n(c, u, l));
    if (U.isPlainObject(t) || t instanceof this.constructor)
      s(t, r);
    else if (U.isString(t) && (t = t.trim()) && !mb(t))
      s(hb(t), r);
    else if (U.isObject(t) && U.isIterable(t)) {
      let i = {}, l, c;
      for (const u of t) {
        if (!U.isArray(u))
          throw TypeError("Object iterator must return a key-value pair");
        i[c = u[0]] = (l = i[c]) ? U.isArray(l) ? [...l, u[1]] : [l, u[1]] : u[1];
      }
      s(i, r);
    } else
      t != null && n(r, t, a);
    return this;
  }
  get(t, r) {
    if (t = Wa(t), t) {
      const a = U.findKey(this, t);
      if (a) {
        const o = this[a];
        if (!r)
          return o;
        if (r === !0)
          return gb(o);
        if (U.isFunction(r))
          return r.call(this, o, a);
        if (U.isRegExp(r))
          return r.exec(o);
        throw new TypeError("parser must be boolean|regexp|function");
      }
    }
  }
  has(t, r) {
    if (t = Wa(t), t) {
      const a = U.findKey(this, t);
      return !!(a && this[a] !== void 0 && (!r || Ss(this, this[a], a, r)));
    }
    return !1;
  }
  delete(t, r) {
    const a = this;
    let o = !1;
    function n(s) {
      if (s = Wa(s), s) {
        const i = U.findKey(a, s);
        i && (!r || Ss(a, a[i], i, r)) && (delete a[i], o = !0);
      }
    }
    return U.isArray(t) ? t.forEach(n) : n(t), o;
  }
  clear(t) {
    const r = Object.keys(this);
    let a = r.length, o = !1;
    for (; a--; ) {
      const n = r[a];
      (!t || Ss(this, this[n], n, t, !0)) && (delete this[n], o = !0);
    }
    return o;
  }
  normalize(t) {
    const r = this, a = {};
    return U.forEach(this, (o, n) => {
      const s = U.findKey(a, n);
      if (s) {
        r[s] = cn(o), delete r[n];
        return;
      }
      const i = t ? vb(n) : String(n).trim();
      i !== n && delete r[n], r[i] = cn(o), a[i] = !0;
    }), this;
  }
  concat(...t) {
    return this.constructor.concat(this, ...t);
  }
  toJSON(t) {
    const r = /* @__PURE__ */ Object.create(null);
    return U.forEach(this, (a, o) => {
      a != null && a !== !1 && (r[o] = t && U.isArray(a) ? a.join(", ") : a);
    }), r;
  }
  [Symbol.iterator]() {
    return Object.entries(this.toJSON())[Symbol.iterator]();
  }
  toString() {
    return Object.entries(this.toJSON()).map(([t, r]) => t + ": " + r).join(`
`);
  }
  getSetCookie() {
    return this.get("set-cookie") || [];
  }
  get [Symbol.toStringTag]() {
    return "AxiosHeaders";
  }
  static from(t) {
    return t instanceof this ? t : new this(t);
  }
  static concat(t, ...r) {
    const a = new this(t);
    return r.forEach((o) => a.set(o)), a;
  }
  static accessor(t) {
    const a = (this[du] = this[du] = {
      accessors: {}
    }).accessors, o = this.prototype;
    function n(s) {
      const i = Wa(s);
      a[i] || (bb(o, s), a[i] = !0);
    }
    return U.isArray(t) ? t.forEach(n) : n(t), this;
  }
};
kt.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]);
U.reduceDescriptors(kt.prototype, ({ value: e }, t) => {
  let r = t[0].toUpperCase() + t.slice(1);
  return {
    get: () => e,
    set(a) {
      this[r] = a;
    }
  };
});
U.freezeMethods(kt);
function Es(e, t) {
  const r = this || Do, a = t || r, o = kt.from(a.headers);
  let n = a.data;
  return U.forEach(e, function(i) {
    n = i.call(r, n, o.normalize(), t ? t.status : void 0);
  }), o.normalize(), n;
}
function Lp(e) {
  return !!(e && e.__CANCEL__);
}
function Ia(e, t, r) {
  Pe.call(this, e ?? "canceled", Pe.ERR_CANCELED, t, r), this.name = "CanceledError";
}
U.inherits(Ia, Pe, {
  __CANCEL__: !0
});
function Np(e, t, r) {
  const a = r.config.validateStatus;
  !r.status || !a || a(r.status) ? e(r) : t(new Pe(
    "Request failed with status code " + r.status,
    [Pe.ERR_BAD_REQUEST, Pe.ERR_BAD_RESPONSE][Math.floor(r.status / 100) - 4],
    r.config,
    r.request,
    r
  ));
}
function yb(e) {
  const t = /^([-+\w]{1,25})(:?\/\/|:)/.exec(e);
  return t && t[1] || "";
}
function wb(e, t) {
  e = e || 10;
  const r = new Array(e), a = new Array(e);
  let o = 0, n = 0, s;
  return t = t !== void 0 ? t : 1e3, function(l) {
    const c = Date.now(), u = a[n];
    s || (s = c), r[o] = l, a[o] = c;
    let f = n, p = 0;
    for (; f !== o; )
      p += r[f++], f = f % e;
    if (o = (o + 1) % e, o === n && (n = (n + 1) % e), c - s < t)
      return;
    const h = u && c - u;
    return h ? Math.round(p * 1e3 / h) : void 0;
  };
}
function xb(e, t) {
  let r = 0, a = 1e3 / t, o, n;
  const s = (c, u = Date.now()) => {
    r = u, o = null, n && (clearTimeout(n), n = null), e(...c);
  };
  return [(...c) => {
    const u = Date.now(), f = u - r;
    f >= a ? s(c, u) : (o = c, n || (n = setTimeout(() => {
      n = null, s(o);
    }, a - f)));
  }, () => o && s(o)];
}
const _n = (e, t, r = 3) => {
  let a = 0;
  const o = wb(50, 250);
  return xb((n) => {
    const s = n.loaded, i = n.lengthComputable ? n.total : void 0, l = s - a, c = o(l), u = s <= i;
    a = s;
    const f = {
      loaded: s,
      total: i,
      progress: i ? s / i : void 0,
      bytes: l,
      rate: c || void 0,
      estimated: c && i && u ? (i - s) / c : void 0,
      event: n,
      lengthComputable: i != null,
      [t ? "download" : "upload"]: !0
    };
    e(f);
  }, r);
}, fu = (e, t) => {
  const r = e != null;
  return [(a) => t[0]({
    lengthComputable: r,
    total: e,
    loaded: a
  }), t[1]];
}, pu = (e) => (...t) => U.asap(() => e(...t)), _b = ft.hasStandardBrowserEnv ? /* @__PURE__ */ ((e, t) => (r) => (r = new URL(r, ft.origin), e.protocol === r.protocol && e.host === r.host && (t || e.port === r.port)))(
  new URL(ft.origin),
  ft.navigator && /(msie|trident)/i.test(ft.navigator.userAgent)
) : () => !0, kb = ft.hasStandardBrowserEnv ? (
  // Standard browser envs support document.cookie
  {
    write(e, t, r, a, o, n) {
      const s = [e + "=" + encodeURIComponent(t)];
      U.isNumber(r) && s.push("expires=" + new Date(r).toGMTString()), U.isString(a) && s.push("path=" + a), U.isString(o) && s.push("domain=" + o), n === !0 && s.push("secure"), document.cookie = s.join("; ");
    },
    read(e) {
      const t = document.cookie.match(new RegExp("(^|;\\s*)(" + e + ")=([^;]*)"));
      return t ? decodeURIComponent(t[3]) : null;
    },
    remove(e) {
      this.write(e, "", Date.now() - 864e5);
    }
  }
) : (
  // Non-standard browser env (web workers, react-native) lack needed support.
  {
    write() {
    },
    read() {
      return null;
    },
    remove() {
    }
  }
);
function Cb(e) {
  return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(e);
}
function Ab(e, t) {
  return t ? e.replace(/\/?\/$/, "") + "/" + t.replace(/^\/+/, "") : e;
}
function Vp(e, t, r) {
  let a = !Cb(t);
  return e && (a || r == !1) ? Ab(e, t) : t;
}
const hu = (e) => e instanceof kt ? { ...e } : e;
function ia(e, t) {
  t = t || {};
  const r = {};
  function a(c, u, f, p) {
    return U.isPlainObject(c) && U.isPlainObject(u) ? U.merge.call({ caseless: p }, c, u) : U.isPlainObject(u) ? U.merge({}, u) : U.isArray(u) ? u.slice() : u;
  }
  function o(c, u, f, p) {
    if (U.isUndefined(u)) {
      if (!U.isUndefined(c))
        return a(void 0, c, f, p);
    } else return a(c, u, f, p);
  }
  function n(c, u) {
    if (!U.isUndefined(u))
      return a(void 0, u);
  }
  function s(c, u) {
    if (U.isUndefined(u)) {
      if (!U.isUndefined(c))
        return a(void 0, c);
    } else return a(void 0, u);
  }
  function i(c, u, f) {
    if (f in t)
      return a(c, u);
    if (f in e)
      return a(void 0, c);
  }
  const l = {
    url: n,
    method: n,
    data: n,
    baseURL: s,
    transformRequest: s,
    transformResponse: s,
    paramsSerializer: s,
    timeout: s,
    timeoutMessage: s,
    withCredentials: s,
    withXSRFToken: s,
    adapter: s,
    responseType: s,
    xsrfCookieName: s,
    xsrfHeaderName: s,
    onUploadProgress: s,
    onDownloadProgress: s,
    decompress: s,
    maxContentLength: s,
    maxBodyLength: s,
    beforeRedirect: s,
    transport: s,
    httpAgent: s,
    httpsAgent: s,
    cancelToken: s,
    socketPath: s,
    responseEncoding: s,
    validateStatus: i,
    headers: (c, u, f) => o(hu(c), hu(u), f, !0)
  };
  return U.forEach(Object.keys({ ...e, ...t }), function(u) {
    const f = l[u] || o, p = f(e[u], t[u], u);
    U.isUndefined(p) && f !== i || (r[u] = p);
  }), r;
}
const Hp = (e) => {
  const t = ia({}, e);
  let { data: r, withXSRFToken: a, xsrfHeaderName: o, xsrfCookieName: n, headers: s, auth: i } = t;
  t.headers = s = kt.from(s), t.url = Dp(Vp(t.baseURL, t.url, t.allowAbsoluteUrls), e.params, e.paramsSerializer), i && s.set(
    "Authorization",
    "Basic " + btoa((i.username || "") + ":" + (i.password ? unescape(encodeURIComponent(i.password)) : ""))
  );
  let l;
  if (U.isFormData(r)) {
    if (ft.hasStandardBrowserEnv || ft.hasStandardBrowserWebWorkerEnv)
      s.setContentType(void 0);
    else if ((l = s.getContentType()) !== !1) {
      const [c, ...u] = l ? l.split(";").map((f) => f.trim()).filter(Boolean) : [];
      s.setContentType([c || "multipart/form-data", ...u].join("; "));
    }
  }
  if (ft.hasStandardBrowserEnv && (a && U.isFunction(a) && (a = a(t)), a || a !== !1 && _b(t.url))) {
    const c = o && n && kb.read(n);
    c && s.set(o, c);
  }
  return t;
}, Sb = typeof XMLHttpRequest < "u", Eb = Sb && function(e) {
  return new Promise(function(r, a) {
    const o = Hp(e);
    let n = o.data;
    const s = kt.from(o.headers).normalize();
    let { responseType: i, onUploadProgress: l, onDownloadProgress: c } = o, u, f, p, h, m;
    function v() {
      h && h(), m && m(), o.cancelToken && o.cancelToken.unsubscribe(u), o.signal && o.signal.removeEventListener("abort", u);
    }
    let x = new XMLHttpRequest();
    x.open(o.method.toUpperCase(), o.url, !0), x.timeout = o.timeout;
    function C() {
      if (!x)
        return;
      const E = kt.from(
        "getAllResponseHeaders" in x && x.getAllResponseHeaders()
      ), F = {
        data: !i || i === "text" || i === "json" ? x.responseText : x.response,
        status: x.status,
        statusText: x.statusText,
        headers: E,
        config: e,
        request: x
      };
      Np(function(H) {
        r(H), v();
      }, function(H) {
        a(H), v();
      }, F), x = null;
    }
    "onloadend" in x ? x.onloadend = C : x.onreadystatechange = function() {
      !x || x.readyState !== 4 || x.status === 0 && !(x.responseURL && x.responseURL.indexOf("file:") === 0) || setTimeout(C);
    }, x.onabort = function() {
      x && (a(new Pe("Request aborted", Pe.ECONNABORTED, e, x)), x = null);
    }, x.onerror = function() {
      a(new Pe("Network Error", Pe.ERR_NETWORK, e, x)), x = null;
    }, x.ontimeout = function() {
      let T = o.timeout ? "timeout of " + o.timeout + "ms exceeded" : "timeout exceeded";
      const F = o.transitional || Ip;
      o.timeoutErrorMessage && (T = o.timeoutErrorMessage), a(new Pe(
        T,
        F.clarifyTimeoutError ? Pe.ETIMEDOUT : Pe.ECONNABORTED,
        e,
        x
      )), x = null;
    }, n === void 0 && s.setContentType(null), "setRequestHeader" in x && U.forEach(s.toJSON(), function(T, F) {
      x.setRequestHeader(F, T);
    }), U.isUndefined(o.withCredentials) || (x.withCredentials = !!o.withCredentials), i && i !== "json" && (x.responseType = o.responseType), c && ([p, m] = _n(c, !0), x.addEventListener("progress", p)), l && x.upload && ([f, h] = _n(l), x.upload.addEventListener("progress", f), x.upload.addEventListener("loadend", h)), (o.cancelToken || o.signal) && (u = (E) => {
      x && (a(!E || E.type ? new Ia(null, e, x) : E), x.abort(), x = null);
    }, o.cancelToken && o.cancelToken.subscribe(u), o.signal && (o.signal.aborted ? u() : o.signal.addEventListener("abort", u)));
    const S = yb(o.url);
    if (S && ft.protocols.indexOf(S) === -1) {
      a(new Pe("Unsupported protocol " + S + ":", Pe.ERR_BAD_REQUEST, e));
      return;
    }
    x.send(n || null);
  });
}, $b = (e, t) => {
  const { length: r } = e = e ? e.filter(Boolean) : [];
  if (t || r) {
    let a = new AbortController(), o;
    const n = function(c) {
      if (!o) {
        o = !0, i();
        const u = c instanceof Error ? c : this.reason;
        a.abort(u instanceof Pe ? u : new Ia(u instanceof Error ? u.message : u));
      }
    };
    let s = t && setTimeout(() => {
      s = null, n(new Pe(`timeout ${t} of ms exceeded`, Pe.ETIMEDOUT));
    }, t);
    const i = () => {
      e && (s && clearTimeout(s), s = null, e.forEach((c) => {
        c.unsubscribe ? c.unsubscribe(n) : c.removeEventListener("abort", n);
      }), e = null);
    };
    e.forEach((c) => c.addEventListener("abort", n));
    const { signal: l } = a;
    return l.unsubscribe = () => U.asap(i), l;
  }
}, Pb = function* (e, t) {
  let r = e.byteLength;
  if (r < t) {
    yield e;
    return;
  }
  let a = 0, o;
  for (; a < r; )
    o = a + t, yield e.slice(a, o), a = o;
}, Tb = async function* (e, t) {
  for await (const r of Mb(e))
    yield* Pb(r, t);
}, Mb = async function* (e) {
  if (e[Symbol.asyncIterator]) {
    yield* e;
    return;
  }
  const t = e.getReader();
  try {
    for (; ; ) {
      const { done: r, value: a } = await t.read();
      if (r)
        break;
      yield a;
    }
  } finally {
    await t.cancel();
  }
}, gu = (e, t, r, a) => {
  const o = Tb(e, t);
  let n = 0, s, i = (l) => {
    s || (s = !0, a && a(l));
  };
  return new ReadableStream({
    async pull(l) {
      try {
        const { done: c, value: u } = await o.next();
        if (c) {
          i(), l.close();
          return;
        }
        let f = u.byteLength;
        if (r) {
          let p = n += f;
          r(p);
        }
        l.enqueue(new Uint8Array(u));
      } catch (c) {
        throw i(c), c;
      }
    },
    cancel(l) {
      return i(l), o.return();
    }
  }, {
    highWaterMark: 2
  });
}, as = typeof fetch == "function" && typeof Request == "function" && typeof Response == "function", Fp = as && typeof ReadableStream == "function", Rb = as && (typeof TextEncoder == "function" ? /* @__PURE__ */ ((e) => (t) => e.encode(t))(new TextEncoder()) : async (e) => new Uint8Array(await new Response(e).arrayBuffer())), zp = (e, ...t) => {
  try {
    return !!e(...t);
  } catch {
    return !1;
  }
}, Ob = Fp && zp(() => {
  let e = !1;
  const t = new Request(ft.origin, {
    body: new ReadableStream(),
    method: "POST",
    get duplex() {
      return e = !0, "half";
    }
  }).headers.has("Content-Type");
  return e && !t;
}), mu = 64 * 1024, Oi = Fp && zp(() => U.isReadableStream(new Response("").body)), kn = {
  stream: Oi && ((e) => e.body)
};
as && ((e) => {
  ["text", "arrayBuffer", "blob", "formData", "stream"].forEach((t) => {
    !kn[t] && (kn[t] = U.isFunction(e[t]) ? (r) => r[t]() : (r, a) => {
      throw new Pe(`Response type '${t}' is not supported`, Pe.ERR_NOT_SUPPORT, a);
    });
  });
})(new Response());
const Bb = async (e) => {
  if (e == null)
    return 0;
  if (U.isBlob(e))
    return e.size;
  if (U.isSpecCompliantForm(e))
    return (await new Request(ft.origin, {
      method: "POST",
      body: e
    }).arrayBuffer()).byteLength;
  if (U.isArrayBufferView(e) || U.isArrayBuffer(e))
    return e.byteLength;
  if (U.isURLSearchParams(e) && (e = e + ""), U.isString(e))
    return (await Rb(e)).byteLength;
}, Db = async (e, t) => {
  const r = U.toFiniteNumber(e.getContentLength());
  return r ?? Bb(t);
}, Ib = as && (async (e) => {
  let {
    url: t,
    method: r,
    data: a,
    signal: o,
    cancelToken: n,
    timeout: s,
    onDownloadProgress: i,
    onUploadProgress: l,
    responseType: c,
    headers: u,
    withCredentials: f = "same-origin",
    fetchOptions: p
  } = Hp(e);
  c = c ? (c + "").toLowerCase() : "text";
  let h = $b([o, n && n.toAbortSignal()], s), m;
  const v = h && h.unsubscribe && (() => {
    h.unsubscribe();
  });
  let x;
  try {
    if (l && Ob && r !== "get" && r !== "head" && (x = await Db(u, a)) !== 0) {
      let F = new Request(t, {
        method: "POST",
        body: a,
        duplex: "half"
      }), j;
      if (U.isFormData(a) && (j = F.headers.get("content-type")) && u.setContentType(j), F.body) {
        const [H, B] = fu(
          x,
          _n(pu(l))
        );
        a = gu(F.body, mu, H, B);
      }
    }
    U.isString(f) || (f = f ? "include" : "omit");
    const C = "credentials" in Request.prototype;
    m = new Request(t, {
      ...p,
      signal: h,
      method: r.toUpperCase(),
      headers: u.normalize().toJSON(),
      body: a,
      duplex: "half",
      credentials: C ? f : void 0
    });
    let S = await fetch(m, p);
    const E = Oi && (c === "stream" || c === "response");
    if (Oi && (i || E && v)) {
      const F = {};
      ["status", "statusText", "headers"].forEach((P) => {
        F[P] = S[P];
      });
      const j = U.toFiniteNumber(S.headers.get("content-length")), [H, B] = i && fu(
        j,
        _n(pu(i), !0)
      ) || [];
      S = new Response(
        gu(S.body, mu, H, () => {
          B && B(), v && v();
        }),
        F
      );
    }
    c = c || "text";
    let T = await kn[U.findKey(kn, c) || "text"](S, e);
    return !E && v && v(), await new Promise((F, j) => {
      Np(F, j, {
        data: T,
        headers: kt.from(S.headers),
        status: S.status,
        statusText: S.statusText,
        config: e,
        request: m
      });
    });
  } catch (C) {
    throw v && v(), C && C.name === "TypeError" && /Load failed|fetch/i.test(C.message) ? Object.assign(
      new Pe("Network Error", Pe.ERR_NETWORK, e, m),
      {
        cause: C.cause || C
      }
    ) : Pe.from(C, C && C.code, e, m);
  }
}), Bi = {
  http: Yv,
  xhr: Eb,
  fetch: Ib
};
U.forEach(Bi, (e, t) => {
  if (e) {
    try {
      Object.defineProperty(e, "name", { value: t });
    } catch {
    }
    Object.defineProperty(e, "adapterName", { value: t });
  }
});
const vu = (e) => `- ${e}`, qb = (e) => U.isFunction(e) || e === null || e === !1, jp = {
  getAdapter: (e) => {
    e = U.isArray(e) ? e : [e];
    const { length: t } = e;
    let r, a;
    const o = {};
    for (let n = 0; n < t; n++) {
      r = e[n];
      let s;
      if (a = r, !qb(r) && (a = Bi[(s = String(r)).toLowerCase()], a === void 0))
        throw new Pe(`Unknown adapter '${s}'`);
      if (a)
        break;
      o[s || "#" + n] = a;
    }
    if (!a) {
      const n = Object.entries(o).map(
        ([i, l]) => `adapter ${i} ` + (l === !1 ? "is not supported by the environment" : "is not available in the build")
      );
      let s = t ? n.length > 1 ? `since :
` + n.map(vu).join(`
`) : " " + vu(n[0]) : "as no adapter specified";
      throw new Pe(
        "There is no suitable adapter to dispatch the request " + s,
        "ERR_NOT_SUPPORT"
      );
    }
    return a;
  },
  adapters: Bi
};
function $s(e) {
  if (e.cancelToken && e.cancelToken.throwIfRequested(), e.signal && e.signal.aborted)
    throw new Ia(null, e);
}
function bu(e) {
  return $s(e), e.headers = kt.from(e.headers), e.data = Es.call(
    e,
    e.transformRequest
  ), ["post", "put", "patch"].indexOf(e.method) !== -1 && e.headers.setContentType("application/x-www-form-urlencoded", !1), jp.getAdapter(e.adapter || Do.adapter)(e).then(function(a) {
    return $s(e), a.data = Es.call(
      e,
      e.transformResponse,
      a
    ), a.headers = kt.from(a.headers), a;
  }, function(a) {
    return Lp(a) || ($s(e), a && a.response && (a.response.data = Es.call(
      e,
      e.transformResponse,
      a.response
    ), a.response.headers = kt.from(a.response.headers))), Promise.reject(a);
  });
}
const Up = "1.11.0", os = {};
["object", "boolean", "number", "function", "string", "symbol"].forEach((e, t) => {
  os[e] = function(a) {
    return typeof a === e || "a" + (t < 1 ? "n " : " ") + e;
  };
});
const yu = {};
os.transitional = function(t, r, a) {
  function o(n, s) {
    return "[Axios v" + Up + "] Transitional option '" + n + "'" + s + (a ? ". " + a : "");
  }
  return (n, s, i) => {
    if (t === !1)
      throw new Pe(
        o(s, " has been removed" + (r ? " in " + r : "")),
        Pe.ERR_DEPRECATED
      );
    return r && !yu[s] && (yu[s] = !0, console.warn(
      o(
        s,
        " has been deprecated since v" + r + " and will be removed in the near future"
      )
    )), t ? t(n, s, i) : !0;
  };
};
os.spelling = function(t) {
  return (r, a) => (console.warn(`${a} is likely a misspelling of ${t}`), !0);
};
function Lb(e, t, r) {
  if (typeof e != "object")
    throw new Pe("options must be an object", Pe.ERR_BAD_OPTION_VALUE);
  const a = Object.keys(e);
  let o = a.length;
  for (; o-- > 0; ) {
    const n = a[o], s = t[n];
    if (s) {
      const i = e[n], l = i === void 0 || s(i, n, e);
      if (l !== !0)
        throw new Pe("option " + n + " must be " + l, Pe.ERR_BAD_OPTION_VALUE);
      continue;
    }
    if (r !== !0)
      throw new Pe("Unknown option " + n, Pe.ERR_BAD_OPTION);
  }
}
const un = {
  assertOptions: Lb,
  validators: os
}, Wt = un.validators;
let na = class {
  constructor(t) {
    this.defaults = t || {}, this.interceptors = {
      request: new uu(),
      response: new uu()
    };
  }
  /**
   * Dispatch a request
   *
   * @param {String|Object} configOrUrl The config specific for this request (merged with this.defaults)
   * @param {?Object} config
   *
   * @returns {Promise} The Promise to be fulfilled
   */
  async request(t, r) {
    try {
      return await this._request(t, r);
    } catch (a) {
      if (a instanceof Error) {
        let o = {};
        Error.captureStackTrace ? Error.captureStackTrace(o) : o = new Error();
        const n = o.stack ? o.stack.replace(/^.+\n/, "") : "";
        try {
          a.stack ? n && !String(a.stack).endsWith(n.replace(/^.+\n.+\n/, "")) && (a.stack += `
` + n) : a.stack = n;
        } catch {
        }
      }
      throw a;
    }
  }
  _request(t, r) {
    typeof t == "string" ? (r = r || {}, r.url = t) : r = t || {}, r = ia(this.defaults, r);
    const { transitional: a, paramsSerializer: o, headers: n } = r;
    a !== void 0 && un.assertOptions(a, {
      silentJSONParsing: Wt.transitional(Wt.boolean),
      forcedJSONParsing: Wt.transitional(Wt.boolean),
      clarifyTimeoutError: Wt.transitional(Wt.boolean)
    }, !1), o != null && (U.isFunction(o) ? r.paramsSerializer = {
      serialize: o
    } : un.assertOptions(o, {
      encode: Wt.function,
      serialize: Wt.function
    }, !0)), r.allowAbsoluteUrls !== void 0 || (this.defaults.allowAbsoluteUrls !== void 0 ? r.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls : r.allowAbsoluteUrls = !0), un.assertOptions(r, {
      baseUrl: Wt.spelling("baseURL"),
      withXsrfToken: Wt.spelling("withXSRFToken")
    }, !0), r.method = (r.method || this.defaults.method || "get").toLowerCase();
    let s = n && U.merge(
      n.common,
      n[r.method]
    );
    n && U.forEach(
      ["delete", "get", "head", "post", "put", "patch", "common"],
      (m) => {
        delete n[m];
      }
    ), r.headers = kt.concat(s, n);
    const i = [];
    let l = !0;
    this.interceptors.request.forEach(function(v) {
      typeof v.runWhen == "function" && v.runWhen(r) === !1 || (l = l && v.synchronous, i.unshift(v.fulfilled, v.rejected));
    });
    const c = [];
    this.interceptors.response.forEach(function(v) {
      c.push(v.fulfilled, v.rejected);
    });
    let u, f = 0, p;
    if (!l) {
      const m = [bu.bind(this), void 0];
      for (m.unshift(...i), m.push(...c), p = m.length, u = Promise.resolve(r); f < p; )
        u = u.then(m[f++], m[f++]);
      return u;
    }
    p = i.length;
    let h = r;
    for (f = 0; f < p; ) {
      const m = i[f++], v = i[f++];
      try {
        h = m(h);
      } catch (x) {
        v.call(this, x);
        break;
      }
    }
    try {
      u = bu.call(this, h);
    } catch (m) {
      return Promise.reject(m);
    }
    for (f = 0, p = c.length; f < p; )
      u = u.then(c[f++], c[f++]);
    return u;
  }
  getUri(t) {
    t = ia(this.defaults, t);
    const r = Vp(t.baseURL, t.url, t.allowAbsoluteUrls);
    return Dp(r, t.params, t.paramsSerializer);
  }
};
U.forEach(["delete", "get", "head", "options"], function(t) {
  na.prototype[t] = function(r, a) {
    return this.request(ia(a || {}, {
      method: t,
      url: r,
      data: (a || {}).data
    }));
  };
});
U.forEach(["post", "put", "patch"], function(t) {
  function r(a) {
    return function(n, s, i) {
      return this.request(ia(i || {}, {
        method: t,
        headers: a ? {
          "Content-Type": "multipart/form-data"
        } : {},
        url: n,
        data: s
      }));
    };
  }
  na.prototype[t] = r(), na.prototype[t + "Form"] = r(!0);
});
let Nb = class Zp {
  constructor(t) {
    if (typeof t != "function")
      throw new TypeError("executor must be a function.");
    let r;
    this.promise = new Promise(function(n) {
      r = n;
    });
    const a = this;
    this.promise.then((o) => {
      if (!a._listeners) return;
      let n = a._listeners.length;
      for (; n-- > 0; )
        a._listeners[n](o);
      a._listeners = null;
    }), this.promise.then = (o) => {
      let n;
      const s = new Promise((i) => {
        a.subscribe(i), n = i;
      }).then(o);
      return s.cancel = function() {
        a.unsubscribe(n);
      }, s;
    }, t(function(n, s, i) {
      a.reason || (a.reason = new Ia(n, s, i), r(a.reason));
    });
  }
  /**
   * Throws a `CanceledError` if cancellation has been requested.
   */
  throwIfRequested() {
    if (this.reason)
      throw this.reason;
  }
  /**
   * Subscribe to the cancel signal
   */
  subscribe(t) {
    if (this.reason) {
      t(this.reason);
      return;
    }
    this._listeners ? this._listeners.push(t) : this._listeners = [t];
  }
  /**
   * Unsubscribe from the cancel signal
   */
  unsubscribe(t) {
    if (!this._listeners)
      return;
    const r = this._listeners.indexOf(t);
    r !== -1 && this._listeners.splice(r, 1);
  }
  toAbortSignal() {
    const t = new AbortController(), r = (a) => {
      t.abort(a);
    };
    return this.subscribe(r), t.signal.unsubscribe = () => this.unsubscribe(r), t.signal;
  }
  /**
   * Returns an object that contains a new `CancelToken` and a function that, when called,
   * cancels the `CancelToken`.
   */
  static source() {
    let t;
    return {
      token: new Zp(function(o) {
        t = o;
      }),
      cancel: t
    };
  }
};
function Vb(e) {
  return function(r) {
    return e.apply(null, r);
  };
}
function Hb(e) {
  return U.isObject(e) && e.isAxiosError === !0;
}
const Di = {
  Continue: 100,
  SwitchingProtocols: 101,
  Processing: 102,
  EarlyHints: 103,
  Ok: 200,
  Created: 201,
  Accepted: 202,
  NonAuthoritativeInformation: 203,
  NoContent: 204,
  ResetContent: 205,
  PartialContent: 206,
  MultiStatus: 207,
  AlreadyReported: 208,
  ImUsed: 226,
  MultipleChoices: 300,
  MovedPermanently: 301,
  Found: 302,
  SeeOther: 303,
  NotModified: 304,
  UseProxy: 305,
  Unused: 306,
  TemporaryRedirect: 307,
  PermanentRedirect: 308,
  BadRequest: 400,
  Unauthorized: 401,
  PaymentRequired: 402,
  Forbidden: 403,
  NotFound: 404,
  MethodNotAllowed: 405,
  NotAcceptable: 406,
  ProxyAuthenticationRequired: 407,
  RequestTimeout: 408,
  Conflict: 409,
  Gone: 410,
  LengthRequired: 411,
  PreconditionFailed: 412,
  PayloadTooLarge: 413,
  UriTooLong: 414,
  UnsupportedMediaType: 415,
  RangeNotSatisfiable: 416,
  ExpectationFailed: 417,
  ImATeapot: 418,
  MisdirectedRequest: 421,
  UnprocessableEntity: 422,
  Locked: 423,
  FailedDependency: 424,
  TooEarly: 425,
  UpgradeRequired: 426,
  PreconditionRequired: 428,
  TooManyRequests: 429,
  RequestHeaderFieldsTooLarge: 431,
  UnavailableForLegalReasons: 451,
  InternalServerError: 500,
  NotImplemented: 501,
  BadGateway: 502,
  ServiceUnavailable: 503,
  GatewayTimeout: 504,
  HttpVersionNotSupported: 505,
  VariantAlsoNegotiates: 506,
  InsufficientStorage: 507,
  LoopDetected: 508,
  NotExtended: 510,
  NetworkAuthenticationRequired: 511
};
Object.entries(Di).forEach(([e, t]) => {
  Di[t] = e;
});
function Kp(e) {
  const t = new na(e), r = kp(na.prototype.request, t);
  return U.extend(r, na.prototype, t, { allOwnKeys: !0 }), U.extend(r, t, null, { allOwnKeys: !0 }), r.create = function(o) {
    return Kp(ia(e, o));
  }, r;
}
const tt = Kp(Do);
tt.Axios = na;
tt.CanceledError = Ia;
tt.CancelToken = Nb;
tt.isCancel = Lp;
tt.VERSION = Up;
tt.toFormData = rs;
tt.AxiosError = Pe;
tt.Cancel = tt.CanceledError;
tt.all = function(t) {
  return Promise.all(t);
};
tt.spread = Vb;
tt.isAxiosError = Hb;
tt.mergeConfig = ia;
tt.AxiosHeaders = kt;
tt.formToJSON = (e) => qp(U.isHTMLForm(e) ? new FormData(e) : e);
tt.getAdapter = jp.getAdapter;
tt.HttpStatusCode = Di;
tt.default = tt;
const {
  Axios: KE,
  AxiosError: WE,
  CanceledError: GE,
  isCancel: JE,
  CancelToken: YE,
  VERSION: XE,
  all: QE,
  Cancel: e$,
  isAxiosError: t$,
  spread: r$,
  toFormData: a$,
  AxiosHeaders: o$,
  HttpStatusCode: n$,
  formToJSON: s$,
  getAdapter: i$,
  mergeConfig: l$
} = tt, Fb = "/apps/kspeeder/", ka = {
  basePath: Pl(),
  apiBase: Ub(),
  mode: "standalone"
};
function zb(e) {
  const r = (typeof e == "string" ? e.trim() : "") || Pl();
  return r.endsWith("/") ? r : `${r}/`;
}
function jb(e, t) {
  const a = (typeof e == "string" ? e.trim() : "") || `${t}api/`;
  return a.endsWith("/") ? a : `${a}/`;
}
function Pl() {
  if (typeof window > "u")
    return Fb;
  const e = window.location.pathname || "/", t = "/apps/kspeeder/";
  return e === "/apps/kspeeder" || e.startsWith(t) ? t : "/";
}
function Ub() {
  return `${Pl()}api/`;
}
function Zb(e = {}) {
  const t = zb(e.basePath);
  ka.basePath = t, ka.apiBase = jb(e.apiBase, t), ka.mode = e.mode || "standalone", ka.hostAdapter = e.hostAdapter;
}
function Kb() {
  return ka;
}
function Wb(e) {
  return e.startsWith("/api/") ? `${ka.apiBase}${e.slice(5)}` : e;
}
const St = tt.create({
  timeout: 2e4
});
St.interceptors.request.use(
  (e) => (typeof e.url == "string" && (e.url = Wb(e.url)), e),
  (e) => Promise.reject(e)
);
St.interceptors.response.use(
  (e) => e,
  (e) => Promise.reject(e)
);
const Gb = /* @__PURE__ */ ep("env-config", {
  state: () => ({
    gaId: "",
    loadSuccess: !1
  }),
  actions: {
    async fetchEnvConfig() {
      this.loadSuccess || await St.get("/api/ks-ctl/env/config").then((e) => {
        this.gaId = e.data.GA_ID || void 0, this.loadSuccess = !0;
      });
    },
    createGtag() {
      return dv({
        tagId: this.gaId,
        config: {
          send_page_view: !0
        }
      });
    }
  }
});
let Ii = 1;
var Jb = class {
  subscribers;
  toasts;
  dismissedToasts;
  constructor() {
    this.subscribers = [], this.toasts = [], this.dismissedToasts = /* @__PURE__ */ new Set();
  }
  subscribe = (e) => (this.subscribers.push(e), () => {
    const t = this.subscribers.indexOf(e);
    this.subscribers.splice(t, 1);
  });
  publish = (e) => {
    this.subscribers.forEach((t) => t(e));
  };
  addToast = (e) => {
    this.publish(e), this.toasts = [...this.toasts, e];
  };
  create = (e) => {
    const { message: t, ...r } = e, a = typeof e.id == "number" || e.id && e.id?.length > 0 ? e.id : Ii++, o = this.toasts.find((s) => s.id === a), n = e.dismissible === void 0 ? !0 : e.dismissible;
    return this.dismissedToasts.has(a) && this.dismissedToasts.delete(a), o ? this.toasts = this.toasts.map((s) => s.id === a ? (this.publish({
      ...s,
      ...e,
      id: a,
      title: t
    }), {
      ...s,
      ...e,
      id: a,
      dismissible: n,
      title: t
    }) : s) : this.addToast({
      title: t,
      ...r,
      dismissible: n,
      id: a
    }), a;
  };
  dismiss = (e) => (e ? (this.dismissedToasts.add(e), requestAnimationFrame(() => this.subscribers.forEach((t) => t({
    id: e,
    dismiss: !0
  })))) : this.toasts.forEach((t) => {
    this.subscribers.forEach((r) => r({
      id: t.id,
      dismiss: !0
    }));
  }), e);
  message = (e, t) => this.create({
    ...t,
    message: e,
    type: "default"
  });
  error = (e, t) => this.create({
    ...t,
    type: "error",
    message: e
  });
  success = (e, t) => this.create({
    ...t,
    type: "success",
    message: e
  });
  info = (e, t) => this.create({
    ...t,
    type: "info",
    message: e
  });
  warning = (e, t) => this.create({
    ...t,
    type: "warning",
    message: e
  });
  loading = (e, t) => this.create({
    ...t,
    type: "loading",
    message: e
  });
  promise = (e, t) => {
    if (!t) return;
    let r;
    t.loading !== void 0 && (r = this.create({
      ...t,
      promise: e,
      type: "loading",
      message: t.loading,
      description: typeof t.description != "function" ? t.description : void 0
    }));
    const a = Promise.resolve(e instanceof Function ? e() : e);
    let o = r !== void 0, n;
    const s = a.then(async (l) => {
      if (n = ["resolve", l], er(l))
        o = !1, this.create({
          id: r,
          type: "default",
          message: l
        });
      else if (Xb(l) && !l.ok) {
        o = !1;
        const u = typeof t.error == "function" ? await t.error(`HTTP error! status: ${l.status}`) : t.error, f = typeof t.description == "function" ? await t.description(`HTTP error! status: ${l.status}`) : t.description, h = typeof u == "object" && !er(u) ? u : {
          message: u || "",
          id: r || ""
        };
        this.create({
          id: r,
          type: "error",
          description: f,
          ...h
        });
      } else if (l instanceof Error) {
        o = !1;
        const u = typeof t.error == "function" ? await t.error(l) : t.error, f = typeof t.description == "function" ? await t.description(l) : t.description, h = typeof u == "object" && !er(u) ? u : {
          message: u || "",
          id: r || ""
        };
        this.create({
          id: r,
          type: "error",
          description: f,
          ...h
        });
      } else if (t.success !== void 0) {
        o = !1;
        const u = typeof t.success == "function" ? await t.success(l) : t.success, f = typeof t.description == "function" ? await t.description(l) : t.description, h = typeof u == "object" && !er(u) ? u : {
          message: u || "",
          id: r || ""
        };
        this.create({
          id: r,
          type: "success",
          description: f,
          ...h
        });
      }
    }).catch(async (l) => {
      if (n = ["reject", l], t.error !== void 0) {
        o = !1;
        const c = typeof t.error == "function" ? await t.error(l) : t.error, u = typeof t.description == "function" ? await t.description(l) : t.description, p = typeof c == "object" && !er(c) ? c : {
          message: c || "",
          id: r || ""
        };
        this.create({
          id: r,
          type: "error",
          description: u,
          ...p
        });
      }
    }).finally(() => {
      o && (this.dismiss(r), r = void 0), t.finally?.();
    }), i = () => new Promise((l, c) => s.then(() => n[0] === "reject" ? c(n[1]) : l(n[1])).catch(c));
    return typeof r != "string" && typeof r != "number" ? { unwrap: i } : Object.assign(r, { unwrap: i });
  };
  custom = (e, t) => {
    const r = t?.id || Ii++, a = this.toasts.find((n) => n.id === r), o = t?.dismissible === void 0 ? !0 : t.dismissible;
    return this.dismissedToasts.has(r) && this.dismissedToasts.delete(r), a ? this.toasts = this.toasts.map((n) => n.id === r ? (this.publish({
      ...n,
      component: e,
      dismissible: o,
      id: r,
      ...t
    }), {
      ...n,
      component: e,
      dismissible: o,
      id: r,
      ...t
    }) : n) : this.addToast({
      component: e,
      dismissible: o,
      id: r,
      ...t
    }), r;
  };
  getActiveToasts = () => this.toasts.filter((e) => !this.dismissedToasts.has(e.id));
};
const xt = new Jb();
function Yb(e, t) {
  const r = t?.id || Ii++;
  return xt.create({
    message: e,
    id: r,
    type: "default",
    ...t
  }), r;
}
const Xb = (e) => e && typeof e == "object" && "ok" in e && typeof e.ok == "boolean" && "status" in e && typeof e.status == "number", Qb = Yb, ey = () => xt.toasts, ty = () => xt.getActiveToasts(), ut = Object.assign(Qb, {
  success: xt.success,
  info: xt.info,
  warning: xt.warning,
  error: xt.error,
  custom: xt.custom,
  message: xt.message,
  promise: xt.promise,
  dismiss: xt.dismiss,
  loading: xt.loading
}, {
  getHistory: ey,
  getToasts: ty
});
function Uo(e) {
  return e.label !== void 0;
}
const ry = 3, Wp = "24px", Gp = "16px", wu = 4e3, ay = 356, oy = 14, ny = 45, Jp = 200;
function sy() {
  const e = K(!1);
  return Xe(() => {
    const t = () => {
      e.value = document.hidden;
    };
    return document.addEventListener("visibilitychange", t), () => window.removeEventListener("visibilitychange", t);
  }), { isDocumentHidden: e };
}
function Tr(...e) {
  return e.filter(Boolean).join(" ");
}
function iy(e) {
  const [t, r] = e.split("-"), a = [];
  return t && a.push(t), r && a.push(r), a;
}
function ly(e, t) {
  const r = {};
  return [e, t].forEach((a, o) => {
    const n = o === 1, s = n ? "--mobile-offset" : "--offset", i = n ? Gp : Wp;
    function l(c) {
      [
        "top",
        "right",
        "bottom",
        "left"
      ].forEach((u) => {
        r[`${s}-${u}`] = typeof c == "number" ? `${c}px` : c;
      });
    }
    typeof a == "number" || typeof a == "string" ? l(a) : typeof a == "object" ? [
      "top",
      "right",
      "bottom",
      "left"
    ].forEach((c) => {
      a[c] === void 0 ? r[`${s}-${c}`] = i : r[`${s}-${c}`] = typeof a[c] == "number" ? `${a[c]}px` : a[c];
    }) : l(i);
  }), r;
}
const cy = [
  "data-rich-colors",
  "data-styled",
  "data-mounted",
  "data-promise",
  "data-swiped",
  "data-removed",
  "data-visible",
  "data-y-position",
  "data-x-position",
  "data-index",
  "data-front",
  "data-swiping",
  "data-dismissible",
  "data-type",
  "data-invert",
  "data-swipe-out",
  "data-swipe-direction",
  "data-expanded",
  "data-testid"
], uy = [
  "aria-label",
  "data-disabled",
  "data-close-button-position"
];
var dy = /* @__PURE__ */ D({
  __name: "Toast",
  props: {
    toast: {},
    toasts: {},
    index: {},
    swipeDirections: {},
    expanded: { type: Boolean },
    invert: { type: Boolean },
    heights: {},
    gap: {},
    position: {},
    closeButtonPosition: {},
    visibleToasts: {},
    expandByDefault: { type: Boolean },
    closeButton: { type: Boolean },
    interacting: { type: Boolean },
    style: {},
    cancelButtonStyle: {},
    actionButtonStyle: {},
    duration: {},
    class: {},
    unstyled: { type: Boolean },
    descriptionClass: {},
    loadingIcon: {},
    classes: {},
    icons: {},
    closeButtonAriaLabel: {},
    defaultRichColors: { type: Boolean }
  },
  emits: [
    "update:heights",
    "update:height",
    "removeToast"
  ],
  setup(e, { emit: t }) {
    const r = e, a = t, o = K(null), n = K(null), s = K(!1), i = K(!1), l = K(!1), c = K(!1), u = K(!1), f = K(0), p = K(0), h = K(r.toast.duration || r.duration || wu), m = K(null), v = K(null), x = L(() => r.index === 0), C = L(() => r.index + 1 <= r.visibleToasts), S = L(() => r.toast.type), E = L(() => r.toast.dismissible !== !1), T = L(() => r.toast.class || ""), F = L(() => r.descriptionClass || ""), j = L(() => {
      const y = r.toast.position || r.position, Z = r.heights.filter((te) => te.position === y).findIndex((te) => te.toastId === r.toast.id);
      return Z >= 0 ? Z : 0;
    }), H = L(() => {
      const y = r.toast.position || r.position;
      return r.heights.filter((Z) => Z.position === y).reduce((Z, te, we) => we >= j.value ? Z : Z + te.height, 0);
    }), B = L(() => j.value * r.gap + H.value || 0), P = L(() => r.toast.closeButton ?? r.closeButton), $ = L(() => r.toast.duration || r.duration || wu), V = K(0), z = K(0), G = K(null), ee = L(() => r.position.split("-")), xe = L(() => ee.value[0]), de = L(() => ee.value[1]), W = L(() => typeof r.toast.title != "string"), M = L(() => typeof r.toast.description != "string"), { isDocumentHidden: ge } = sy(), Me = L(() => S.value && S.value === "loading");
    at(() => {
      s.value = !0, h.value = $.value;
    }), Xe(async () => {
      if (!s.value || !v.value) return;
      await et();
      const y = v.value, Q = y.style.height;
      y.style.height = "auto";
      const Z = y.getBoundingClientRect().height;
      y.style.height = Q, p.value = Z, a("update:height", {
        toastId: r.toast.id,
        height: Z,
        position: r.toast.position || r.position
      });
    });
    function Ie() {
      i.value = !0, f.value = B.value, setTimeout(() => {
        a("removeToast", r.toast);
      }, Jp);
    }
    function ze() {
      if (Me.value || !E.value) return {};
      Ie(), r.toast.onDismiss?.(r.toast);
    }
    function ae(y) {
      y.button !== 2 && (Me.value || !E.value || (m.value = /* @__PURE__ */ new Date(), f.value = B.value, y.target.setPointerCapture(y.pointerId), y.target.tagName !== "BUTTON" && (l.value = !0, G.value = {
        x: y.clientX,
        y: y.clientY
      })));
    }
    function O() {
      if (c.value || !E.value) return;
      G.value = null;
      const y = Number(v.value?.style.getPropertyValue("--swipe-amount-x").replace("px", "") || 0), Q = Number(v.value?.style.getPropertyValue("--swipe-amount-y").replace("px", "") || 0), Z = (/* @__PURE__ */ new Date()).getTime() - (m.value?.getTime() || 0), te = o.value === "x" ? y : Q, we = Math.abs(te) / Z;
      if (Math.abs(te) >= ny || we > 0.11) {
        f.value = B.value, r.toast.onDismiss?.(r.toast), o.value === "x" ? n.value = y > 0 ? "right" : "left" : n.value = Q > 0 ? "down" : "up", Ie(), c.value = !0;
        return;
      } else
        v.value?.style.setProperty("--swipe-amount-x", "0px"), v.value?.style.setProperty("--swipe-amount-y", "0px");
      u.value = !1, l.value = !1, o.value = null;
    }
    function Ae(y) {
      if (!G.value || !E.value || (window?.getSelection()?.toString()?.length ?? !1)) return;
      const Z = y.clientY - G.value.y, te = y.clientX - G.value.x, we = r.swipeDirections ?? iy(r.position);
      !o.value && (Math.abs(te) > 1 || Math.abs(Z) > 1) && (o.value = Math.abs(te) > Math.abs(Z) ? "x" : "y");
      let _ = {
        x: 0,
        y: 0
      };
      const A = (I) => 1 / (1.5 + Math.abs(I) / 20);
      if (o.value === "y") {
        if (we.includes("top") || we.includes("bottom")) if (we.includes("top") && Z < 0 || we.includes("bottom") && Z > 0) _.y = Z;
        else {
          const I = Z * A(Z);
          _.y = Math.abs(I) < Math.abs(Z) ? I : Z;
        }
      } else if (o.value === "x" && (we.includes("left") || we.includes("right")))
        if (we.includes("left") && te < 0 || we.includes("right") && te > 0) _.x = te;
        else {
          const I = te * A(te);
          _.x = Math.abs(I) < Math.abs(te) ? I : te;
        }
      (Math.abs(_.x) > 0 || Math.abs(_.y) > 0) && (u.value = !0), v.value?.style.setProperty("--swipe-amount-x", `${_.x}px`), v.value?.style.setProperty("--swipe-amount-y", `${_.y}px`);
    }
    at(() => {
      if (s.value = !0, !v.value) return;
      const y = v.value.getBoundingClientRect().height;
      p.value = y;
      const Q = [{
        toastId: r.toast.id,
        height: y,
        position: r.toast.position
      }, ...r.heights];
      a("update:heights", Q);
    }), jn(() => {
      v.value && a("removeToast", r.toast);
    }), Xe((y) => {
      if (r.toast.promise && S.value === "loading" || r.toast.duration === 1 / 0 || r.toast.type === "loading") return;
      let Q;
      const Z = () => {
        if (z.value < V.value) {
          const we = (/* @__PURE__ */ new Date()).getTime() - V.value;
          h.value = h.value - we;
        }
        z.value = (/* @__PURE__ */ new Date()).getTime();
      }, te = () => {
        h.value !== 1 / 0 && (V.value = (/* @__PURE__ */ new Date()).getTime(), Q = setTimeout(() => {
          r.toast.onAutoClose?.(r.toast), Ie();
        }, h.value));
      };
      r.expanded || r.interacting || ge.value ? Z() : te(), y(() => {
        clearTimeout(Q);
      });
    }), Ke(() => r.toast.delete, (y) => {
      y !== void 0 && y && (Ie(), r.toast.onDismiss?.(r.toast));
    }, { deep: !0 });
    function _e() {
      l.value = !1, o.value = null, G.value = null;
    }
    return (y, Q) => (g(), R("li", {
      tabindex: "0",
      ref_key: "toastRef",
      ref: v,
      class: ke(d(Tr)(r.class, T.value, y.classes?.toast, y.toast.classes?.toast, y.classes?.[S.value], y.toast?.classes?.[S.value])),
      "data-sonner-toast": "",
      "data-rich-colors": y.toast.richColors ?? y.defaultRichColors,
      "data-styled": !(y.toast.component || y.toast?.unstyled || y.unstyled),
      "data-mounted": s.value,
      "data-promise": !!y.toast.promise,
      "data-swiped": u.value,
      "data-removed": i.value,
      "data-visible": C.value,
      "data-y-position": xe.value,
      "data-x-position": de.value,
      "data-index": y.index,
      "data-front": x.value,
      "data-swiping": l.value,
      "data-dismissible": E.value,
      "data-type": S.value,
      "data-invert": y.toast.invert || y.invert,
      "data-swipe-out": c.value,
      "data-swipe-direction": n.value,
      "data-expanded": !!(y.expanded || y.expandByDefault && s.value),
      "data-testid": y.toast.testId,
      style: Tt({
        "--index": y.index,
        "--toasts-before": y.index,
        "--z-index": y.toasts.length - y.index,
        "--offset": `${i.value ? f.value : B.value}px`,
        "--initial-height": y.expandByDefault ? "auto" : `${p.value}px`,
        ...y.style,
        ...r.toast.style
      }),
      onDragend: _e,
      onPointerdown: ae,
      onPointerup: O,
      onPointermove: Ae
    }, [P.value && !y.toast.component && S.value !== "loading" ? (g(), R("button", {
      key: 0,
      "aria-label": y.closeButtonAriaLabel || "Close toast",
      "data-disabled": Me.value,
      "data-close-button": "true",
      "data-close-button-position": y.closeButtonPosition,
      class: ke(d(Tr)(y.classes?.closeButton, y.toast?.classes?.closeButton)),
      onClick: ze
    }, [y.icons?.close ? (g(), N(Qt(y.icons?.close), { key: 0 })) : q(y.$slots, "close-icon", { key: 1 })], 10, uy)) : $e("v-if", !0), y.toast.component ? (g(), N(Qt(y.toast.component), re({ key: 1 }, y.toast.componentProps, {
      onCloseToast: ze,
      isPaused: y.$props.expanded || y.$props.interacting || d(ge)
    }), null, 16, ["isPaused"])) : (g(), R(Be, { key: 2 }, [
      S.value !== "default" || y.toast.icon || y.toast.promise ? (g(), R("div", {
        key: 0,
        "data-icon": "",
        class: ke(d(Tr)(y.classes?.icon, y.toast?.classes?.icon))
      }, [y.toast.icon ? (g(), N(Qt(y.toast.icon), { key: 0 })) : (g(), R(Be, { key: 1 }, [S.value === "loading" ? q(y.$slots, "loading-icon", { key: 0 }) : S.value === "success" ? q(y.$slots, "success-icon", { key: 1 }) : S.value === "error" ? q(y.$slots, "error-icon", { key: 2 }) : S.value === "warning" ? q(y.$slots, "warning-icon", { key: 3 }) : S.value === "info" ? q(y.$slots, "info-icon", { key: 4 }) : $e("v-if", !0)], 64))], 2)) : $e("v-if", !0),
      w("div", {
        "data-content": "",
        class: ke(d(Tr)(y.classes?.content, y.toast?.classes?.content))
      }, [w("div", {
        "data-title": "",
        class: ke(d(Tr)(y.classes?.title, y.toast.classes?.title))
      }, [W.value ? (g(), N(Qt(y.toast.title), De(re({ key: 0 }, y.toast.componentProps)), null, 16)) : (g(), R(Be, { key: 1 }, [ne(ue(y.toast.title), 1)], 64))], 2), y.toast.description ? (g(), R("div", {
        key: 0,
        "data-description": "",
        class: ke(d(Tr)(y.descriptionClass, F.value, y.classes?.description, y.toast.classes?.description))
      }, [M.value ? (g(), N(Qt(y.toast.description), De(re({ key: 0 }, y.toast.componentProps)), null, 16)) : (g(), R(Be, { key: 1 }, [ne(ue(y.toast.description), 1)], 64))], 2)) : $e("v-if", !0)], 2),
      y.toast.cancel ? (g(), R("button", {
        key: 1,
        style: Tt(y.toast.cancelButtonStyle || y.cancelButtonStyle),
        class: ke(d(Tr)(y.classes?.cancelButton, y.toast.classes?.cancelButton)),
        "data-button": "",
        "data-cancel": "",
        onClick: Q[0] || (Q[0] = (Z) => {
          d(Uo)(y.toast.cancel) && E.value && (y.toast.cancel.onClick?.(Z), Ie());
        })
      }, ue(d(Uo)(y.toast.cancel) ? y.toast.cancel?.label : y.toast.cancel), 7)) : $e("v-if", !0),
      y.toast.action ? (g(), R("button", {
        key: 2,
        style: Tt(y.toast.actionButtonStyle || y.actionButtonStyle),
        class: ke(d(Tr)(y.classes?.actionButton, y.toast.classes?.actionButton)),
        "data-button": "",
        "data-action": "",
        onClick: Q[1] || (Q[1] = (Z) => {
          d(Uo)(y.toast.action) && (y.toast.action.onClick?.(Z), !Z.defaultPrevented && Ie());
        })
      }, ue(d(Uo)(y.toast.action) ? y.toast.action?.label : y.toast.action), 7)) : $e("v-if", !0)
    ], 64))], 46, cy));
  }
}), fy = dy, Io = (e, t) => {
  const r = e.__vccOpts || e;
  for (const [a, o] of t) r[a] = o;
  return r;
};
const py = {}, hy = {
  xmlns: "http://www.w3.org/2000/svg",
  width: "12",
  height: "12",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  "stoke-width": "1.5",
  "stroke-linecap": "round",
  "stroke-linejoin": "round"
};
function gy(e, t) {
  return g(), R("svg", hy, t[0] || (t[0] = [w("line", {
    x1: "18",
    y1: "6",
    x2: "6",
    y2: "18"
  }, null, -1), w("line", {
    x1: "6",
    y1: "6",
    x2: "18",
    y2: "18"
  }, null, -1)]));
}
var my = /* @__PURE__ */ Io(py, [["render", gy]]);
const vy = ["data-visible"], by = { class: "sonner-spinner" };
var yy = /* @__PURE__ */ D({
  __name: "Loader",
  props: { visible: { type: Boolean } },
  setup(e) {
    const t = Array(12).fill(0);
    return (r, a) => (g(), R("div", {
      class: "sonner-loading-wrapper",
      "data-visible": r.visible
    }, [w("div", by, [(g(!0), R(Be, null, qt(d(t), (o) => (g(), R("div", {
      key: `spinner-bar-${o}`,
      class: "sonner-loading-bar"
    }))), 128))])], 8, vy));
  }
}), wy = yy;
const xy = {}, _y = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 20 20",
  fill: "currentColor",
  height: "20",
  width: "20"
};
function ky(e, t) {
  return g(), R("svg", _y, t[0] || (t[0] = [w("path", {
    "fill-rule": "evenodd",
    d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z",
    "clip-rule": "evenodd"
  }, null, -1)]));
}
var Cy = /* @__PURE__ */ Io(xy, [["render", ky]]);
const Ay = {}, Sy = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 20 20",
  fill: "currentColor",
  height: "20",
  width: "20"
};
function Ey(e, t) {
  return g(), R("svg", Sy, t[0] || (t[0] = [w("path", {
    "fill-rule": "evenodd",
    d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z",
    "clip-rule": "evenodd"
  }, null, -1)]));
}
var $y = /* @__PURE__ */ Io(Ay, [["render", Ey]]);
const Py = {}, Ty = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24",
  fill: "currentColor",
  height: "20",
  width: "20"
};
function My(e, t) {
  return g(), R("svg", Ty, t[0] || (t[0] = [w("path", {
    "fill-rule": "evenodd",
    d: "M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z",
    "clip-rule": "evenodd"
  }, null, -1)]));
}
var Ry = /* @__PURE__ */ Io(Py, [["render", My]]);
const Oy = {}, By = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 20 20",
  fill: "currentColor",
  height: "20",
  width: "20"
};
function Dy(e, t) {
  return g(), R("svg", By, t[0] || (t[0] = [w("path", {
    "fill-rule": "evenodd",
    d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-5a.75.75 0 01.75.75v4.5a.75.75 0 01-1.5 0v-4.5A.75.75 0 0110 5zm0 10a1 1 0 100-2 1 1 0 000 2z",
    "clip-rule": "evenodd"
  }, null, -1)]));
}
var Iy = /* @__PURE__ */ Io(Oy, [["render", Dy]]);
const qy = ["aria-label"], Ly = [
  "data-sonner-theme",
  "dir",
  "data-theme",
  "data-rich-colors",
  "data-y-position",
  "data-x-position"
], Ny = typeof window < "u" && typeof document < "u";
function Vy() {
  if (typeof window > "u" || typeof document > "u") return "ltr";
  const e = document.documentElement.getAttribute("dir");
  return e === "auto" || !e ? window.getComputedStyle(document.documentElement).direction : e;
}
var Hy = /* @__PURE__ */ D({
  name: "Toaster",
  inheritAttrs: !1,
  __name: "Toaster",
  props: {
    id: {},
    invert: {
      type: Boolean,
      default: !1
    },
    theme: { default: "light" },
    position: { default: "bottom-right" },
    closeButtonPosition: { default: "top-left" },
    hotkey: { default: () => ["altKey", "KeyT"] },
    richColors: {
      type: Boolean,
      default: !1
    },
    expand: {
      type: Boolean,
      default: !1
    },
    duration: {},
    gap: { default: oy },
    visibleToasts: { default: ry },
    closeButton: {
      type: Boolean,
      default: !1
    },
    toastOptions: { default: () => ({}) },
    class: { default: "" },
    style: {},
    offset: { default: Wp },
    mobileOffset: { default: Gp },
    dir: { default: "auto" },
    swipeDirections: {},
    icons: {},
    containerAriaLabel: { default: "Notifications" }
  },
  setup(e) {
    const t = e, r = xg(), a = K([]), o = L(() => t.id ? a.value.filter(($) => $.toasterId === t.id) : a.value.filter(($) => !$.toasterId));
    function n($, V) {
      return o.value.filter((z) => !z.position && V === 0 || z.position === $);
    }
    const s = L(() => {
      const $ = o.value.filter((V) => V.position).map((V) => V.position);
      return $.length > 0 ? Array.from(new Set([t.position].concat($))) : [t.position];
    }), i = L(() => {
      const $ = {};
      return s.value.forEach((V) => {
        $[V] = a.value.filter((z) => z.position === V);
      }), $;
    }), l = K([]), c = K({}), u = K(!1);
    Xe(() => {
      s.value.forEach(($) => {
        $ in c.value || (c.value[$] = !1);
      });
    });
    const f = K(t.theme !== "system" ? t.theme : typeof window < "u" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"), p = K(null), h = K(null), m = K(!1), v = t.hotkey.join("+").replace(/Key/g, "").replace(/Digit/g, "");
    function x($) {
      a.value.find((V) => V.id === $.id)?.delete || xt.dismiss($.id), a.value = a.value.filter(({ id: V }) => V !== $.id), setTimeout(() => {
        a.value.find((V) => V.id === $.id) || (l.value = l.value.filter((V) => V.toastId !== $.id));
      }, Jp + 50);
    }
    function C($) {
      m.value && !$.currentTarget?.contains?.($.relatedTarget) && (m.value = !1, h.value && (h.value.focus({ preventScroll: !0 }), h.value = null));
    }
    function S($) {
      $.target instanceof HTMLElement && $.target.dataset.dismissible === "false" || m.value || (m.value = !0, h.value = $.relatedTarget);
    }
    function E($) {
      $.target && $.target instanceof HTMLElement && $.target.dataset.dismissible === "false" || (u.value = !0);
    }
    Xe(($) => {
      const V = xt.subscribe((z) => {
        if (z.dismiss) {
          requestAnimationFrame(() => {
            a.value = a.value.map((G) => G.id === z.id ? {
              ...G,
              delete: !0
            } : G);
          });
          return;
        }
        et(() => {
          const G = a.value.findIndex((ee) => ee.id === z.id);
          G !== -1 ? a.value = [
            ...a.value.slice(0, G),
            {
              ...a.value[G],
              ...z
            },
            ...a.value.slice(G + 1)
          ] : a.value = [z, ...a.value];
        });
      });
      $(V);
    }), Xe(($) => {
      if (typeof window > "u") return;
      if (t.theme !== "system") {
        f.value = t.theme;
        return;
      }
      const V = window.matchMedia("(prefers-color-scheme: dark)"), z = (ee) => {
        f.value = ee ? "dark" : "light";
      };
      z(V.matches);
      const G = (ee) => {
        z(ee.matches);
      };
      try {
        V.addEventListener("change", G);
      } catch {
        V.addListener(G);
      }
      $(() => {
        try {
          V.removeEventListener("change", G);
        } catch {
          V.removeListener(G);
        }
      });
    }), Xe(() => {
      p.value && h.value && (h.value.focus({ preventScroll: !0 }), h.value = null, m.value = !1);
    }), Xe(() => {
      a.value.length <= 1 && Object.keys(c.value).forEach(($) => {
        c.value[$] = !1;
      });
    }), Xe(($) => {
      function V(z) {
        const G = t.hotkey.every((de) => z[de] || z.code === de), ee = Array.isArray(p.value) ? p.value[0] : p.value;
        G && (s.value.forEach((de) => {
          c.value[de] = !0;
        }), ee?.focus());
        const xe = document.activeElement === p.value || ee?.contains(document.activeElement);
        z.code === "Escape" && xe && s.value.forEach((de) => {
          c.value[de] = !1;
        });
      }
      Ny && (document.addEventListener("keydown", V), $(() => {
        document.removeEventListener("keydown", V);
      }));
    });
    function T($) {
      const V = $.currentTarget, z = V.getAttribute("data-y-position") + "-" + V.getAttribute("data-x-position");
      c.value[z] = !0;
    }
    function F($) {
      if (!u.value) {
        const V = $.currentTarget, z = V.getAttribute("data-y-position") + "-" + V.getAttribute("data-x-position");
        c.value[z] = !1;
      }
    }
    function j() {
      Object.keys(c.value).forEach(($) => {
        c.value[$] = !1;
      });
    }
    function H() {
      u.value = !1;
    }
    function B($) {
      l.value = $;
    }
    function P($) {
      const V = l.value.findIndex((z) => z.toastId === $.toastId);
      if (V !== -1) l.value[V] = $;
      else {
        const z = l.value.findIndex((G) => G.position === $.position);
        z !== -1 ? l.value.splice(z, 0, $) : l.value.unshift($);
      }
    }
    return ($, V) => (g(), R(Be, null, [$e(" Remove item from normal navigation flow, only available via hotkey "), w("section", {
      "aria-label": `${$.containerAriaLabel} ${d(v)}`,
      tabIndex: -1,
      "aria-live": "polite",
      "aria-relevant": "additions text",
      "aria-atomic": "false"
    }, [(g(!0), R(Be, null, qt(s.value, (z, G) => (g(), R("ol", re({
      key: z,
      ref_for: !0,
      ref_key: "listRef",
      ref: p,
      "data-sonner-toaster": "",
      "data-sonner-theme": f.value,
      class: t.class,
      dir: $.dir === "auto" ? Vy() : $.dir,
      tabIndex: -1,
      "data-theme": $.theme,
      "data-rich-colors": $.richColors,
      "data-y-position": z.split("-")[0],
      "data-x-position": z.split("-")[1],
      style: {
        "--front-toast-height": `${l.value[0]?.height || 0}px`,
        "--width": `${d(ay)}px`,
        "--gap": `${$.gap}px`,
        ...$.style,
        ...d(r).style,
        ...d(ly)($.offset, $.mobileOffset)
      }
    }, { ref_for: !0 }, $.$attrs, {
      onBlur: C,
      onFocus: S,
      onMouseenter: T,
      onMousemove: T,
      onMouseleave: F,
      onDragend: j,
      onPointerdown: E,
      onPointerup: H
    }), [(g(!0), R(Be, null, qt(n(z, G), (ee, xe) => (g(), N(fy, {
      key: ee.id,
      heights: l.value,
      icons: $.icons,
      index: xe,
      toast: ee,
      defaultRichColors: $.richColors,
      duration: $.toastOptions?.duration ?? $.duration,
      class: ke($.toastOptions?.class ?? ""),
      descriptionClass: $.toastOptions?.descriptionClass,
      invert: $.invert,
      visibleToasts: $.visibleToasts,
      closeButton: $.toastOptions?.closeButton ?? $.closeButton,
      interacting: u.value,
      position: z,
      closeButtonPosition: $.toastOptions?.closeButtonPosition ?? $.closeButtonPosition,
      style: Tt($.toastOptions?.style),
      unstyled: $.toastOptions?.unstyled,
      classes: $.toastOptions?.classes,
      cancelButtonStyle: $.toastOptions?.cancelButtonStyle,
      actionButtonStyle: $.toastOptions?.actionButtonStyle,
      "close-button-aria-label": $.toastOptions?.closeButtonAriaLabel,
      toasts: i.value[z],
      expandByDefault: $.expand,
      gap: $.gap,
      expanded: c.value[z] || !1,
      swipeDirections: t.swipeDirections,
      "onUpdate:heights": B,
      "onUpdate:height": P,
      onRemoveToast: x
    }, {
      "close-icon": b(() => [q($.$slots, "close-icon", {}, () => [k(my)])]),
      "loading-icon": b(() => [q($.$slots, "loading-icon", {}, () => [k(wy, { visible: ee.type === "loading" }, null, 8, ["visible"])])]),
      "success-icon": b(() => [q($.$slots, "success-icon", {}, () => [k(Cy)])]),
      "error-icon": b(() => [q($.$slots, "error-icon", {}, () => [k(Iy)])]),
      "warning-icon": b(() => [q($.$slots, "warning-icon", {}, () => [k(Ry)])]),
      "info-icon": b(() => [q($.$slots, "info-icon", {}, () => [k($y)])]),
      _: 2
    }, 1032, [
      "heights",
      "icons",
      "index",
      "toast",
      "defaultRichColors",
      "duration",
      "class",
      "descriptionClass",
      "invert",
      "visibleToasts",
      "closeButton",
      "interacting",
      "position",
      "closeButtonPosition",
      "style",
      "unstyled",
      "classes",
      "cancelButtonStyle",
      "actionButtonStyle",
      "close-button-aria-label",
      "toasts",
      "expandByDefault",
      "gap",
      "expanded",
      "swipeDirections"
    ]))), 128))], 16, Ly))), 128))], 8, qy)], 2112));
  }
}), Fy = Hy;
function zy(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var ga = {}, Ps, xu;
function jy() {
  return xu || (xu = 1, Ps = function() {
    return typeof Promise == "function" && Promise.prototype && Promise.prototype.then;
  }), Ps;
}
var Ts = {}, Mr = {}, _u;
function ca() {
  if (_u) return Mr;
  _u = 1;
  let e;
  const t = [
    0,
    // Not used
    26,
    44,
    70,
    100,
    134,
    172,
    196,
    242,
    292,
    346,
    404,
    466,
    532,
    581,
    655,
    733,
    815,
    901,
    991,
    1085,
    1156,
    1258,
    1364,
    1474,
    1588,
    1706,
    1828,
    1921,
    2051,
    2185,
    2323,
    2465,
    2611,
    2761,
    2876,
    3034,
    3196,
    3362,
    3532,
    3706
  ];
  return Mr.getSymbolSize = function(a) {
    if (!a) throw new Error('"version" cannot be null or undefined');
    if (a < 1 || a > 40) throw new Error('"version" should be in range from 1 to 40');
    return a * 4 + 17;
  }, Mr.getSymbolTotalCodewords = function(a) {
    return t[a];
  }, Mr.getBCHDigit = function(r) {
    let a = 0;
    for (; r !== 0; )
      a++, r >>>= 1;
    return a;
  }, Mr.setToSJISFunction = function(a) {
    if (typeof a != "function")
      throw new Error('"toSJISFunc" is not a valid function.');
    e = a;
  }, Mr.isKanjiModeEnabled = function() {
    return typeof e < "u";
  }, Mr.toSJIS = function(a) {
    return e(a);
  }, Mr;
}
var Ms = {}, ku;
function Tl() {
  return ku || (ku = 1, function(e) {
    e.L = { bit: 1 }, e.M = { bit: 0 }, e.Q = { bit: 3 }, e.H = { bit: 2 };
    function t(r) {
      if (typeof r != "string")
        throw new Error("Param is not a string");
      switch (r.toLowerCase()) {
        case "l":
        case "low":
          return e.L;
        case "m":
        case "medium":
          return e.M;
        case "q":
        case "quartile":
          return e.Q;
        case "h":
        case "high":
          return e.H;
        default:
          throw new Error("Unknown EC Level: " + r);
      }
    }
    e.isValid = function(a) {
      return a && typeof a.bit < "u" && a.bit >= 0 && a.bit < 4;
    }, e.from = function(a, o) {
      if (e.isValid(a))
        return a;
      try {
        return t(a);
      } catch {
        return o;
      }
    };
  }(Ms)), Ms;
}
var Rs, Cu;
function Uy() {
  if (Cu) return Rs;
  Cu = 1;
  function e() {
    this.buffer = [], this.length = 0;
  }
  return e.prototype = {
    get: function(t) {
      const r = Math.floor(t / 8);
      return (this.buffer[r] >>> 7 - t % 8 & 1) === 1;
    },
    put: function(t, r) {
      for (let a = 0; a < r; a++)
        this.putBit((t >>> r - a - 1 & 1) === 1);
    },
    getLengthInBits: function() {
      return this.length;
    },
    putBit: function(t) {
      const r = Math.floor(this.length / 8);
      this.buffer.length <= r && this.buffer.push(0), t && (this.buffer[r] |= 128 >>> this.length % 8), this.length++;
    }
  }, Rs = e, Rs;
}
var Os, Au;
function Zy() {
  if (Au) return Os;
  Au = 1;
  function e(t) {
    if (!t || t < 1)
      throw new Error("BitMatrix size must be defined and greater than 0");
    this.size = t, this.data = new Uint8Array(t * t), this.reservedBit = new Uint8Array(t * t);
  }
  return e.prototype.set = function(t, r, a, o) {
    const n = t * this.size + r;
    this.data[n] = a, o && (this.reservedBit[n] = !0);
  }, e.prototype.get = function(t, r) {
    return this.data[t * this.size + r];
  }, e.prototype.xor = function(t, r, a) {
    this.data[t * this.size + r] ^= a;
  }, e.prototype.isReserved = function(t, r) {
    return this.reservedBit[t * this.size + r];
  }, Os = e, Os;
}
var Bs = {}, Su;
function Ky() {
  return Su || (Su = 1, function(e) {
    const t = ca().getSymbolSize;
    e.getRowColCoords = function(a) {
      if (a === 1) return [];
      const o = Math.floor(a / 7) + 2, n = t(a), s = n === 145 ? 26 : Math.ceil((n - 13) / (2 * o - 2)) * 2, i = [n - 7];
      for (let l = 1; l < o - 1; l++)
        i[l] = i[l - 1] - s;
      return i.push(6), i.reverse();
    }, e.getPositions = function(a) {
      const o = [], n = e.getRowColCoords(a), s = n.length;
      for (let i = 0; i < s; i++)
        for (let l = 0; l < s; l++)
          i === 0 && l === 0 || // top-left
          i === 0 && l === s - 1 || // bottom-left
          i === s - 1 && l === 0 || o.push([n[i], n[l]]);
      return o;
    };
  }(Bs)), Bs;
}
var Ds = {}, Eu;
function Wy() {
  if (Eu) return Ds;
  Eu = 1;
  const e = ca().getSymbolSize, t = 7;
  return Ds.getPositions = function(a) {
    const o = e(a);
    return [
      // top-left
      [0, 0],
      // top-right
      [o - t, 0],
      // bottom-left
      [0, o - t]
    ];
  }, Ds;
}
var Is = {}, $u;
function Gy() {
  return $u || ($u = 1, function(e) {
    e.Patterns = {
      PATTERN000: 0,
      PATTERN001: 1,
      PATTERN010: 2,
      PATTERN011: 3,
      PATTERN100: 4,
      PATTERN101: 5,
      PATTERN110: 6,
      PATTERN111: 7
    };
    const t = {
      N1: 3,
      N2: 3,
      N3: 40,
      N4: 10
    };
    e.isValid = function(o) {
      return o != null && o !== "" && !isNaN(o) && o >= 0 && o <= 7;
    }, e.from = function(o) {
      return e.isValid(o) ? parseInt(o, 10) : void 0;
    }, e.getPenaltyN1 = function(o) {
      const n = o.size;
      let s = 0, i = 0, l = 0, c = null, u = null;
      for (let f = 0; f < n; f++) {
        i = l = 0, c = u = null;
        for (let p = 0; p < n; p++) {
          let h = o.get(f, p);
          h === c ? i++ : (i >= 5 && (s += t.N1 + (i - 5)), c = h, i = 1), h = o.get(p, f), h === u ? l++ : (l >= 5 && (s += t.N1 + (l - 5)), u = h, l = 1);
        }
        i >= 5 && (s += t.N1 + (i - 5)), l >= 5 && (s += t.N1 + (l - 5));
      }
      return s;
    }, e.getPenaltyN2 = function(o) {
      const n = o.size;
      let s = 0;
      for (let i = 0; i < n - 1; i++)
        for (let l = 0; l < n - 1; l++) {
          const c = o.get(i, l) + o.get(i, l + 1) + o.get(i + 1, l) + o.get(i + 1, l + 1);
          (c === 4 || c === 0) && s++;
        }
      return s * t.N2;
    }, e.getPenaltyN3 = function(o) {
      const n = o.size;
      let s = 0, i = 0, l = 0;
      for (let c = 0; c < n; c++) {
        i = l = 0;
        for (let u = 0; u < n; u++)
          i = i << 1 & 2047 | o.get(c, u), u >= 10 && (i === 1488 || i === 93) && s++, l = l << 1 & 2047 | o.get(u, c), u >= 10 && (l === 1488 || l === 93) && s++;
      }
      return s * t.N3;
    }, e.getPenaltyN4 = function(o) {
      let n = 0;
      const s = o.data.length;
      for (let l = 0; l < s; l++) n += o.data[l];
      return Math.abs(Math.ceil(n * 100 / s / 5) - 10) * t.N4;
    };
    function r(a, o, n) {
      switch (a) {
        case e.Patterns.PATTERN000:
          return (o + n) % 2 === 0;
        case e.Patterns.PATTERN001:
          return o % 2 === 0;
        case e.Patterns.PATTERN010:
          return n % 3 === 0;
        case e.Patterns.PATTERN011:
          return (o + n) % 3 === 0;
        case e.Patterns.PATTERN100:
          return (Math.floor(o / 2) + Math.floor(n / 3)) % 2 === 0;
        case e.Patterns.PATTERN101:
          return o * n % 2 + o * n % 3 === 0;
        case e.Patterns.PATTERN110:
          return (o * n % 2 + o * n % 3) % 2 === 0;
        case e.Patterns.PATTERN111:
          return (o * n % 3 + (o + n) % 2) % 2 === 0;
        default:
          throw new Error("bad maskPattern:" + a);
      }
    }
    e.applyMask = function(o, n) {
      const s = n.size;
      for (let i = 0; i < s; i++)
        for (let l = 0; l < s; l++)
          n.isReserved(l, i) || n.xor(l, i, r(o, l, i));
    }, e.getBestMask = function(o, n) {
      const s = Object.keys(e.Patterns).length;
      let i = 0, l = 1 / 0;
      for (let c = 0; c < s; c++) {
        n(c), e.applyMask(c, o);
        const u = e.getPenaltyN1(o) + e.getPenaltyN2(o) + e.getPenaltyN3(o) + e.getPenaltyN4(o);
        e.applyMask(c, o), u < l && (l = u, i = c);
      }
      return i;
    };
  }(Is)), Is;
}
var Zo = {}, Pu;
function Yp() {
  if (Pu) return Zo;
  Pu = 1;
  const e = Tl(), t = [
    // L  M  Q  H
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    2,
    1,
    2,
    2,
    4,
    1,
    2,
    4,
    4,
    2,
    4,
    4,
    4,
    2,
    4,
    6,
    5,
    2,
    4,
    6,
    6,
    2,
    5,
    8,
    8,
    4,
    5,
    8,
    8,
    4,
    5,
    8,
    11,
    4,
    8,
    10,
    11,
    4,
    9,
    12,
    16,
    4,
    9,
    16,
    16,
    6,
    10,
    12,
    18,
    6,
    10,
    17,
    16,
    6,
    11,
    16,
    19,
    6,
    13,
    18,
    21,
    7,
    14,
    21,
    25,
    8,
    16,
    20,
    25,
    8,
    17,
    23,
    25,
    9,
    17,
    23,
    34,
    9,
    18,
    25,
    30,
    10,
    20,
    27,
    32,
    12,
    21,
    29,
    35,
    12,
    23,
    34,
    37,
    12,
    25,
    34,
    40,
    13,
    26,
    35,
    42,
    14,
    28,
    38,
    45,
    15,
    29,
    40,
    48,
    16,
    31,
    43,
    51,
    17,
    33,
    45,
    54,
    18,
    35,
    48,
    57,
    19,
    37,
    51,
    60,
    19,
    38,
    53,
    63,
    20,
    40,
    56,
    66,
    21,
    43,
    59,
    70,
    22,
    45,
    62,
    74,
    24,
    47,
    65,
    77,
    25,
    49,
    68,
    81
  ], r = [
    // L  M  Q  H
    7,
    10,
    13,
    17,
    10,
    16,
    22,
    28,
    15,
    26,
    36,
    44,
    20,
    36,
    52,
    64,
    26,
    48,
    72,
    88,
    36,
    64,
    96,
    112,
    40,
    72,
    108,
    130,
    48,
    88,
    132,
    156,
    60,
    110,
    160,
    192,
    72,
    130,
    192,
    224,
    80,
    150,
    224,
    264,
    96,
    176,
    260,
    308,
    104,
    198,
    288,
    352,
    120,
    216,
    320,
    384,
    132,
    240,
    360,
    432,
    144,
    280,
    408,
    480,
    168,
    308,
    448,
    532,
    180,
    338,
    504,
    588,
    196,
    364,
    546,
    650,
    224,
    416,
    600,
    700,
    224,
    442,
    644,
    750,
    252,
    476,
    690,
    816,
    270,
    504,
    750,
    900,
    300,
    560,
    810,
    960,
    312,
    588,
    870,
    1050,
    336,
    644,
    952,
    1110,
    360,
    700,
    1020,
    1200,
    390,
    728,
    1050,
    1260,
    420,
    784,
    1140,
    1350,
    450,
    812,
    1200,
    1440,
    480,
    868,
    1290,
    1530,
    510,
    924,
    1350,
    1620,
    540,
    980,
    1440,
    1710,
    570,
    1036,
    1530,
    1800,
    570,
    1064,
    1590,
    1890,
    600,
    1120,
    1680,
    1980,
    630,
    1204,
    1770,
    2100,
    660,
    1260,
    1860,
    2220,
    720,
    1316,
    1950,
    2310,
    750,
    1372,
    2040,
    2430
  ];
  return Zo.getBlocksCount = function(o, n) {
    switch (n) {
      case e.L:
        return t[(o - 1) * 4 + 0];
      case e.M:
        return t[(o - 1) * 4 + 1];
      case e.Q:
        return t[(o - 1) * 4 + 2];
      case e.H:
        return t[(o - 1) * 4 + 3];
      default:
        return;
    }
  }, Zo.getTotalCodewordsCount = function(o, n) {
    switch (n) {
      case e.L:
        return r[(o - 1) * 4 + 0];
      case e.M:
        return r[(o - 1) * 4 + 1];
      case e.Q:
        return r[(o - 1) * 4 + 2];
      case e.H:
        return r[(o - 1) * 4 + 3];
      default:
        return;
    }
  }, Zo;
}
var qs = {}, Ga = {}, Tu;
function Jy() {
  if (Tu) return Ga;
  Tu = 1;
  const e = new Uint8Array(512), t = new Uint8Array(256);
  return function() {
    let a = 1;
    for (let o = 0; o < 255; o++)
      e[o] = a, t[a] = o, a <<= 1, a & 256 && (a ^= 285);
    for (let o = 255; o < 512; o++)
      e[o] = e[o - 255];
  }(), Ga.log = function(a) {
    if (a < 1) throw new Error("log(" + a + ")");
    return t[a];
  }, Ga.exp = function(a) {
    return e[a];
  }, Ga.mul = function(a, o) {
    return a === 0 || o === 0 ? 0 : e[t[a] + t[o]];
  }, Ga;
}
var Mu;
function Yy() {
  return Mu || (Mu = 1, function(e) {
    const t = Jy();
    e.mul = function(a, o) {
      const n = new Uint8Array(a.length + o.length - 1);
      for (let s = 0; s < a.length; s++)
        for (let i = 0; i < o.length; i++)
          n[s + i] ^= t.mul(a[s], o[i]);
      return n;
    }, e.mod = function(a, o) {
      let n = new Uint8Array(a);
      for (; n.length - o.length >= 0; ) {
        const s = n[0];
        for (let l = 0; l < o.length; l++)
          n[l] ^= t.mul(o[l], s);
        let i = 0;
        for (; i < n.length && n[i] === 0; ) i++;
        n = n.slice(i);
      }
      return n;
    }, e.generateECPolynomial = function(a) {
      let o = new Uint8Array([1]);
      for (let n = 0; n < a; n++)
        o = e.mul(o, new Uint8Array([1, t.exp(n)]));
      return o;
    };
  }(qs)), qs;
}
var Ls, Ru;
function Xy() {
  if (Ru) return Ls;
  Ru = 1;
  const e = Yy();
  function t(r) {
    this.genPoly = void 0, this.degree = r, this.degree && this.initialize(this.degree);
  }
  return t.prototype.initialize = function(a) {
    this.degree = a, this.genPoly = e.generateECPolynomial(this.degree);
  }, t.prototype.encode = function(a) {
    if (!this.genPoly)
      throw new Error("Encoder not initialized");
    const o = new Uint8Array(a.length + this.degree);
    o.set(a);
    const n = e.mod(o, this.genPoly), s = this.degree - n.length;
    if (s > 0) {
      const i = new Uint8Array(this.degree);
      return i.set(n, s), i;
    }
    return n;
  }, Ls = t, Ls;
}
var Ns = {}, Vs = {}, Hs = {}, Ou;
function Xp() {
  return Ou || (Ou = 1, Hs.isValid = function(t) {
    return !isNaN(t) && t >= 1 && t <= 40;
  }), Hs;
}
var Gt = {}, Bu;
function Qp() {
  if (Bu) return Gt;
  Bu = 1;
  const e = "[0-9]+", t = "[A-Z $%*+\\-./:]+";
  let r = "(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";
  r = r.replace(/u/g, "\\u");
  const a = "(?:(?![A-Z0-9 $%*+\\-./:]|" + r + `)(?:.|[\r
]))+`;
  Gt.KANJI = new RegExp(r, "g"), Gt.BYTE_KANJI = new RegExp("[^A-Z0-9 $%*+\\-./:]+", "g"), Gt.BYTE = new RegExp(a, "g"), Gt.NUMERIC = new RegExp(e, "g"), Gt.ALPHANUMERIC = new RegExp(t, "g");
  const o = new RegExp("^" + r + "$"), n = new RegExp("^" + e + "$"), s = new RegExp("^[A-Z0-9 $%*+\\-./:]+$");
  return Gt.testKanji = function(l) {
    return o.test(l);
  }, Gt.testNumeric = function(l) {
    return n.test(l);
  }, Gt.testAlphanumeric = function(l) {
    return s.test(l);
  }, Gt;
}
var Du;
function ua() {
  return Du || (Du = 1, function(e) {
    const t = Xp(), r = Qp();
    e.NUMERIC = {
      id: "Numeric",
      bit: 1,
      ccBits: [10, 12, 14]
    }, e.ALPHANUMERIC = {
      id: "Alphanumeric",
      bit: 2,
      ccBits: [9, 11, 13]
    }, e.BYTE = {
      id: "Byte",
      bit: 4,
      ccBits: [8, 16, 16]
    }, e.KANJI = {
      id: "Kanji",
      bit: 8,
      ccBits: [8, 10, 12]
    }, e.MIXED = {
      bit: -1
    }, e.getCharCountIndicator = function(n, s) {
      if (!n.ccBits) throw new Error("Invalid mode: " + n);
      if (!t.isValid(s))
        throw new Error("Invalid version: " + s);
      return s >= 1 && s < 10 ? n.ccBits[0] : s < 27 ? n.ccBits[1] : n.ccBits[2];
    }, e.getBestModeForData = function(n) {
      return r.testNumeric(n) ? e.NUMERIC : r.testAlphanumeric(n) ? e.ALPHANUMERIC : r.testKanji(n) ? e.KANJI : e.BYTE;
    }, e.toString = function(n) {
      if (n && n.id) return n.id;
      throw new Error("Invalid mode");
    }, e.isValid = function(n) {
      return n && n.bit && n.ccBits;
    };
    function a(o) {
      if (typeof o != "string")
        throw new Error("Param is not a string");
      switch (o.toLowerCase()) {
        case "numeric":
          return e.NUMERIC;
        case "alphanumeric":
          return e.ALPHANUMERIC;
        case "kanji":
          return e.KANJI;
        case "byte":
          return e.BYTE;
        default:
          throw new Error("Unknown mode: " + o);
      }
    }
    e.from = function(n, s) {
      if (e.isValid(n))
        return n;
      try {
        return a(n);
      } catch {
        return s;
      }
    };
  }(Vs)), Vs;
}
var Iu;
function Qy() {
  return Iu || (Iu = 1, function(e) {
    const t = ca(), r = Yp(), a = Tl(), o = ua(), n = Xp(), s = 7973, i = t.getBCHDigit(s);
    function l(p, h, m) {
      for (let v = 1; v <= 40; v++)
        if (h <= e.getCapacity(v, m, p))
          return v;
    }
    function c(p, h) {
      return o.getCharCountIndicator(p, h) + 4;
    }
    function u(p, h) {
      let m = 0;
      return p.forEach(function(v) {
        const x = c(v.mode, h);
        m += x + v.getBitsLength();
      }), m;
    }
    function f(p, h) {
      for (let m = 1; m <= 40; m++)
        if (u(p, m) <= e.getCapacity(m, h, o.MIXED))
          return m;
    }
    e.from = function(h, m) {
      return n.isValid(h) ? parseInt(h, 10) : m;
    }, e.getCapacity = function(h, m, v) {
      if (!n.isValid(h))
        throw new Error("Invalid QR Code version");
      typeof v > "u" && (v = o.BYTE);
      const x = t.getSymbolTotalCodewords(h), C = r.getTotalCodewordsCount(h, m), S = (x - C) * 8;
      if (v === o.MIXED) return S;
      const E = S - c(v, h);
      switch (v) {
        case o.NUMERIC:
          return Math.floor(E / 10 * 3);
        case o.ALPHANUMERIC:
          return Math.floor(E / 11 * 2);
        case o.KANJI:
          return Math.floor(E / 13);
        case o.BYTE:
        default:
          return Math.floor(E / 8);
      }
    }, e.getBestVersionForData = function(h, m) {
      let v;
      const x = a.from(m, a.M);
      if (Array.isArray(h)) {
        if (h.length > 1)
          return f(h, x);
        if (h.length === 0)
          return 1;
        v = h[0];
      } else
        v = h;
      return l(v.mode, v.getLength(), x);
    }, e.getEncodedBits = function(h) {
      if (!n.isValid(h) || h < 7)
        throw new Error("Invalid QR Code version");
      let m = h << 12;
      for (; t.getBCHDigit(m) - i >= 0; )
        m ^= s << t.getBCHDigit(m) - i;
      return h << 12 | m;
    };
  }(Ns)), Ns;
}
var Fs = {}, qu;
function ew() {
  if (qu) return Fs;
  qu = 1;
  const e = ca(), t = 1335, r = 21522, a = e.getBCHDigit(t);
  return Fs.getEncodedBits = function(n, s) {
    const i = n.bit << 3 | s;
    let l = i << 10;
    for (; e.getBCHDigit(l) - a >= 0; )
      l ^= t << e.getBCHDigit(l) - a;
    return (i << 10 | l) ^ r;
  }, Fs;
}
var zs = {}, js, Lu;
function tw() {
  if (Lu) return js;
  Lu = 1;
  const e = ua();
  function t(r) {
    this.mode = e.NUMERIC, this.data = r.toString();
  }
  return t.getBitsLength = function(a) {
    return 10 * Math.floor(a / 3) + (a % 3 ? a % 3 * 3 + 1 : 0);
  }, t.prototype.getLength = function() {
    return this.data.length;
  }, t.prototype.getBitsLength = function() {
    return t.getBitsLength(this.data.length);
  }, t.prototype.write = function(a) {
    let o, n, s;
    for (o = 0; o + 3 <= this.data.length; o += 3)
      n = this.data.substr(o, 3), s = parseInt(n, 10), a.put(s, 10);
    const i = this.data.length - o;
    i > 0 && (n = this.data.substr(o), s = parseInt(n, 10), a.put(s, i * 3 + 1));
  }, js = t, js;
}
var Us, Nu;
function rw() {
  if (Nu) return Us;
  Nu = 1;
  const e = ua(), t = [
    "0",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
    " ",
    "$",
    "%",
    "*",
    "+",
    "-",
    ".",
    "/",
    ":"
  ];
  function r(a) {
    this.mode = e.ALPHANUMERIC, this.data = a;
  }
  return r.getBitsLength = function(o) {
    return 11 * Math.floor(o / 2) + 6 * (o % 2);
  }, r.prototype.getLength = function() {
    return this.data.length;
  }, r.prototype.getBitsLength = function() {
    return r.getBitsLength(this.data.length);
  }, r.prototype.write = function(o) {
    let n;
    for (n = 0; n + 2 <= this.data.length; n += 2) {
      let s = t.indexOf(this.data[n]) * 45;
      s += t.indexOf(this.data[n + 1]), o.put(s, 11);
    }
    this.data.length % 2 && o.put(t.indexOf(this.data[n]), 6);
  }, Us = r, Us;
}
var Zs, Vu;
function aw() {
  if (Vu) return Zs;
  Vu = 1;
  const e = ua();
  function t(r) {
    this.mode = e.BYTE, typeof r == "string" ? this.data = new TextEncoder().encode(r) : this.data = new Uint8Array(r);
  }
  return t.getBitsLength = function(a) {
    return a * 8;
  }, t.prototype.getLength = function() {
    return this.data.length;
  }, t.prototype.getBitsLength = function() {
    return t.getBitsLength(this.data.length);
  }, t.prototype.write = function(r) {
    for (let a = 0, o = this.data.length; a < o; a++)
      r.put(this.data[a], 8);
  }, Zs = t, Zs;
}
var Ks, Hu;
function ow() {
  if (Hu) return Ks;
  Hu = 1;
  const e = ua(), t = ca();
  function r(a) {
    this.mode = e.KANJI, this.data = a;
  }
  return r.getBitsLength = function(o) {
    return o * 13;
  }, r.prototype.getLength = function() {
    return this.data.length;
  }, r.prototype.getBitsLength = function() {
    return r.getBitsLength(this.data.length);
  }, r.prototype.write = function(a) {
    let o;
    for (o = 0; o < this.data.length; o++) {
      let n = t.toSJIS(this.data[o]);
      if (n >= 33088 && n <= 40956)
        n -= 33088;
      else if (n >= 57408 && n <= 60351)
        n -= 49472;
      else
        throw new Error(
          "Invalid SJIS character: " + this.data[o] + `
Make sure your charset is UTF-8`
        );
      n = (n >>> 8 & 255) * 192 + (n & 255), a.put(n, 13);
    }
  }, Ks = r, Ks;
}
var Ws = { exports: {} }, Fu;
function nw() {
  return Fu || (Fu = 1, function(e) {
    var t = {
      single_source_shortest_paths: function(r, a, o) {
        var n = {}, s = {};
        s[a] = 0;
        var i = t.PriorityQueue.make();
        i.push(a, 0);
        for (var l, c, u, f, p, h, m, v, x; !i.empty(); ) {
          l = i.pop(), c = l.value, f = l.cost, p = r[c] || {};
          for (u in p)
            p.hasOwnProperty(u) && (h = p[u], m = f + h, v = s[u], x = typeof s[u] > "u", (x || v > m) && (s[u] = m, i.push(u, m), n[u] = c));
        }
        if (typeof o < "u" && typeof s[o] > "u") {
          var C = ["Could not find a path from ", a, " to ", o, "."].join("");
          throw new Error(C);
        }
        return n;
      },
      extract_shortest_path_from_predecessor_list: function(r, a) {
        for (var o = [], n = a; n; )
          o.push(n), r[n], n = r[n];
        return o.reverse(), o;
      },
      find_path: function(r, a, o) {
        var n = t.single_source_shortest_paths(r, a, o);
        return t.extract_shortest_path_from_predecessor_list(
          n,
          o
        );
      },
      /**
       * A very naive priority queue implementation.
       */
      PriorityQueue: {
        make: function(r) {
          var a = t.PriorityQueue, o = {}, n;
          r = r || {};
          for (n in a)
            a.hasOwnProperty(n) && (o[n] = a[n]);
          return o.queue = [], o.sorter = r.sorter || a.default_sorter, o;
        },
        default_sorter: function(r, a) {
          return r.cost - a.cost;
        },
        /**
         * Add a new item to the queue and ensure the highest priority element
         * is at the front of the queue.
         */
        push: function(r, a) {
          var o = { value: r, cost: a };
          this.queue.push(o), this.queue.sort(this.sorter);
        },
        /**
         * Return the highest priority element in the queue.
         */
        pop: function() {
          return this.queue.shift();
        },
        empty: function() {
          return this.queue.length === 0;
        }
      }
    };
    e.exports = t;
  }(Ws)), Ws.exports;
}
var zu;
function sw() {
  return zu || (zu = 1, function(e) {
    const t = ua(), r = tw(), a = rw(), o = aw(), n = ow(), s = Qp(), i = ca(), l = nw();
    function c(C) {
      return unescape(encodeURIComponent(C)).length;
    }
    function u(C, S, E) {
      const T = [];
      let F;
      for (; (F = C.exec(E)) !== null; )
        T.push({
          data: F[0],
          index: F.index,
          mode: S,
          length: F[0].length
        });
      return T;
    }
    function f(C) {
      const S = u(s.NUMERIC, t.NUMERIC, C), E = u(s.ALPHANUMERIC, t.ALPHANUMERIC, C);
      let T, F;
      return i.isKanjiModeEnabled() ? (T = u(s.BYTE, t.BYTE, C), F = u(s.KANJI, t.KANJI, C)) : (T = u(s.BYTE_KANJI, t.BYTE, C), F = []), S.concat(E, T, F).sort(function(H, B) {
        return H.index - B.index;
      }).map(function(H) {
        return {
          data: H.data,
          mode: H.mode,
          length: H.length
        };
      });
    }
    function p(C, S) {
      switch (S) {
        case t.NUMERIC:
          return r.getBitsLength(C);
        case t.ALPHANUMERIC:
          return a.getBitsLength(C);
        case t.KANJI:
          return n.getBitsLength(C);
        case t.BYTE:
          return o.getBitsLength(C);
      }
    }
    function h(C) {
      return C.reduce(function(S, E) {
        const T = S.length - 1 >= 0 ? S[S.length - 1] : null;
        return T && T.mode === E.mode ? (S[S.length - 1].data += E.data, S) : (S.push(E), S);
      }, []);
    }
    function m(C) {
      const S = [];
      for (let E = 0; E < C.length; E++) {
        const T = C[E];
        switch (T.mode) {
          case t.NUMERIC:
            S.push([
              T,
              { data: T.data, mode: t.ALPHANUMERIC, length: T.length },
              { data: T.data, mode: t.BYTE, length: T.length }
            ]);
            break;
          case t.ALPHANUMERIC:
            S.push([
              T,
              { data: T.data, mode: t.BYTE, length: T.length }
            ]);
            break;
          case t.KANJI:
            S.push([
              T,
              { data: T.data, mode: t.BYTE, length: c(T.data) }
            ]);
            break;
          case t.BYTE:
            S.push([
              { data: T.data, mode: t.BYTE, length: c(T.data) }
            ]);
        }
      }
      return S;
    }
    function v(C, S) {
      const E = {}, T = { start: {} };
      let F = ["start"];
      for (let j = 0; j < C.length; j++) {
        const H = C[j], B = [];
        for (let P = 0; P < H.length; P++) {
          const $ = H[P], V = "" + j + P;
          B.push(V), E[V] = { node: $, lastCount: 0 }, T[V] = {};
          for (let z = 0; z < F.length; z++) {
            const G = F[z];
            E[G] && E[G].node.mode === $.mode ? (T[G][V] = p(E[G].lastCount + $.length, $.mode) - p(E[G].lastCount, $.mode), E[G].lastCount += $.length) : (E[G] && (E[G].lastCount = $.length), T[G][V] = p($.length, $.mode) + 4 + t.getCharCountIndicator($.mode, S));
          }
        }
        F = B;
      }
      for (let j = 0; j < F.length; j++)
        T[F[j]].end = 0;
      return { map: T, table: E };
    }
    function x(C, S) {
      let E;
      const T = t.getBestModeForData(C);
      if (E = t.from(S, T), E !== t.BYTE && E.bit < T.bit)
        throw new Error('"' + C + '" cannot be encoded with mode ' + t.toString(E) + `.
 Suggested mode is: ` + t.toString(T));
      switch (E === t.KANJI && !i.isKanjiModeEnabled() && (E = t.BYTE), E) {
        case t.NUMERIC:
          return new r(C);
        case t.ALPHANUMERIC:
          return new a(C);
        case t.KANJI:
          return new n(C);
        case t.BYTE:
          return new o(C);
      }
    }
    e.fromArray = function(S) {
      return S.reduce(function(E, T) {
        return typeof T == "string" ? E.push(x(T, null)) : T.data && E.push(x(T.data, T.mode)), E;
      }, []);
    }, e.fromString = function(S, E) {
      const T = f(S, i.isKanjiModeEnabled()), F = m(T), j = v(F, E), H = l.find_path(j.map, "start", "end"), B = [];
      for (let P = 1; P < H.length - 1; P++)
        B.push(j.table[H[P]].node);
      return e.fromArray(h(B));
    }, e.rawSplit = function(S) {
      return e.fromArray(
        f(S, i.isKanjiModeEnabled())
      );
    };
  }(zs)), zs;
}
var ju;
function iw() {
  if (ju) return Ts;
  ju = 1;
  const e = ca(), t = Tl(), r = Uy(), a = Zy(), o = Ky(), n = Wy(), s = Gy(), i = Yp(), l = Xy(), c = Qy(), u = ew(), f = ua(), p = sw();
  function h(j, H) {
    const B = j.size, P = n.getPositions(H);
    for (let $ = 0; $ < P.length; $++) {
      const V = P[$][0], z = P[$][1];
      for (let G = -1; G <= 7; G++)
        if (!(V + G <= -1 || B <= V + G))
          for (let ee = -1; ee <= 7; ee++)
            z + ee <= -1 || B <= z + ee || (G >= 0 && G <= 6 && (ee === 0 || ee === 6) || ee >= 0 && ee <= 6 && (G === 0 || G === 6) || G >= 2 && G <= 4 && ee >= 2 && ee <= 4 ? j.set(V + G, z + ee, !0, !0) : j.set(V + G, z + ee, !1, !0));
    }
  }
  function m(j) {
    const H = j.size;
    for (let B = 8; B < H - 8; B++) {
      const P = B % 2 === 0;
      j.set(B, 6, P, !0), j.set(6, B, P, !0);
    }
  }
  function v(j, H) {
    const B = o.getPositions(H);
    for (let P = 0; P < B.length; P++) {
      const $ = B[P][0], V = B[P][1];
      for (let z = -2; z <= 2; z++)
        for (let G = -2; G <= 2; G++)
          z === -2 || z === 2 || G === -2 || G === 2 || z === 0 && G === 0 ? j.set($ + z, V + G, !0, !0) : j.set($ + z, V + G, !1, !0);
    }
  }
  function x(j, H) {
    const B = j.size, P = c.getEncodedBits(H);
    let $, V, z;
    for (let G = 0; G < 18; G++)
      $ = Math.floor(G / 3), V = G % 3 + B - 8 - 3, z = (P >> G & 1) === 1, j.set($, V, z, !0), j.set(V, $, z, !0);
  }
  function C(j, H, B) {
    const P = j.size, $ = u.getEncodedBits(H, B);
    let V, z;
    for (V = 0; V < 15; V++)
      z = ($ >> V & 1) === 1, V < 6 ? j.set(V, 8, z, !0) : V < 8 ? j.set(V + 1, 8, z, !0) : j.set(P - 15 + V, 8, z, !0), V < 8 ? j.set(8, P - V - 1, z, !0) : V < 9 ? j.set(8, 15 - V - 1 + 1, z, !0) : j.set(8, 15 - V - 1, z, !0);
    j.set(P - 8, 8, 1, !0);
  }
  function S(j, H) {
    const B = j.size;
    let P = -1, $ = B - 1, V = 7, z = 0;
    for (let G = B - 1; G > 0; G -= 2)
      for (G === 6 && G--; ; ) {
        for (let ee = 0; ee < 2; ee++)
          if (!j.isReserved($, G - ee)) {
            let xe = !1;
            z < H.length && (xe = (H[z] >>> V & 1) === 1), j.set($, G - ee, xe), V--, V === -1 && (z++, V = 7);
          }
        if ($ += P, $ < 0 || B <= $) {
          $ -= P, P = -P;
          break;
        }
      }
  }
  function E(j, H, B) {
    const P = new r();
    B.forEach(function(ee) {
      P.put(ee.mode.bit, 4), P.put(ee.getLength(), f.getCharCountIndicator(ee.mode, j)), ee.write(P);
    });
    const $ = e.getSymbolTotalCodewords(j), V = i.getTotalCodewordsCount(j, H), z = ($ - V) * 8;
    for (P.getLengthInBits() + 4 <= z && P.put(0, 4); P.getLengthInBits() % 8 !== 0; )
      P.putBit(0);
    const G = (z - P.getLengthInBits()) / 8;
    for (let ee = 0; ee < G; ee++)
      P.put(ee % 2 ? 17 : 236, 8);
    return T(P, j, H);
  }
  function T(j, H, B) {
    const P = e.getSymbolTotalCodewords(H), $ = i.getTotalCodewordsCount(H, B), V = P - $, z = i.getBlocksCount(H, B), G = P % z, ee = z - G, xe = Math.floor(P / z), de = Math.floor(V / z), W = de + 1, M = xe - de, ge = new l(M);
    let Me = 0;
    const Ie = new Array(z), ze = new Array(z);
    let ae = 0;
    const O = new Uint8Array(j.buffer);
    for (let Z = 0; Z < z; Z++) {
      const te = Z < ee ? de : W;
      Ie[Z] = O.slice(Me, Me + te), ze[Z] = ge.encode(Ie[Z]), Me += te, ae = Math.max(ae, te);
    }
    const Ae = new Uint8Array(P);
    let _e = 0, y, Q;
    for (y = 0; y < ae; y++)
      for (Q = 0; Q < z; Q++)
        y < Ie[Q].length && (Ae[_e++] = Ie[Q][y]);
    for (y = 0; y < M; y++)
      for (Q = 0; Q < z; Q++)
        Ae[_e++] = ze[Q][y];
    return Ae;
  }
  function F(j, H, B, P) {
    let $;
    if (Array.isArray(j))
      $ = p.fromArray(j);
    else if (typeof j == "string") {
      let xe = H;
      if (!xe) {
        const de = p.rawSplit(j);
        xe = c.getBestVersionForData(de, B);
      }
      $ = p.fromString(j, xe || 40);
    } else
      throw new Error("Invalid data");
    const V = c.getBestVersionForData($, B);
    if (!V)
      throw new Error("The amount of data is too big to be stored in a QR Code");
    if (!H)
      H = V;
    else if (H < V)
      throw new Error(
        `
The chosen QR Code version cannot contain this amount of data.
Minimum version required to store current data is: ` + V + `.
`
      );
    const z = E(H, B, $), G = e.getSymbolSize(H), ee = new a(G);
    return h(ee, H), m(ee), v(ee, H), C(ee, B, 0), H >= 7 && x(ee, H), S(ee, z), isNaN(P) && (P = s.getBestMask(
      ee,
      C.bind(null, ee, B)
    )), s.applyMask(P, ee), C(ee, B, P), {
      modules: ee,
      version: H,
      errorCorrectionLevel: B,
      maskPattern: P,
      segments: $
    };
  }
  return Ts.create = function(H, B) {
    if (typeof H > "u" || H === "")
      throw new Error("No input text");
    let P = t.M, $, V;
    return typeof B < "u" && (P = t.from(B.errorCorrectionLevel, t.M), $ = c.from(B.version), V = s.from(B.maskPattern), B.toSJISFunc && e.setToSJISFunction(B.toSJISFunc)), F(H, $, P, V);
  }, Ts;
}
var Gs = {}, Js = {}, Uu;
function e0() {
  return Uu || (Uu = 1, function(e) {
    function t(r) {
      if (typeof r == "number" && (r = r.toString()), typeof r != "string")
        throw new Error("Color should be defined as hex string");
      let a = r.slice().replace("#", "").split("");
      if (a.length < 3 || a.length === 5 || a.length > 8)
        throw new Error("Invalid hex color: " + r);
      (a.length === 3 || a.length === 4) && (a = Array.prototype.concat.apply([], a.map(function(n) {
        return [n, n];
      }))), a.length === 6 && a.push("F", "F");
      const o = parseInt(a.join(""), 16);
      return {
        r: o >> 24 & 255,
        g: o >> 16 & 255,
        b: o >> 8 & 255,
        a: o & 255,
        hex: "#" + a.slice(0, 6).join("")
      };
    }
    e.getOptions = function(a) {
      a || (a = {}), a.color || (a.color = {});
      const o = typeof a.margin > "u" || a.margin === null || a.margin < 0 ? 4 : a.margin, n = a.width && a.width >= 21 ? a.width : void 0, s = a.scale || 4;
      return {
        width: n,
        scale: n ? 4 : s,
        margin: o,
        color: {
          dark: t(a.color.dark || "#000000ff"),
          light: t(a.color.light || "#ffffffff")
        },
        type: a.type,
        rendererOpts: a.rendererOpts || {}
      };
    }, e.getScale = function(a, o) {
      return o.width && o.width >= a + o.margin * 2 ? o.width / (a + o.margin * 2) : o.scale;
    }, e.getImageWidth = function(a, o) {
      const n = e.getScale(a, o);
      return Math.floor((a + o.margin * 2) * n);
    }, e.qrToImageData = function(a, o, n) {
      const s = o.modules.size, i = o.modules.data, l = e.getScale(s, n), c = Math.floor((s + n.margin * 2) * l), u = n.margin * l, f = [n.color.light, n.color.dark];
      for (let p = 0; p < c; p++)
        for (let h = 0; h < c; h++) {
          let m = (p * c + h) * 4, v = n.color.light;
          if (p >= u && h >= u && p < c - u && h < c - u) {
            const x = Math.floor((p - u) / l), C = Math.floor((h - u) / l);
            v = f[i[x * s + C] ? 1 : 0];
          }
          a[m++] = v.r, a[m++] = v.g, a[m++] = v.b, a[m] = v.a;
        }
    };
  }(Js)), Js;
}
var Zu;
function lw() {
  return Zu || (Zu = 1, function(e) {
    const t = e0();
    function r(o, n, s) {
      o.clearRect(0, 0, n.width, n.height), n.style || (n.style = {}), n.height = s, n.width = s, n.style.height = s + "px", n.style.width = s + "px";
    }
    function a() {
      try {
        return document.createElement("canvas");
      } catch {
        throw new Error("You need to specify a canvas element");
      }
    }
    e.render = function(n, s, i) {
      let l = i, c = s;
      typeof l > "u" && (!s || !s.getContext) && (l = s, s = void 0), s || (c = a()), l = t.getOptions(l);
      const u = t.getImageWidth(n.modules.size, l), f = c.getContext("2d"), p = f.createImageData(u, u);
      return t.qrToImageData(p.data, n, l), r(f, c, u), f.putImageData(p, 0, 0), c;
    }, e.renderToDataURL = function(n, s, i) {
      let l = i;
      typeof l > "u" && (!s || !s.getContext) && (l = s, s = void 0), l || (l = {});
      const c = e.render(n, s, l), u = l.type || "image/png", f = l.rendererOpts || {};
      return c.toDataURL(u, f.quality);
    };
  }(Gs)), Gs;
}
var Ys = {}, Ku;
function cw() {
  if (Ku) return Ys;
  Ku = 1;
  const e = e0();
  function t(o, n) {
    const s = o.a / 255, i = n + '="' + o.hex + '"';
    return s < 1 ? i + " " + n + '-opacity="' + s.toFixed(2).slice(1) + '"' : i;
  }
  function r(o, n, s) {
    let i = o + n;
    return typeof s < "u" && (i += " " + s), i;
  }
  function a(o, n, s) {
    let i = "", l = 0, c = !1, u = 0;
    for (let f = 0; f < o.length; f++) {
      const p = Math.floor(f % n), h = Math.floor(f / n);
      !p && !c && (c = !0), o[f] ? (u++, f > 0 && p > 0 && o[f - 1] || (i += c ? r("M", p + s, 0.5 + h + s) : r("m", l, 0), l = 0, c = !1), p + 1 < n && o[f + 1] || (i += r("h", u), u = 0)) : l++;
    }
    return i;
  }
  return Ys.render = function(n, s, i) {
    const l = e.getOptions(s), c = n.modules.size, u = n.modules.data, f = c + l.margin * 2, p = l.color.light.a ? "<path " + t(l.color.light, "fill") + ' d="M0 0h' + f + "v" + f + 'H0z"/>' : "", h = "<path " + t(l.color.dark, "stroke") + ' d="' + a(u, c, l.margin) + '"/>', m = 'viewBox="0 0 ' + f + " " + f + '"', x = '<svg xmlns="http://www.w3.org/2000/svg" ' + (l.width ? 'width="' + l.width + '" height="' + l.width + '" ' : "") + m + ' shape-rendering="crispEdges">' + p + h + `</svg>
`;
    return typeof i == "function" && i(null, x), x;
  }, Ys;
}
var Wu;
function uw() {
  if (Wu) return ga;
  Wu = 1;
  const e = jy(), t = iw(), r = lw(), a = cw();
  function o(n, s, i, l, c) {
    const u = [].slice.call(arguments, 1), f = u.length, p = typeof u[f - 1] == "function";
    if (!p && !e())
      throw new Error("Callback required as last argument");
    if (p) {
      if (f < 2)
        throw new Error("Too few arguments provided");
      f === 2 ? (c = i, i = s, s = l = void 0) : f === 3 && (s.getContext && typeof c > "u" ? (c = l, l = void 0) : (c = l, l = i, i = s, s = void 0));
    } else {
      if (f < 1)
        throw new Error("Too few arguments provided");
      return f === 1 ? (i = s, s = l = void 0) : f === 2 && !s.getContext && (l = i, i = s, s = void 0), new Promise(function(h, m) {
        try {
          const v = t.create(i, l);
          h(n(v, s, l));
        } catch (v) {
          m(v);
        }
      });
    }
    try {
      const h = t.create(i, l);
      c(null, n(h, s, l));
    } catch (h) {
      c(h);
    }
  }
  return ga.create = t.create, ga.toCanvas = o.bind(null, r.render), ga.toDataURL = o.bind(null, r.renderToDataURL), ga.toString = o.bind(null, function(n, s, i) {
    return a.render(n, i);
  }), ga;
}
var dw = uw();
const fw = /* @__PURE__ */ zy(dw);
class pw {
  sessionId;
  expireSeconds;
  qrcodeContent;
  constructor(t) {
    this.sessionId = t.session_id, this.expireSeconds = t.expire_seconds, this.qrcodeContent = t.qrcode_content;
  }
  async qrcodeBase64() {
    return fw.toDataURL(this.qrcodeContent);
  }
  get expireMilliseconds() {
    return this.expireSeconds * 1e3;
  }
}
const hw = async (e) => {
  const t = await St.post(
    "/api/ks-ctl/webchat/auth-qrcode",
    { session_id: e }
  );
  return new pw(t.data);
}, gw = async (e) => {
  const t = await St.post("/api/ks-ctl/webchat/auth", {
    session_id: e
  });
  if (t.status !== 200)
    return null;
  const r = t.data;
  return {
    token: r.token,
    profile: {
      username: r.profile.username,
      isPlus: r.profile.is_plus,
      roleExpiredAt: r.profile.role_expired_at
    },
    trafficBalance: {
      balanceBytes: r.traffic_balance.balance_bytes,
      usageBytes: r.traffic_balance.usage_bytes
    }
  };
}, mw = async () => {
  await St.post("/api/ks-ctl/webchat/logout");
};
class ko {
  _value;
  _unitLevel;
  UNITS = ["B", "K", "M", "G", "T", "PB", "EB", "ZB", "YB"];
  static trafficUnitFormater(t) {
    if (t <= 0)
      return new ko(0, 0);
    const r = Math.floor(Math.log(t) / Math.log(1024)), a = parseFloat((t / Math.pow(1024, r)).toFixed(2));
    return new ko(a, r);
  }
  get value() {
    return this._value;
  }
  get unit() {
    return this.UNITS[this._unitLevel] || this.UNITS[0];
  }
  constructor(t, r) {
    this._value = t, this._unitLevel = r;
  }
  toText() {
    return `${this._value} ${this.UNITS[this._unitLevel]}`;
  }
}
const t0 = async (e) => {
  const t = new URLSearchParams();
  e?.forceSpeedTest !== !1 && t.set("forceSpeedTest", "1"), e?.includeCfipTest && t.set("includeCfipTest", "1");
  const r = t.toString(), a = r ? `/api/mirrors/refresh?${r}` : "/api/mirrors/refresh", o = await St.get(a);
  return o.status >= 200 && o.status < 300;
}, vw = async () => {
  const t = (await St.get("/api/mirrors/overview")).data;
  return {
    ...t,
    isCN: t.isCN ?? t.is_cn
  };
}, bw = async () => (await St.get("/api/summary")).data, yw = async () => {
  const t = (await St.get("/api/ks-ctl/traffic-balance/cache")).data;
  return {
    balanceBytes: t.balance_bytes,
    usageBytes: t.usage_bytes
  };
};
let Xs = null, Gu = 0;
const ww = 1500, Ju = () => {
  const e = Date.now();
  Xs || e - Gu < ww || (Gu = e, Xs = t0({ forceSpeedTest: !0, includeCfipTest: !1 }).catch(() => !1).finally(() => {
    Xs = null;
  }));
}, qa = /* @__PURE__ */ ep("auth", {
  state: () => ({
    token: "",
    user: {},
    trafficBalance: {
      balanceBytes: 0,
      usageBytes: 0
    }
  }),
  getters: {
    isLogin: (e) => !!e.token,
    isPlus: (e) => e.user?.isPlus,
    userLevelText: (e) => e.user?.isPlus ? "Plus" : "Free",
    usageTrafficWithUnit: (e) => ko.trafficUnitFormater(e.trafficBalance.usageBytes),
    balanceTrafficWithUnit: (e) => ko.trafficUnitFormater(e.trafficBalance.balanceBytes),
    roleExpiredAt: (e) => e.user?.roleExpiredAt
  },
  actions: {
    async syncLoginStatus() {
      await this.login("", { triggerMirrorRefresh: !1 });
    },
    async login(e, t) {
      const r = await gw(e);
      return !r || !r.token ? !1 : (this.token = r.token, this.user = r.profile, this.trafficBalance = r.trafficBalance, t?.triggerMirrorRefresh !== !1 && Ju(), this.isLogin);
    },
    async refreshTrafficBalance() {
      this.isLogin && (this.trafficBalance = await yw());
    },
    flush() {
      this.user = null, this.token = "", Ju();
    }
  }
}), xw = /* @__PURE__ */ D({
  __name: "App",
  setup(e) {
    const t = Gb(), r = qa();
    return at(async () => {
      await t.fetchEnvConfig(), await r.syncLoginStatus();
    }), Ke(
      () => t.gaId,
      () => {
        {
          const a = t.createGtag();
          bt()?.appContext.app?.use(a);
        }
      },
      { immediate: !0 }
    ), (a, o) => (g(), R(Be, null, [
      k(d(kl)),
      k(d(Fy), {
        position: "top-center",
        richColors: ""
      })
    ], 64));
  }
}), r0 = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20200%20200'%3e%3ccircle%20cx='100'%20cy='100'%20r='90'%20fill='%230073e6'/%3e%3cpath%20d='M100%2020v160M20%20100h160'%20stroke='%23fff'%20stroke-width='10'/%3e%3cpath%20d='M100%2060l40%2040-40%2040-40-40z'%20fill='%23fff'/%3e%3c/svg%3e";
function a0(e) {
  var t, r, a = "";
  if (typeof e == "string" || typeof e == "number") a += e;
  else if (typeof e == "object") if (Array.isArray(e)) {
    var o = e.length;
    for (t = 0; t < o; t++) e[t] && (r = a0(e[t])) && (a && (a += " "), a += r);
  } else for (r in e) e[r] && (a && (a += " "), a += r);
  return a;
}
function o0() {
  for (var e, t, r = 0, a = "", o = arguments.length; r < o; r++) (e = arguments[r]) && (t = a0(e)) && (a && (a += " "), a += t);
  return a;
}
const Ml = "-", _w = (e) => {
  const t = Cw(e), {
    conflictingClassGroups: r,
    conflictingClassGroupModifiers: a
  } = e;
  return {
    getClassGroupId: (s) => {
      const i = s.split(Ml);
      return i[0] === "" && i.length !== 1 && i.shift(), n0(i, t) || kw(s);
    },
    getConflictingClassGroupIds: (s, i) => {
      const l = r[s] || [];
      return i && a[s] ? [...l, ...a[s]] : l;
    }
  };
}, n0 = (e, t) => {
  if (e.length === 0)
    return t.classGroupId;
  const r = e[0], a = t.nextPart.get(r), o = a ? n0(e.slice(1), a) : void 0;
  if (o)
    return o;
  if (t.validators.length === 0)
    return;
  const n = e.join(Ml);
  return t.validators.find(({
    validator: s
  }) => s(n))?.classGroupId;
}, Yu = /^\[(.+)\]$/, kw = (e) => {
  if (Yu.test(e)) {
    const t = Yu.exec(e)[1], r = t?.substring(0, t.indexOf(":"));
    if (r)
      return "arbitrary.." + r;
  }
}, Cw = (e) => {
  const {
    theme: t,
    classGroups: r
  } = e, a = {
    nextPart: /* @__PURE__ */ new Map(),
    validators: []
  };
  for (const o in r)
    qi(r[o], a, o, t);
  return a;
}, qi = (e, t, r, a) => {
  e.forEach((o) => {
    if (typeof o == "string") {
      const n = o === "" ? t : Xu(t, o);
      n.classGroupId = r;
      return;
    }
    if (typeof o == "function") {
      if (Aw(o)) {
        qi(o(a), t, r, a);
        return;
      }
      t.validators.push({
        validator: o,
        classGroupId: r
      });
      return;
    }
    Object.entries(o).forEach(([n, s]) => {
      qi(s, Xu(t, n), r, a);
    });
  });
}, Xu = (e, t) => {
  let r = e;
  return t.split(Ml).forEach((a) => {
    r.nextPart.has(a) || r.nextPart.set(a, {
      nextPart: /* @__PURE__ */ new Map(),
      validators: []
    }), r = r.nextPart.get(a);
  }), r;
}, Aw = (e) => e.isThemeGetter, Sw = (e) => {
  if (e < 1)
    return {
      get: () => {
      },
      set: () => {
      }
    };
  let t = 0, r = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map();
  const o = (n, s) => {
    r.set(n, s), t++, t > e && (t = 0, a = r, r = /* @__PURE__ */ new Map());
  };
  return {
    get(n) {
      let s = r.get(n);
      if (s !== void 0)
        return s;
      if ((s = a.get(n)) !== void 0)
        return o(n, s), s;
    },
    set(n, s) {
      r.has(n) ? r.set(n, s) : o(n, s);
    }
  };
}, Li = "!", Ni = ":", Ew = Ni.length, $w = (e) => {
  const {
    prefix: t,
    experimentalParseClassName: r
  } = e;
  let a = (o) => {
    const n = [];
    let s = 0, i = 0, l = 0, c;
    for (let m = 0; m < o.length; m++) {
      let v = o[m];
      if (s === 0 && i === 0) {
        if (v === Ni) {
          n.push(o.slice(l, m)), l = m + Ew;
          continue;
        }
        if (v === "/") {
          c = m;
          continue;
        }
      }
      v === "[" ? s++ : v === "]" ? s-- : v === "(" ? i++ : v === ")" && i--;
    }
    const u = n.length === 0 ? o : o.substring(l), f = Pw(u), p = f !== u, h = c && c > l ? c - l : void 0;
    return {
      modifiers: n,
      hasImportantModifier: p,
      baseClassName: f,
      maybePostfixModifierPosition: h
    };
  };
  if (t) {
    const o = t + Ni, n = a;
    a = (s) => s.startsWith(o) ? n(s.substring(o.length)) : {
      isExternal: !0,
      modifiers: [],
      hasImportantModifier: !1,
      baseClassName: s,
      maybePostfixModifierPosition: void 0
    };
  }
  if (r) {
    const o = a;
    a = (n) => r({
      className: n,
      parseClassName: o
    });
  }
  return a;
}, Pw = (e) => e.endsWith(Li) ? e.substring(0, e.length - 1) : e.startsWith(Li) ? e.substring(1) : e, Tw = (e) => {
  const t = Object.fromEntries(e.orderSensitiveModifiers.map((a) => [a, !0]));
  return (a) => {
    if (a.length <= 1)
      return a;
    const o = [];
    let n = [];
    return a.forEach((s) => {
      s[0] === "[" || t[s] ? (o.push(...n.sort(), s), n = []) : n.push(s);
    }), o.push(...n.sort()), o;
  };
}, Mw = (e) => ({
  cache: Sw(e.cacheSize),
  parseClassName: $w(e),
  sortModifiers: Tw(e),
  ..._w(e)
}), Rw = /\s+/, Ow = (e, t) => {
  const {
    parseClassName: r,
    getClassGroupId: a,
    getConflictingClassGroupIds: o,
    sortModifiers: n
  } = t, s = [], i = e.trim().split(Rw);
  let l = "";
  for (let c = i.length - 1; c >= 0; c -= 1) {
    const u = i[c], {
      isExternal: f,
      modifiers: p,
      hasImportantModifier: h,
      baseClassName: m,
      maybePostfixModifierPosition: v
    } = r(u);
    if (f) {
      l = u + (l.length > 0 ? " " + l : l);
      continue;
    }
    let x = !!v, C = a(x ? m.substring(0, v) : m);
    if (!C) {
      if (!x) {
        l = u + (l.length > 0 ? " " + l : l);
        continue;
      }
      if (C = a(m), !C) {
        l = u + (l.length > 0 ? " " + l : l);
        continue;
      }
      x = !1;
    }
    const S = n(p).join(":"), E = h ? S + Li : S, T = E + C;
    if (s.includes(T))
      continue;
    s.push(T);
    const F = o(C, x);
    for (let j = 0; j < F.length; ++j) {
      const H = F[j];
      s.push(E + H);
    }
    l = u + (l.length > 0 ? " " + l : l);
  }
  return l;
};
function Bw() {
  let e = 0, t, r, a = "";
  for (; e < arguments.length; )
    (t = arguments[e++]) && (r = s0(t)) && (a && (a += " "), a += r);
  return a;
}
const s0 = (e) => {
  if (typeof e == "string")
    return e;
  let t, r = "";
  for (let a = 0; a < e.length; a++)
    e[a] && (t = s0(e[a])) && (r && (r += " "), r += t);
  return r;
};
function Dw(e, ...t) {
  let r, a, o, n = s;
  function s(l) {
    const c = t.reduce((u, f) => f(u), e());
    return r = Mw(c), a = r.cache.get, o = r.cache.set, n = i, i(l);
  }
  function i(l) {
    const c = a(l);
    if (c)
      return c;
    const u = Ow(l, r);
    return o(l, u), u;
  }
  return function() {
    return n(Bw.apply(null, arguments));
  };
}
const ot = (e) => {
  const t = (r) => r[e] || [];
  return t.isThemeGetter = !0, t;
}, i0 = /^\[(?:(\w[\w-]*):)?(.+)\]$/i, l0 = /^\((?:(\w[\w-]*):)?(.+)\)$/i, Iw = /^\d+\/\d+$/, qw = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/, Lw = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/, Nw = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/, Vw = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/, Hw = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/, ma = (e) => Iw.test(e), Te = (e) => !!e && !Number.isNaN(Number(e)), Rr = (e) => !!e && Number.isInteger(Number(e)), Qs = (e) => e.endsWith("%") && Te(e.slice(0, -1)), gr = (e) => qw.test(e), Fw = () => !0, zw = (e) => (
  // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
  // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
  // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
  Lw.test(e) && !Nw.test(e)
), c0 = () => !1, jw = (e) => Vw.test(e), Uw = (e) => Hw.test(e), Zw = (e) => !fe(e) && !pe(e), Kw = (e) => La(e, f0, c0), fe = (e) => i0.test(e), Xr = (e) => La(e, p0, zw), ei = (e) => La(e, Xw, Te), Qu = (e) => La(e, u0, c0), Ww = (e) => La(e, d0, Uw), Ko = (e) => La(e, h0, jw), pe = (e) => l0.test(e), Ja = (e) => Na(e, p0), Gw = (e) => Na(e, Qw), ed = (e) => Na(e, u0), Jw = (e) => Na(e, f0), Yw = (e) => Na(e, d0), Wo = (e) => Na(e, h0, !0), La = (e, t, r) => {
  const a = i0.exec(e);
  return a ? a[1] ? t(a[1]) : r(a[2]) : !1;
}, Na = (e, t, r = !1) => {
  const a = l0.exec(e);
  return a ? a[1] ? t(a[1]) : r : !1;
}, u0 = (e) => e === "position" || e === "percentage", d0 = (e) => e === "image" || e === "url", f0 = (e) => e === "length" || e === "size" || e === "bg-size", p0 = (e) => e === "length", Xw = (e) => e === "number", Qw = (e) => e === "family-name", h0 = (e) => e === "shadow", e2 = () => {
  const e = ot("color"), t = ot("font"), r = ot("text"), a = ot("font-weight"), o = ot("tracking"), n = ot("leading"), s = ot("breakpoint"), i = ot("container"), l = ot("spacing"), c = ot("radius"), u = ot("shadow"), f = ot("inset-shadow"), p = ot("text-shadow"), h = ot("drop-shadow"), m = ot("blur"), v = ot("perspective"), x = ot("aspect"), C = ot("ease"), S = ot("animate"), E = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"], T = () => [
    "center",
    "top",
    "bottom",
    "left",
    "right",
    "top-left",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "left-top",
    "top-right",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "right-top",
    "bottom-right",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "right-bottom",
    "bottom-left",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "left-bottom"
  ], F = () => [...T(), pe, fe], j = () => ["auto", "hidden", "clip", "visible", "scroll"], H = () => ["auto", "contain", "none"], B = () => [pe, fe, l], P = () => [ma, "full", "auto", ...B()], $ = () => [Rr, "none", "subgrid", pe, fe], V = () => ["auto", {
    span: ["full", Rr, pe, fe]
  }, Rr, pe, fe], z = () => [Rr, "auto", pe, fe], G = () => ["auto", "min", "max", "fr", pe, fe], ee = () => ["start", "end", "center", "between", "around", "evenly", "stretch", "baseline", "center-safe", "end-safe"], xe = () => ["start", "end", "center", "stretch", "center-safe", "end-safe"], de = () => ["auto", ...B()], W = () => [ma, "auto", "full", "dvw", "dvh", "lvw", "lvh", "svw", "svh", "min", "max", "fit", ...B()], M = () => [e, pe, fe], ge = () => [...T(), ed, Qu, {
    position: [pe, fe]
  }], Me = () => ["no-repeat", {
    repeat: ["", "x", "y", "space", "round"]
  }], Ie = () => ["auto", "cover", "contain", Jw, Kw, {
    size: [pe, fe]
  }], ze = () => [Qs, Ja, Xr], ae = () => [
    // Deprecated since Tailwind CSS v4.0.0
    "",
    "none",
    "full",
    c,
    pe,
    fe
  ], O = () => ["", Te, Ja, Xr], Ae = () => ["solid", "dashed", "dotted", "double"], _e = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"], y = () => [Te, Qs, ed, Qu], Q = () => [
    // Deprecated since Tailwind CSS v4.0.0
    "",
    "none",
    m,
    pe,
    fe
  ], Z = () => ["none", Te, pe, fe], te = () => ["none", Te, pe, fe], we = () => [Te, pe, fe], _ = () => [ma, "full", ...B()];
  return {
    cacheSize: 500,
    theme: {
      animate: ["spin", "ping", "pulse", "bounce"],
      aspect: ["video"],
      blur: [gr],
      breakpoint: [gr],
      color: [Fw],
      container: [gr],
      "drop-shadow": [gr],
      ease: ["in", "out", "in-out"],
      font: [Zw],
      "font-weight": ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black"],
      "inset-shadow": [gr],
      leading: ["none", "tight", "snug", "normal", "relaxed", "loose"],
      perspective: ["dramatic", "near", "normal", "midrange", "distant", "none"],
      radius: [gr],
      shadow: [gr],
      spacing: ["px", Te],
      text: [gr],
      "text-shadow": [gr],
      tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"]
    },
    classGroups: {
      // --------------
      // --- Layout ---
      // --------------
      /**
       * Aspect Ratio
       * @see https://tailwindcss.com/docs/aspect-ratio
       */
      aspect: [{
        aspect: ["auto", "square", ma, fe, pe, x]
      }],
      /**
       * Container
       * @see https://tailwindcss.com/docs/container
       * @deprecated since Tailwind CSS v4.0.0
       */
      container: ["container"],
      /**
       * Columns
       * @see https://tailwindcss.com/docs/columns
       */
      columns: [{
        columns: [Te, fe, pe, i]
      }],
      /**
       * Break After
       * @see https://tailwindcss.com/docs/break-after
       */
      "break-after": [{
        "break-after": E()
      }],
      /**
       * Break Before
       * @see https://tailwindcss.com/docs/break-before
       */
      "break-before": [{
        "break-before": E()
      }],
      /**
       * Break Inside
       * @see https://tailwindcss.com/docs/break-inside
       */
      "break-inside": [{
        "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
      }],
      /**
       * Box Decoration Break
       * @see https://tailwindcss.com/docs/box-decoration-break
       */
      "box-decoration": [{
        "box-decoration": ["slice", "clone"]
      }],
      /**
       * Box Sizing
       * @see https://tailwindcss.com/docs/box-sizing
       */
      box: [{
        box: ["border", "content"]
      }],
      /**
       * Display
       * @see https://tailwindcss.com/docs/display
       */
      display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
      /**
       * Screen Reader Only
       * @see https://tailwindcss.com/docs/display#screen-reader-only
       */
      sr: ["sr-only", "not-sr-only"],
      /**
       * Floats
       * @see https://tailwindcss.com/docs/float
       */
      float: [{
        float: ["right", "left", "none", "start", "end"]
      }],
      /**
       * Clear
       * @see https://tailwindcss.com/docs/clear
       */
      clear: [{
        clear: ["left", "right", "both", "none", "start", "end"]
      }],
      /**
       * Isolation
       * @see https://tailwindcss.com/docs/isolation
       */
      isolation: ["isolate", "isolation-auto"],
      /**
       * Object Fit
       * @see https://tailwindcss.com/docs/object-fit
       */
      "object-fit": [{
        object: ["contain", "cover", "fill", "none", "scale-down"]
      }],
      /**
       * Object Position
       * @see https://tailwindcss.com/docs/object-position
       */
      "object-position": [{
        object: F()
      }],
      /**
       * Overflow
       * @see https://tailwindcss.com/docs/overflow
       */
      overflow: [{
        overflow: j()
      }],
      /**
       * Overflow X
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-x": [{
        "overflow-x": j()
      }],
      /**
       * Overflow Y
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-y": [{
        "overflow-y": j()
      }],
      /**
       * Overscroll Behavior
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      overscroll: [{
        overscroll: H()
      }],
      /**
       * Overscroll Behavior X
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-x": [{
        "overscroll-x": H()
      }],
      /**
       * Overscroll Behavior Y
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-y": [{
        "overscroll-y": H()
      }],
      /**
       * Position
       * @see https://tailwindcss.com/docs/position
       */
      position: ["static", "fixed", "absolute", "relative", "sticky"],
      /**
       * Top / Right / Bottom / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      inset: [{
        inset: P()
      }],
      /**
       * Right / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-x": [{
        "inset-x": P()
      }],
      /**
       * Top / Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-y": [{
        "inset-y": P()
      }],
      /**
       * Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      start: [{
        start: P()
      }],
      /**
       * End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      end: [{
        end: P()
      }],
      /**
       * Top
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      top: [{
        top: P()
      }],
      /**
       * Right
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      right: [{
        right: P()
      }],
      /**
       * Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      bottom: [{
        bottom: P()
      }],
      /**
       * Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      left: [{
        left: P()
      }],
      /**
       * Visibility
       * @see https://tailwindcss.com/docs/visibility
       */
      visibility: ["visible", "invisible", "collapse"],
      /**
       * Z-Index
       * @see https://tailwindcss.com/docs/z-index
       */
      z: [{
        z: [Rr, "auto", pe, fe]
      }],
      // ------------------------
      // --- Flexbox and Grid ---
      // ------------------------
      /**
       * Flex Basis
       * @see https://tailwindcss.com/docs/flex-basis
       */
      basis: [{
        basis: [ma, "full", "auto", i, ...B()]
      }],
      /**
       * Flex Direction
       * @see https://tailwindcss.com/docs/flex-direction
       */
      "flex-direction": [{
        flex: ["row", "row-reverse", "col", "col-reverse"]
      }],
      /**
       * Flex Wrap
       * @see https://tailwindcss.com/docs/flex-wrap
       */
      "flex-wrap": [{
        flex: ["nowrap", "wrap", "wrap-reverse"]
      }],
      /**
       * Flex
       * @see https://tailwindcss.com/docs/flex
       */
      flex: [{
        flex: [Te, ma, "auto", "initial", "none", fe]
      }],
      /**
       * Flex Grow
       * @see https://tailwindcss.com/docs/flex-grow
       */
      grow: [{
        grow: ["", Te, pe, fe]
      }],
      /**
       * Flex Shrink
       * @see https://tailwindcss.com/docs/flex-shrink
       */
      shrink: [{
        shrink: ["", Te, pe, fe]
      }],
      /**
       * Order
       * @see https://tailwindcss.com/docs/order
       */
      order: [{
        order: [Rr, "first", "last", "none", pe, fe]
      }],
      /**
       * Grid Template Columns
       * @see https://tailwindcss.com/docs/grid-template-columns
       */
      "grid-cols": [{
        "grid-cols": $()
      }],
      /**
       * Grid Column Start / End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start-end": [{
        col: V()
      }],
      /**
       * Grid Column Start
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start": [{
        "col-start": z()
      }],
      /**
       * Grid Column End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-end": [{
        "col-end": z()
      }],
      /**
       * Grid Template Rows
       * @see https://tailwindcss.com/docs/grid-template-rows
       */
      "grid-rows": [{
        "grid-rows": $()
      }],
      /**
       * Grid Row Start / End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start-end": [{
        row: V()
      }],
      /**
       * Grid Row Start
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start": [{
        "row-start": z()
      }],
      /**
       * Grid Row End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-end": [{
        "row-end": z()
      }],
      /**
       * Grid Auto Flow
       * @see https://tailwindcss.com/docs/grid-auto-flow
       */
      "grid-flow": [{
        "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
      }],
      /**
       * Grid Auto Columns
       * @see https://tailwindcss.com/docs/grid-auto-columns
       */
      "auto-cols": [{
        "auto-cols": G()
      }],
      /**
       * Grid Auto Rows
       * @see https://tailwindcss.com/docs/grid-auto-rows
       */
      "auto-rows": [{
        "auto-rows": G()
      }],
      /**
       * Gap
       * @see https://tailwindcss.com/docs/gap
       */
      gap: [{
        gap: B()
      }],
      /**
       * Gap X
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-x": [{
        "gap-x": B()
      }],
      /**
       * Gap Y
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-y": [{
        "gap-y": B()
      }],
      /**
       * Justify Content
       * @see https://tailwindcss.com/docs/justify-content
       */
      "justify-content": [{
        justify: [...ee(), "normal"]
      }],
      /**
       * Justify Items
       * @see https://tailwindcss.com/docs/justify-items
       */
      "justify-items": [{
        "justify-items": [...xe(), "normal"]
      }],
      /**
       * Justify Self
       * @see https://tailwindcss.com/docs/justify-self
       */
      "justify-self": [{
        "justify-self": ["auto", ...xe()]
      }],
      /**
       * Align Content
       * @see https://tailwindcss.com/docs/align-content
       */
      "align-content": [{
        content: ["normal", ...ee()]
      }],
      /**
       * Align Items
       * @see https://tailwindcss.com/docs/align-items
       */
      "align-items": [{
        items: [...xe(), {
          baseline: ["", "last"]
        }]
      }],
      /**
       * Align Self
       * @see https://tailwindcss.com/docs/align-self
       */
      "align-self": [{
        self: ["auto", ...xe(), {
          baseline: ["", "last"]
        }]
      }],
      /**
       * Place Content
       * @see https://tailwindcss.com/docs/place-content
       */
      "place-content": [{
        "place-content": ee()
      }],
      /**
       * Place Items
       * @see https://tailwindcss.com/docs/place-items
       */
      "place-items": [{
        "place-items": [...xe(), "baseline"]
      }],
      /**
       * Place Self
       * @see https://tailwindcss.com/docs/place-self
       */
      "place-self": [{
        "place-self": ["auto", ...xe()]
      }],
      // Spacing
      /**
       * Padding
       * @see https://tailwindcss.com/docs/padding
       */
      p: [{
        p: B()
      }],
      /**
       * Padding X
       * @see https://tailwindcss.com/docs/padding
       */
      px: [{
        px: B()
      }],
      /**
       * Padding Y
       * @see https://tailwindcss.com/docs/padding
       */
      py: [{
        py: B()
      }],
      /**
       * Padding Start
       * @see https://tailwindcss.com/docs/padding
       */
      ps: [{
        ps: B()
      }],
      /**
       * Padding End
       * @see https://tailwindcss.com/docs/padding
       */
      pe: [{
        pe: B()
      }],
      /**
       * Padding Top
       * @see https://tailwindcss.com/docs/padding
       */
      pt: [{
        pt: B()
      }],
      /**
       * Padding Right
       * @see https://tailwindcss.com/docs/padding
       */
      pr: [{
        pr: B()
      }],
      /**
       * Padding Bottom
       * @see https://tailwindcss.com/docs/padding
       */
      pb: [{
        pb: B()
      }],
      /**
       * Padding Left
       * @see https://tailwindcss.com/docs/padding
       */
      pl: [{
        pl: B()
      }],
      /**
       * Margin
       * @see https://tailwindcss.com/docs/margin
       */
      m: [{
        m: de()
      }],
      /**
       * Margin X
       * @see https://tailwindcss.com/docs/margin
       */
      mx: [{
        mx: de()
      }],
      /**
       * Margin Y
       * @see https://tailwindcss.com/docs/margin
       */
      my: [{
        my: de()
      }],
      /**
       * Margin Start
       * @see https://tailwindcss.com/docs/margin
       */
      ms: [{
        ms: de()
      }],
      /**
       * Margin End
       * @see https://tailwindcss.com/docs/margin
       */
      me: [{
        me: de()
      }],
      /**
       * Margin Top
       * @see https://tailwindcss.com/docs/margin
       */
      mt: [{
        mt: de()
      }],
      /**
       * Margin Right
       * @see https://tailwindcss.com/docs/margin
       */
      mr: [{
        mr: de()
      }],
      /**
       * Margin Bottom
       * @see https://tailwindcss.com/docs/margin
       */
      mb: [{
        mb: de()
      }],
      /**
       * Margin Left
       * @see https://tailwindcss.com/docs/margin
       */
      ml: [{
        ml: de()
      }],
      /**
       * Space Between X
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-x": [{
        "space-x": B()
      }],
      /**
       * Space Between X Reverse
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-x-reverse": ["space-x-reverse"],
      /**
       * Space Between Y
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-y": [{
        "space-y": B()
      }],
      /**
       * Space Between Y Reverse
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-y-reverse": ["space-y-reverse"],
      // --------------
      // --- Sizing ---
      // --------------
      /**
       * Size
       * @see https://tailwindcss.com/docs/width#setting-both-width-and-height
       */
      size: [{
        size: W()
      }],
      /**
       * Width
       * @see https://tailwindcss.com/docs/width
       */
      w: [{
        w: [i, "screen", ...W()]
      }],
      /**
       * Min-Width
       * @see https://tailwindcss.com/docs/min-width
       */
      "min-w": [{
        "min-w": [
          i,
          "screen",
          /** Deprecated. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          "none",
          ...W()
        ]
      }],
      /**
       * Max-Width
       * @see https://tailwindcss.com/docs/max-width
       */
      "max-w": [{
        "max-w": [
          i,
          "screen",
          "none",
          /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          "prose",
          /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          {
            screen: [s]
          },
          ...W()
        ]
      }],
      /**
       * Height
       * @see https://tailwindcss.com/docs/height
       */
      h: [{
        h: ["screen", "lh", ...W()]
      }],
      /**
       * Min-Height
       * @see https://tailwindcss.com/docs/min-height
       */
      "min-h": [{
        "min-h": ["screen", "lh", "none", ...W()]
      }],
      /**
       * Max-Height
       * @see https://tailwindcss.com/docs/max-height
       */
      "max-h": [{
        "max-h": ["screen", "lh", ...W()]
      }],
      // ------------------
      // --- Typography ---
      // ------------------
      /**
       * Font Size
       * @see https://tailwindcss.com/docs/font-size
       */
      "font-size": [{
        text: ["base", r, Ja, Xr]
      }],
      /**
       * Font Smoothing
       * @see https://tailwindcss.com/docs/font-smoothing
       */
      "font-smoothing": ["antialiased", "subpixel-antialiased"],
      /**
       * Font Style
       * @see https://tailwindcss.com/docs/font-style
       */
      "font-style": ["italic", "not-italic"],
      /**
       * Font Weight
       * @see https://tailwindcss.com/docs/font-weight
       */
      "font-weight": [{
        font: [a, pe, ei]
      }],
      /**
       * Font Stretch
       * @see https://tailwindcss.com/docs/font-stretch
       */
      "font-stretch": [{
        "font-stretch": ["ultra-condensed", "extra-condensed", "condensed", "semi-condensed", "normal", "semi-expanded", "expanded", "extra-expanded", "ultra-expanded", Qs, fe]
      }],
      /**
       * Font Family
       * @see https://tailwindcss.com/docs/font-family
       */
      "font-family": [{
        font: [Gw, fe, t]
      }],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-normal": ["normal-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-ordinal": ["ordinal"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-slashed-zero": ["slashed-zero"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-figure": ["lining-nums", "oldstyle-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-spacing": ["proportional-nums", "tabular-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
      /**
       * Letter Spacing
       * @see https://tailwindcss.com/docs/letter-spacing
       */
      tracking: [{
        tracking: [o, pe, fe]
      }],
      /**
       * Line Clamp
       * @see https://tailwindcss.com/docs/line-clamp
       */
      "line-clamp": [{
        "line-clamp": [Te, "none", pe, ei]
      }],
      /**
       * Line Height
       * @see https://tailwindcss.com/docs/line-height
       */
      leading: [{
        leading: [
          /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          n,
          ...B()
        ]
      }],
      /**
       * List Style Image
       * @see https://tailwindcss.com/docs/list-style-image
       */
      "list-image": [{
        "list-image": ["none", pe, fe]
      }],
      /**
       * List Style Position
       * @see https://tailwindcss.com/docs/list-style-position
       */
      "list-style-position": [{
        list: ["inside", "outside"]
      }],
      /**
       * List Style Type
       * @see https://tailwindcss.com/docs/list-style-type
       */
      "list-style-type": [{
        list: ["disc", "decimal", "none", pe, fe]
      }],
      /**
       * Text Alignment
       * @see https://tailwindcss.com/docs/text-align
       */
      "text-alignment": [{
        text: ["left", "center", "right", "justify", "start", "end"]
      }],
      /**
       * Placeholder Color
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://v3.tailwindcss.com/docs/placeholder-color
       */
      "placeholder-color": [{
        placeholder: M()
      }],
      /**
       * Text Color
       * @see https://tailwindcss.com/docs/text-color
       */
      "text-color": [{
        text: M()
      }],
      /**
       * Text Decoration
       * @see https://tailwindcss.com/docs/text-decoration
       */
      "text-decoration": ["underline", "overline", "line-through", "no-underline"],
      /**
       * Text Decoration Style
       * @see https://tailwindcss.com/docs/text-decoration-style
       */
      "text-decoration-style": [{
        decoration: [...Ae(), "wavy"]
      }],
      /**
       * Text Decoration Thickness
       * @see https://tailwindcss.com/docs/text-decoration-thickness
       */
      "text-decoration-thickness": [{
        decoration: [Te, "from-font", "auto", pe, Xr]
      }],
      /**
       * Text Decoration Color
       * @see https://tailwindcss.com/docs/text-decoration-color
       */
      "text-decoration-color": [{
        decoration: M()
      }],
      /**
       * Text Underline Offset
       * @see https://tailwindcss.com/docs/text-underline-offset
       */
      "underline-offset": [{
        "underline-offset": [Te, "auto", pe, fe]
      }],
      /**
       * Text Transform
       * @see https://tailwindcss.com/docs/text-transform
       */
      "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
      /**
       * Text Overflow
       * @see https://tailwindcss.com/docs/text-overflow
       */
      "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
      /**
       * Text Wrap
       * @see https://tailwindcss.com/docs/text-wrap
       */
      "text-wrap": [{
        text: ["wrap", "nowrap", "balance", "pretty"]
      }],
      /**
       * Text Indent
       * @see https://tailwindcss.com/docs/text-indent
       */
      indent: [{
        indent: B()
      }],
      /**
       * Vertical Alignment
       * @see https://tailwindcss.com/docs/vertical-align
       */
      "vertical-align": [{
        align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", pe, fe]
      }],
      /**
       * Whitespace
       * @see https://tailwindcss.com/docs/whitespace
       */
      whitespace: [{
        whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
      }],
      /**
       * Word Break
       * @see https://tailwindcss.com/docs/word-break
       */
      break: [{
        break: ["normal", "words", "all", "keep"]
      }],
      /**
       * Overflow Wrap
       * @see https://tailwindcss.com/docs/overflow-wrap
       */
      wrap: [{
        wrap: ["break-word", "anywhere", "normal"]
      }],
      /**
       * Hyphens
       * @see https://tailwindcss.com/docs/hyphens
       */
      hyphens: [{
        hyphens: ["none", "manual", "auto"]
      }],
      /**
       * Content
       * @see https://tailwindcss.com/docs/content
       */
      content: [{
        content: ["none", pe, fe]
      }],
      // -------------------
      // --- Backgrounds ---
      // -------------------
      /**
       * Background Attachment
       * @see https://tailwindcss.com/docs/background-attachment
       */
      "bg-attachment": [{
        bg: ["fixed", "local", "scroll"]
      }],
      /**
       * Background Clip
       * @see https://tailwindcss.com/docs/background-clip
       */
      "bg-clip": [{
        "bg-clip": ["border", "padding", "content", "text"]
      }],
      /**
       * Background Origin
       * @see https://tailwindcss.com/docs/background-origin
       */
      "bg-origin": [{
        "bg-origin": ["border", "padding", "content"]
      }],
      /**
       * Background Position
       * @see https://tailwindcss.com/docs/background-position
       */
      "bg-position": [{
        bg: ge()
      }],
      /**
       * Background Repeat
       * @see https://tailwindcss.com/docs/background-repeat
       */
      "bg-repeat": [{
        bg: Me()
      }],
      /**
       * Background Size
       * @see https://tailwindcss.com/docs/background-size
       */
      "bg-size": [{
        bg: Ie()
      }],
      /**
       * Background Image
       * @see https://tailwindcss.com/docs/background-image
       */
      "bg-image": [{
        bg: ["none", {
          linear: [{
            to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
          }, Rr, pe, fe],
          radial: ["", pe, fe],
          conic: [Rr, pe, fe]
        }, Yw, Ww]
      }],
      /**
       * Background Color
       * @see https://tailwindcss.com/docs/background-color
       */
      "bg-color": [{
        bg: M()
      }],
      /**
       * Gradient Color Stops From Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from-pos": [{
        from: ze()
      }],
      /**
       * Gradient Color Stops Via Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via-pos": [{
        via: ze()
      }],
      /**
       * Gradient Color Stops To Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to-pos": [{
        to: ze()
      }],
      /**
       * Gradient Color Stops From
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from": [{
        from: M()
      }],
      /**
       * Gradient Color Stops Via
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via": [{
        via: M()
      }],
      /**
       * Gradient Color Stops To
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to": [{
        to: M()
      }],
      // ---------------
      // --- Borders ---
      // ---------------
      /**
       * Border Radius
       * @see https://tailwindcss.com/docs/border-radius
       */
      rounded: [{
        rounded: ae()
      }],
      /**
       * Border Radius Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-s": [{
        "rounded-s": ae()
      }],
      /**
       * Border Radius End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-e": [{
        "rounded-e": ae()
      }],
      /**
       * Border Radius Top
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-t": [{
        "rounded-t": ae()
      }],
      /**
       * Border Radius Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-r": [{
        "rounded-r": ae()
      }],
      /**
       * Border Radius Bottom
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-b": [{
        "rounded-b": ae()
      }],
      /**
       * Border Radius Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-l": [{
        "rounded-l": ae()
      }],
      /**
       * Border Radius Start Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ss": [{
        "rounded-ss": ae()
      }],
      /**
       * Border Radius Start End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-se": [{
        "rounded-se": ae()
      }],
      /**
       * Border Radius End End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ee": [{
        "rounded-ee": ae()
      }],
      /**
       * Border Radius End Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-es": [{
        "rounded-es": ae()
      }],
      /**
       * Border Radius Top Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tl": [{
        "rounded-tl": ae()
      }],
      /**
       * Border Radius Top Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tr": [{
        "rounded-tr": ae()
      }],
      /**
       * Border Radius Bottom Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-br": [{
        "rounded-br": ae()
      }],
      /**
       * Border Radius Bottom Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-bl": [{
        "rounded-bl": ae()
      }],
      /**
       * Border Width
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w": [{
        border: O()
      }],
      /**
       * Border Width X
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-x": [{
        "border-x": O()
      }],
      /**
       * Border Width Y
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-y": [{
        "border-y": O()
      }],
      /**
       * Border Width Start
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-s": [{
        "border-s": O()
      }],
      /**
       * Border Width End
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-e": [{
        "border-e": O()
      }],
      /**
       * Border Width Top
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-t": [{
        "border-t": O()
      }],
      /**
       * Border Width Right
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-r": [{
        "border-r": O()
      }],
      /**
       * Border Width Bottom
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-b": [{
        "border-b": O()
      }],
      /**
       * Border Width Left
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-l": [{
        "border-l": O()
      }],
      /**
       * Divide Width X
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-x": [{
        "divide-x": O()
      }],
      /**
       * Divide Width X Reverse
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-x-reverse": ["divide-x-reverse"],
      /**
       * Divide Width Y
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-y": [{
        "divide-y": O()
      }],
      /**
       * Divide Width Y Reverse
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-y-reverse": ["divide-y-reverse"],
      /**
       * Border Style
       * @see https://tailwindcss.com/docs/border-style
       */
      "border-style": [{
        border: [...Ae(), "hidden", "none"]
      }],
      /**
       * Divide Style
       * @see https://tailwindcss.com/docs/border-style#setting-the-divider-style
       */
      "divide-style": [{
        divide: [...Ae(), "hidden", "none"]
      }],
      /**
       * Border Color
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color": [{
        border: M()
      }],
      /**
       * Border Color X
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-x": [{
        "border-x": M()
      }],
      /**
       * Border Color Y
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-y": [{
        "border-y": M()
      }],
      /**
       * Border Color S
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-s": [{
        "border-s": M()
      }],
      /**
       * Border Color E
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-e": [{
        "border-e": M()
      }],
      /**
       * Border Color Top
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-t": [{
        "border-t": M()
      }],
      /**
       * Border Color Right
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-r": [{
        "border-r": M()
      }],
      /**
       * Border Color Bottom
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-b": [{
        "border-b": M()
      }],
      /**
       * Border Color Left
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-l": [{
        "border-l": M()
      }],
      /**
       * Divide Color
       * @see https://tailwindcss.com/docs/divide-color
       */
      "divide-color": [{
        divide: M()
      }],
      /**
       * Outline Style
       * @see https://tailwindcss.com/docs/outline-style
       */
      "outline-style": [{
        outline: [...Ae(), "none", "hidden"]
      }],
      /**
       * Outline Offset
       * @see https://tailwindcss.com/docs/outline-offset
       */
      "outline-offset": [{
        "outline-offset": [Te, pe, fe]
      }],
      /**
       * Outline Width
       * @see https://tailwindcss.com/docs/outline-width
       */
      "outline-w": [{
        outline: ["", Te, Ja, Xr]
      }],
      /**
       * Outline Color
       * @see https://tailwindcss.com/docs/outline-color
       */
      "outline-color": [{
        outline: M()
      }],
      // ---------------
      // --- Effects ---
      // ---------------
      /**
       * Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow
       */
      shadow: [{
        shadow: [
          // Deprecated since Tailwind CSS v4.0.0
          "",
          "none",
          u,
          Wo,
          Ko
        ]
      }],
      /**
       * Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-shadow-color
       */
      "shadow-color": [{
        shadow: M()
      }],
      /**
       * Inset Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-shadow
       */
      "inset-shadow": [{
        "inset-shadow": ["none", f, Wo, Ko]
      }],
      /**
       * Inset Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-shadow-color
       */
      "inset-shadow-color": [{
        "inset-shadow": M()
      }],
      /**
       * Ring Width
       * @see https://tailwindcss.com/docs/box-shadow#adding-a-ring
       */
      "ring-w": [{
        ring: O()
      }],
      /**
       * Ring Width Inset
       * @see https://v3.tailwindcss.com/docs/ring-width#inset-rings
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */
      "ring-w-inset": ["ring-inset"],
      /**
       * Ring Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-ring-color
       */
      "ring-color": [{
        ring: M()
      }],
      /**
       * Ring Offset Width
       * @see https://v3.tailwindcss.com/docs/ring-offset-width
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */
      "ring-offset-w": [{
        "ring-offset": [Te, Xr]
      }],
      /**
       * Ring Offset Color
       * @see https://v3.tailwindcss.com/docs/ring-offset-color
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */
      "ring-offset-color": [{
        "ring-offset": M()
      }],
      /**
       * Inset Ring Width
       * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-ring
       */
      "inset-ring-w": [{
        "inset-ring": O()
      }],
      /**
       * Inset Ring Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-ring-color
       */
      "inset-ring-color": [{
        "inset-ring": M()
      }],
      /**
       * Text Shadow
       * @see https://tailwindcss.com/docs/text-shadow
       */
      "text-shadow": [{
        "text-shadow": ["none", p, Wo, Ko]
      }],
      /**
       * Text Shadow Color
       * @see https://tailwindcss.com/docs/text-shadow#setting-the-shadow-color
       */
      "text-shadow-color": [{
        "text-shadow": M()
      }],
      /**
       * Opacity
       * @see https://tailwindcss.com/docs/opacity
       */
      opacity: [{
        opacity: [Te, pe, fe]
      }],
      /**
       * Mix Blend Mode
       * @see https://tailwindcss.com/docs/mix-blend-mode
       */
      "mix-blend": [{
        "mix-blend": [..._e(), "plus-darker", "plus-lighter"]
      }],
      /**
       * Background Blend Mode
       * @see https://tailwindcss.com/docs/background-blend-mode
       */
      "bg-blend": [{
        "bg-blend": _e()
      }],
      /**
       * Mask Clip
       * @see https://tailwindcss.com/docs/mask-clip
       */
      "mask-clip": [{
        "mask-clip": ["border", "padding", "content", "fill", "stroke", "view"]
      }, "mask-no-clip"],
      /**
       * Mask Composite
       * @see https://tailwindcss.com/docs/mask-composite
       */
      "mask-composite": [{
        mask: ["add", "subtract", "intersect", "exclude"]
      }],
      /**
       * Mask Image
       * @see https://tailwindcss.com/docs/mask-image
       */
      "mask-image-linear-pos": [{
        "mask-linear": [Te]
      }],
      "mask-image-linear-from-pos": [{
        "mask-linear-from": y()
      }],
      "mask-image-linear-to-pos": [{
        "mask-linear-to": y()
      }],
      "mask-image-linear-from-color": [{
        "mask-linear-from": M()
      }],
      "mask-image-linear-to-color": [{
        "mask-linear-to": M()
      }],
      "mask-image-t-from-pos": [{
        "mask-t-from": y()
      }],
      "mask-image-t-to-pos": [{
        "mask-t-to": y()
      }],
      "mask-image-t-from-color": [{
        "mask-t-from": M()
      }],
      "mask-image-t-to-color": [{
        "mask-t-to": M()
      }],
      "mask-image-r-from-pos": [{
        "mask-r-from": y()
      }],
      "mask-image-r-to-pos": [{
        "mask-r-to": y()
      }],
      "mask-image-r-from-color": [{
        "mask-r-from": M()
      }],
      "mask-image-r-to-color": [{
        "mask-r-to": M()
      }],
      "mask-image-b-from-pos": [{
        "mask-b-from": y()
      }],
      "mask-image-b-to-pos": [{
        "mask-b-to": y()
      }],
      "mask-image-b-from-color": [{
        "mask-b-from": M()
      }],
      "mask-image-b-to-color": [{
        "mask-b-to": M()
      }],
      "mask-image-l-from-pos": [{
        "mask-l-from": y()
      }],
      "mask-image-l-to-pos": [{
        "mask-l-to": y()
      }],
      "mask-image-l-from-color": [{
        "mask-l-from": M()
      }],
      "mask-image-l-to-color": [{
        "mask-l-to": M()
      }],
      "mask-image-x-from-pos": [{
        "mask-x-from": y()
      }],
      "mask-image-x-to-pos": [{
        "mask-x-to": y()
      }],
      "mask-image-x-from-color": [{
        "mask-x-from": M()
      }],
      "mask-image-x-to-color": [{
        "mask-x-to": M()
      }],
      "mask-image-y-from-pos": [{
        "mask-y-from": y()
      }],
      "mask-image-y-to-pos": [{
        "mask-y-to": y()
      }],
      "mask-image-y-from-color": [{
        "mask-y-from": M()
      }],
      "mask-image-y-to-color": [{
        "mask-y-to": M()
      }],
      "mask-image-radial": [{
        "mask-radial": [pe, fe]
      }],
      "mask-image-radial-from-pos": [{
        "mask-radial-from": y()
      }],
      "mask-image-radial-to-pos": [{
        "mask-radial-to": y()
      }],
      "mask-image-radial-from-color": [{
        "mask-radial-from": M()
      }],
      "mask-image-radial-to-color": [{
        "mask-radial-to": M()
      }],
      "mask-image-radial-shape": [{
        "mask-radial": ["circle", "ellipse"]
      }],
      "mask-image-radial-size": [{
        "mask-radial": [{
          closest: ["side", "corner"],
          farthest: ["side", "corner"]
        }]
      }],
      "mask-image-radial-pos": [{
        "mask-radial-at": T()
      }],
      "mask-image-conic-pos": [{
        "mask-conic": [Te]
      }],
      "mask-image-conic-from-pos": [{
        "mask-conic-from": y()
      }],
      "mask-image-conic-to-pos": [{
        "mask-conic-to": y()
      }],
      "mask-image-conic-from-color": [{
        "mask-conic-from": M()
      }],
      "mask-image-conic-to-color": [{
        "mask-conic-to": M()
      }],
      /**
       * Mask Mode
       * @see https://tailwindcss.com/docs/mask-mode
       */
      "mask-mode": [{
        mask: ["alpha", "luminance", "match"]
      }],
      /**
       * Mask Origin
       * @see https://tailwindcss.com/docs/mask-origin
       */
      "mask-origin": [{
        "mask-origin": ["border", "padding", "content", "fill", "stroke", "view"]
      }],
      /**
       * Mask Position
       * @see https://tailwindcss.com/docs/mask-position
       */
      "mask-position": [{
        mask: ge()
      }],
      /**
       * Mask Repeat
       * @see https://tailwindcss.com/docs/mask-repeat
       */
      "mask-repeat": [{
        mask: Me()
      }],
      /**
       * Mask Size
       * @see https://tailwindcss.com/docs/mask-size
       */
      "mask-size": [{
        mask: Ie()
      }],
      /**
       * Mask Type
       * @see https://tailwindcss.com/docs/mask-type
       */
      "mask-type": [{
        "mask-type": ["alpha", "luminance"]
      }],
      /**
       * Mask Image
       * @see https://tailwindcss.com/docs/mask-image
       */
      "mask-image": [{
        mask: ["none", pe, fe]
      }],
      // ---------------
      // --- Filters ---
      // ---------------
      /**
       * Filter
       * @see https://tailwindcss.com/docs/filter
       */
      filter: [{
        filter: [
          // Deprecated since Tailwind CSS v3.0.0
          "",
          "none",
          pe,
          fe
        ]
      }],
      /**
       * Blur
       * @see https://tailwindcss.com/docs/blur
       */
      blur: [{
        blur: Q()
      }],
      /**
       * Brightness
       * @see https://tailwindcss.com/docs/brightness
       */
      brightness: [{
        brightness: [Te, pe, fe]
      }],
      /**
       * Contrast
       * @see https://tailwindcss.com/docs/contrast
       */
      contrast: [{
        contrast: [Te, pe, fe]
      }],
      /**
       * Drop Shadow
       * @see https://tailwindcss.com/docs/drop-shadow
       */
      "drop-shadow": [{
        "drop-shadow": [
          // Deprecated since Tailwind CSS v4.0.0
          "",
          "none",
          h,
          Wo,
          Ko
        ]
      }],
      /**
       * Drop Shadow Color
       * @see https://tailwindcss.com/docs/filter-drop-shadow#setting-the-shadow-color
       */
      "drop-shadow-color": [{
        "drop-shadow": M()
      }],
      /**
       * Grayscale
       * @see https://tailwindcss.com/docs/grayscale
       */
      grayscale: [{
        grayscale: ["", Te, pe, fe]
      }],
      /**
       * Hue Rotate
       * @see https://tailwindcss.com/docs/hue-rotate
       */
      "hue-rotate": [{
        "hue-rotate": [Te, pe, fe]
      }],
      /**
       * Invert
       * @see https://tailwindcss.com/docs/invert
       */
      invert: [{
        invert: ["", Te, pe, fe]
      }],
      /**
       * Saturate
       * @see https://tailwindcss.com/docs/saturate
       */
      saturate: [{
        saturate: [Te, pe, fe]
      }],
      /**
       * Sepia
       * @see https://tailwindcss.com/docs/sepia
       */
      sepia: [{
        sepia: ["", Te, pe, fe]
      }],
      /**
       * Backdrop Filter
       * @see https://tailwindcss.com/docs/backdrop-filter
       */
      "backdrop-filter": [{
        "backdrop-filter": [
          // Deprecated since Tailwind CSS v3.0.0
          "",
          "none",
          pe,
          fe
        ]
      }],
      /**
       * Backdrop Blur
       * @see https://tailwindcss.com/docs/backdrop-blur
       */
      "backdrop-blur": [{
        "backdrop-blur": Q()
      }],
      /**
       * Backdrop Brightness
       * @see https://tailwindcss.com/docs/backdrop-brightness
       */
      "backdrop-brightness": [{
        "backdrop-brightness": [Te, pe, fe]
      }],
      /**
       * Backdrop Contrast
       * @see https://tailwindcss.com/docs/backdrop-contrast
       */
      "backdrop-contrast": [{
        "backdrop-contrast": [Te, pe, fe]
      }],
      /**
       * Backdrop Grayscale
       * @see https://tailwindcss.com/docs/backdrop-grayscale
       */
      "backdrop-grayscale": [{
        "backdrop-grayscale": ["", Te, pe, fe]
      }],
      /**
       * Backdrop Hue Rotate
       * @see https://tailwindcss.com/docs/backdrop-hue-rotate
       */
      "backdrop-hue-rotate": [{
        "backdrop-hue-rotate": [Te, pe, fe]
      }],
      /**
       * Backdrop Invert
       * @see https://tailwindcss.com/docs/backdrop-invert
       */
      "backdrop-invert": [{
        "backdrop-invert": ["", Te, pe, fe]
      }],
      /**
       * Backdrop Opacity
       * @see https://tailwindcss.com/docs/backdrop-opacity
       */
      "backdrop-opacity": [{
        "backdrop-opacity": [Te, pe, fe]
      }],
      /**
       * Backdrop Saturate
       * @see https://tailwindcss.com/docs/backdrop-saturate
       */
      "backdrop-saturate": [{
        "backdrop-saturate": [Te, pe, fe]
      }],
      /**
       * Backdrop Sepia
       * @see https://tailwindcss.com/docs/backdrop-sepia
       */
      "backdrop-sepia": [{
        "backdrop-sepia": ["", Te, pe, fe]
      }],
      // --------------
      // --- Tables ---
      // --------------
      /**
       * Border Collapse
       * @see https://tailwindcss.com/docs/border-collapse
       */
      "border-collapse": [{
        border: ["collapse", "separate"]
      }],
      /**
       * Border Spacing
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing": [{
        "border-spacing": B()
      }],
      /**
       * Border Spacing X
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-x": [{
        "border-spacing-x": B()
      }],
      /**
       * Border Spacing Y
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-y": [{
        "border-spacing-y": B()
      }],
      /**
       * Table Layout
       * @see https://tailwindcss.com/docs/table-layout
       */
      "table-layout": [{
        table: ["auto", "fixed"]
      }],
      /**
       * Caption Side
       * @see https://tailwindcss.com/docs/caption-side
       */
      caption: [{
        caption: ["top", "bottom"]
      }],
      // ---------------------------------
      // --- Transitions and Animation ---
      // ---------------------------------
      /**
       * Transition Property
       * @see https://tailwindcss.com/docs/transition-property
       */
      transition: [{
        transition: ["", "all", "colors", "opacity", "shadow", "transform", "none", pe, fe]
      }],
      /**
       * Transition Behavior
       * @see https://tailwindcss.com/docs/transition-behavior
       */
      "transition-behavior": [{
        transition: ["normal", "discrete"]
      }],
      /**
       * Transition Duration
       * @see https://tailwindcss.com/docs/transition-duration
       */
      duration: [{
        duration: [Te, "initial", pe, fe]
      }],
      /**
       * Transition Timing Function
       * @see https://tailwindcss.com/docs/transition-timing-function
       */
      ease: [{
        ease: ["linear", "initial", C, pe, fe]
      }],
      /**
       * Transition Delay
       * @see https://tailwindcss.com/docs/transition-delay
       */
      delay: [{
        delay: [Te, pe, fe]
      }],
      /**
       * Animation
       * @see https://tailwindcss.com/docs/animation
       */
      animate: [{
        animate: ["none", S, pe, fe]
      }],
      // ------------------
      // --- Transforms ---
      // ------------------
      /**
       * Backface Visibility
       * @see https://tailwindcss.com/docs/backface-visibility
       */
      backface: [{
        backface: ["hidden", "visible"]
      }],
      /**
       * Perspective
       * @see https://tailwindcss.com/docs/perspective
       */
      perspective: [{
        perspective: [v, pe, fe]
      }],
      /**
       * Perspective Origin
       * @see https://tailwindcss.com/docs/perspective-origin
       */
      "perspective-origin": [{
        "perspective-origin": F()
      }],
      /**
       * Rotate
       * @see https://tailwindcss.com/docs/rotate
       */
      rotate: [{
        rotate: Z()
      }],
      /**
       * Rotate X
       * @see https://tailwindcss.com/docs/rotate
       */
      "rotate-x": [{
        "rotate-x": Z()
      }],
      /**
       * Rotate Y
       * @see https://tailwindcss.com/docs/rotate
       */
      "rotate-y": [{
        "rotate-y": Z()
      }],
      /**
       * Rotate Z
       * @see https://tailwindcss.com/docs/rotate
       */
      "rotate-z": [{
        "rotate-z": Z()
      }],
      /**
       * Scale
       * @see https://tailwindcss.com/docs/scale
       */
      scale: [{
        scale: te()
      }],
      /**
       * Scale X
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-x": [{
        "scale-x": te()
      }],
      /**
       * Scale Y
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-y": [{
        "scale-y": te()
      }],
      /**
       * Scale Z
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-z": [{
        "scale-z": te()
      }],
      /**
       * Scale 3D
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-3d": ["scale-3d"],
      /**
       * Skew
       * @see https://tailwindcss.com/docs/skew
       */
      skew: [{
        skew: we()
      }],
      /**
       * Skew X
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-x": [{
        "skew-x": we()
      }],
      /**
       * Skew Y
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-y": [{
        "skew-y": we()
      }],
      /**
       * Transform
       * @see https://tailwindcss.com/docs/transform
       */
      transform: [{
        transform: [pe, fe, "", "none", "gpu", "cpu"]
      }],
      /**
       * Transform Origin
       * @see https://tailwindcss.com/docs/transform-origin
       */
      "transform-origin": [{
        origin: F()
      }],
      /**
       * Transform Style
       * @see https://tailwindcss.com/docs/transform-style
       */
      "transform-style": [{
        transform: ["3d", "flat"]
      }],
      /**
       * Translate
       * @see https://tailwindcss.com/docs/translate
       */
      translate: [{
        translate: _()
      }],
      /**
       * Translate X
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-x": [{
        "translate-x": _()
      }],
      /**
       * Translate Y
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-y": [{
        "translate-y": _()
      }],
      /**
       * Translate Z
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-z": [{
        "translate-z": _()
      }],
      /**
       * Translate None
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-none": ["translate-none"],
      // ---------------------
      // --- Interactivity ---
      // ---------------------
      /**
       * Accent Color
       * @see https://tailwindcss.com/docs/accent-color
       */
      accent: [{
        accent: M()
      }],
      /**
       * Appearance
       * @see https://tailwindcss.com/docs/appearance
       */
      appearance: [{
        appearance: ["none", "auto"]
      }],
      /**
       * Caret Color
       * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
       */
      "caret-color": [{
        caret: M()
      }],
      /**
       * Color Scheme
       * @see https://tailwindcss.com/docs/color-scheme
       */
      "color-scheme": [{
        scheme: ["normal", "dark", "light", "light-dark", "only-dark", "only-light"]
      }],
      /**
       * Cursor
       * @see https://tailwindcss.com/docs/cursor
       */
      cursor: [{
        cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", pe, fe]
      }],
      /**
       * Field Sizing
       * @see https://tailwindcss.com/docs/field-sizing
       */
      "field-sizing": [{
        "field-sizing": ["fixed", "content"]
      }],
      /**
       * Pointer Events
       * @see https://tailwindcss.com/docs/pointer-events
       */
      "pointer-events": [{
        "pointer-events": ["auto", "none"]
      }],
      /**
       * Resize
       * @see https://tailwindcss.com/docs/resize
       */
      resize: [{
        resize: ["none", "", "y", "x"]
      }],
      /**
       * Scroll Behavior
       * @see https://tailwindcss.com/docs/scroll-behavior
       */
      "scroll-behavior": [{
        scroll: ["auto", "smooth"]
      }],
      /**
       * Scroll Margin
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-m": [{
        "scroll-m": B()
      }],
      /**
       * Scroll Margin X
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mx": [{
        "scroll-mx": B()
      }],
      /**
       * Scroll Margin Y
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-my": [{
        "scroll-my": B()
      }],
      /**
       * Scroll Margin Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ms": [{
        "scroll-ms": B()
      }],
      /**
       * Scroll Margin End
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-me": [{
        "scroll-me": B()
      }],
      /**
       * Scroll Margin Top
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mt": [{
        "scroll-mt": B()
      }],
      /**
       * Scroll Margin Right
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mr": [{
        "scroll-mr": B()
      }],
      /**
       * Scroll Margin Bottom
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mb": [{
        "scroll-mb": B()
      }],
      /**
       * Scroll Margin Left
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ml": [{
        "scroll-ml": B()
      }],
      /**
       * Scroll Padding
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-p": [{
        "scroll-p": B()
      }],
      /**
       * Scroll Padding X
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-px": [{
        "scroll-px": B()
      }],
      /**
       * Scroll Padding Y
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-py": [{
        "scroll-py": B()
      }],
      /**
       * Scroll Padding Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-ps": [{
        "scroll-ps": B()
      }],
      /**
       * Scroll Padding End
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pe": [{
        "scroll-pe": B()
      }],
      /**
       * Scroll Padding Top
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pt": [{
        "scroll-pt": B()
      }],
      /**
       * Scroll Padding Right
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pr": [{
        "scroll-pr": B()
      }],
      /**
       * Scroll Padding Bottom
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pb": [{
        "scroll-pb": B()
      }],
      /**
       * Scroll Padding Left
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pl": [{
        "scroll-pl": B()
      }],
      /**
       * Scroll Snap Align
       * @see https://tailwindcss.com/docs/scroll-snap-align
       */
      "snap-align": [{
        snap: ["start", "end", "center", "align-none"]
      }],
      /**
       * Scroll Snap Stop
       * @see https://tailwindcss.com/docs/scroll-snap-stop
       */
      "snap-stop": [{
        snap: ["normal", "always"]
      }],
      /**
       * Scroll Snap Type
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-type": [{
        snap: ["none", "x", "y", "both"]
      }],
      /**
       * Scroll Snap Type Strictness
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-strictness": [{
        snap: ["mandatory", "proximity"]
      }],
      /**
       * Touch Action
       * @see https://tailwindcss.com/docs/touch-action
       */
      touch: [{
        touch: ["auto", "none", "manipulation"]
      }],
      /**
       * Touch Action X
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-x": [{
        "touch-pan": ["x", "left", "right"]
      }],
      /**
       * Touch Action Y
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-y": [{
        "touch-pan": ["y", "up", "down"]
      }],
      /**
       * Touch Action Pinch Zoom
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-pz": ["touch-pinch-zoom"],
      /**
       * User Select
       * @see https://tailwindcss.com/docs/user-select
       */
      select: [{
        select: ["none", "text", "all", "auto"]
      }],
      /**
       * Will Change
       * @see https://tailwindcss.com/docs/will-change
       */
      "will-change": [{
        "will-change": ["auto", "scroll", "contents", "transform", pe, fe]
      }],
      // -----------
      // --- SVG ---
      // -----------
      /**
       * Fill
       * @see https://tailwindcss.com/docs/fill
       */
      fill: [{
        fill: ["none", ...M()]
      }],
      /**
       * Stroke Width
       * @see https://tailwindcss.com/docs/stroke-width
       */
      "stroke-w": [{
        stroke: [Te, Ja, Xr, ei]
      }],
      /**
       * Stroke
       * @see https://tailwindcss.com/docs/stroke
       */
      stroke: [{
        stroke: ["none", ...M()]
      }],
      // ---------------------
      // --- Accessibility ---
      // ---------------------
      /**
       * Forced Color Adjust
       * @see https://tailwindcss.com/docs/forced-color-adjust
       */
      "forced-color-adjust": [{
        "forced-color-adjust": ["auto", "none"]
      }]
    },
    conflictingClassGroups: {
      overflow: ["overflow-x", "overflow-y"],
      overscroll: ["overscroll-x", "overscroll-y"],
      inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
      "inset-x": ["right", "left"],
      "inset-y": ["top", "bottom"],
      flex: ["basis", "grow", "shrink"],
      gap: ["gap-x", "gap-y"],
      p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
      px: ["pr", "pl"],
      py: ["pt", "pb"],
      m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
      mx: ["mr", "ml"],
      my: ["mt", "mb"],
      size: ["w", "h"],
      "font-size": ["leading"],
      "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
      "fvn-ordinal": ["fvn-normal"],
      "fvn-slashed-zero": ["fvn-normal"],
      "fvn-figure": ["fvn-normal"],
      "fvn-spacing": ["fvn-normal"],
      "fvn-fraction": ["fvn-normal"],
      "line-clamp": ["display", "overflow"],
      rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
      "rounded-s": ["rounded-ss", "rounded-es"],
      "rounded-e": ["rounded-se", "rounded-ee"],
      "rounded-t": ["rounded-tl", "rounded-tr"],
      "rounded-r": ["rounded-tr", "rounded-br"],
      "rounded-b": ["rounded-br", "rounded-bl"],
      "rounded-l": ["rounded-tl", "rounded-bl"],
      "border-spacing": ["border-spacing-x", "border-spacing-y"],
      "border-w": ["border-w-x", "border-w-y", "border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
      "border-w-x": ["border-w-r", "border-w-l"],
      "border-w-y": ["border-w-t", "border-w-b"],
      "border-color": ["border-color-x", "border-color-y", "border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
      "border-color-x": ["border-color-r", "border-color-l"],
      "border-color-y": ["border-color-t", "border-color-b"],
      translate: ["translate-x", "translate-y", "translate-none"],
      "translate-none": ["translate", "translate-x", "translate-y", "translate-z"],
      "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
      "scroll-mx": ["scroll-mr", "scroll-ml"],
      "scroll-my": ["scroll-mt", "scroll-mb"],
      "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
      "scroll-px": ["scroll-pr", "scroll-pl"],
      "scroll-py": ["scroll-pt", "scroll-pb"],
      touch: ["touch-x", "touch-y", "touch-pz"],
      "touch-x": ["touch"],
      "touch-y": ["touch"],
      "touch-pz": ["touch"]
    },
    conflictingClassGroupModifiers: {
      "font-size": ["leading"]
    },
    orderSensitiveModifiers: ["*", "**", "after", "backdrop", "before", "details-content", "file", "first-letter", "first-line", "marker", "placeholder", "selection"]
  };
}, t2 = /* @__PURE__ */ Dw(e2);
function ve(...e) {
  return t2(o0(e));
}
const yr = /* @__PURE__ */ D({
  __name: "Card",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("div", {
      "data-slot": "card",
      class: ke(
        d(ve)(
          "bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm",
          t.class
        )
      )
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), wr = /* @__PURE__ */ D({
  __name: "CardContent",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("div", {
      "data-slot": "card-content",
      class: ke(d(ve)("px-6", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), Co = /* @__PURE__ */ D({
  __name: "CardDescription",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("p", {
      "data-slot": "card-description",
      class: ke(d(ve)("text-muted-foreground text-sm", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), Ra = /* @__PURE__ */ D({
  __name: "CardHeader",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("div", {
      "data-slot": "card-header",
      class: ke(d(ve)("@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-1.5 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), Oa = /* @__PURE__ */ D({
  __name: "CardTitle",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("h3", {
      "data-slot": "card-title",
      class: ke(d(ve)("leading-none font-semibold", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), td = (e) => typeof e == "boolean" ? `${e}` : e === 0 ? "0" : e, rd = o0, Rl = (e, t) => (r) => {
  var a;
  if (t?.variants == null) return rd(e, r?.class, r?.className);
  const { variants: o, defaultVariants: n } = t, s = Object.keys(o).map((c) => {
    const u = r?.[c], f = n?.[c];
    if (u === null) return null;
    const p = td(u) || td(f);
    return o[c][p];
  }), i = r && Object.entries(r).reduce((c, u) => {
    let [f, p] = u;
    return p === void 0 || (c[f] = p), c;
  }, {}), l = t == null || (a = t.compoundVariants) === null || a === void 0 ? void 0 : a.reduce((c, u) => {
    let { class: f, className: p, ...h } = u;
    return Object.entries(h).every((m) => {
      let [v, x] = m;
      return Array.isArray(x) ? x.includes({
        ...n,
        ...i
      }[v]) : {
        ...n,
        ...i
      }[v] === x;
    }) ? [
      ...c,
      f,
      p
    ] : c;
  }, []);
  return rd(e, s, l, r?.class, r?.className);
};
function it(e, t) {
  const r = typeof e == "string" && !t ? `${e}Context` : t, a = Symbol(r);
  return [(s) => {
    const i = he(a, s);
    if (i || i === null) return i;
    throw new Error(`Injection \`${a.toString()}\` not found. Component must be used within ${Array.isArray(e) ? `one of the following components: ${e.join(", ")}` : `\`${e}\``}`);
  }, (s) => ($a(a, s), s)];
}
function Ct() {
  let e = document.activeElement;
  if (e == null) return null;
  for (; e != null && e.shadowRoot != null && e.shadowRoot.activeElement != null; ) e = e.shadowRoot.activeElement;
  return e;
}
function g0(e, t, r) {
  const a = r.originalEvent.target, o = new CustomEvent(e, {
    bubbles: !1,
    cancelable: !0,
    detail: r
  });
  t && a.addEventListener(e, t, { once: !0 }), a.dispatchEvent(o);
}
function r2(e) {
  return e == null;
}
function Ol(e) {
  return e ? e.flatMap((t) => t.type === Be ? Ol(t.children) : [t]) : [];
}
const a2 = ["INPUT", "TEXTAREA"];
function o2(e, t, r, a = {}) {
  if (!t || a.enableIgnoredElement && a2.includes(t.nodeName)) return null;
  const { arrowKeyOptions: o = "both", attributeName: n = "[data-reka-collection-item]", itemsArray: s = [], loop: i = !0, dir: l = "ltr", preventScroll: c = !0, focus: u = !1 } = a, [f, p, h, m, v, x] = [
    e.key === "ArrowRight",
    e.key === "ArrowLeft",
    e.key === "ArrowUp",
    e.key === "ArrowDown",
    e.key === "Home",
    e.key === "End"
  ], C = h || m, S = f || p;
  if (!v && !x && (!C && !S || o === "vertical" && S || o === "horizontal" && C)) return null;
  const E = r ? Array.from(r.querySelectorAll(n)) : s;
  if (!E.length) return null;
  c && e.preventDefault();
  let T = null;
  return S || C ? T = m0(E, t, {
    goForward: C ? m : l === "ltr" ? f : p,
    loop: i
  }) : v ? T = E.at(0) || null : x && (T = E.at(-1) || null), u && T?.focus(), T;
}
function m0(e, t, r, a = e.length) {
  if (--a === 0) return null;
  const o = e.indexOf(t), n = r.goForward ? o + 1 : o - 1;
  if (!r.loop && (n < 0 || n >= e.length)) return null;
  const s = (n + e.length) % e.length, i = e[s];
  return i ? i.hasAttribute("disabled") && i.getAttribute("disabled") !== "false" ? m0(e, i, r, a) : i : null;
}
const [v0, c$] = it("ConfigProvider");
function n2(e, t) {
  var r;
  const a = ar();
  return Xe(() => {
    a.value = e();
  }, {
    ...t,
    flush: (r = t?.flush) !== null && r !== void 0 ? r : "sync"
  }), cl(a);
}
function qo(e, t) {
  return $o() ? (In(e, t), !0) : !1;
}
// @__NO_SIDE_EFFECTS__
function s2() {
  const e = /* @__PURE__ */ new Set(), t = (n) => {
    e.delete(n);
  };
  return {
    on: (n) => {
      e.add(n);
      const s = () => t(n);
      return qo(s), { off: s };
    },
    off: t,
    trigger: (...n) => Promise.all(Array.from(e).map((s) => s(...n))),
    clear: () => {
      e.clear();
    }
  };
}
// @__NO_SIDE_EFFECTS__
function i2(e) {
  let t = !1, r;
  const a = Dn(!0);
  return (...o) => (t || (r = a.run(() => e(...o)), t = !0), r);
}
const ur = typeof window < "u" && typeof document < "u";
typeof WorkerGlobalScope < "u" && globalThis instanceof WorkerGlobalScope;
const l2 = (e) => typeof e < "u", c2 = Object.prototype.toString, u2 = (e) => c2.call(e) === "[object Object]";
function ti(e) {
  return Array.isArray(e) ? e : [e];
}
function d2(e) {
  return bt();
}
// @__NO_SIDE_EFFECTS__
function b0(e) {
  if (!ur) return e;
  let t = 0, r, a;
  const o = () => {
    t -= 1, a && t <= 0 && (a.stop(), r = void 0, a = void 0);
  };
  return (...n) => (t += 1, a || (a = Dn(!0), r = a.run(() => e(...n))), qo(o), r);
}
function f2(e) {
  return Ve(e) ? Rt(new Proxy({}, {
    get(t, r, a) {
      return d(Reflect.get(e.value, r, a));
    },
    set(t, r, a) {
      return Ve(e.value[r]) && !Ve(a) ? e.value[r].value = a : e.value[r] = a, !0;
    },
    deleteProperty(t, r) {
      return Reflect.deleteProperty(e.value, r);
    },
    has(t, r) {
      return Reflect.has(e.value, r);
    },
    ownKeys() {
      return Object.keys(e.value);
    },
    getOwnPropertyDescriptor() {
      return {
        enumerable: !0,
        configurable: !0
      };
    }
  })) : Rt(e);
}
function p2(e) {
  return f2(L(e));
}
function h2(e, ...t) {
  const r = t.flat(), a = r[0];
  return p2(() => Object.fromEntries(typeof a == "function" ? Object.entries(ht(e)).filter(([o, n]) => !a(Je(n), o)) : Object.entries(ht(e)).filter((o) => !r.includes(o[0]))));
}
function y0(e, t = 1e4) {
  return Kh((r, a) => {
    let o = Je(e), n;
    const s = () => setTimeout(() => {
      o = Je(e), a();
    }, Je(t));
    return qo(() => {
      clearTimeout(n);
    }), {
      get() {
        return r(), o;
      },
      set(i) {
        o = i, a(), clearTimeout(n), n = s();
      }
    };
  });
}
function g2(e, t) {
  d2() && jn(e, t);
}
function w0(e, t, r = {}) {
  const { immediate: a = !0, immediateCallback: o = !1 } = r, n = ar(!1);
  let s;
  function i() {
    s && (clearTimeout(s), s = void 0);
  }
  function l() {
    n.value = !1, i();
  }
  function c(...u) {
    o && e(), i(), n.value = !0, s = setTimeout(() => {
      n.value = !1, s = void 0, e(...u);
    }, Je(t));
  }
  return a && (n.value = !0, ur && c()), qo(l), {
    isPending: ea(n),
    start: c,
    stop: l
  };
}
function m2(e, t, r) {
  return Ke(e, t, {
    ...r,
    immediate: !0
  });
}
const Bl = ur ? window : void 0;
function Va(e) {
  var t;
  const r = Je(e);
  return (t = r?.$el) !== null && t !== void 0 ? t : r;
}
function Ao(...e) {
  const t = (a, o, n, s) => (a.addEventListener(o, n, s), () => a.removeEventListener(o, n, s)), r = L(() => {
    const a = ti(Je(e[0])).filter((o) => o != null);
    return a.every((o) => typeof o != "string") ? a : void 0;
  });
  return m2(() => {
    var a, o;
    return [
      (a = (o = r.value) === null || o === void 0 ? void 0 : o.map((n) => Va(n))) !== null && a !== void 0 ? a : [Bl].filter((n) => n != null),
      ti(Je(r.value ? e[1] : e[0])),
      ti(d(r.value ? e[2] : e[1])),
      Je(r.value ? e[3] : e[2])
    ];
  }, ([a, o, n, s], i, l) => {
    if (!a?.length || !o?.length || !n?.length) return;
    const c = u2(s) ? { ...s } : s, u = a.flatMap((f) => o.flatMap((p) => n.map((h) => t(f, p, h, c))));
    l(() => {
      u.forEach((f) => f());
    });
  }, { flush: "post" });
}
// @__NO_SIDE_EFFECTS__
function v2() {
  const e = ar(!1), t = bt();
  return t && at(() => {
    e.value = !0;
  }, t), e;
}
function b2(e) {
  return typeof e == "function" ? e : typeof e == "string" ? (t) => t.key === e : Array.isArray(e) ? (t) => e.includes(t.key) : () => !0;
}
function y2(...e) {
  let t, r, a = {};
  e.length === 3 ? (t = e[0], r = e[1], a = e[2]) : e.length === 2 ? typeof e[1] == "object" ? (t = !0, r = e[0], a = e[1]) : (t = e[0], r = e[1]) : (t = !0, r = e[0]);
  const { target: o = Bl, eventName: n = "keydown", passive: s = !1, dedupe: i = !1 } = a, l = b2(t);
  return Ao(o, n, (u) => {
    u.repeat && Je(i) || l(u) && r(u);
  }, s);
}
function w2(e) {
  return JSON.parse(JSON.stringify(e));
}
// @__NO_SIDE_EFFECTS__
function Gr(e, t, r, a = {}) {
  var o, n;
  const { clone: s = !1, passive: i = !1, eventName: l, deep: c = !1, defaultValue: u, shouldEmit: f } = a, p = bt(), h = r || p?.emit || (p == null || (o = p.$emit) === null || o === void 0 ? void 0 : o.bind(p)) || (p == null || (n = p.proxy) === null || n === void 0 || (n = n.$emit) === null || n === void 0 ? void 0 : n.bind(p?.proxy));
  let m = l;
  t || (t = "modelValue"), m = m || `update:${t.toString()}`;
  const v = (S) => s ? typeof s == "function" ? s(S) : w2(S) : S, x = () => l2(e[t]) ? v(e[t]) : u, C = (S) => {
    f ? f(S) && h(m, S) : h(m, S);
  };
  if (i) {
    const S = K(x());
    let E = !1;
    return Ke(() => e[t], (T) => {
      E || (E = !0, S.value = v(T), et(() => E = !1));
    }), Ke(S, (T) => {
      !E && (T !== e[t] || c) && C(T);
    }, { deep: c }), S;
  } else return L({
    get() {
      return x();
    },
    set(S) {
      C(S);
    }
  });
}
function ri(e) {
  if (e === null || typeof e != "object")
    return !1;
  const t = Object.getPrototypeOf(e);
  return t !== null && t !== Object.prototype && Object.getPrototypeOf(t) !== null || Symbol.iterator in e ? !1 : Symbol.toStringTag in e ? Object.prototype.toString.call(e) === "[object Module]" : !0;
}
function Vi(e, t, r = ".", a) {
  if (!ri(t))
    return Vi(e, {}, r, a);
  const o = Object.assign({}, t);
  for (const n in e) {
    if (n === "__proto__" || n === "constructor")
      continue;
    const s = e[n];
    s != null && (a && a(o, n, s, r) || (Array.isArray(s) && Array.isArray(o[n]) ? o[n] = [...s, ...o[n]] : ri(s) && ri(o[n]) ? o[n] = Vi(
      s,
      o[n],
      (r ? `${r}.` : "") + n.toString(),
      a
    ) : o[n] = s));
  }
  return o;
}
function x2(e) {
  return (...t) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    t.reduce((r, a) => Vi(r, a, "", e), {})
  );
}
const _2 = x2(), k2 = /* @__PURE__ */ b0(() => {
  const e = K(/* @__PURE__ */ new Map()), t = K(), r = L(() => {
    for (const n of e.value.values()) if (n) return !0;
    return !1;
  }), a = v0({ scrollBody: K(!0) }), o = () => {
    document.body.style.paddingRight = "", document.body.style.marginRight = "", document.body.style.pointerEvents = "", document.documentElement.style.removeProperty("--scrollbar-width"), document.body.style.overflow = t.value ?? "", t.value = void 0;
  };
  return Ke(r, (n, s) => {
    if (!ur) return;
    if (!n) {
      s && o();
      return;
    }
    t.value === void 0 && (t.value = document.body.style.overflow);
    const i = window.innerWidth - document.documentElement.clientWidth, l = {
      padding: i,
      margin: 0
    }, c = a.scrollBody?.value ? typeof a.scrollBody.value == "object" ? _2({
      padding: a.scrollBody.value.padding === !0 ? i : a.scrollBody.value.padding,
      margin: a.scrollBody.value.margin === !0 ? i : a.scrollBody.value.margin
    }, l) : l : {
      padding: 0,
      margin: 0
    };
    i > 0 && (document.body.style.paddingRight = typeof c.padding == "number" ? `${c.padding}px` : String(c.padding), document.body.style.marginRight = typeof c.margin == "number" ? `${c.margin}px` : String(c.margin), document.documentElement.style.setProperty("--scrollbar-width", `${i}px`), document.body.style.overflow = "hidden"), et(() => {
      document.body.style.pointerEvents = "none", document.body.style.overflow = "hidden";
    });
  }, {
    immediate: !0,
    flush: "sync"
  }), e;
});
function Dl(e) {
  const t = Math.random().toString(36).substring(2, 7), r = k2();
  r.value.set(t, e ?? !1);
  const a = L({
    get: () => r.value.get(t) ?? !1,
    set: (o) => r.value.set(t, o)
  });
  return g2(() => {
    r.value.delete(t);
  }), a;
}
function ns(e) {
  const t = v0({ dir: K("ltr") });
  return L(() => e?.value || t.dir?.value || "ltr");
}
function Ha(e) {
  const t = bt(), r = t?.type.emits, a = {};
  return r?.length || console.warn(`No emitted event found. Please check component: ${t?.type.__name}`), r?.forEach((o) => {
    a[ro(At(o))] = (...n) => e(o, ...n);
  }), a;
}
let ai = 0;
function x0() {
  Xe((e) => {
    if (!ur) return;
    const t = document.querySelectorAll("[data-reka-focus-guard]");
    document.body.insertAdjacentElement("afterbegin", t[0] ?? ad()), document.body.insertAdjacentElement("beforeend", t[1] ?? ad()), ai++, e(() => {
      ai === 1 && document.querySelectorAll("[data-reka-focus-guard]").forEach((r) => r.remove()), ai--;
    });
  });
}
function ad() {
  const e = document.createElement("span");
  return e.setAttribute("data-reka-focus-guard", ""), e.tabIndex = 0, e.style.outline = "none", e.style.opacity = "0", e.style.position = "fixed", e.style.pointerEvents = "none", e;
}
function be() {
  const e = bt(), t = K(), r = L(() => ["#text", "#comment"].includes(t.value?.$el.nodeName) ? t.value?.$el.nextElementSibling : Va(t)), a = Object.assign({}, e.exposed), o = {};
  for (const s in e.props) Object.defineProperty(o, s, {
    enumerable: !0,
    configurable: !0,
    get: () => e.props[s]
  });
  if (Object.keys(a).length > 0) for (const s in a) Object.defineProperty(o, s, {
    enumerable: !0,
    configurable: !0,
    get: () => a[s]
  });
  Object.defineProperty(o, "$el", {
    enumerable: !0,
    configurable: !0,
    get: () => e.vnode.el
  }), e.exposed = o;
  function n(s) {
    if (t.value = s, !!s && (Object.defineProperty(o, "$el", {
      enumerable: !0,
      configurable: !0,
      get: () => s instanceof Element ? s : s.$el
    }), !(s instanceof Element) && !Object.hasOwn(s, "$el"))) {
      const i = s.$.exposed, l = Object.assign({}, o);
      for (const c in i) Object.defineProperty(l, c, {
        enumerable: !0,
        configurable: !0,
        get: () => i[c]
      });
      e.exposed = l;
    }
  }
  return {
    forwardRef: n,
    currentRef: t,
    currentElement: r
  };
}
function da(e) {
  const t = bt(), r = Object.keys(t?.type.props ?? {}).reduce((o, n) => {
    const s = (t?.type.props[n]).default;
    return s !== void 0 && (o[n] = s), o;
  }, {}), a = Jh(e);
  return L(() => {
    const o = {}, n = t?.vnode.props ?? {};
    return Object.keys(n).forEach((s) => {
      o[At(s)] = n[s];
    }), Object.keys({
      ...r,
      ...o
    }).reduce((s, i) => (a.value[i] !== void 0 && (s[i] = a.value[i]), s), {});
  });
}
function rt(e, t) {
  const r = da(e), a = t ? Ha(t) : {};
  return L(() => ({
    ...r.value,
    ...a
  }));
}
function C2(e, t) {
  const r = y0(!1, 300);
  qo(() => {
    r.value = !1;
  });
  const a = K(null), o = /* @__PURE__ */ s2();
  function n() {
    a.value = null, r.value = !1;
  }
  function s(i, l) {
    const c = i.currentTarget, u = {
      x: i.clientX,
      y: i.clientY
    }, f = A2(u, c.getBoundingClientRect()), p = S2(u, f, 1), h = E2(l.getBoundingClientRect()), m = P2([...p, ...h]);
    a.value = m, r.value = !0;
  }
  return Xe((i) => {
    if (e.value && t.value) {
      const l = (u) => s(u, t.value), c = (u) => s(u, e.value);
      e.value.addEventListener("pointerleave", l), t.value.addEventListener("pointerleave", c), i(() => {
        e.value?.removeEventListener("pointerleave", l), t.value?.removeEventListener("pointerleave", c);
      });
    }
  }), Xe((i) => {
    if (a.value) {
      const l = (c) => {
        if (!a.value || !(c.target instanceof Element)) return;
        const u = c.target, f = {
          x: c.clientX,
          y: c.clientY
        }, p = e.value?.contains(u) || t.value?.contains(u), h = !$2(f, a.value), m = !!u.closest("[data-grace-area-trigger]");
        p ? n() : (h || m) && (n(), o.trigger());
      };
      e.value?.ownerDocument.addEventListener("pointermove", l), i(() => e.value?.ownerDocument.removeEventListener("pointermove", l));
    }
  }), {
    isPointerInTransit: r,
    onPointerExit: o.on
  };
}
function A2(e, t) {
  const r = Math.abs(t.top - e.y), a = Math.abs(t.bottom - e.y), o = Math.abs(t.right - e.x), n = Math.abs(t.left - e.x);
  switch (Math.min(r, a, o, n)) {
    case n:
      return "left";
    case o:
      return "right";
    case r:
      return "top";
    case a:
      return "bottom";
    default:
      throw new Error("unreachable");
  }
}
function S2(e, t, r = 5) {
  const a = [];
  switch (t) {
    case "top":
      a.push({
        x: e.x - r,
        y: e.y + r
      }, {
        x: e.x + r,
        y: e.y + r
      });
      break;
    case "bottom":
      a.push({
        x: e.x - r,
        y: e.y - r
      }, {
        x: e.x + r,
        y: e.y - r
      });
      break;
    case "left":
      a.push({
        x: e.x + r,
        y: e.y - r
      }, {
        x: e.x + r,
        y: e.y + r
      });
      break;
    case "right":
      a.push({
        x: e.x - r,
        y: e.y - r
      }, {
        x: e.x - r,
        y: e.y + r
      });
      break;
  }
  return a;
}
function E2(e) {
  const { top: t, right: r, bottom: a, left: o } = e;
  return [
    {
      x: o,
      y: t
    },
    {
      x: r,
      y: t
    },
    {
      x: r,
      y: a
    },
    {
      x: o,
      y: a
    }
  ];
}
function $2(e, t) {
  const { x: r, y: a } = e;
  let o = !1;
  for (let n = 0, s = t.length - 1; n < t.length; s = n++) {
    const i = t[n].x, l = t[n].y, c = t[s].x, u = t[s].y;
    l > a != u > a && r < (c - i) * (a - l) / (u - l) + i && (o = !o);
  }
  return o;
}
function P2(e) {
  const t = e.slice();
  return t.sort((r, a) => r.x < a.x ? -1 : r.x > a.x ? 1 : r.y < a.y ? -1 : r.y > a.y ? 1 : 0), T2(t);
}
function T2(e) {
  if (e.length <= 1) return e.slice();
  const t = [];
  for (let a = 0; a < e.length; a++) {
    const o = e[a];
    for (; t.length >= 2; ) {
      const n = t[t.length - 1], s = t[t.length - 2];
      if ((n.x - s.x) * (o.y - s.y) >= (n.y - s.y) * (o.x - s.x)) t.pop();
      else break;
    }
    t.push(o);
  }
  t.pop();
  const r = [];
  for (let a = e.length - 1; a >= 0; a--) {
    const o = e[a];
    for (; r.length >= 2; ) {
      const n = r[r.length - 1], s = r[r.length - 2];
      if ((n.x - s.x) * (o.y - s.y) >= (n.y - s.y) * (o.x - s.x)) r.pop();
      else break;
    }
    r.push(o);
  }
  return r.pop(), t.length === 1 && r.length === 1 && t[0].x === r[0].x && t[0].y === r[0].y ? t : t.concat(r);
}
var M2 = function(e) {
  if (typeof document > "u")
    return null;
  var t = Array.isArray(e) ? e[0] : e;
  return t.ownerDocument.body;
}, va = /* @__PURE__ */ new WeakMap(), Go = /* @__PURE__ */ new WeakMap(), Jo = {}, oi = 0, _0 = function(e) {
  return e && (e.host || _0(e.parentNode));
}, R2 = function(e, t) {
  return t.map(function(r) {
    if (e.contains(r))
      return r;
    var a = _0(r);
    return a && e.contains(a) ? a : (console.error("aria-hidden", r, "in not contained inside", e, ". Doing nothing"), null);
  }).filter(function(r) {
    return !!r;
  });
}, O2 = function(e, t, r, a) {
  var o = R2(t, Array.isArray(e) ? e : [e]);
  Jo[r] || (Jo[r] = /* @__PURE__ */ new WeakMap());
  var n = Jo[r], s = [], i = /* @__PURE__ */ new Set(), l = new Set(o), c = function(f) {
    !f || i.has(f) || (i.add(f), c(f.parentNode));
  };
  o.forEach(c);
  var u = function(f) {
    !f || l.has(f) || Array.prototype.forEach.call(f.children, function(p) {
      if (i.has(p))
        u(p);
      else
        try {
          var h = p.getAttribute(a), m = h !== null && h !== "false", v = (va.get(p) || 0) + 1, x = (n.get(p) || 0) + 1;
          va.set(p, v), n.set(p, x), s.push(p), v === 1 && m && Go.set(p, !0), x === 1 && p.setAttribute(r, "true"), m || p.setAttribute(a, "true");
        } catch (C) {
          console.error("aria-hidden: cannot operate on ", p, C);
        }
    });
  };
  return u(t), i.clear(), oi++, function() {
    s.forEach(function(f) {
      var p = va.get(f) - 1, h = n.get(f) - 1;
      va.set(f, p), n.set(f, h), p || (Go.has(f) || f.removeAttribute(a), Go.delete(f)), h || f.removeAttribute(r);
    }), oi--, oi || (va = /* @__PURE__ */ new WeakMap(), va = /* @__PURE__ */ new WeakMap(), Go = /* @__PURE__ */ new WeakMap(), Jo = {});
  };
}, B2 = function(e, t, r) {
  r === void 0 && (r = "data-aria-hidden");
  var a = Array.from(Array.isArray(e) ? e : [e]), o = M2(e);
  return o ? (a.push.apply(a, Array.from(o.querySelectorAll("[aria-live], script"))), O2(a, o, r, "aria-hidden")) : function() {
    return null;
  };
};
function Il(e) {
  let t;
  Ke(() => Va(e), (r) => {
    r ? t = B2(r) : t && t();
  }), $r(() => {
    t && t();
  });
}
function lr(e, t = "reka") {
  return `${t}-${lg?.()}`;
}
function D2(e) {
  const t = K(), r = L(() => t.value?.width ?? 0), a = L(() => t.value?.height ?? 0);
  return at(() => {
    const o = Va(e);
    if (o) {
      t.value = {
        width: o.offsetWidth,
        height: o.offsetHeight
      };
      const n = new ResizeObserver((s) => {
        if (!Array.isArray(s) || !s.length) return;
        const i = s[0];
        let l, c;
        if ("borderBoxSize" in i) {
          const u = i.borderBoxSize, f = Array.isArray(u) ? u[0] : u;
          l = f.inlineSize, c = f.blockSize;
        } else
          l = o.offsetWidth, c = o.offsetHeight;
        t.value = {
          width: l,
          height: c
        };
      });
      return n.observe(o, { box: "border-box" }), () => n.unobserve(o);
    } else t.value = void 0;
  }), {
    width: r,
    height: a
  };
}
function I2(e, t) {
  const r = K(e);
  function a(n) {
    return t[r.value][n] ?? r.value;
  }
  return {
    state: r,
    dispatch: (n) => {
      r.value = a(n);
    }
  };
}
function q2(e) {
  const t = y0("", 1e3);
  return {
    search: t,
    handleTypeaheadSearch: (o, n) => {
      t.value = t.value + o;
      {
        const s = Ct(), i = n.map((p) => ({
          ...p,
          textValue: p.value?.textValue ?? p.ref.textContent?.trim() ?? ""
        })), l = i.find((p) => p.ref === s), c = i.map((p) => p.textValue), u = N2(c, t.value, l?.textValue), f = i.find((p) => p.textValue === u);
        return f && f.ref.focus(), f?.ref;
      }
    },
    resetTypeahead: () => {
      t.value = "";
    }
  };
}
function L2(e, t) {
  return e.map((r, a) => e[(t + a) % e.length]);
}
function N2(e, t, r) {
  const o = t.length > 1 && Array.from(t).every((c) => c === t[0]) ? t[0] : t, n = r ? e.indexOf(r) : -1;
  let s = L2(e, Math.max(n, 0));
  o.length === 1 && (s = s.filter((c) => c !== r));
  const l = s.find((c) => c.toLowerCase().startsWith(o.toLowerCase()));
  return l !== r ? l : void 0;
}
function V2(e, t) {
  const r = K({}), a = K("none"), o = K(e), n = e.value ? "mounted" : "unmounted";
  let s;
  const i = t.value?.ownerDocument.defaultView ?? Bl, { state: l, dispatch: c } = I2(n, {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: { MOUNT: "mounted" }
  }), u = (x) => {
    if (ur) {
      const C = new CustomEvent(x, {
        bubbles: !1,
        cancelable: !1
      });
      t.value?.dispatchEvent(C);
    }
  };
  Ke(e, async (x, C) => {
    const S = C !== x;
    if (await et(), S) {
      const E = a.value, T = Yo(t.value);
      x ? (c("MOUNT"), u("enter"), T === "none" && u("after-enter")) : T === "none" || T === "undefined" || r.value?.display === "none" ? (c("UNMOUNT"), u("leave"), u("after-leave")) : C && E !== T ? (c("ANIMATION_OUT"), u("leave")) : (c("UNMOUNT"), u("after-leave"));
    }
  }, { immediate: !0 });
  const f = (x) => {
    const C = Yo(t.value), S = C.includes(CSS.escape(x.animationName)), E = l.value === "mounted" ? "enter" : "leave";
    if (x.target === t.value && S && (u(`after-${E}`), c("ANIMATION_END"), !o.value)) {
      const T = t.value.style.animationFillMode;
      t.value.style.animationFillMode = "forwards", s = i?.setTimeout(() => {
        t.value?.style.animationFillMode === "forwards" && (t.value.style.animationFillMode = T);
      });
    }
    x.target === t.value && C === "none" && c("ANIMATION_END");
  }, p = (x) => {
    x.target === t.value && (a.value = Yo(t.value));
  }, h = Ke(t, (x, C) => {
    x ? (r.value = getComputedStyle(x), x.addEventListener("animationstart", p), x.addEventListener("animationcancel", f), x.addEventListener("animationend", f)) : (c("ANIMATION_END"), s !== void 0 && i?.clearTimeout(s), C?.removeEventListener("animationstart", p), C?.removeEventListener("animationcancel", f), C?.removeEventListener("animationend", f));
  }, { immediate: !0 }), m = Ke(l, () => {
    const x = Yo(t.value);
    a.value = l.value === "mounted" ? x : "none";
  });
  return $r(() => {
    h(), m();
  }), { isPresent: L(() => ["mounted", "unmountSuspended"].includes(l.value)) };
}
function Yo(e) {
  return e && getComputedStyle(e).animationName || "none";
}
var Fa = /* @__PURE__ */ D({
  name: "Presence",
  props: {
    present: {
      type: Boolean,
      required: !0
    },
    forceMount: { type: Boolean }
  },
  slots: {},
  setup(e, { slots: t, expose: r }) {
    const { present: a, forceMount: o } = ht(e), n = K(), { isPresent: s } = V2(a, n);
    r({ present: s });
    let i = t.default({ present: s.value });
    i = Ol(i || []);
    const l = bt();
    if (i && i?.length > 1) {
      const c = l?.parent?.type.name ? `<${l.parent.type.name} />` : "component";
      throw new Error([
        `Detected an invalid children for \`${c}\` for  \`Presence\` component.`,
        "",
        "Note: Presence works similarly to `v-if` directly, but it waits for animation/transition to finished before unmounting. So it expect only one direct child of valid VNode type.",
        "You can apply a few solutions:",
        ["Provide a single child element so that `presence` directive attach correctly.", "Ensure the first child is an actual element instead of a raw text node or comment node."].map((u) => `  - ${u}`).join(`
`)
      ].join(`
`));
    }
    return () => o.value || a.value || s.value ? Nt(t.default({ present: s.value })[0], { ref: (c) => {
      const u = Va(c);
      return typeof u?.hasAttribute > "u" || (u?.hasAttribute("data-reka-popper-content-wrapper") ? n.value = u.firstElementChild : n.value = u), u;
    } }) : null;
  }
});
const Hi = /* @__PURE__ */ D({
  name: "PrimitiveSlot",
  inheritAttrs: !1,
  setup(e, { attrs: t, slots: r }) {
    return () => {
      if (!r.default) return null;
      const a = Ol(r.default()), o = a.findIndex((l) => l.type !== sr);
      if (o === -1) return a;
      const n = a[o];
      delete n.props?.ref;
      const s = n.props ? re(t, n.props) : t, i = sa({
        ...n,
        props: {}
      }, s);
      return a.length === 1 ? i : (a[o] = i, a);
    };
  }
}), H2 = [
  "area",
  "img",
  "input"
], Re = /* @__PURE__ */ D({
  name: "Primitive",
  inheritAttrs: !1,
  props: {
    asChild: {
      type: Boolean,
      default: !1
    },
    as: {
      type: [String, Object],
      default: "div"
    }
  },
  setup(e, { attrs: t, slots: r }) {
    const a = e.asChild ? "template" : e.as;
    return typeof a == "string" && H2.includes(a) ? () => Nt(a, t) : a !== "template" ? () => Nt(e.as, t, { default: r.default }) : () => Nt(Hi, t, { default: r.default });
  }
});
function od() {
  const e = K(), t = L(() => ["#text", "#comment"].includes(e.value?.$el.nodeName) ? e.value?.$el.nextElementSibling : Va(e));
  return {
    primitiveElement: e,
    currentElement: t
  };
}
const [F2, z2] = it("CollapsibleRoot");
var j2 = /* @__PURE__ */ D({
  __name: "CollapsibleRoot",
  props: {
    defaultOpen: {
      type: Boolean,
      required: !1,
      default: !1
    },
    open: {
      type: Boolean,
      required: !1,
      default: void 0
    },
    disabled: {
      type: Boolean,
      required: !1
    },
    unmountOnHide: {
      type: Boolean,
      required: !1,
      default: !0
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: ["update:open"],
  setup(e, { expose: t, emit: r }) {
    const a = e, n = /* @__PURE__ */ Gr(a, "open", r, {
      defaultValue: a.defaultOpen,
      passive: a.open === void 0
    }), { disabled: s, unmountOnHide: i } = ht(a);
    return z2({
      contentId: "",
      disabled: s,
      open: n,
      unmountOnHide: i,
      onOpenToggle: () => {
        s.value || (n.value = !n.value);
      }
    }), t({ open: n }), be(), (l, c) => (g(), N(d(Re), {
      as: l.as,
      "as-child": a.asChild,
      "data-state": d(n) ? "open" : "closed",
      "data-disabled": d(s) ? "" : void 0
    }, {
      default: b(() => [q(l.$slots, "default", { open: d(n) })]),
      _: 3
    }, 8, [
      "as",
      "as-child",
      "data-state",
      "data-disabled"
    ]));
  }
}), U2 = j2, Z2 = /* @__PURE__ */ D({
  __name: "CollapsibleTrigger",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "button"
    }
  },
  setup(e) {
    const t = e;
    be();
    const r = F2();
    return (a, o) => (g(), N(d(Re), {
      type: a.as === "button" ? "button" : void 0,
      as: a.as,
      "as-child": t.asChild,
      "aria-controls": d(r).contentId,
      "aria-expanded": d(r).open.value,
      "data-state": d(r).open.value ? "open" : "closed",
      "data-disabled": d(r).disabled?.value ? "" : void 0,
      disabled: d(r).disabled?.value,
      onClick: d(r).onOpenToggle
    }, {
      default: b(() => [q(a.$slots, "default")]),
      _: 3
    }, 8, [
      "type",
      "as",
      "as-child",
      "aria-controls",
      "aria-expanded",
      "data-state",
      "data-disabled",
      "disabled",
      "onClick"
    ]));
  }
}), K2 = Z2;
const [dr, W2] = it("DialogRoot");
var G2 = /* @__PURE__ */ D({
  inheritAttrs: !1,
  __name: "DialogRoot",
  props: {
    open: {
      type: Boolean,
      required: !1,
      default: void 0
    },
    defaultOpen: {
      type: Boolean,
      required: !1,
      default: !1
    },
    modal: {
      type: Boolean,
      required: !1,
      default: !0
    }
  },
  emits: ["update:open"],
  setup(e, { emit: t }) {
    const r = e, o = /* @__PURE__ */ Gr(r, "open", t, {
      defaultValue: r.defaultOpen,
      passive: r.open === void 0
    }), n = K(), s = K(), { modal: i } = ht(r);
    return W2({
      open: o,
      modal: i,
      openModal: () => {
        o.value = !0;
      },
      onOpenChange: (l) => {
        o.value = l;
      },
      onOpenToggle: () => {
        o.value = !o.value;
      },
      contentId: "",
      titleId: "",
      descriptionId: "",
      triggerElement: n,
      contentElement: s
    }), (l, c) => q(l.$slots, "default", {
      open: d(o),
      close: () => o.value = !1
    });
  }
}), k0 = G2, J2 = /* @__PURE__ */ D({
  __name: "DialogClose",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "button"
    }
  },
  setup(e) {
    const t = e;
    be();
    const r = dr();
    return (a, o) => (g(), N(d(Re), re(t, {
      type: a.as === "button" ? "button" : void 0,
      onClick: o[0] || (o[0] = (n) => d(r).onOpenChange(!1))
    }), {
      default: b(() => [q(a.$slots, "default")]),
      _: 3
    }, 16, ["type"]));
  }
}), ql = J2;
const Y2 = "dismissableLayer.pointerDownOutside", X2 = "dismissableLayer.focusOutside";
function C0(e, t) {
  const r = t.closest("[data-dismissable-layer]"), a = e.dataset.dismissableLayer === "" ? e : e.querySelector("[data-dismissable-layer]"), o = Array.from(e.ownerDocument.querySelectorAll("[data-dismissable-layer]"));
  return !!(r && (a === r || o.indexOf(a) < o.indexOf(r)));
}
function Q2(e, t, r = !0) {
  const a = t?.value?.ownerDocument ?? globalThis?.document, o = K(!1), n = K(() => {
  });
  return Xe((s) => {
    if (!ur || !Je(r)) return;
    const i = async (c) => {
      const u = c.target;
      if (!(!t?.value || !u)) {
        if (C0(t.value, u)) {
          o.value = !1;
          return;
        }
        if (c.target && !o.value) {
          let p = function() {
            g0(Y2, e, f);
          };
          const f = { originalEvent: c };
          c.pointerType === "touch" ? (a.removeEventListener("click", n.value), n.value = p, a.addEventListener("click", n.value, { once: !0 })) : p();
        } else a.removeEventListener("click", n.value);
        o.value = !1;
      }
    }, l = window.setTimeout(() => {
      a.addEventListener("pointerdown", i);
    }, 0);
    s(() => {
      window.clearTimeout(l), a.removeEventListener("pointerdown", i), a.removeEventListener("click", n.value);
    });
  }), { onPointerDownCapture: () => {
    Je(r) && (o.value = !0);
  } };
}
function e8(e, t, r = !0) {
  const a = t?.value?.ownerDocument ?? globalThis?.document, o = K(!1);
  return Xe((n) => {
    if (!ur || !Je(r)) return;
    const s = async (i) => {
      if (!t?.value) return;
      await et(), await et();
      const l = i.target;
      !t.value || !l || C0(t.value, l) || i.target && !o.value && g0(X2, e, { originalEvent: i });
    };
    a.addEventListener("focusin", s), n(() => a.removeEventListener("focusin", s));
  }), {
    onFocusCapture: () => {
      Je(r) && (o.value = !0);
    },
    onBlurCapture: () => {
      Je(r) && (o.value = !1);
    }
  };
}
const Ot = Rt({
  layersRoot: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  originalBodyPointerEvents: void 0,
  branches: /* @__PURE__ */ new Set()
});
var t8 = /* @__PURE__ */ D({
  __name: "DismissableLayer",
  props: {
    disableOutsidePointerEvents: {
      type: Boolean,
      required: !1,
      default: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "dismiss"
  ],
  setup(e, { emit: t }) {
    const r = e, a = t, { forwardRef: o, currentElement: n } = be(), s = L(() => n.value?.ownerDocument ?? globalThis.document), i = L(() => Ot.layersRoot), l = L(() => n.value ? Array.from(i.value).indexOf(n.value) : -1), c = L(() => Ot.layersWithOutsidePointerEventsDisabled.size > 0), u = L(() => {
      const h = Array.from(i.value), [m] = [...Ot.layersWithOutsidePointerEventsDisabled].slice(-1), v = h.indexOf(m);
      return l.value >= v;
    }), f = Q2(async (h) => {
      const m = [...Ot.branches].some((v) => v?.contains(h.target));
      !u.value || m || (a("pointerDownOutside", h), a("interactOutside", h), await et(), h.defaultPrevented || a("dismiss"));
    }, n), p = e8((h) => {
      [...Ot.branches].some((v) => v?.contains(h.target)) || (a("focusOutside", h), a("interactOutside", h), h.defaultPrevented || a("dismiss"));
    }, n);
    return y2("Escape", (h) => {
      l.value === i.value.size - 1 && (a("escapeKeyDown", h), h.defaultPrevented || a("dismiss"));
    }), Xe((h) => {
      n.value && (r.disableOutsidePointerEvents && (Ot.layersWithOutsidePointerEventsDisabled.size === 0 && (Ot.originalBodyPointerEvents = s.value.body.style.pointerEvents, s.value.body.style.pointerEvents = "none"), Ot.layersWithOutsidePointerEventsDisabled.add(n.value)), i.value.add(n.value), h(() => {
        r.disableOutsidePointerEvents && Ot.layersWithOutsidePointerEventsDisabled.size === 1 && !r2(Ot.originalBodyPointerEvents) && (s.value.body.style.pointerEvents = Ot.originalBodyPointerEvents);
      }));
    }), Xe((h) => {
      h(() => {
        n.value && (i.value.delete(n.value), Ot.layersWithOutsidePointerEventsDisabled.delete(n.value));
      });
    }), (h, m) => (g(), N(d(Re), {
      ref: d(o),
      "as-child": h.asChild,
      as: h.as,
      "data-dismissable-layer": "",
      style: Tt({ pointerEvents: c.value ? u.value ? "auto" : "none" : void 0 }),
      onFocusCapture: d(p).onFocusCapture,
      onBlurCapture: d(p).onBlurCapture,
      onPointerdownCapture: d(f).onPointerDownCapture
    }, {
      default: b(() => [q(h.$slots, "default")]),
      _: 3
    }, 8, [
      "as-child",
      "as",
      "style",
      "onFocusCapture",
      "onBlurCapture",
      "onPointerdownCapture"
    ]));
  }
}), ss = t8;
const r8 = /* @__PURE__ */ i2(() => K([]));
function a8() {
  const e = r8();
  return {
    add(t) {
      const r = e.value[0];
      t !== r && r?.pause(), e.value = nd(e.value, t), e.value.unshift(t);
    },
    remove(t) {
      e.value = nd(e.value, t), e.value[0]?.resume();
    }
  };
}
function nd(e, t) {
  const r = [...e], a = r.indexOf(t);
  return a !== -1 && r.splice(a, 1), r;
}
const ni = "focusScope.autoFocusOnMount", si = "focusScope.autoFocusOnUnmount", sd = {
  bubbles: !1,
  cancelable: !0
};
function o8(e, { select: t = !1 } = {}) {
  const r = Ct();
  for (const a of e)
    if (Ir(a, { select: t }), Ct() !== r) return !0;
}
function n8(e) {
  const t = A0(e), r = id(t, e), a = id(t.reverse(), e);
  return [r, a];
}
function A0(e) {
  const t = [], r = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, { acceptNode: (a) => {
    const o = a.tagName === "INPUT" && a.type === "hidden";
    return a.disabled || a.hidden || o ? NodeFilter.FILTER_SKIP : a.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
  } });
  for (; r.nextNode(); ) t.push(r.currentNode);
  return t;
}
function id(e, t) {
  for (const r of e) if (!s8(r, { upTo: t })) return r;
}
function s8(e, { upTo: t }) {
  if (getComputedStyle(e).visibility === "hidden") return !0;
  for (; e; ) {
    if (t !== void 0 && e === t) return !1;
    if (getComputedStyle(e).display === "none") return !0;
    e = e.parentElement;
  }
  return !1;
}
function i8(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
function Ir(e, { select: t = !1 } = {}) {
  if (e && e.focus) {
    const r = Ct();
    e.focus({ preventScroll: !0 }), e !== r && i8(e) && t && e.select();
  }
}
var l8 = /* @__PURE__ */ D({
  __name: "FocusScope",
  props: {
    loop: {
      type: Boolean,
      required: !1,
      default: !1
    },
    trapped: {
      type: Boolean,
      required: !1,
      default: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: ["mountAutoFocus", "unmountAutoFocus"],
  setup(e, { emit: t }) {
    const r = e, a = t, { currentRef: o, currentElement: n } = be(), s = K(null), i = a8(), l = Rt({
      paused: !1,
      pause() {
        this.paused = !0;
      },
      resume() {
        this.paused = !1;
      }
    });
    Xe((u) => {
      if (!ur) return;
      const f = n.value;
      if (!r.trapped) return;
      function p(x) {
        if (l.paused || !f) return;
        const C = x.target;
        f.contains(C) ? s.value = C : Ir(s.value, { select: !0 });
      }
      function h(x) {
        if (l.paused || !f) return;
        const C = x.relatedTarget;
        C !== null && (f.contains(C) || Ir(s.value, { select: !0 }));
      }
      function m(x) {
        f.contains(s.value) || Ir(f);
      }
      document.addEventListener("focusin", p), document.addEventListener("focusout", h);
      const v = new MutationObserver(m);
      f && v.observe(f, {
        childList: !0,
        subtree: !0
      }), u(() => {
        document.removeEventListener("focusin", p), document.removeEventListener("focusout", h), v.disconnect();
      });
    }), Xe(async (u) => {
      const f = n.value;
      if (await et(), !f) return;
      i.add(l);
      const p = Ct();
      if (!f.contains(p)) {
        const m = new CustomEvent(ni, sd);
        f.addEventListener(ni, (v) => a("mountAutoFocus", v)), f.dispatchEvent(m), m.defaultPrevented || (o8(A0(f), { select: !0 }), Ct() === p && Ir(f));
      }
      u(() => {
        f.removeEventListener(ni, (x) => a("mountAutoFocus", x));
        const m = new CustomEvent(si, sd), v = (x) => {
          a("unmountAutoFocus", x);
        };
        f.addEventListener(si, v), f.dispatchEvent(m), setTimeout(() => {
          m.defaultPrevented || Ir(p ?? document.body, { select: !0 }), f.removeEventListener(si, v), i.remove(l);
        }, 0);
      });
    });
    function c(u) {
      if (!r.loop && !r.trapped || l.paused) return;
      const f = u.key === "Tab" && !u.altKey && !u.ctrlKey && !u.metaKey, p = Ct();
      if (f && p) {
        const h = u.currentTarget, [m, v] = n8(h);
        m && v ? !u.shiftKey && p === v ? (u.preventDefault(), r.loop && Ir(m, { select: !0 })) : u.shiftKey && p === m && (u.preventDefault(), r.loop && Ir(v, { select: !0 })) : p === h && u.preventDefault();
      }
    }
    return (u, f) => (g(), N(d(Re), {
      ref_key: "currentRef",
      ref: o,
      tabindex: "-1",
      "as-child": u.asChild,
      as: u.as,
      onKeydown: c
    }, {
      default: b(() => [q(u.$slots, "default")]),
      _: 3
    }, 8, ["as-child", "as"]));
  }
}), Ll = l8;
const c8 = "menu.itemSelect", Fi = ["Enter", " "], u8 = [
  "ArrowDown",
  "PageUp",
  "Home"
], S0 = [
  "ArrowUp",
  "PageDown",
  "End"
], d8 = [...u8, ...S0];
[...Fi], [...Fi];
function E0(e) {
  return e ? "open" : "closed";
}
function f8(e) {
  const t = Ct();
  for (const r of e)
    if (r === t || (r.focus(), Ct() !== t)) return;
}
function p8(e, t) {
  const { x: r, y: a } = e;
  let o = !1;
  for (let n = 0, s = t.length - 1; n < t.length; s = n++) {
    const i = t[n].x, l = t[n].y, c = t[s].x, u = t[s].y;
    l > a != u > a && r < (c - i) * (a - l) / (u - l) + i && (o = !o);
  }
  return o;
}
function h8(e, t) {
  if (!t) return !1;
  const r = {
    x: e.clientX,
    y: e.clientY
  };
  return p8(r, t);
}
function zi(e) {
  return e.pointerType === "mouse";
}
var g8 = /* @__PURE__ */ D({
  __name: "DialogContentImpl",
  props: {
    forceMount: {
      type: Boolean,
      required: !1
    },
    trapFocus: {
      type: Boolean,
      required: !1
    },
    disableOutsidePointerEvents: {
      type: Boolean,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "openAutoFocus",
    "closeAutoFocus"
  ],
  setup(e, { emit: t }) {
    const r = e, a = t, o = dr(), { forwardRef: n, currentElement: s } = be();
    return o.titleId ||= lr(void 0, "reka-dialog-title"), o.descriptionId ||= lr(void 0, "reka-dialog-description"), at(() => {
      o.contentElement = s, Ct() !== document.body && (o.triggerElement.value = Ct());
    }), (i, l) => (g(), N(d(Ll), {
      "as-child": "",
      loop: "",
      trapped: r.trapFocus,
      onMountAutoFocus: l[5] || (l[5] = (c) => a("openAutoFocus", c)),
      onUnmountAutoFocus: l[6] || (l[6] = (c) => a("closeAutoFocus", c))
    }, {
      default: b(() => [k(d(ss), re({
        id: d(o).contentId,
        ref: d(n),
        as: i.as,
        "as-child": i.asChild,
        "disable-outside-pointer-events": i.disableOutsidePointerEvents,
        role: "dialog",
        "aria-describedby": d(o).descriptionId,
        "aria-labelledby": d(o).titleId,
        "data-state": d(E0)(d(o).open.value)
      }, i.$attrs, {
        onDismiss: l[0] || (l[0] = (c) => d(o).onOpenChange(!1)),
        onEscapeKeyDown: l[1] || (l[1] = (c) => a("escapeKeyDown", c)),
        onFocusOutside: l[2] || (l[2] = (c) => a("focusOutside", c)),
        onInteractOutside: l[3] || (l[3] = (c) => a("interactOutside", c)),
        onPointerDownOutside: l[4] || (l[4] = (c) => a("pointerDownOutside", c))
      }), {
        default: b(() => [q(i.$slots, "default")]),
        _: 3
      }, 16, [
        "id",
        "as",
        "as-child",
        "disable-outside-pointer-events",
        "aria-describedby",
        "aria-labelledby",
        "data-state"
      ])]),
      _: 3
    }, 8, ["trapped"]));
  }
}), $0 = g8, m8 = /* @__PURE__ */ D({
  __name: "DialogContentModal",
  props: {
    forceMount: {
      type: Boolean,
      required: !1
    },
    trapFocus: {
      type: Boolean,
      required: !1
    },
    disableOutsidePointerEvents: {
      type: Boolean,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "openAutoFocus",
    "closeAutoFocus"
  ],
  setup(e, { emit: t }) {
    const r = e, a = t, o = dr(), n = Ha(a), { forwardRef: s, currentElement: i } = be();
    return Il(i), (l, c) => (g(), N($0, re({
      ...r,
      ...d(n)
    }, {
      ref: d(s),
      "trap-focus": d(o).open.value,
      "disable-outside-pointer-events": !0,
      onCloseAutoFocus: c[0] || (c[0] = (u) => {
        u.defaultPrevented || (u.preventDefault(), d(o).triggerElement.value?.focus());
      }),
      onPointerDownOutside: c[1] || (c[1] = (u) => {
        const f = u.detail.originalEvent, p = f.button === 0 && f.ctrlKey === !0;
        (f.button === 2 || p) && u.preventDefault();
      }),
      onFocusOutside: c[2] || (c[2] = (u) => {
        u.preventDefault();
      })
    }), {
      default: b(() => [q(l.$slots, "default")]),
      _: 3
    }, 16, ["trap-focus"]));
  }
}), v8 = m8, b8 = /* @__PURE__ */ D({
  __name: "DialogContentNonModal",
  props: {
    forceMount: {
      type: Boolean,
      required: !1
    },
    trapFocus: {
      type: Boolean,
      required: !1
    },
    disableOutsidePointerEvents: {
      type: Boolean,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "openAutoFocus",
    "closeAutoFocus"
  ],
  setup(e, { emit: t }) {
    const r = e, o = Ha(t);
    be();
    const n = dr(), s = K(!1), i = K(!1);
    return (l, c) => (g(), N($0, re({
      ...r,
      ...d(o)
    }, {
      "trap-focus": !1,
      "disable-outside-pointer-events": !1,
      onCloseAutoFocus: c[0] || (c[0] = (u) => {
        u.defaultPrevented || (s.value || d(n).triggerElement.value?.focus(), u.preventDefault()), s.value = !1, i.value = !1;
      }),
      onInteractOutside: c[1] || (c[1] = (u) => {
        u.defaultPrevented || (s.value = !0, u.detail.originalEvent.type === "pointerdown" && (i.value = !0));
        const f = u.target;
        d(n).triggerElement.value?.contains(f) && u.preventDefault(), u.detail.originalEvent.type === "focusin" && i.value && u.preventDefault();
      })
    }), {
      default: b(() => [q(l.$slots, "default")]),
      _: 3
    }, 16));
  }
}), y8 = b8, w8 = /* @__PURE__ */ D({
  __name: "DialogContent",
  props: {
    forceMount: {
      type: Boolean,
      required: !1
    },
    disableOutsidePointerEvents: {
      type: Boolean,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "openAutoFocus",
    "closeAutoFocus"
  ],
  setup(e, { emit: t }) {
    const r = e, a = t, o = dr(), n = Ha(a), { forwardRef: s } = be();
    return (i, l) => (g(), N(d(Fa), { present: i.forceMount || d(o).open.value }, {
      default: b(() => [d(o).modal.value ? (g(), N(v8, re({
        key: 0,
        ref: d(s)
      }, {
        ...r,
        ...d(n),
        ...i.$attrs
      }), {
        default: b(() => [q(i.$slots, "default")]),
        _: 3
      }, 16)) : (g(), N(y8, re({
        key: 1,
        ref: d(s)
      }, {
        ...r,
        ...d(n),
        ...i.$attrs
      }), {
        default: b(() => [q(i.$slots, "default")]),
        _: 3
      }, 16))]),
      _: 3
    }, 8, ["present"]));
  }
}), P0 = w8, x8 = /* @__PURE__ */ D({
  __name: "DialogDescription",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "p"
    }
  },
  setup(e) {
    const t = e;
    be();
    const r = dr();
    return (a, o) => (g(), N(d(Re), re(t, { id: d(r).descriptionId }), {
      default: b(() => [q(a.$slots, "default")]),
      _: 3
    }, 16, ["id"]));
  }
}), T0 = x8, _8 = /* @__PURE__ */ D({
  __name: "DialogOverlayImpl",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  setup(e) {
    const t = dr();
    return Dl(!0), be(), (r, a) => (g(), N(d(Re), {
      as: r.as,
      "as-child": r.asChild,
      "data-state": d(t).open.value ? "open" : "closed",
      style: { "pointer-events": "auto" }
    }, {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 8, [
      "as",
      "as-child",
      "data-state"
    ]));
  }
}), k8 = _8, C8 = /* @__PURE__ */ D({
  __name: "DialogOverlay",
  props: {
    forceMount: {
      type: Boolean,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  setup(e) {
    const t = dr(), { forwardRef: r } = be();
    return (a, o) => d(t)?.modal.value ? (g(), N(d(Fa), {
      key: 0,
      present: a.forceMount || d(t).open.value
    }, {
      default: b(() => [k(k8, re(a.$attrs, {
        ref: d(r),
        as: a.as,
        "as-child": a.asChild
      }), {
        default: b(() => [q(a.$slots, "default")]),
        _: 3
      }, 16, ["as", "as-child"])]),
      _: 3
    }, 8, ["present"])) : $e("v-if", !0);
  }
}), M0 = C8, A8 = /* @__PURE__ */ D({
  __name: "Teleport",
  props: {
    to: {
      type: null,
      required: !1,
      default: "body"
    },
    disabled: {
      type: Boolean,
      required: !1
    },
    defer: {
      type: Boolean,
      required: !1
    },
    forceMount: {
      type: Boolean,
      required: !1
    }
  },
  setup(e) {
    const t = /* @__PURE__ */ v2();
    return (r, a) => d(t) || r.forceMount ? (g(), N(ig, {
      key: 0,
      to: r.to,
      disabled: r.disabled,
      defer: r.defer
    }, [q(r.$slots, "default")], 8, [
      "to",
      "disabled",
      "defer"
    ])) : $e("v-if", !0);
  }
}), Lo = A8, S8 = /* @__PURE__ */ D({
  __name: "DialogPortal",
  props: {
    to: {
      type: null,
      required: !1
    },
    disabled: {
      type: Boolean,
      required: !1
    },
    defer: {
      type: Boolean,
      required: !1
    },
    forceMount: {
      type: Boolean,
      required: !1
    }
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(Lo), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), E8 = S8, $8 = /* @__PURE__ */ D({
  __name: "DialogTitle",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "h2"
    }
  },
  setup(e) {
    const t = e, r = dr();
    return be(), (a, o) => (g(), N(d(Re), re(t, { id: d(r).titleId }), {
      default: b(() => [q(a.$slots, "default")]),
      _: 3
    }, 16, ["id"]));
  }
}), R0 = $8, P8 = /* @__PURE__ */ D({
  __name: "DialogTrigger",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "button"
    }
  },
  setup(e) {
    const t = e, r = dr(), { forwardRef: a, currentElement: o } = be();
    return r.contentId ||= lr(void 0, "reka-dialog-content"), at(() => {
      r.triggerElement.value = o.value;
    }), (n, s) => (g(), N(d(Re), re(t, {
      ref: d(a),
      type: n.as === "button" ? "button" : void 0,
      "aria-haspopup": "dialog",
      "aria-expanded": d(r).open.value || !1,
      "aria-controls": d(r).open.value ? d(r).contentId : void 0,
      "data-state": d(r).open.value ? "open" : "closed",
      onClick: d(r).onOpenToggle
    }), {
      default: b(() => [q(n.$slots, "default")]),
      _: 3
    }, 16, [
      "type",
      "aria-expanded",
      "aria-controls",
      "data-state",
      "onClick"
    ]));
  }
}), T8 = P8, M8 = /* @__PURE__ */ D({
  __name: "AlertDialogAction",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "button"
    }
  },
  setup(e) {
    const t = e;
    return be(), (r, a) => (g(), N(d(ql), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), R8 = M8;
const [O8, B8] = it("AlertDialogContent");
var D8 = /* @__PURE__ */ D({
  __name: "AlertDialogContent",
  props: {
    forceMount: {
      type: Boolean,
      required: !1
    },
    disableOutsidePointerEvents: {
      type: Boolean,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "openAutoFocus",
    "closeAutoFocus"
  ],
  setup(e, { emit: t }) {
    const r = e, o = Ha(t);
    be();
    const n = K();
    return B8({ onCancelElementChange: (s) => {
      n.value = s;
    } }), (s, i) => (g(), N(d(P0), re({
      ...r,
      ...d(o)
    }, {
      role: "alertdialog",
      onPointerDownOutside: i[0] || (i[0] = ir(() => {
      }, ["prevent"])),
      onInteractOutside: i[1] || (i[1] = ir(() => {
      }, ["prevent"])),
      onOpenAutoFocus: i[2] || (i[2] = () => {
        et(() => {
          n.value?.focus({ preventScroll: !0 });
        });
      })
    }), {
      default: b(() => [q(s.$slots, "default")]),
      _: 3
    }, 16));
  }
}), I8 = D8, q8 = /* @__PURE__ */ D({
  __name: "AlertDialogCancel",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "button"
    }
  },
  setup(e) {
    const t = e, r = O8(), { forwardRef: a, currentElement: o } = be();
    return at(() => {
      r.onCancelElementChange(o.value);
    }), (n, s) => (g(), N(d(ql), re(t, { ref: d(a) }), {
      default: b(() => [q(n.$slots, "default")]),
      _: 3
    }, 16));
  }
}), L8 = q8, N8 = /* @__PURE__ */ D({
  __name: "AlertDialogDescription",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "p"
    }
  },
  setup(e) {
    const t = e;
    return be(), (r, a) => (g(), N(d(T0), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), V8 = N8, H8 = /* @__PURE__ */ D({
  __name: "AlertDialogOverlay",
  props: {
    forceMount: {
      type: Boolean,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  setup(e) {
    const t = e;
    return be(), (r, a) => (g(), N(d(M0), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), F8 = H8, z8 = /* @__PURE__ */ D({
  __name: "AlertDialogPortal",
  props: {
    to: {
      type: null,
      required: !1
    },
    disabled: {
      type: Boolean,
      required: !1
    },
    defer: {
      type: Boolean,
      required: !1
    },
    forceMount: {
      type: Boolean,
      required: !1
    }
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(Lo), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), j8 = z8, U8 = /* @__PURE__ */ D({
  __name: "AlertDialogRoot",
  props: {
    open: {
      type: Boolean,
      required: !1
    },
    defaultOpen: {
      type: Boolean,
      required: !1
    }
  },
  emits: ["update:open"],
  setup(e, { emit: t }) {
    const o = rt(e, t);
    return be(), (n, s) => (g(), N(d(k0), re(d(o), { modal: !0 }), {
      default: b((i) => [q(n.$slots, "default", De(Fe(i)))]),
      _: 3
    }, 16));
  }
}), Z8 = U8, K8 = /* @__PURE__ */ D({
  __name: "AlertDialogTitle",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "h2"
    }
  },
  setup(e) {
    const t = e;
    return be(), (r, a) => (g(), N(d(R0), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), W8 = K8, G8 = /* @__PURE__ */ D({
  __name: "AlertDialogTrigger",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "button"
    }
  },
  setup(e) {
    const t = e;
    return be(), (r, a) => (g(), N(d(T8), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), J8 = G8;
const [Y8, X8] = it("AvatarRoot");
var Q8 = /* @__PURE__ */ D({
  __name: "AvatarRoot",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "span"
    }
  },
  setup(e) {
    return be(), X8({ imageLoadingStatus: K("idle") }), (t, r) => (g(), N(d(Re), {
      "as-child": t.asChild,
      as: t.as
    }, {
      default: b(() => [q(t.$slots, "default")]),
      _: 3
    }, 8, ["as-child", "as"]));
  }
}), e4 = Q8, t4 = /* @__PURE__ */ D({
  __name: "AvatarFallback",
  props: {
    delayMs: {
      type: Number,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "span"
    }
  },
  setup(e) {
    const t = e, r = Y8();
    be();
    const a = K(t.delayMs === void 0);
    return Xe((o) => {
      if (t.delayMs && ur) {
        const n = window.setTimeout(() => {
          a.value = !0;
        }, t.delayMs);
        o(() => {
          window.clearTimeout(n);
        });
      }
    }), (o, n) => a.value && d(r).imageLoadingStatus.value !== "loaded" ? (g(), N(d(Re), {
      key: 0,
      "as-child": o.asChild,
      as: o.as
    }, {
      default: b(() => [q(o.$slots, "default")]),
      _: 3
    }, 8, ["as-child", "as"])) : $e("v-if", !0);
  }
}), r4 = t4;
const ld = "data-reka-collection-item";
function Nl(e = {}) {
  const { key: t = "", isProvider: r = !1 } = e, a = `${t}CollectionProvider`;
  let o;
  if (r) {
    const u = K(/* @__PURE__ */ new Map());
    o = {
      collectionRef: K(),
      itemMap: u
    }, $a(a, o);
  } else o = he(a);
  const n = (u = !1) => {
    const f = o.collectionRef.value;
    if (!f) return [];
    const p = Array.from(f.querySelectorAll(`[${ld}]`)), m = Array.from(o.itemMap.value.values()).sort((v, x) => p.indexOf(v.ref) - p.indexOf(x.ref));
    return u ? m : m.filter((v) => v.ref.dataset.disabled !== "");
  }, s = /* @__PURE__ */ D({
    name: "CollectionSlot",
    inheritAttrs: !1,
    setup(u, { slots: f, attrs: p }) {
      const { primitiveElement: h, currentElement: m } = od();
      return Ke(m, () => {
        o.collectionRef.value = m.value;
      }), () => Nt(Hi, {
        ref: h,
        ...p
      }, f);
    }
  }), i = /* @__PURE__ */ D({
    name: "CollectionItem",
    inheritAttrs: !1,
    props: { value: { validator: () => !0 } },
    setup(u, { slots: f, attrs: p }) {
      const { primitiveElement: h, currentElement: m } = od();
      return Xe((v) => {
        if (m.value) {
          const x = Hn(m.value);
          o.itemMap.value.set(x, {
            ref: m.value,
            value: u.value
          }), v(() => o.itemMap.value.delete(x));
        }
      }), () => Nt(Hi, {
        ...p,
        [ld]: "",
        ref: h
      }, f);
    }
  }), l = L(() => Array.from(o.itemMap.value.values())), c = L(() => o.itemMap.value.size);
  return {
    getItems: n,
    reactiveItems: l,
    itemMapSize: c,
    CollectionSlot: s,
    CollectionItem: i
  };
}
const a4 = "rovingFocusGroup.onEntryFocus", o4 = {
  bubbles: !1,
  cancelable: !0
}, n4 = {
  ArrowLeft: "prev",
  ArrowUp: "prev",
  ArrowRight: "next",
  ArrowDown: "next",
  PageUp: "first",
  Home: "first",
  PageDown: "last",
  End: "last"
};
function s4(e, t) {
  return t !== "rtl" ? e : e === "ArrowLeft" ? "ArrowRight" : e === "ArrowRight" ? "ArrowLeft" : e;
}
function i4(e, t, r) {
  const a = s4(e.key, r);
  if (!(t === "vertical" && ["ArrowLeft", "ArrowRight"].includes(a)) && !(t === "horizontal" && ["ArrowUp", "ArrowDown"].includes(a)))
    return n4[a];
}
function O0(e, t = !1) {
  const r = Ct();
  for (const a of e)
    if (a === r || (a.focus({ preventScroll: t }), Ct() !== r)) return;
}
function l4(e, t) {
  return e.map((r, a) => e[(t + a) % e.length]);
}
const [c4, u4] = it("RovingFocusGroup");
var d4 = /* @__PURE__ */ D({
  __name: "RovingFocusGroup",
  props: {
    orientation: {
      type: String,
      required: !1,
      default: void 0
    },
    dir: {
      type: String,
      required: !1
    },
    loop: {
      type: Boolean,
      required: !1,
      default: !1
    },
    currentTabStopId: {
      type: [String, null],
      required: !1
    },
    defaultCurrentTabStopId: {
      type: String,
      required: !1
    },
    preventScrollOnEntryFocus: {
      type: Boolean,
      required: !1,
      default: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: ["entryFocus", "update:currentTabStopId"],
  setup(e, { expose: t, emit: r }) {
    const a = e, o = r, { loop: n, orientation: s, dir: i } = ht(a), l = ns(i), c = /* @__PURE__ */ Gr(a, "currentTabStopId", o, {
      defaultValue: a.defaultCurrentTabStopId,
      passive: a.currentTabStopId === void 0
    }), u = K(!1), f = K(!1), p = K(0), { getItems: h, CollectionSlot: m } = Nl({ isProvider: !0 });
    function v(C) {
      const S = !f.value;
      if (C.currentTarget && C.target === C.currentTarget && S && !u.value) {
        const E = new CustomEvent(a4, o4);
        if (C.currentTarget.dispatchEvent(E), o("entryFocus", E), !E.defaultPrevented) {
          const T = h().map((P) => P.ref).filter((P) => P.dataset.disabled !== ""), F = T.find((P) => P.getAttribute("data-active") === ""), j = T.find((P) => P.getAttribute("data-highlighted") === ""), H = T.find((P) => P.id === c.value), B = [
            F,
            j,
            H,
            ...T
          ].filter(Boolean);
          O0(B, a.preventScrollOnEntryFocus);
        }
      }
      f.value = !1;
    }
    function x() {
      setTimeout(() => {
        f.value = !1;
      }, 1);
    }
    return t({ getItems: h }), u4({
      loop: n,
      dir: l,
      orientation: s,
      currentTabStopId: c,
      onItemFocus: (C) => {
        c.value = C;
      },
      onItemShiftTab: () => {
        u.value = !0;
      },
      onFocusableItemAdd: () => {
        p.value++;
      },
      onFocusableItemRemove: () => {
        p.value--;
      }
    }), (C, S) => (g(), N(d(m), null, {
      default: b(() => [k(d(Re), {
        tabindex: u.value || p.value === 0 ? -1 : 0,
        "data-orientation": d(s),
        as: C.as,
        "as-child": C.asChild,
        dir: d(l),
        style: { outline: "none" },
        onMousedown: S[0] || (S[0] = (E) => f.value = !0),
        onMouseup: x,
        onFocus: v,
        onBlur: S[1] || (S[1] = (E) => u.value = !1)
      }, {
        default: b(() => [q(C.$slots, "default")]),
        _: 3
      }, 8, [
        "tabindex",
        "data-orientation",
        "as",
        "as-child",
        "dir"
      ])]),
      _: 3
    }));
  }
}), B0 = d4, f4 = /* @__PURE__ */ D({
  __name: "RovingFocusItem",
  props: {
    tabStopId: {
      type: String,
      required: !1
    },
    focusable: {
      type: Boolean,
      required: !1,
      default: !0
    },
    active: {
      type: Boolean,
      required: !1
    },
    allowShiftKey: {
      type: Boolean,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "span"
    }
  },
  setup(e) {
    const t = e, r = c4(), a = lr(), o = L(() => t.tabStopId || a), n = L(() => r.currentTabStopId.value === o.value), { getItems: s, CollectionItem: i } = Nl();
    at(() => {
      t.focusable && r.onFocusableItemAdd();
    }), $r(() => {
      t.focusable && r.onFocusableItemRemove();
    });
    function l(c) {
      if (c.key === "Tab" && c.shiftKey) {
        r.onItemShiftTab();
        return;
      }
      if (c.target !== c.currentTarget) return;
      const u = i4(c, r.orientation.value, r.dir.value);
      if (u !== void 0) {
        if (c.metaKey || c.ctrlKey || c.altKey || !t.allowShiftKey && c.shiftKey) return;
        c.preventDefault();
        let f = [...s().map((p) => p.ref).filter((p) => p.dataset.disabled !== "")];
        if (u === "last") f.reverse();
        else if (u === "prev" || u === "next") {
          u === "prev" && f.reverse();
          const p = f.indexOf(c.currentTarget);
          f = r.loop.value ? l4(f, p + 1) : f.slice(p + 1);
        }
        et(() => O0(f));
      }
    }
    return (c, u) => (g(), N(d(i), null, {
      default: b(() => [k(d(Re), {
        tabindex: n.value ? 0 : -1,
        "data-orientation": d(r).orientation.value,
        "data-active": c.active ? "" : void 0,
        "data-disabled": c.focusable ? void 0 : "",
        as: c.as,
        "as-child": c.asChild,
        onMousedown: u[0] || (u[0] = (f) => {
          c.focusable ? d(r).onItemFocus(o.value) : f.preventDefault();
        }),
        onFocus: u[1] || (u[1] = (f) => d(r).onItemFocus(o.value)),
        onKeydown: l
      }, {
        default: b(() => [q(c.$slots, "default")]),
        _: 3
      }, 8, [
        "tabindex",
        "data-orientation",
        "data-active",
        "data-disabled",
        "as",
        "as-child"
      ])]),
      _: 3
    }));
  }
}), p4 = f4, h4 = /* @__PURE__ */ D({
  __name: "VisuallyHidden",
  props: {
    feature: {
      type: String,
      required: !1,
      default: "focusable"
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "span"
    }
  },
  setup(e) {
    return (t, r) => (g(), N(d(Re), {
      as: t.as,
      "as-child": t.asChild,
      "aria-hidden": t.feature === "focusable" ? "true" : void 0,
      "data-hidden": t.feature === "fully-hidden" ? "" : void 0,
      tabindex: t.feature === "fully-hidden" ? "-1" : void 0,
      style: {
        position: "absolute",
        border: 0,
        width: "1px",
        height: "1px",
        padding: 0,
        margin: "-1px",
        overflow: "hidden",
        clip: "rect(0, 0, 0, 0)",
        clipPath: "inset(50%)",
        whiteSpace: "nowrap",
        wordWrap: "normal",
        top: "-1px",
        left: "-1px"
      }
    }, {
      default: b(() => [q(t.$slots, "default")]),
      _: 3
    }, 8, [
      "as",
      "as-child",
      "aria-hidden",
      "data-hidden",
      "tabindex"
    ]));
  }
}), g4 = h4;
const [D0, m4] = it("PopperRoot");
var v4 = /* @__PURE__ */ D({
  inheritAttrs: !1,
  __name: "PopperRoot",
  setup(e) {
    const t = K();
    return m4({
      anchor: t,
      onAnchorChange: (r) => t.value = r
    }), (r, a) => q(r.$slots, "default");
  }
}), Vl = v4, b4 = /* @__PURE__ */ D({
  __name: "PopperAnchor",
  props: {
    reference: {
      type: null,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  setup(e) {
    const t = e, { forwardRef: r, currentElement: a } = be(), o = D0();
    return Vf(() => {
      o.onAnchorChange(t.reference ?? a.value);
    }), (n, s) => (g(), N(d(Re), {
      ref: d(r),
      as: n.as,
      "as-child": n.asChild
    }, {
      default: b(() => [q(n.$slots, "default")]),
      _: 3
    }, 8, ["as", "as-child"]));
  }
}), Hl = b4;
const y4 = {
  key: 0,
  d: "M0 0L6 6L12 0"
}, w4 = {
  key: 1,
  d: "M0 0L4.58579 4.58579C5.36683 5.36683 6.63316 5.36684 7.41421 4.58579L12 0"
};
var x4 = /* @__PURE__ */ D({
  __name: "Arrow",
  props: {
    width: {
      type: Number,
      required: !1,
      default: 10
    },
    height: {
      type: Number,
      required: !1,
      default: 5
    },
    rounded: {
      type: Boolean,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "svg"
    }
  },
  setup(e) {
    const t = e;
    return be(), (r, a) => (g(), N(d(Re), re(t, {
      width: r.width,
      height: r.height,
      viewBox: r.asChild ? void 0 : "0 0 12 6",
      preserveAspectRatio: r.asChild ? void 0 : "none"
    }), {
      default: b(() => [q(r.$slots, "default", {}, () => [r.rounded ? (g(), R("path", w4)) : (g(), R("path", y4))])]),
      _: 3
    }, 16, [
      "width",
      "height",
      "viewBox",
      "preserveAspectRatio"
    ]));
  }
}), _4 = x4;
function k4(e) {
  return e !== null;
}
function C4(e) {
  return {
    name: "transformOrigin",
    options: e,
    fn(t) {
      const { placement: r, rects: a, middlewareData: o } = t, s = o.arrow?.centerOffset !== 0, i = s ? 0 : e.arrowWidth, l = s ? 0 : e.arrowHeight, [c, u] = ji(r), f = {
        start: "0%",
        center: "50%",
        end: "100%"
      }[u], p = (o.arrow?.x ?? 0) + i / 2, h = (o.arrow?.y ?? 0) + l / 2;
      let m = "", v = "";
      return c === "bottom" ? (m = s ? f : `${p}px`, v = `${-l}px`) : c === "top" ? (m = s ? f : `${p}px`, v = `${a.floating.height + l}px`) : c === "right" ? (m = `${-l}px`, v = s ? f : `${h}px`) : c === "left" && (m = `${a.floating.width + l}px`, v = s ? f : `${h}px`), { data: {
        x: m,
        y: v
      } };
    }
  };
}
function ji(e) {
  const [t, r = "center"] = e.split("-");
  return [t, r];
}
const A4 = ["top", "right", "bottom", "left"], Zr = Math.min, $t = Math.max, Cn = Math.round, Xo = Math.floor, or = (e) => ({
  x: e,
  y: e
}), S4 = {
  left: "right",
  right: "left",
  bottom: "top",
  top: "bottom"
}, E4 = {
  start: "end",
  end: "start"
};
function Ui(e, t, r) {
  return $t(e, Zr(t, r));
}
function Cr(e, t) {
  return typeof e == "function" ? e(t) : e;
}
function Ar(e) {
  return e.split("-")[0];
}
function za(e) {
  return e.split("-")[1];
}
function Fl(e) {
  return e === "x" ? "y" : "x";
}
function zl(e) {
  return e === "y" ? "height" : "width";
}
const $4 = /* @__PURE__ */ new Set(["top", "bottom"]);
function tr(e) {
  return $4.has(Ar(e)) ? "y" : "x";
}
function jl(e) {
  return Fl(tr(e));
}
function P4(e, t, r) {
  r === void 0 && (r = !1);
  const a = za(e), o = jl(e), n = zl(o);
  let s = o === "x" ? a === (r ? "end" : "start") ? "right" : "left" : a === "start" ? "bottom" : "top";
  return t.reference[n] > t.floating[n] && (s = An(s)), [s, An(s)];
}
function T4(e) {
  const t = An(e);
  return [Zi(e), t, Zi(t)];
}
function Zi(e) {
  return e.replace(/start|end/g, (t) => E4[t]);
}
const cd = ["left", "right"], ud = ["right", "left"], M4 = ["top", "bottom"], R4 = ["bottom", "top"];
function O4(e, t, r) {
  switch (e) {
    case "top":
    case "bottom":
      return r ? t ? ud : cd : t ? cd : ud;
    case "left":
    case "right":
      return t ? M4 : R4;
    default:
      return [];
  }
}
function B4(e, t, r, a) {
  const o = za(e);
  let n = O4(Ar(e), r === "start", a);
  return o && (n = n.map((s) => s + "-" + o), t && (n = n.concat(n.map(Zi)))), n;
}
function An(e) {
  return e.replace(/left|right|bottom|top/g, (t) => S4[t]);
}
function D4(e) {
  return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    ...e
  };
}
function I0(e) {
  return typeof e != "number" ? D4(e) : {
    top: e,
    right: e,
    bottom: e,
    left: e
  };
}
function Sn(e) {
  const {
    x: t,
    y: r,
    width: a,
    height: o
  } = e;
  return {
    width: a,
    height: o,
    top: r,
    left: t,
    right: t + a,
    bottom: r + o,
    x: t,
    y: r
  };
}
function dd(e, t, r) {
  let {
    reference: a,
    floating: o
  } = e;
  const n = tr(t), s = jl(t), i = zl(s), l = Ar(t), c = n === "y", u = a.x + a.width / 2 - o.width / 2, f = a.y + a.height / 2 - o.height / 2, p = a[i] / 2 - o[i] / 2;
  let h;
  switch (l) {
    case "top":
      h = {
        x: u,
        y: a.y - o.height
      };
      break;
    case "bottom":
      h = {
        x: u,
        y: a.y + a.height
      };
      break;
    case "right":
      h = {
        x: a.x + a.width,
        y: f
      };
      break;
    case "left":
      h = {
        x: a.x - o.width,
        y: f
      };
      break;
    default:
      h = {
        x: a.x,
        y: a.y
      };
  }
  switch (za(t)) {
    case "start":
      h[s] -= p * (r && c ? -1 : 1);
      break;
    case "end":
      h[s] += p * (r && c ? -1 : 1);
      break;
  }
  return h;
}
const I4 = async (e, t, r) => {
  const {
    placement: a = "bottom",
    strategy: o = "absolute",
    middleware: n = [],
    platform: s
  } = r, i = n.filter(Boolean), l = await (s.isRTL == null ? void 0 : s.isRTL(t));
  let c = await s.getElementRects({
    reference: e,
    floating: t,
    strategy: o
  }), {
    x: u,
    y: f
  } = dd(c, a, l), p = a, h = {}, m = 0;
  for (let v = 0; v < i.length; v++) {
    const {
      name: x,
      fn: C
    } = i[v], {
      x: S,
      y: E,
      data: T,
      reset: F
    } = await C({
      x: u,
      y: f,
      initialPlacement: a,
      placement: p,
      strategy: o,
      middlewareData: h,
      rects: c,
      platform: s,
      elements: {
        reference: e,
        floating: t
      }
    });
    u = S ?? u, f = E ?? f, h = {
      ...h,
      [x]: {
        ...h[x],
        ...T
      }
    }, F && m <= 50 && (m++, typeof F == "object" && (F.placement && (p = F.placement), F.rects && (c = F.rects === !0 ? await s.getElementRects({
      reference: e,
      floating: t,
      strategy: o
    }) : F.rects), {
      x: u,
      y: f
    } = dd(c, p, l)), v = -1);
  }
  return {
    x: u,
    y: f,
    placement: p,
    strategy: o,
    middlewareData: h
  };
};
async function So(e, t) {
  var r;
  t === void 0 && (t = {});
  const {
    x: a,
    y: o,
    platform: n,
    rects: s,
    elements: i,
    strategy: l
  } = e, {
    boundary: c = "clippingAncestors",
    rootBoundary: u = "viewport",
    elementContext: f = "floating",
    altBoundary: p = !1,
    padding: h = 0
  } = Cr(t, e), m = I0(h), x = i[p ? f === "floating" ? "reference" : "floating" : f], C = Sn(await n.getClippingRect({
    element: (r = await (n.isElement == null ? void 0 : n.isElement(x))) == null || r ? x : x.contextElement || await (n.getDocumentElement == null ? void 0 : n.getDocumentElement(i.floating)),
    boundary: c,
    rootBoundary: u,
    strategy: l
  })), S = f === "floating" ? {
    x: a,
    y: o,
    width: s.floating.width,
    height: s.floating.height
  } : s.reference, E = await (n.getOffsetParent == null ? void 0 : n.getOffsetParent(i.floating)), T = await (n.isElement == null ? void 0 : n.isElement(E)) ? await (n.getScale == null ? void 0 : n.getScale(E)) || {
    x: 1,
    y: 1
  } : {
    x: 1,
    y: 1
  }, F = Sn(n.convertOffsetParentRelativeRectToViewportRelativeRect ? await n.convertOffsetParentRelativeRectToViewportRelativeRect({
    elements: i,
    rect: S,
    offsetParent: E,
    strategy: l
  }) : S);
  return {
    top: (C.top - F.top + m.top) / T.y,
    bottom: (F.bottom - C.bottom + m.bottom) / T.y,
    left: (C.left - F.left + m.left) / T.x,
    right: (F.right - C.right + m.right) / T.x
  };
}
const q4 = (e) => ({
  name: "arrow",
  options: e,
  async fn(t) {
    const {
      x: r,
      y: a,
      placement: o,
      rects: n,
      platform: s,
      elements: i,
      middlewareData: l
    } = t, {
      element: c,
      padding: u = 0
    } = Cr(e, t) || {};
    if (c == null)
      return {};
    const f = I0(u), p = {
      x: r,
      y: a
    }, h = jl(o), m = zl(h), v = await s.getDimensions(c), x = h === "y", C = x ? "top" : "left", S = x ? "bottom" : "right", E = x ? "clientHeight" : "clientWidth", T = n.reference[m] + n.reference[h] - p[h] - n.floating[m], F = p[h] - n.reference[h], j = await (s.getOffsetParent == null ? void 0 : s.getOffsetParent(c));
    let H = j ? j[E] : 0;
    (!H || !await (s.isElement == null ? void 0 : s.isElement(j))) && (H = i.floating[E] || n.floating[m]);
    const B = T / 2 - F / 2, P = H / 2 - v[m] / 2 - 1, $ = Zr(f[C], P), V = Zr(f[S], P), z = $, G = H - v[m] - V, ee = H / 2 - v[m] / 2 + B, xe = Ui(z, ee, G), de = !l.arrow && za(o) != null && ee !== xe && n.reference[m] / 2 - (ee < z ? $ : V) - v[m] / 2 < 0, W = de ? ee < z ? ee - z : ee - G : 0;
    return {
      [h]: p[h] + W,
      data: {
        [h]: xe,
        centerOffset: ee - xe - W,
        ...de && {
          alignmentOffset: W
        }
      },
      reset: de
    };
  }
}), L4 = function(e) {
  return e === void 0 && (e = {}), {
    name: "flip",
    options: e,
    async fn(t) {
      var r, a;
      const {
        placement: o,
        middlewareData: n,
        rects: s,
        initialPlacement: i,
        platform: l,
        elements: c
      } = t, {
        mainAxis: u = !0,
        crossAxis: f = !0,
        fallbackPlacements: p,
        fallbackStrategy: h = "bestFit",
        fallbackAxisSideDirection: m = "none",
        flipAlignment: v = !0,
        ...x
      } = Cr(e, t);
      if ((r = n.arrow) != null && r.alignmentOffset)
        return {};
      const C = Ar(o), S = tr(i), E = Ar(i) === i, T = await (l.isRTL == null ? void 0 : l.isRTL(c.floating)), F = p || (E || !v ? [An(i)] : T4(i)), j = m !== "none";
      !p && j && F.push(...B4(i, v, m, T));
      const H = [i, ...F], B = await So(t, x), P = [];
      let $ = ((a = n.flip) == null ? void 0 : a.overflows) || [];
      if (u && P.push(B[C]), f) {
        const ee = P4(o, s, T);
        P.push(B[ee[0]], B[ee[1]]);
      }
      if ($ = [...$, {
        placement: o,
        overflows: P
      }], !P.every((ee) => ee <= 0)) {
        var V, z;
        const ee = (((V = n.flip) == null ? void 0 : V.index) || 0) + 1, xe = H[ee];
        if (xe && (!(f === "alignment" ? S !== tr(xe) : !1) || // We leave the current main axis only if every placement on that axis
        // overflows the main axis.
        $.every((M) => M.overflows[0] > 0 && tr(M.placement) === S)))
          return {
            data: {
              index: ee,
              overflows: $
            },
            reset: {
              placement: xe
            }
          };
        let de = (z = $.filter((W) => W.overflows[0] <= 0).sort((W, M) => W.overflows[1] - M.overflows[1])[0]) == null ? void 0 : z.placement;
        if (!de)
          switch (h) {
            case "bestFit": {
              var G;
              const W = (G = $.filter((M) => {
                if (j) {
                  const ge = tr(M.placement);
                  return ge === S || // Create a bias to the `y` side axis due to horizontal
                  // reading directions favoring greater width.
                  ge === "y";
                }
                return !0;
              }).map((M) => [M.placement, M.overflows.filter((ge) => ge > 0).reduce((ge, Me) => ge + Me, 0)]).sort((M, ge) => M[1] - ge[1])[0]) == null ? void 0 : G[0];
              W && (de = W);
              break;
            }
            case "initialPlacement":
              de = i;
              break;
          }
        if (o !== de)
          return {
            reset: {
              placement: de
            }
          };
      }
      return {};
    }
  };
};
function fd(e, t) {
  return {
    top: e.top - t.height,
    right: e.right - t.width,
    bottom: e.bottom - t.height,
    left: e.left - t.width
  };
}
function pd(e) {
  return A4.some((t) => e[t] >= 0);
}
const N4 = function(e) {
  return e === void 0 && (e = {}), {
    name: "hide",
    options: e,
    async fn(t) {
      const {
        rects: r
      } = t, {
        strategy: a = "referenceHidden",
        ...o
      } = Cr(e, t);
      switch (a) {
        case "referenceHidden": {
          const n = await So(t, {
            ...o,
            elementContext: "reference"
          }), s = fd(n, r.reference);
          return {
            data: {
              referenceHiddenOffsets: s,
              referenceHidden: pd(s)
            }
          };
        }
        case "escaped": {
          const n = await So(t, {
            ...o,
            altBoundary: !0
          }), s = fd(n, r.floating);
          return {
            data: {
              escapedOffsets: s,
              escaped: pd(s)
            }
          };
        }
        default:
          return {};
      }
    }
  };
}, q0 = /* @__PURE__ */ new Set(["left", "top"]);
async function V4(e, t) {
  const {
    placement: r,
    platform: a,
    elements: o
  } = e, n = await (a.isRTL == null ? void 0 : a.isRTL(o.floating)), s = Ar(r), i = za(r), l = tr(r) === "y", c = q0.has(s) ? -1 : 1, u = n && l ? -1 : 1, f = Cr(t, e);
  let {
    mainAxis: p,
    crossAxis: h,
    alignmentAxis: m
  } = typeof f == "number" ? {
    mainAxis: f,
    crossAxis: 0,
    alignmentAxis: null
  } : {
    mainAxis: f.mainAxis || 0,
    crossAxis: f.crossAxis || 0,
    alignmentAxis: f.alignmentAxis
  };
  return i && typeof m == "number" && (h = i === "end" ? m * -1 : m), l ? {
    x: h * u,
    y: p * c
  } : {
    x: p * c,
    y: h * u
  };
}
const H4 = function(e) {
  return e === void 0 && (e = 0), {
    name: "offset",
    options: e,
    async fn(t) {
      var r, a;
      const {
        x: o,
        y: n,
        placement: s,
        middlewareData: i
      } = t, l = await V4(t, e);
      return s === ((r = i.offset) == null ? void 0 : r.placement) && (a = i.arrow) != null && a.alignmentOffset ? {} : {
        x: o + l.x,
        y: n + l.y,
        data: {
          ...l,
          placement: s
        }
      };
    }
  };
}, F4 = function(e) {
  return e === void 0 && (e = {}), {
    name: "shift",
    options: e,
    async fn(t) {
      const {
        x: r,
        y: a,
        placement: o
      } = t, {
        mainAxis: n = !0,
        crossAxis: s = !1,
        limiter: i = {
          fn: (x) => {
            let {
              x: C,
              y: S
            } = x;
            return {
              x: C,
              y: S
            };
          }
        },
        ...l
      } = Cr(e, t), c = {
        x: r,
        y: a
      }, u = await So(t, l), f = tr(Ar(o)), p = Fl(f);
      let h = c[p], m = c[f];
      if (n) {
        const x = p === "y" ? "top" : "left", C = p === "y" ? "bottom" : "right", S = h + u[x], E = h - u[C];
        h = Ui(S, h, E);
      }
      if (s) {
        const x = f === "y" ? "top" : "left", C = f === "y" ? "bottom" : "right", S = m + u[x], E = m - u[C];
        m = Ui(S, m, E);
      }
      const v = i.fn({
        ...t,
        [p]: h,
        [f]: m
      });
      return {
        ...v,
        data: {
          x: v.x - r,
          y: v.y - a,
          enabled: {
            [p]: n,
            [f]: s
          }
        }
      };
    }
  };
}, z4 = function(e) {
  return e === void 0 && (e = {}), {
    options: e,
    fn(t) {
      const {
        x: r,
        y: a,
        placement: o,
        rects: n,
        middlewareData: s
      } = t, {
        offset: i = 0,
        mainAxis: l = !0,
        crossAxis: c = !0
      } = Cr(e, t), u = {
        x: r,
        y: a
      }, f = tr(o), p = Fl(f);
      let h = u[p], m = u[f];
      const v = Cr(i, t), x = typeof v == "number" ? {
        mainAxis: v,
        crossAxis: 0
      } : {
        mainAxis: 0,
        crossAxis: 0,
        ...v
      };
      if (l) {
        const E = p === "y" ? "height" : "width", T = n.reference[p] - n.floating[E] + x.mainAxis, F = n.reference[p] + n.reference[E] - x.mainAxis;
        h < T ? h = T : h > F && (h = F);
      }
      if (c) {
        var C, S;
        const E = p === "y" ? "width" : "height", T = q0.has(Ar(o)), F = n.reference[f] - n.floating[E] + (T && ((C = s.offset) == null ? void 0 : C[f]) || 0) + (T ? 0 : x.crossAxis), j = n.reference[f] + n.reference[E] + (T ? 0 : ((S = s.offset) == null ? void 0 : S[f]) || 0) - (T ? x.crossAxis : 0);
        m < F ? m = F : m > j && (m = j);
      }
      return {
        [p]: h,
        [f]: m
      };
    }
  };
}, j4 = function(e) {
  return e === void 0 && (e = {}), {
    name: "size",
    options: e,
    async fn(t) {
      var r, a;
      const {
        placement: o,
        rects: n,
        platform: s,
        elements: i
      } = t, {
        apply: l = () => {
        },
        ...c
      } = Cr(e, t), u = await So(t, c), f = Ar(o), p = za(o), h = tr(o) === "y", {
        width: m,
        height: v
      } = n.floating;
      let x, C;
      f === "top" || f === "bottom" ? (x = f, C = p === (await (s.isRTL == null ? void 0 : s.isRTL(i.floating)) ? "start" : "end") ? "left" : "right") : (C = f, x = p === "end" ? "top" : "bottom");
      const S = v - u.top - u.bottom, E = m - u.left - u.right, T = Zr(v - u[x], S), F = Zr(m - u[C], E), j = !t.middlewareData.shift;
      let H = T, B = F;
      if ((r = t.middlewareData.shift) != null && r.enabled.x && (B = E), (a = t.middlewareData.shift) != null && a.enabled.y && (H = S), j && !p) {
        const $ = $t(u.left, 0), V = $t(u.right, 0), z = $t(u.top, 0), G = $t(u.bottom, 0);
        h ? B = m - 2 * ($ !== 0 || V !== 0 ? $ + V : $t(u.left, u.right)) : H = v - 2 * (z !== 0 || G !== 0 ? z + G : $t(u.top, u.bottom));
      }
      await l({
        ...t,
        availableWidth: B,
        availableHeight: H
      });
      const P = await s.getDimensions(i.floating);
      return m !== P.width || v !== P.height ? {
        reset: {
          rects: !0
        }
      } : {};
    }
  };
};
function is() {
  return typeof window < "u";
}
function fa(e) {
  return Ul(e) ? (e.nodeName || "").toLowerCase() : "#document";
}
function Mt(e) {
  var t;
  return (e == null || (t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
}
function fr(e) {
  var t;
  return (t = (Ul(e) ? e.ownerDocument : e.document) || window.document) == null ? void 0 : t.documentElement;
}
function Ul(e) {
  return is() ? e instanceof Node || e instanceof Mt(e).Node : !1;
}
function Ht(e) {
  return is() ? e instanceof Element || e instanceof Mt(e).Element : !1;
}
function cr(e) {
  return is() ? e instanceof HTMLElement || e instanceof Mt(e).HTMLElement : !1;
}
function hd(e) {
  return !is() || typeof ShadowRoot > "u" ? !1 : e instanceof ShadowRoot || e instanceof Mt(e).ShadowRoot;
}
const U4 = /* @__PURE__ */ new Set(["inline", "contents"]);
function No(e) {
  const {
    overflow: t,
    overflowX: r,
    overflowY: a,
    display: o
  } = Ft(e);
  return /auto|scroll|overlay|hidden|clip/.test(t + a + r) && !U4.has(o);
}
const Z4 = /* @__PURE__ */ new Set(["table", "td", "th"]);
function K4(e) {
  return Z4.has(fa(e));
}
const W4 = [":popover-open", ":modal"];
function ls(e) {
  return W4.some((t) => {
    try {
      return e.matches(t);
    } catch {
      return !1;
    }
  });
}
const G4 = ["transform", "translate", "scale", "rotate", "perspective"], J4 = ["transform", "translate", "scale", "rotate", "perspective", "filter"], Y4 = ["paint", "layout", "strict", "content"];
function Zl(e) {
  const t = Kl(), r = Ht(e) ? Ft(e) : e;
  return G4.some((a) => r[a] ? r[a] !== "none" : !1) || (r.containerType ? r.containerType !== "normal" : !1) || !t && (r.backdropFilter ? r.backdropFilter !== "none" : !1) || !t && (r.filter ? r.filter !== "none" : !1) || J4.some((a) => (r.willChange || "").includes(a)) || Y4.some((a) => (r.contain || "").includes(a));
}
function X4(e) {
  let t = Kr(e);
  for (; cr(t) && !Ba(t); ) {
    if (Zl(t))
      return t;
    if (ls(t))
      return null;
    t = Kr(t);
  }
  return null;
}
function Kl() {
  return typeof CSS > "u" || !CSS.supports ? !1 : CSS.supports("-webkit-backdrop-filter", "none");
}
const Q4 = /* @__PURE__ */ new Set(["html", "body", "#document"]);
function Ba(e) {
  return Q4.has(fa(e));
}
function Ft(e) {
  return Mt(e).getComputedStyle(e);
}
function cs(e) {
  return Ht(e) ? {
    scrollLeft: e.scrollLeft,
    scrollTop: e.scrollTop
  } : {
    scrollLeft: e.scrollX,
    scrollTop: e.scrollY
  };
}
function Kr(e) {
  if (fa(e) === "html")
    return e;
  const t = (
    // Step into the shadow DOM of the parent of a slotted node.
    e.assignedSlot || // DOM Element detected.
    e.parentNode || // ShadowRoot detected.
    hd(e) && e.host || // Fallback.
    fr(e)
  );
  return hd(t) ? t.host : t;
}
function L0(e) {
  const t = Kr(e);
  return Ba(t) ? e.ownerDocument ? e.ownerDocument.body : e.body : cr(t) && No(t) ? t : L0(t);
}
function Eo(e, t, r) {
  var a;
  t === void 0 && (t = []), r === void 0 && (r = !0);
  const o = L0(e), n = o === ((a = e.ownerDocument) == null ? void 0 : a.body), s = Mt(o);
  if (n) {
    const i = Ki(s);
    return t.concat(s, s.visualViewport || [], No(o) ? o : [], i && r ? Eo(i) : []);
  }
  return t.concat(o, Eo(o, [], r));
}
function Ki(e) {
  return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null;
}
function N0(e) {
  const t = Ft(e);
  let r = parseFloat(t.width) || 0, a = parseFloat(t.height) || 0;
  const o = cr(e), n = o ? e.offsetWidth : r, s = o ? e.offsetHeight : a, i = Cn(r) !== n || Cn(a) !== s;
  return i && (r = n, a = s), {
    width: r,
    height: a,
    $: i
  };
}
function Wl(e) {
  return Ht(e) ? e : e.contextElement;
}
function Pa(e) {
  const t = Wl(e);
  if (!cr(t))
    return or(1);
  const r = t.getBoundingClientRect(), {
    width: a,
    height: o,
    $: n
  } = N0(t);
  let s = (n ? Cn(r.width) : r.width) / a, i = (n ? Cn(r.height) : r.height) / o;
  return (!s || !Number.isFinite(s)) && (s = 1), (!i || !Number.isFinite(i)) && (i = 1), {
    x: s,
    y: i
  };
}
const ex = /* @__PURE__ */ or(0);
function V0(e) {
  const t = Mt(e);
  return !Kl() || !t.visualViewport ? ex : {
    x: t.visualViewport.offsetLeft,
    y: t.visualViewport.offsetTop
  };
}
function tx(e, t, r) {
  return t === void 0 && (t = !1), !r || t && r !== Mt(e) ? !1 : t;
}
function la(e, t, r, a) {
  t === void 0 && (t = !1), r === void 0 && (r = !1);
  const o = e.getBoundingClientRect(), n = Wl(e);
  let s = or(1);
  t && (a ? Ht(a) && (s = Pa(a)) : s = Pa(e));
  const i = tx(n, r, a) ? V0(n) : or(0);
  let l = (o.left + i.x) / s.x, c = (o.top + i.y) / s.y, u = o.width / s.x, f = o.height / s.y;
  if (n) {
    const p = Mt(n), h = a && Ht(a) ? Mt(a) : a;
    let m = p, v = Ki(m);
    for (; v && a && h !== m; ) {
      const x = Pa(v), C = v.getBoundingClientRect(), S = Ft(v), E = C.left + (v.clientLeft + parseFloat(S.paddingLeft)) * x.x, T = C.top + (v.clientTop + parseFloat(S.paddingTop)) * x.y;
      l *= x.x, c *= x.y, u *= x.x, f *= x.y, l += E, c += T, m = Mt(v), v = Ki(m);
    }
  }
  return Sn({
    width: u,
    height: f,
    x: l,
    y: c
  });
}
function Gl(e, t) {
  const r = cs(e).scrollLeft;
  return t ? t.left + r : la(fr(e)).left + r;
}
function H0(e, t, r) {
  r === void 0 && (r = !1);
  const a = e.getBoundingClientRect(), o = a.left + t.scrollLeft - (r ? 0 : (
    // RTL <body> scrollbar.
    Gl(e, a)
  )), n = a.top + t.scrollTop;
  return {
    x: o,
    y: n
  };
}
function rx(e) {
  let {
    elements: t,
    rect: r,
    offsetParent: a,
    strategy: o
  } = e;
  const n = o === "fixed", s = fr(a), i = t ? ls(t.floating) : !1;
  if (a === s || i && n)
    return r;
  let l = {
    scrollLeft: 0,
    scrollTop: 0
  }, c = or(1);
  const u = or(0), f = cr(a);
  if ((f || !f && !n) && ((fa(a) !== "body" || No(s)) && (l = cs(a)), cr(a))) {
    const h = la(a);
    c = Pa(a), u.x = h.x + a.clientLeft, u.y = h.y + a.clientTop;
  }
  const p = s && !f && !n ? H0(s, l, !0) : or(0);
  return {
    width: r.width * c.x,
    height: r.height * c.y,
    x: r.x * c.x - l.scrollLeft * c.x + u.x + p.x,
    y: r.y * c.y - l.scrollTop * c.y + u.y + p.y
  };
}
function ax(e) {
  return Array.from(e.getClientRects());
}
function ox(e) {
  const t = fr(e), r = cs(e), a = e.ownerDocument.body, o = $t(t.scrollWidth, t.clientWidth, a.scrollWidth, a.clientWidth), n = $t(t.scrollHeight, t.clientHeight, a.scrollHeight, a.clientHeight);
  let s = -r.scrollLeft + Gl(e);
  const i = -r.scrollTop;
  return Ft(a).direction === "rtl" && (s += $t(t.clientWidth, a.clientWidth) - o), {
    width: o,
    height: n,
    x: s,
    y: i
  };
}
function nx(e, t) {
  const r = Mt(e), a = fr(e), o = r.visualViewport;
  let n = a.clientWidth, s = a.clientHeight, i = 0, l = 0;
  if (o) {
    n = o.width, s = o.height;
    const c = Kl();
    (!c || c && t === "fixed") && (i = o.offsetLeft, l = o.offsetTop);
  }
  return {
    width: n,
    height: s,
    x: i,
    y: l
  };
}
const sx = /* @__PURE__ */ new Set(["absolute", "fixed"]);
function ix(e, t) {
  const r = la(e, !0, t === "fixed"), a = r.top + e.clientTop, o = r.left + e.clientLeft, n = cr(e) ? Pa(e) : or(1), s = e.clientWidth * n.x, i = e.clientHeight * n.y, l = o * n.x, c = a * n.y;
  return {
    width: s,
    height: i,
    x: l,
    y: c
  };
}
function gd(e, t, r) {
  let a;
  if (t === "viewport")
    a = nx(e, r);
  else if (t === "document")
    a = ox(fr(e));
  else if (Ht(t))
    a = ix(t, r);
  else {
    const o = V0(e);
    a = {
      x: t.x - o.x,
      y: t.y - o.y,
      width: t.width,
      height: t.height
    };
  }
  return Sn(a);
}
function F0(e, t) {
  const r = Kr(e);
  return r === t || !Ht(r) || Ba(r) ? !1 : Ft(r).position === "fixed" || F0(r, t);
}
function lx(e, t) {
  const r = t.get(e);
  if (r)
    return r;
  let a = Eo(e, [], !1).filter((i) => Ht(i) && fa(i) !== "body"), o = null;
  const n = Ft(e).position === "fixed";
  let s = n ? Kr(e) : e;
  for (; Ht(s) && !Ba(s); ) {
    const i = Ft(s), l = Zl(s);
    !l && i.position === "fixed" && (o = null), (n ? !l && !o : !l && i.position === "static" && !!o && sx.has(o.position) || No(s) && !l && F0(e, s)) ? a = a.filter((u) => u !== s) : o = i, s = Kr(s);
  }
  return t.set(e, a), a;
}
function cx(e) {
  let {
    element: t,
    boundary: r,
    rootBoundary: a,
    strategy: o
  } = e;
  const s = [...r === "clippingAncestors" ? ls(t) ? [] : lx(t, this._c) : [].concat(r), a], i = s[0], l = s.reduce((c, u) => {
    const f = gd(t, u, o);
    return c.top = $t(f.top, c.top), c.right = Zr(f.right, c.right), c.bottom = Zr(f.bottom, c.bottom), c.left = $t(f.left, c.left), c;
  }, gd(t, i, o));
  return {
    width: l.right - l.left,
    height: l.bottom - l.top,
    x: l.left,
    y: l.top
  };
}
function ux(e) {
  const {
    width: t,
    height: r
  } = N0(e);
  return {
    width: t,
    height: r
  };
}
function dx(e, t, r) {
  const a = cr(t), o = fr(t), n = r === "fixed", s = la(e, !0, n, t);
  let i = {
    scrollLeft: 0,
    scrollTop: 0
  };
  const l = or(0);
  function c() {
    l.x = Gl(o);
  }
  if (a || !a && !n)
    if ((fa(t) !== "body" || No(o)) && (i = cs(t)), a) {
      const h = la(t, !0, n, t);
      l.x = h.x + t.clientLeft, l.y = h.y + t.clientTop;
    } else o && c();
  n && !a && o && c();
  const u = o && !a && !n ? H0(o, i) : or(0), f = s.left + i.scrollLeft - l.x - u.x, p = s.top + i.scrollTop - l.y - u.y;
  return {
    x: f,
    y: p,
    width: s.width,
    height: s.height
  };
}
function ii(e) {
  return Ft(e).position === "static";
}
function md(e, t) {
  if (!cr(e) || Ft(e).position === "fixed")
    return null;
  if (t)
    return t(e);
  let r = e.offsetParent;
  return fr(e) === r && (r = r.ownerDocument.body), r;
}
function z0(e, t) {
  const r = Mt(e);
  if (ls(e))
    return r;
  if (!cr(e)) {
    let o = Kr(e);
    for (; o && !Ba(o); ) {
      if (Ht(o) && !ii(o))
        return o;
      o = Kr(o);
    }
    return r;
  }
  let a = md(e, t);
  for (; a && K4(a) && ii(a); )
    a = md(a, t);
  return a && Ba(a) && ii(a) && !Zl(a) ? r : a || X4(e) || r;
}
const fx = async function(e) {
  const t = this.getOffsetParent || z0, r = this.getDimensions, a = await r(e.floating);
  return {
    reference: dx(e.reference, await t(e.floating), e.strategy),
    floating: {
      x: 0,
      y: 0,
      width: a.width,
      height: a.height
    }
  };
};
function px(e) {
  return Ft(e).direction === "rtl";
}
const hx = {
  convertOffsetParentRelativeRectToViewportRelativeRect: rx,
  getDocumentElement: fr,
  getClippingRect: cx,
  getOffsetParent: z0,
  getElementRects: fx,
  getClientRects: ax,
  getDimensions: ux,
  getScale: Pa,
  isElement: Ht,
  isRTL: px
};
function j0(e, t) {
  return e.x === t.x && e.y === t.y && e.width === t.width && e.height === t.height;
}
function gx(e, t) {
  let r = null, a;
  const o = fr(e);
  function n() {
    var i;
    clearTimeout(a), (i = r) == null || i.disconnect(), r = null;
  }
  function s(i, l) {
    i === void 0 && (i = !1), l === void 0 && (l = 1), n();
    const c = e.getBoundingClientRect(), {
      left: u,
      top: f,
      width: p,
      height: h
    } = c;
    if (i || t(), !p || !h)
      return;
    const m = Xo(f), v = Xo(o.clientWidth - (u + p)), x = Xo(o.clientHeight - (f + h)), C = Xo(u), E = {
      rootMargin: -m + "px " + -v + "px " + -x + "px " + -C + "px",
      threshold: $t(0, Zr(1, l)) || 1
    };
    let T = !0;
    function F(j) {
      const H = j[0].intersectionRatio;
      if (H !== l) {
        if (!T)
          return s();
        H ? s(!1, H) : a = setTimeout(() => {
          s(!1, 1e-7);
        }, 1e3);
      }
      H === 1 && !j0(c, e.getBoundingClientRect()) && s(), T = !1;
    }
    try {
      r = new IntersectionObserver(F, {
        ...E,
        // Handle <iframe>s
        root: o.ownerDocument
      });
    } catch {
      r = new IntersectionObserver(F, E);
    }
    r.observe(e);
  }
  return s(!0), n;
}
function mx(e, t, r, a) {
  a === void 0 && (a = {});
  const {
    ancestorScroll: o = !0,
    ancestorResize: n = !0,
    elementResize: s = typeof ResizeObserver == "function",
    layoutShift: i = typeof IntersectionObserver == "function",
    animationFrame: l = !1
  } = a, c = Wl(e), u = o || n ? [...c ? Eo(c) : [], ...Eo(t)] : [];
  u.forEach((C) => {
    o && C.addEventListener("scroll", r, {
      passive: !0
    }), n && C.addEventListener("resize", r);
  });
  const f = c && i ? gx(c, r) : null;
  let p = -1, h = null;
  s && (h = new ResizeObserver((C) => {
    let [S] = C;
    S && S.target === c && h && (h.unobserve(t), cancelAnimationFrame(p), p = requestAnimationFrame(() => {
      var E;
      (E = h) == null || E.observe(t);
    })), r();
  }), c && !l && h.observe(c), h.observe(t));
  let m, v = l ? la(e) : null;
  l && x();
  function x() {
    const C = la(e);
    v && !j0(v, C) && r(), v = C, m = requestAnimationFrame(x);
  }
  return r(), () => {
    var C;
    u.forEach((S) => {
      o && S.removeEventListener("scroll", r), n && S.removeEventListener("resize", r);
    }), f?.(), (C = h) == null || C.disconnect(), h = null, l && cancelAnimationFrame(m);
  };
}
const vx = H4, bx = F4, vd = L4, yx = j4, wx = N4, xx = q4, _x = z4, kx = (e, t, r) => {
  const a = /* @__PURE__ */ new Map(), o = {
    platform: hx,
    ...r
  }, n = {
    ...o.platform,
    _c: a
  };
  return I4(e, t, {
    ...o,
    platform: n
  });
};
function Cx(e) {
  return e != null && typeof e == "object" && "$el" in e;
}
function Wi(e) {
  if (Cx(e)) {
    const t = e.$el;
    return Ul(t) && fa(t) === "#comment" ? null : t;
  }
  return e;
}
function _a(e) {
  return typeof e == "function" ? e() : d(e);
}
function Ax(e) {
  return {
    name: "arrow",
    options: e,
    fn(t) {
      const r = Wi(_a(e.element));
      return r == null ? {} : xx({
        element: r,
        padding: e.padding
      }).fn(t);
    }
  };
}
function U0(e) {
  return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function bd(e, t) {
  const r = U0(e);
  return Math.round(t * r) / r;
}
function Sx(e, t, r) {
  r === void 0 && (r = {});
  const a = r.whileElementsMounted, o = L(() => {
    var H;
    return (H = _a(r.open)) != null ? H : !0;
  }), n = L(() => _a(r.middleware)), s = L(() => {
    var H;
    return (H = _a(r.placement)) != null ? H : "bottom";
  }), i = L(() => {
    var H;
    return (H = _a(r.strategy)) != null ? H : "absolute";
  }), l = L(() => {
    var H;
    return (H = _a(r.transform)) != null ? H : !0;
  }), c = L(() => Wi(e.value)), u = L(() => Wi(t.value)), f = K(0), p = K(0), h = K(i.value), m = K(s.value), v = ar({}), x = K(!1), C = L(() => {
    const H = {
      position: h.value,
      left: "0",
      top: "0"
    };
    if (!u.value)
      return H;
    const B = bd(u.value, f.value), P = bd(u.value, p.value);
    return l.value ? {
      ...H,
      transform: "translate(" + B + "px, " + P + "px)",
      ...U0(u.value) >= 1.5 && {
        willChange: "transform"
      }
    } : {
      position: h.value,
      left: B + "px",
      top: P + "px"
    };
  });
  let S;
  function E() {
    if (c.value == null || u.value == null)
      return;
    const H = o.value;
    kx(c.value, u.value, {
      middleware: n.value,
      placement: s.value,
      strategy: i.value
    }).then((B) => {
      f.value = B.x, p.value = B.y, h.value = B.strategy, m.value = B.placement, v.value = B.middlewareData, x.value = H !== !1;
    });
  }
  function T() {
    typeof S == "function" && (S(), S = void 0);
  }
  function F() {
    if (T(), a === void 0) {
      E();
      return;
    }
    if (c.value != null && u.value != null) {
      S = a(c.value, u.value, E);
      return;
    }
  }
  function j() {
    o.value || (x.value = !1);
  }
  return Ke([n, s, i, o], E, {
    flush: "sync"
  }), Ke([c, u], F, {
    flush: "sync"
  }), Ke(o, j, {
    flush: "sync"
  }), $o() && In(T), {
    x: ea(f),
    y: ea(p),
    strategy: ea(h),
    placement: ea(m),
    middlewareData: ea(v),
    isPositioned: ea(x),
    floatingStyles: C,
    update: E
  };
}
const Z0 = {
  side: "bottom",
  sideOffset: 0,
  sideFlip: !0,
  align: "center",
  alignOffset: 0,
  alignFlip: !0,
  arrowPadding: 0,
  hideShiftedArrow: !0,
  avoidCollisions: !0,
  collisionBoundary: () => [],
  collisionPadding: 0,
  sticky: "partial",
  hideWhenDetached: !1,
  positionStrategy: "fixed",
  updatePositionStrategy: "optimized",
  prioritizePosition: !1
}, [Ex, $x] = it("PopperContent");
var Px = /* @__PURE__ */ D({
  inheritAttrs: !1,
  __name: "PopperContent",
  props: /* @__PURE__ */ Ef({
    side: {
      type: null,
      required: !1
    },
    sideOffset: {
      type: Number,
      required: !1
    },
    sideFlip: {
      type: Boolean,
      required: !1
    },
    align: {
      type: null,
      required: !1
    },
    alignOffset: {
      type: Number,
      required: !1
    },
    alignFlip: {
      type: Boolean,
      required: !1
    },
    avoidCollisions: {
      type: Boolean,
      required: !1
    },
    collisionBoundary: {
      type: null,
      required: !1
    },
    collisionPadding: {
      type: [Number, Object],
      required: !1
    },
    arrowPadding: {
      type: Number,
      required: !1
    },
    hideShiftedArrow: {
      type: Boolean,
      required: !1
    },
    sticky: {
      type: String,
      required: !1
    },
    hideWhenDetached: {
      type: Boolean,
      required: !1
    },
    positionStrategy: {
      type: String,
      required: !1
    },
    updatePositionStrategy: {
      type: String,
      required: !1
    },
    disableUpdateOnLayoutShift: {
      type: Boolean,
      required: !1
    },
    prioritizePosition: {
      type: Boolean,
      required: !1
    },
    reference: {
      type: null,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  }, { ...Z0 }),
  emits: ["placed"],
  setup(e, { emit: t }) {
    const r = e, a = t, o = D0(), { forwardRef: n, currentElement: s } = be(), i = K(), l = K(), { width: c, height: u } = D2(l), f = L(() => r.side + (r.align !== "center" ? `-${r.align}` : "")), p = L(() => typeof r.collisionPadding == "number" ? r.collisionPadding : {
      top: 0,
      right: 0,
      bottom: 0,
      left: 0,
      ...r.collisionPadding
    }), h = L(() => Array.isArray(r.collisionBoundary) ? r.collisionBoundary : [r.collisionBoundary]), m = L(() => ({
      padding: p.value,
      boundary: h.value.filter(k4),
      altBoundary: h.value.length > 0
    })), v = L(() => ({
      mainAxis: r.sideFlip,
      crossAxis: r.alignFlip
    })), x = n2(() => [
      vx({
        mainAxis: r.sideOffset + u.value,
        alignmentAxis: r.alignOffset
      }),
      r.prioritizePosition && r.avoidCollisions && vd({
        ...m.value,
        ...v.value
      }),
      r.avoidCollisions && bx({
        mainAxis: !0,
        crossAxis: !!r.prioritizePosition,
        limiter: r.sticky === "partial" ? _x() : void 0,
        ...m.value
      }),
      !r.prioritizePosition && r.avoidCollisions && vd({
        ...m.value,
        ...v.value
      }),
      yx({
        ...m.value,
        apply: ({ elements: z, rects: G, availableWidth: ee, availableHeight: xe }) => {
          const { width: de, height: W } = G.reference, M = z.floating.style;
          M.setProperty("--reka-popper-available-width", `${ee}px`), M.setProperty("--reka-popper-available-height", `${xe}px`), M.setProperty("--reka-popper-anchor-width", `${de}px`), M.setProperty("--reka-popper-anchor-height", `${W}px`);
        }
      }),
      l.value && Ax({
        element: l.value,
        padding: r.arrowPadding
      }),
      C4({
        arrowWidth: c.value,
        arrowHeight: u.value
      }),
      r.hideWhenDetached && wx({
        strategy: "referenceHidden",
        ...m.value
      })
    ]), C = L(() => r.reference ?? o.anchor.value), { floatingStyles: S, placement: E, isPositioned: T, middlewareData: F } = Sx(C, i, {
      strategy: r.positionStrategy,
      placement: f,
      whileElementsMounted: (...z) => mx(...z, {
        layoutShift: !r.disableUpdateOnLayoutShift,
        animationFrame: r.updatePositionStrategy === "always"
      }),
      middleware: x
    }), j = L(() => ji(E.value)[0]), H = L(() => ji(E.value)[1]);
    Vf(() => {
      T.value && a("placed");
    });
    const B = L(() => {
      const z = F.value.arrow?.centerOffset !== 0;
      return r.hideShiftedArrow && z;
    }), P = K("");
    Xe(() => {
      s.value && (P.value = window.getComputedStyle(s.value).zIndex);
    });
    const $ = L(() => F.value.arrow?.x ?? 0), V = L(() => F.value.arrow?.y ?? 0);
    return $x({
      placedSide: j,
      onArrowChange: (z) => l.value = z,
      arrowX: $,
      arrowY: V,
      shouldHideArrow: B
    }), (z, G) => (g(), R("div", {
      ref_key: "floatingRef",
      ref: i,
      "data-reka-popper-content-wrapper": "",
      style: Tt({
        ...d(S),
        transform: d(T) ? d(S).transform : "translate(0, -200%)",
        minWidth: "max-content",
        zIndex: P.value,
        "--reka-popper-transform-origin": [d(F).transformOrigin?.x, d(F).transformOrigin?.y].join(" "),
        ...d(F).hide?.referenceHidden && {
          visibility: "hidden",
          pointerEvents: "none"
        }
      })
    }, [k(d(Re), re({ ref: d(n) }, z.$attrs, {
      "as-child": r.asChild,
      as: z.as,
      "data-side": j.value,
      "data-align": H.value,
      style: { animation: d(T) ? void 0 : "none" }
    }), {
      default: b(() => [q(z.$slots, "default")]),
      _: 3
    }, 16, [
      "as-child",
      "as",
      "data-side",
      "data-align",
      "style"
    ])], 4));
  }
}), Jl = Px;
const Tx = {
  top: "bottom",
  right: "left",
  bottom: "top",
  left: "right"
};
var Mx = /* @__PURE__ */ D({
  inheritAttrs: !1,
  __name: "PopperArrow",
  props: {
    width: {
      type: Number,
      required: !1
    },
    height: {
      type: Number,
      required: !1
    },
    rounded: {
      type: Boolean,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "svg"
    }
  },
  setup(e) {
    const { forwardRef: t } = be(), r = Ex(), a = L(() => Tx[r.placedSide.value]);
    return (o, n) => (g(), R("span", {
      ref: (s) => {
        d(r).onArrowChange(s);
      },
      style: Tt({
        position: "absolute",
        left: d(r).arrowX?.value ? `${d(r).arrowX?.value}px` : void 0,
        top: d(r).arrowY?.value ? `${d(r).arrowY?.value}px` : void 0,
        [a.value]: 0,
        transformOrigin: {
          top: "",
          right: "0 0",
          bottom: "center 0",
          left: "100% 0"
        }[d(r).placedSide.value],
        transform: {
          top: "translateY(100%)",
          right: "translateY(50%) rotate(90deg) translateX(-50%)",
          bottom: "rotate(180deg)",
          left: "translateY(50%) rotate(-90deg) translateX(50%)"
        }[d(r).placedSide.value],
        visibility: d(r).shouldHideArrow.value ? "hidden" : void 0
      })
    }, [k(_4, re(o.$attrs, {
      ref: d(t),
      style: { display: "block" },
      as: o.as,
      "as-child": o.asChild,
      rounded: o.rounded,
      width: o.width,
      height: o.height
    }), {
      default: b(() => [q(o.$slots, "default")]),
      _: 3
    }, 16, [
      "as",
      "as-child",
      "rounded",
      "width",
      "height"
    ])], 4));
  }
}), Rx = Mx, Ox = /* @__PURE__ */ D({
  __name: "MenuAnchor",
  props: {
    reference: {
      type: null,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(Hl), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), Bx = Ox;
function Dx() {
  const e = K(!1);
  return at(() => {
    Ao("keydown", () => {
      e.value = !0;
    }, {
      capture: !0,
      passive: !0
    }), Ao(["pointerdown", "pointermove"], () => {
      e.value = !1;
    }, {
      capture: !0,
      passive: !0
    });
  }), e;
}
const Ix = /* @__PURE__ */ b0(Dx), [us, qx] = it(["MenuRoot", "MenuSub"], "MenuContext"), [Yl, Lx] = it("MenuRoot");
var Nx = /* @__PURE__ */ D({
  __name: "MenuRoot",
  props: {
    open: {
      type: Boolean,
      required: !1,
      default: !1
    },
    dir: {
      type: String,
      required: !1
    },
    modal: {
      type: Boolean,
      required: !1,
      default: !0
    }
  },
  emits: ["update:open"],
  setup(e, { emit: t }) {
    const r = e, a = t, { modal: o, dir: n } = ht(r), s = ns(n), i = /* @__PURE__ */ Gr(r, "open", a), l = K(), c = Ix();
    return qx({
      open: i,
      onOpenChange: (u) => {
        i.value = u;
      },
      content: l,
      onContentChange: (u) => {
        l.value = u;
      }
    }), Lx({
      onClose: () => {
        i.value = !1;
      },
      isUsingKeyboardRef: c,
      dir: s,
      modal: o
    }), (u, f) => (g(), N(d(Vl), null, {
      default: b(() => [q(u.$slots, "default")]),
      _: 3
    }));
  }
}), Vx = Nx;
const [K0, Hx] = it("MenuContent");
var Fx = /* @__PURE__ */ D({
  __name: "MenuContentImpl",
  props: /* @__PURE__ */ Ef({
    loop: {
      type: Boolean,
      required: !1
    },
    disableOutsidePointerEvents: {
      type: Boolean,
      required: !1
    },
    disableOutsideScroll: {
      type: Boolean,
      required: !1
    },
    trapFocus: {
      type: Boolean,
      required: !1
    },
    side: {
      type: null,
      required: !1
    },
    sideOffset: {
      type: Number,
      required: !1
    },
    sideFlip: {
      type: Boolean,
      required: !1
    },
    align: {
      type: null,
      required: !1
    },
    alignOffset: {
      type: Number,
      required: !1
    },
    alignFlip: {
      type: Boolean,
      required: !1
    },
    avoidCollisions: {
      type: Boolean,
      required: !1
    },
    collisionBoundary: {
      type: null,
      required: !1
    },
    collisionPadding: {
      type: [Number, Object],
      required: !1
    },
    arrowPadding: {
      type: Number,
      required: !1
    },
    hideShiftedArrow: {
      type: Boolean,
      required: !1
    },
    sticky: {
      type: String,
      required: !1
    },
    hideWhenDetached: {
      type: Boolean,
      required: !1
    },
    positionStrategy: {
      type: String,
      required: !1
    },
    updatePositionStrategy: {
      type: String,
      required: !1
    },
    disableUpdateOnLayoutShift: {
      type: Boolean,
      required: !1
    },
    prioritizePosition: {
      type: Boolean,
      required: !1
    },
    reference: {
      type: null,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  }, { ...Z0 }),
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "entryFocus",
    "openAutoFocus",
    "closeAutoFocus",
    "dismiss"
  ],
  setup(e, { emit: t }) {
    const r = e, a = t, o = us(), n = Yl(), { trapFocus: s, disableOutsidePointerEvents: i, loop: l } = ht(r);
    x0(), Dl(i.value);
    const c = K(""), u = K(0), f = K(0), p = K(null), h = K("right"), m = K(0), v = K(null), x = K(), { forwardRef: C, currentElement: S } = be(), { handleTypeaheadSearch: E } = q2();
    Ke(S, (P) => {
      o.onContentChange(P);
    }), $r(() => {
      window.clearTimeout(u.value);
    });
    function T(P) {
      return h.value === p.value?.side && h8(P, p.value?.area);
    }
    async function F(P) {
      a("openAutoFocus", P), !P.defaultPrevented && (P.preventDefault(), S.value?.focus({ preventScroll: !0 }));
    }
    function j(P) {
      if (P.defaultPrevented) return;
      const V = P.target.closest("[data-reka-menu-content]") === P.currentTarget, z = P.ctrlKey || P.altKey || P.metaKey, G = P.key.length === 1, ee = o2(P, Ct(), S.value, {
        loop: l.value,
        arrowKeyOptions: "vertical",
        dir: n?.dir.value,
        focus: !0,
        attributeName: "[data-reka-collection-item]:not([data-disabled])"
      });
      if (ee) return ee?.focus();
      if (P.code === "Space") return;
      const xe = x.value?.getItems() ?? [];
      if (V && (P.key === "Tab" && P.preventDefault(), !z && G && E(P.key, xe)), P.target !== S.value || !d8.includes(P.key)) return;
      P.preventDefault();
      const de = [...xe.map((W) => W.ref)];
      S0.includes(P.key) && de.reverse(), f8(de);
    }
    function H(P) {
      P?.currentTarget?.contains?.(P.target) || (window.clearTimeout(u.value), c.value = "");
    }
    function B(P) {
      if (!zi(P)) return;
      const $ = P.target, V = m.value !== P.clientX;
      if (P?.currentTarget?.contains($) && V) {
        const z = P.clientX > m.value ? "right" : "left";
        h.value = z, m.value = P.clientX;
      }
    }
    return Hx({
      onItemEnter: (P) => !!T(P),
      onItemLeave: (P) => {
        T(P) || (S.value?.focus(), v.value = null);
      },
      onTriggerLeave: (P) => !!T(P),
      searchRef: c,
      pointerGraceTimerRef: f,
      onPointerGraceIntentChange: (P) => {
        p.value = P;
      }
    }), (P, $) => (g(), N(d(Ll), {
      "as-child": "",
      trapped: d(s),
      onMountAutoFocus: F,
      onUnmountAutoFocus: $[7] || ($[7] = (V) => a("closeAutoFocus", V))
    }, {
      default: b(() => [k(d(ss), {
        "as-child": "",
        "disable-outside-pointer-events": d(i),
        onEscapeKeyDown: $[2] || ($[2] = (V) => a("escapeKeyDown", V)),
        onPointerDownOutside: $[3] || ($[3] = (V) => a("pointerDownOutside", V)),
        onFocusOutside: $[4] || ($[4] = (V) => a("focusOutside", V)),
        onInteractOutside: $[5] || ($[5] = (V) => a("interactOutside", V)),
        onDismiss: $[6] || ($[6] = (V) => a("dismiss"))
      }, {
        default: b(() => [k(d(B0), {
          ref_key: "rovingFocusGroupRef",
          ref: x,
          "current-tab-stop-id": v.value,
          "onUpdate:currentTabStopId": $[0] || ($[0] = (V) => v.value = V),
          "as-child": "",
          orientation: "vertical",
          dir: d(n).dir.value,
          loop: d(l),
          onEntryFocus: $[1] || ($[1] = (V) => {
            a("entryFocus", V), d(n).isUsingKeyboardRef.value || V.preventDefault();
          })
        }, {
          default: b(() => [k(d(Jl), {
            ref: d(C),
            role: "menu",
            as: P.as,
            "as-child": P.asChild,
            "aria-orientation": "vertical",
            "data-reka-menu-content": "",
            "data-state": d(E0)(d(o).open.value),
            dir: d(n).dir.value,
            side: P.side,
            "side-offset": P.sideOffset,
            align: P.align,
            "align-offset": P.alignOffset,
            "avoid-collisions": P.avoidCollisions,
            "collision-boundary": P.collisionBoundary,
            "collision-padding": P.collisionPadding,
            "arrow-padding": P.arrowPadding,
            "prioritize-position": P.prioritizePosition,
            "position-strategy": P.positionStrategy,
            "update-position-strategy": P.updatePositionStrategy,
            sticky: P.sticky,
            "hide-when-detached": P.hideWhenDetached,
            reference: P.reference,
            onKeydown: j,
            onBlur: H,
            onPointermove: B
          }, {
            default: b(() => [q(P.$slots, "default")]),
            _: 3
          }, 8, [
            "as",
            "as-child",
            "data-state",
            "dir",
            "side",
            "side-offset",
            "align",
            "align-offset",
            "avoid-collisions",
            "collision-boundary",
            "collision-padding",
            "arrow-padding",
            "prioritize-position",
            "position-strategy",
            "update-position-strategy",
            "sticky",
            "hide-when-detached",
            "reference"
          ])]),
          _: 3
        }, 8, [
          "current-tab-stop-id",
          "dir",
          "loop"
        ])]),
        _: 3
      }, 8, ["disable-outside-pointer-events"])]),
      _: 3
    }, 8, ["trapped"]));
  }
}), W0 = Fx, zx = /* @__PURE__ */ D({
  inheritAttrs: !1,
  __name: "MenuItemImpl",
  props: {
    disabled: {
      type: Boolean,
      required: !1
    },
    textValue: {
      type: String,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  setup(e) {
    const t = e, r = K0(), { forwardRef: a } = be(), { CollectionItem: o } = Nl(), n = K(!1);
    async function s(l) {
      l.defaultPrevented || zi(l) && (t.disabled ? r.onItemLeave(l) : r.onItemEnter(l) || l.currentTarget?.focus({ preventScroll: !0 }));
    }
    async function i(l) {
      await et(), !l.defaultPrevented && zi(l) && r.onItemLeave(l);
    }
    return (l, c) => (g(), N(d(o), { value: { textValue: l.textValue } }, {
      default: b(() => [k(d(Re), re({
        ref: d(a),
        role: "menuitem",
        tabindex: "-1"
      }, l.$attrs, {
        as: l.as,
        "as-child": l.asChild,
        "aria-disabled": l.disabled || void 0,
        "data-disabled": l.disabled ? "" : void 0,
        "data-highlighted": n.value ? "" : void 0,
        onPointermove: s,
        onPointerleave: i,
        onFocus: c[0] || (c[0] = async (u) => {
          await et(), !(u.defaultPrevented || l.disabled) && (n.value = !0);
        }),
        onBlur: c[1] || (c[1] = async (u) => {
          await et(), !u.defaultPrevented && (n.value = !1);
        })
      }), {
        default: b(() => [q(l.$slots, "default")]),
        _: 3
      }, 16, [
        "as",
        "as-child",
        "aria-disabled",
        "data-disabled",
        "data-highlighted"
      ])]),
      _: 3
    }, 8, ["value"]));
  }
}), jx = zx, Ux = /* @__PURE__ */ D({
  __name: "MenuItem",
  props: {
    disabled: {
      type: Boolean,
      required: !1
    },
    textValue: {
      type: String,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: ["select"],
  setup(e, { emit: t }) {
    const r = e, a = t, { forwardRef: o, currentElement: n } = be(), s = Yl(), i = K0(), l = K(!1);
    async function c() {
      const u = n.value;
      if (!r.disabled && u) {
        const f = new CustomEvent(c8, {
          bubbles: !0,
          cancelable: !0
        });
        a("select", f), await et(), f.defaultPrevented ? l.value = !1 : s.onClose();
      }
    }
    return (u, f) => (g(), N(jx, re(r, {
      ref: d(o),
      onClick: c,
      onPointerdown: f[0] || (f[0] = () => {
        l.value = !0;
      }),
      onPointerup: f[1] || (f[1] = async (p) => {
        await et(), !p.defaultPrevented && (l.value || p.currentTarget?.click());
      }),
      onKeydown: f[2] || (f[2] = async (p) => {
        const h = d(i).searchRef.value !== "";
        u.disabled || h && p.key === " " || d(Fi).includes(p.key) && (p.currentTarget.click(), p.preventDefault());
      })
    }), {
      default: b(() => [q(u.$slots, "default")]),
      _: 3
    }, 16));
  }
}), Zx = Ux, Kx = /* @__PURE__ */ D({
  __name: "MenuRootContentModal",
  props: {
    loop: {
      type: Boolean,
      required: !1
    },
    side: {
      type: null,
      required: !1
    },
    sideOffset: {
      type: Number,
      required: !1
    },
    sideFlip: {
      type: Boolean,
      required: !1
    },
    align: {
      type: null,
      required: !1
    },
    alignOffset: {
      type: Number,
      required: !1
    },
    alignFlip: {
      type: Boolean,
      required: !1
    },
    avoidCollisions: {
      type: Boolean,
      required: !1
    },
    collisionBoundary: {
      type: null,
      required: !1
    },
    collisionPadding: {
      type: [Number, Object],
      required: !1
    },
    arrowPadding: {
      type: Number,
      required: !1
    },
    hideShiftedArrow: {
      type: Boolean,
      required: !1
    },
    sticky: {
      type: String,
      required: !1
    },
    hideWhenDetached: {
      type: Boolean,
      required: !1
    },
    positionStrategy: {
      type: String,
      required: !1
    },
    updatePositionStrategy: {
      type: String,
      required: !1
    },
    disableUpdateOnLayoutShift: {
      type: Boolean,
      required: !1
    },
    prioritizePosition: {
      type: Boolean,
      required: !1
    },
    reference: {
      type: null,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "entryFocus",
    "openAutoFocus",
    "closeAutoFocus"
  ],
  setup(e, { emit: t }) {
    const r = e, a = t, o = rt(r, a), n = us(), { forwardRef: s, currentElement: i } = be();
    return Il(i), (l, c) => (g(), N(W0, re(d(o), {
      ref: d(s),
      "trap-focus": d(n).open.value,
      "disable-outside-pointer-events": d(n).open.value,
      "disable-outside-scroll": !0,
      onDismiss: c[0] || (c[0] = (u) => d(n).onOpenChange(!1)),
      onFocusOutside: c[1] || (c[1] = ir((u) => a("focusOutside", u), ["prevent"]))
    }), {
      default: b(() => [q(l.$slots, "default")]),
      _: 3
    }, 16, ["trap-focus", "disable-outside-pointer-events"]));
  }
}), Wx = Kx, Gx = /* @__PURE__ */ D({
  __name: "MenuRootContentNonModal",
  props: {
    loop: {
      type: Boolean,
      required: !1
    },
    side: {
      type: null,
      required: !1
    },
    sideOffset: {
      type: Number,
      required: !1
    },
    sideFlip: {
      type: Boolean,
      required: !1
    },
    align: {
      type: null,
      required: !1
    },
    alignOffset: {
      type: Number,
      required: !1
    },
    alignFlip: {
      type: Boolean,
      required: !1
    },
    avoidCollisions: {
      type: Boolean,
      required: !1
    },
    collisionBoundary: {
      type: null,
      required: !1
    },
    collisionPadding: {
      type: [Number, Object],
      required: !1
    },
    arrowPadding: {
      type: Number,
      required: !1
    },
    hideShiftedArrow: {
      type: Boolean,
      required: !1
    },
    sticky: {
      type: String,
      required: !1
    },
    hideWhenDetached: {
      type: Boolean,
      required: !1
    },
    positionStrategy: {
      type: String,
      required: !1
    },
    updatePositionStrategy: {
      type: String,
      required: !1
    },
    disableUpdateOnLayoutShift: {
      type: Boolean,
      required: !1
    },
    prioritizePosition: {
      type: Boolean,
      required: !1
    },
    reference: {
      type: null,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "entryFocus",
    "openAutoFocus",
    "closeAutoFocus"
  ],
  setup(e, { emit: t }) {
    const o = rt(e, t), n = us();
    return (s, i) => (g(), N(W0, re(d(o), {
      "trap-focus": !1,
      "disable-outside-pointer-events": !1,
      "disable-outside-scroll": !1,
      onDismiss: i[0] || (i[0] = (l) => d(n).onOpenChange(!1))
    }), {
      default: b(() => [q(s.$slots, "default")]),
      _: 3
    }, 16));
  }
}), Jx = Gx, Yx = /* @__PURE__ */ D({
  __name: "MenuContent",
  props: {
    forceMount: {
      type: Boolean,
      required: !1
    },
    loop: {
      type: Boolean,
      required: !1
    },
    side: {
      type: null,
      required: !1
    },
    sideOffset: {
      type: Number,
      required: !1
    },
    sideFlip: {
      type: Boolean,
      required: !1
    },
    align: {
      type: null,
      required: !1
    },
    alignOffset: {
      type: Number,
      required: !1
    },
    alignFlip: {
      type: Boolean,
      required: !1
    },
    avoidCollisions: {
      type: Boolean,
      required: !1
    },
    collisionBoundary: {
      type: null,
      required: !1
    },
    collisionPadding: {
      type: [Number, Object],
      required: !1
    },
    arrowPadding: {
      type: Number,
      required: !1
    },
    hideShiftedArrow: {
      type: Boolean,
      required: !1
    },
    sticky: {
      type: String,
      required: !1
    },
    hideWhenDetached: {
      type: Boolean,
      required: !1
    },
    positionStrategy: {
      type: String,
      required: !1
    },
    updatePositionStrategy: {
      type: String,
      required: !1
    },
    disableUpdateOnLayoutShift: {
      type: Boolean,
      required: !1
    },
    prioritizePosition: {
      type: Boolean,
      required: !1
    },
    reference: {
      type: null,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "entryFocus",
    "openAutoFocus",
    "closeAutoFocus"
  ],
  setup(e, { emit: t }) {
    const o = rt(e, t), n = us(), s = Yl();
    return (i, l) => (g(), N(d(Fa), { present: i.forceMount || d(n).open.value }, {
      default: b(() => [d(s).modal.value ? (g(), N(Wx, De(re({ key: 0 }, {
        ...i.$attrs,
        ...d(o)
      })), {
        default: b(() => [q(i.$slots, "default")]),
        _: 3
      }, 16)) : (g(), N(Jx, De(re({ key: 1 }, {
        ...i.$attrs,
        ...d(o)
      })), {
        default: b(() => [q(i.$slots, "default")]),
        _: 3
      }, 16))]),
      _: 3
    }, 8, ["present"]));
  }
}), Xx = Yx, Qx = /* @__PURE__ */ D({
  __name: "MenuLabel",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "div"
    }
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(Re), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), e_ = Qx, t_ = /* @__PURE__ */ D({
  __name: "MenuPortal",
  props: {
    to: {
      type: null,
      required: !1
    },
    disabled: {
      type: Boolean,
      required: !1
    },
    defer: {
      type: Boolean,
      required: !1
    },
    forceMount: {
      type: Boolean,
      required: !1
    }
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(Lo), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), r_ = t_, a_ = /* @__PURE__ */ D({
  __name: "MenuSeparator",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(Re), re(t, {
      role: "separator",
      "aria-orientation": "horizontal"
    }), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), o_ = a_;
const [Vo, n_] = it("PopoverRoot");
var s_ = /* @__PURE__ */ D({
  __name: "PopoverRoot",
  props: {
    defaultOpen: {
      type: Boolean,
      required: !1,
      default: !1
    },
    open: {
      type: Boolean,
      required: !1,
      default: void 0
    },
    modal: {
      type: Boolean,
      required: !1,
      default: !1
    }
  },
  emits: ["update:open"],
  setup(e, { emit: t }) {
    const r = e, a = t, { modal: o } = ht(r), n = /* @__PURE__ */ Gr(r, "open", a, {
      defaultValue: r.defaultOpen,
      passive: r.open === void 0
    }), s = K(), i = K(!1);
    return n_({
      contentId: "",
      triggerId: "",
      modal: o,
      open: n,
      onOpenChange: (l) => {
        n.value = l;
      },
      onOpenToggle: () => {
        n.value = !n.value;
      },
      triggerElement: s,
      hasCustomAnchor: i
    }), (l, c) => (g(), N(d(Vl), null, {
      default: b(() => [q(l.$slots, "default", {
        open: d(n),
        close: () => n.value = !1
      })]),
      _: 3
    }));
  }
}), i_ = s_, l_ = /* @__PURE__ */ D({
  __name: "PopoverContentImpl",
  props: {
    trapFocus: {
      type: Boolean,
      required: !1
    },
    side: {
      type: null,
      required: !1
    },
    sideOffset: {
      type: Number,
      required: !1
    },
    sideFlip: {
      type: Boolean,
      required: !1
    },
    align: {
      type: null,
      required: !1
    },
    alignOffset: {
      type: Number,
      required: !1
    },
    alignFlip: {
      type: Boolean,
      required: !1
    },
    avoidCollisions: {
      type: Boolean,
      required: !1
    },
    collisionBoundary: {
      type: null,
      required: !1
    },
    collisionPadding: {
      type: [Number, Object],
      required: !1
    },
    arrowPadding: {
      type: Number,
      required: !1
    },
    hideShiftedArrow: {
      type: Boolean,
      required: !1
    },
    sticky: {
      type: String,
      required: !1
    },
    hideWhenDetached: {
      type: Boolean,
      required: !1
    },
    positionStrategy: {
      type: String,
      required: !1
    },
    updatePositionStrategy: {
      type: String,
      required: !1
    },
    disableUpdateOnLayoutShift: {
      type: Boolean,
      required: !1
    },
    prioritizePosition: {
      type: Boolean,
      required: !1
    },
    reference: {
      type: null,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    },
    disableOutsidePointerEvents: {
      type: Boolean,
      required: !1
    }
  },
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "openAutoFocus",
    "closeAutoFocus"
  ],
  setup(e, { emit: t }) {
    const r = e, a = t, o = da(h2(r, "trapFocus", "disableOutsidePointerEvents")), { forwardRef: n } = be(), s = Vo();
    return x0(), (i, l) => (g(), N(d(Ll), {
      "as-child": "",
      loop: "",
      trapped: i.trapFocus,
      onMountAutoFocus: l[5] || (l[5] = (c) => a("openAutoFocus", c)),
      onUnmountAutoFocus: l[6] || (l[6] = (c) => a("closeAutoFocus", c))
    }, {
      default: b(() => [k(d(ss), {
        "as-child": "",
        "disable-outside-pointer-events": i.disableOutsidePointerEvents,
        onPointerDownOutside: l[0] || (l[0] = (c) => a("pointerDownOutside", c)),
        onInteractOutside: l[1] || (l[1] = (c) => a("interactOutside", c)),
        onEscapeKeyDown: l[2] || (l[2] = (c) => a("escapeKeyDown", c)),
        onFocusOutside: l[3] || (l[3] = (c) => a("focusOutside", c)),
        onDismiss: l[4] || (l[4] = (c) => d(s).onOpenChange(!1))
      }, {
        default: b(() => [k(d(Jl), re(d(o), {
          id: d(s).contentId,
          ref: d(n),
          "data-state": d(s).open.value ? "open" : "closed",
          "aria-labelledby": d(s).triggerId,
          style: {
            "--reka-popover-content-transform-origin": "var(--reka-popper-transform-origin)",
            "--reka-popover-content-available-width": "var(--reka-popper-available-width)",
            "--reka-popover-content-available-height": "var(--reka-popper-available-height)",
            "--reka-popover-trigger-width": "var(--reka-popper-anchor-width)",
            "--reka-popover-trigger-height": "var(--reka-popper-anchor-height)"
          },
          role: "dialog"
        }), {
          default: b(() => [q(i.$slots, "default")]),
          _: 3
        }, 16, [
          "id",
          "data-state",
          "aria-labelledby"
        ])]),
        _: 3
      }, 8, ["disable-outside-pointer-events"])]),
      _: 3
    }, 8, ["trapped"]));
  }
}), G0 = l_, c_ = /* @__PURE__ */ D({
  __name: "PopoverContentModal",
  props: {
    side: {
      type: null,
      required: !1
    },
    sideOffset: {
      type: Number,
      required: !1
    },
    sideFlip: {
      type: Boolean,
      required: !1
    },
    align: {
      type: null,
      required: !1
    },
    alignOffset: {
      type: Number,
      required: !1
    },
    alignFlip: {
      type: Boolean,
      required: !1
    },
    avoidCollisions: {
      type: Boolean,
      required: !1
    },
    collisionBoundary: {
      type: null,
      required: !1
    },
    collisionPadding: {
      type: [Number, Object],
      required: !1
    },
    arrowPadding: {
      type: Number,
      required: !1
    },
    hideShiftedArrow: {
      type: Boolean,
      required: !1
    },
    sticky: {
      type: String,
      required: !1
    },
    hideWhenDetached: {
      type: Boolean,
      required: !1
    },
    positionStrategy: {
      type: String,
      required: !1
    },
    updatePositionStrategy: {
      type: String,
      required: !1
    },
    disableUpdateOnLayoutShift: {
      type: Boolean,
      required: !1
    },
    prioritizePosition: {
      type: Boolean,
      required: !1
    },
    reference: {
      type: null,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    },
    disableOutsidePointerEvents: {
      type: Boolean,
      required: !1
    }
  },
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "openAutoFocus",
    "closeAutoFocus"
  ],
  setup(e, { emit: t }) {
    const r = e, a = t, o = Vo(), n = K(!1);
    Dl(!0);
    const s = rt(r, a), { forwardRef: i, currentElement: l } = be();
    return Il(l), (c, u) => (g(), N(G0, re(d(s), {
      ref: d(i),
      "trap-focus": d(o).open.value,
      "disable-outside-pointer-events": "",
      onCloseAutoFocus: u[0] || (u[0] = ir((f) => {
        a("closeAutoFocus", f), n.value || d(o).triggerElement.value?.focus();
      }, ["prevent"])),
      onPointerDownOutside: u[1] || (u[1] = (f) => {
        a("pointerDownOutside", f);
        const p = f.detail.originalEvent, h = p.button === 0 && p.ctrlKey === !0, m = p.button === 2 || h;
        n.value = m;
      }),
      onFocusOutside: u[2] || (u[2] = ir(() => {
      }, ["prevent"]))
    }), {
      default: b(() => [q(c.$slots, "default")]),
      _: 3
    }, 16, ["trap-focus"]));
  }
}), u_ = c_, d_ = /* @__PURE__ */ D({
  __name: "PopoverContentNonModal",
  props: {
    side: {
      type: null,
      required: !1
    },
    sideOffset: {
      type: Number,
      required: !1
    },
    sideFlip: {
      type: Boolean,
      required: !1
    },
    align: {
      type: null,
      required: !1
    },
    alignOffset: {
      type: Number,
      required: !1
    },
    alignFlip: {
      type: Boolean,
      required: !1
    },
    avoidCollisions: {
      type: Boolean,
      required: !1
    },
    collisionBoundary: {
      type: null,
      required: !1
    },
    collisionPadding: {
      type: [Number, Object],
      required: !1
    },
    arrowPadding: {
      type: Number,
      required: !1
    },
    hideShiftedArrow: {
      type: Boolean,
      required: !1
    },
    sticky: {
      type: String,
      required: !1
    },
    hideWhenDetached: {
      type: Boolean,
      required: !1
    },
    positionStrategy: {
      type: String,
      required: !1
    },
    updatePositionStrategy: {
      type: String,
      required: !1
    },
    disableUpdateOnLayoutShift: {
      type: Boolean,
      required: !1
    },
    prioritizePosition: {
      type: Boolean,
      required: !1
    },
    reference: {
      type: null,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    },
    disableOutsidePointerEvents: {
      type: Boolean,
      required: !1
    }
  },
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "openAutoFocus",
    "closeAutoFocus"
  ],
  setup(e, { emit: t }) {
    const r = e, a = t, o = Vo(), n = K(!1), s = K(!1), i = rt(r, a);
    return (l, c) => (g(), N(G0, re(d(i), {
      "trap-focus": !1,
      "disable-outside-pointer-events": !1,
      onCloseAutoFocus: c[0] || (c[0] = (u) => {
        a("closeAutoFocus", u), u.defaultPrevented || (n.value || d(o).triggerElement.value?.focus(), u.preventDefault()), n.value = !1, s.value = !1;
      }),
      onInteractOutside: c[1] || (c[1] = async (u) => {
        a("interactOutside", u), u.defaultPrevented || (n.value = !0, u.detail.originalEvent.type === "pointerdown" && (s.value = !0));
        const f = u.target;
        d(o).triggerElement.value?.contains(f) && u.preventDefault(), u.detail.originalEvent.type === "focusin" && s.value && u.preventDefault();
      })
    }), {
      default: b(() => [q(l.$slots, "default")]),
      _: 3
    }, 16));
  }
}), f_ = d_, p_ = /* @__PURE__ */ D({
  __name: "PopoverContent",
  props: {
    forceMount: {
      type: Boolean,
      required: !1
    },
    side: {
      type: null,
      required: !1
    },
    sideOffset: {
      type: Number,
      required: !1
    },
    sideFlip: {
      type: Boolean,
      required: !1
    },
    align: {
      type: null,
      required: !1
    },
    alignOffset: {
      type: Number,
      required: !1
    },
    alignFlip: {
      type: Boolean,
      required: !1
    },
    avoidCollisions: {
      type: Boolean,
      required: !1
    },
    collisionBoundary: {
      type: null,
      required: !1
    },
    collisionPadding: {
      type: [Number, Object],
      required: !1
    },
    arrowPadding: {
      type: Number,
      required: !1
    },
    hideShiftedArrow: {
      type: Boolean,
      required: !1
    },
    sticky: {
      type: String,
      required: !1
    },
    hideWhenDetached: {
      type: Boolean,
      required: !1
    },
    positionStrategy: {
      type: String,
      required: !1
    },
    updatePositionStrategy: {
      type: String,
      required: !1
    },
    disableUpdateOnLayoutShift: {
      type: Boolean,
      required: !1
    },
    prioritizePosition: {
      type: Boolean,
      required: !1
    },
    reference: {
      type: null,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    },
    disableOutsidePointerEvents: {
      type: Boolean,
      required: !1
    }
  },
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "openAutoFocus",
    "closeAutoFocus"
  ],
  setup(e, { emit: t }) {
    const r = e, a = t, o = Vo(), n = rt(r, a), { forwardRef: s } = be();
    return o.contentId ||= lr(void 0, "reka-popover-content"), (i, l) => (g(), N(d(Fa), { present: i.forceMount || d(o).open.value }, {
      default: b(() => [d(o).modal.value ? (g(), N(u_, re({ key: 0 }, d(n), { ref: d(s) }), {
        default: b(() => [q(i.$slots, "default")]),
        _: 3
      }, 16)) : (g(), N(f_, re({ key: 1 }, d(n), { ref: d(s) }), {
        default: b(() => [q(i.$slots, "default")]),
        _: 3
      }, 16))]),
      _: 3
    }, 8, ["present"]));
  }
}), h_ = p_, g_ = /* @__PURE__ */ D({
  __name: "PopoverPortal",
  props: {
    to: {
      type: null,
      required: !1
    },
    disabled: {
      type: Boolean,
      required: !1
    },
    defer: {
      type: Boolean,
      required: !1
    },
    forceMount: {
      type: Boolean,
      required: !1
    }
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(Lo), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), m_ = g_, v_ = /* @__PURE__ */ D({
  __name: "PopoverTrigger",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "button"
    }
  },
  setup(e) {
    const t = e, r = Vo(), { forwardRef: a, currentElement: o } = be();
    return r.triggerId ||= lr(void 0, "reka-popover-trigger"), at(() => {
      r.triggerElement.value = o.value;
    }), (n, s) => (g(), N(Qt(d(r).hasCustomAnchor.value ? d(Re) : d(Hl)), { "as-child": "" }, {
      default: b(() => [k(d(Re), {
        id: d(r).triggerId,
        ref: d(a),
        type: n.as === "button" ? "button" : void 0,
        "aria-haspopup": "dialog",
        "aria-expanded": d(r).open.value,
        "aria-controls": d(r).contentId,
        "data-state": d(r).open.value ? "open" : "closed",
        as: n.as,
        "as-child": t.asChild,
        onClick: d(r).onOpenToggle
      }, {
        default: b(() => [q(n.$slots, "default")]),
        _: 3
      }, 8, [
        "id",
        "type",
        "aria-expanded",
        "aria-controls",
        "data-state",
        "as",
        "as-child",
        "onClick"
      ])]),
      _: 3
    }));
  }
}), b_ = v_;
const [J0, y_] = it("DropdownMenuRoot");
var w_ = /* @__PURE__ */ D({
  __name: "DropdownMenuRoot",
  props: {
    defaultOpen: {
      type: Boolean,
      required: !1
    },
    open: {
      type: Boolean,
      required: !1,
      default: void 0
    },
    dir: {
      type: String,
      required: !1
    },
    modal: {
      type: Boolean,
      required: !1,
      default: !0
    }
  },
  emits: ["update:open"],
  setup(e, { emit: t }) {
    const r = e, a = t;
    be();
    const o = /* @__PURE__ */ Gr(r, "open", a, {
      defaultValue: r.defaultOpen,
      passive: r.open === void 0
    }), n = K(), { modal: s, dir: i } = ht(r), l = ns(i);
    return y_({
      open: o,
      onOpenChange: (c) => {
        o.value = c;
      },
      onOpenToggle: () => {
        o.value = !o.value;
      },
      triggerId: "",
      triggerElement: n,
      contentId: "",
      modal: s,
      dir: l
    }), (c, u) => (g(), N(d(Vx), {
      open: d(o),
      "onUpdate:open": u[0] || (u[0] = (f) => Ve(o) ? o.value = f : null),
      dir: d(l),
      modal: d(s)
    }, {
      default: b(() => [q(c.$slots, "default", { open: d(o) })]),
      _: 3
    }, 8, [
      "open",
      "dir",
      "modal"
    ]));
  }
}), x_ = w_, __ = /* @__PURE__ */ D({
  __name: "DropdownMenuContent",
  props: {
    forceMount: {
      type: Boolean,
      required: !1
    },
    loop: {
      type: Boolean,
      required: !1
    },
    side: {
      type: null,
      required: !1
    },
    sideOffset: {
      type: Number,
      required: !1
    },
    sideFlip: {
      type: Boolean,
      required: !1
    },
    align: {
      type: null,
      required: !1
    },
    alignOffset: {
      type: Number,
      required: !1
    },
    alignFlip: {
      type: Boolean,
      required: !1
    },
    avoidCollisions: {
      type: Boolean,
      required: !1
    },
    collisionBoundary: {
      type: null,
      required: !1
    },
    collisionPadding: {
      type: [Number, Object],
      required: !1
    },
    arrowPadding: {
      type: Number,
      required: !1
    },
    hideShiftedArrow: {
      type: Boolean,
      required: !1
    },
    sticky: {
      type: String,
      required: !1
    },
    hideWhenDetached: {
      type: Boolean,
      required: !1
    },
    positionStrategy: {
      type: String,
      required: !1
    },
    updatePositionStrategy: {
      type: String,
      required: !1
    },
    disableUpdateOnLayoutShift: {
      type: Boolean,
      required: !1
    },
    prioritizePosition: {
      type: Boolean,
      required: !1
    },
    reference: {
      type: null,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: [
    "escapeKeyDown",
    "pointerDownOutside",
    "focusOutside",
    "interactOutside",
    "closeAutoFocus"
  ],
  setup(e, { emit: t }) {
    const o = rt(e, t);
    be();
    const n = J0(), s = K(!1);
    function i(l) {
      l.defaultPrevented || (s.value || setTimeout(() => {
        n.triggerElement.value?.focus();
      }, 0), s.value = !1, l.preventDefault());
    }
    return n.contentId ||= lr(void 0, "reka-dropdown-menu-content"), (l, c) => (g(), N(d(Xx), re(d(o), {
      id: d(n).contentId,
      "aria-labelledby": d(n)?.triggerId,
      style: {
        "--reka-dropdown-menu-content-transform-origin": "var(--reka-popper-transform-origin)",
        "--reka-dropdown-menu-content-available-width": "var(--reka-popper-available-width)",
        "--reka-dropdown-menu-content-available-height": "var(--reka-popper-available-height)",
        "--reka-dropdown-menu-trigger-width": "var(--reka-popper-anchor-width)",
        "--reka-dropdown-menu-trigger-height": "var(--reka-popper-anchor-height)"
      },
      onCloseAutoFocus: i,
      onInteractOutside: c[0] || (c[0] = (u) => {
        if (u.defaultPrevented) return;
        const f = u.detail.originalEvent, p = f.button === 0 && f.ctrlKey === !0, h = f.button === 2 || p;
        (!d(n).modal.value || h) && (s.value = !0), d(n).triggerElement.value?.contains(u.target) && u.preventDefault();
      })
    }), {
      default: b(() => [q(l.$slots, "default")]),
      _: 3
    }, 16, ["id", "aria-labelledby"]));
  }
}), k_ = __, C_ = /* @__PURE__ */ D({
  __name: "DropdownMenuItem",
  props: {
    disabled: {
      type: Boolean,
      required: !1
    },
    textValue: {
      type: String,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: ["select"],
  setup(e, { emit: t }) {
    const r = e, o = Ha(t);
    return be(), (n, s) => (g(), N(d(Zx), De(Fe({
      ...r,
      ...d(o)
    })), {
      default: b(() => [q(n.$slots, "default")]),
      _: 3
    }, 16));
  }
}), A_ = C_, S_ = /* @__PURE__ */ D({
  __name: "DropdownMenuLabel",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  setup(e) {
    const t = e;
    return be(), (r, a) => (g(), N(d(e_), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), E_ = S_, $_ = /* @__PURE__ */ D({
  __name: "DropdownMenuPortal",
  props: {
    to: {
      type: null,
      required: !1
    },
    disabled: {
      type: Boolean,
      required: !1
    },
    defer: {
      type: Boolean,
      required: !1
    },
    forceMount: {
      type: Boolean,
      required: !1
    }
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(r_), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), P_ = $_, T_ = /* @__PURE__ */ D({
  __name: "DropdownMenuSeparator",
  props: {
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  setup(e) {
    const t = e;
    return be(), (r, a) => (g(), N(d(o_), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), M_ = T_, R_ = /* @__PURE__ */ D({
  __name: "DropdownMenuTrigger",
  props: {
    disabled: {
      type: Boolean,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "button"
    }
  },
  setup(e) {
    const t = e, r = J0(), { forwardRef: a, currentElement: o } = be();
    return at(() => {
      r.triggerElement = o;
    }), r.triggerId ||= lr(void 0, "reka-dropdown-menu-trigger"), (n, s) => (g(), N(d(Bx), { "as-child": "" }, {
      default: b(() => [k(d(Re), {
        id: d(r).triggerId,
        ref: d(a),
        type: n.as === "button" ? "button" : void 0,
        "as-child": t.asChild,
        as: n.as,
        "aria-haspopup": "menu",
        "aria-expanded": d(r).open.value,
        "aria-controls": d(r).open.value ? d(r).contentId : void 0,
        "data-disabled": n.disabled ? "" : void 0,
        disabled: n.disabled,
        "data-state": d(r).open.value ? "open" : "closed",
        onClick: s[0] || (s[0] = async (i) => {
          !n.disabled && i.button === 0 && i.ctrlKey === !1 && (d(r)?.onOpenToggle(), await et(), d(r).open.value && i.preventDefault());
        }),
        onKeydown: s[1] || (s[1] = wl((i) => {
          n.disabled || (["Enter", " "].includes(i.key) && d(r).onOpenToggle(), i.key === "ArrowDown" && d(r).onOpenChange(!0), [
            "Enter",
            " ",
            "ArrowDown"
          ].includes(i.key) && i.preventDefault());
        }, [
          "enter",
          "space",
          "arrow-down"
        ]))
      }, {
        default: b(() => [q(n.$slots, "default")]),
        _: 3
      }, 8, [
        "id",
        "type",
        "as-child",
        "as",
        "aria-expanded",
        "aria-controls",
        "data-disabled",
        "disabled",
        "data-state"
      ])]),
      _: 3
    }));
  }
}), O_ = R_, B_ = /* @__PURE__ */ D({
  __name: "Label",
  props: {
    for: {
      type: String,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "label"
    }
  },
  setup(e) {
    const t = e;
    return be(), (r, a) => (g(), N(d(Re), re(t, { onMousedown: a[0] || (a[0] = (o) => {
      !o.defaultPrevented && o.detail > 1 && o.preventDefault();
    }) }), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), D_ = B_, I_ = /* @__PURE__ */ D({
  __name: "BaseSeparator",
  props: {
    orientation: {
      type: String,
      required: !1,
      default: "horizontal"
    },
    decorative: {
      type: Boolean,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  setup(e) {
    const t = e, r = ["horizontal", "vertical"];
    function a(i) {
      return r.includes(i);
    }
    const o = L(() => a(t.orientation) ? t.orientation : "horizontal"), n = L(() => o.value === "vertical" ? t.orientation : void 0), s = L(() => t.decorative ? { role: "none" } : {
      "aria-orientation": n.value,
      role: "separator"
    });
    return (i, l) => (g(), N(d(Re), re({
      as: i.as,
      "as-child": i.asChild,
      "data-orientation": o.value
    }, s.value), {
      default: b(() => [q(i.$slots, "default")]),
      _: 3
    }, 16, [
      "as",
      "as-child",
      "data-orientation"
    ]));
  }
}), q_ = I_, L_ = /* @__PURE__ */ D({
  __name: "Separator",
  props: {
    orientation: {
      type: String,
      required: !1,
      default: "horizontal"
    },
    decorative: {
      type: Boolean,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(q_, De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), N_ = L_;
const [Xl, V_] = it("TabsRoot");
var H_ = /* @__PURE__ */ D({
  __name: "TabsRoot",
  props: {
    defaultValue: {
      type: null,
      required: !1
    },
    orientation: {
      type: String,
      required: !1,
      default: "horizontal"
    },
    dir: {
      type: String,
      required: !1
    },
    activationMode: {
      type: String,
      required: !1,
      default: "automatic"
    },
    modelValue: {
      type: null,
      required: !1
    },
    unmountOnHide: {
      type: Boolean,
      required: !1,
      default: !0
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  emits: ["update:modelValue"],
  setup(e, { emit: t }) {
    const r = e, a = t, { orientation: o, unmountOnHide: n, dir: s } = ht(r), i = ns(s);
    be();
    const l = /* @__PURE__ */ Gr(r, "modelValue", a, {
      defaultValue: r.defaultValue,
      passive: r.modelValue === void 0
    }), c = K(), u = ar(/* @__PURE__ */ new Set());
    return V_({
      modelValue: l,
      changeModelValue: (f) => {
        l.value = f;
      },
      orientation: o,
      dir: i,
      unmountOnHide: n,
      activationMode: r.activationMode,
      baseId: lr(void 0, "reka-tabs"),
      tabsList: c,
      contentIds: u,
      registerContent: (f) => {
        u.value = /* @__PURE__ */ new Set([...u.value, f]);
      },
      unregisterContent: (f) => {
        const p = new Set(u.value);
        p.delete(f), u.value = p;
      }
    }), (f, p) => (g(), N(d(Re), {
      dir: d(i),
      "data-orientation": d(o),
      "as-child": f.asChild,
      as: f.as
    }, {
      default: b(() => [q(f.$slots, "default", { modelValue: d(l) })]),
      _: 3
    }, 8, [
      "dir",
      "data-orientation",
      "as-child",
      "as"
    ]));
  }
}), F_ = H_;
function Y0(e, t) {
  return `${e}-trigger-${t}`;
}
function X0(e, t) {
  return `${e}-content-${t}`;
}
var z_ = /* @__PURE__ */ D({
  __name: "TabsContent",
  props: {
    value: {
      type: [String, Number],
      required: !0
    },
    forceMount: {
      type: Boolean,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  setup(e) {
    const t = e, { forwardRef: r } = be(), a = Xl(), o = L(() => Y0(a.baseId, t.value)), n = L(() => X0(a.baseId, t.value)), s = L(() => t.value === a.modelValue.value), i = K(s.value);
    return at(() => {
      a.registerContent(t.value), requestAnimationFrame(() => {
        i.value = !1;
      });
    }), jn(() => {
      a.unregisterContent(t.value);
    }), (l, c) => (g(), N(d(Fa), {
      present: l.forceMount || s.value,
      "force-mount": ""
    }, {
      default: b(({ present: u }) => [k(d(Re), {
        id: n.value,
        ref: d(r),
        "as-child": l.asChild,
        as: l.as,
        role: "tabpanel",
        "data-state": s.value ? "active" : "inactive",
        "data-orientation": d(a).orientation.value,
        "aria-labelledby": o.value,
        hidden: !u,
        tabindex: "0",
        style: Tt({ animationDuration: i.value ? "0s" : void 0 })
      }, {
        default: b(() => [!d(a).unmountOnHide.value || u ? q(l.$slots, "default", { key: 0 }) : $e("v-if", !0)]),
        _: 2
      }, 1032, [
        "id",
        "as-child",
        "as",
        "data-state",
        "data-orientation",
        "aria-labelledby",
        "hidden",
        "style"
      ])]),
      _: 3
    }, 8, ["present"]));
  }
}), j_ = z_, U_ = /* @__PURE__ */ D({
  __name: "TabsList",
  props: {
    loop: {
      type: Boolean,
      required: !1,
      default: !0
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    }
  },
  setup(e) {
    const t = e, { loop: r } = ht(t), { forwardRef: a, currentElement: o } = be(), n = Xl();
    return n.tabsList = o, (s, i) => (g(), N(d(B0), {
      "as-child": "",
      orientation: d(n).orientation.value,
      dir: d(n).dir.value,
      loop: d(r)
    }, {
      default: b(() => [k(d(Re), {
        ref: d(a),
        role: "tablist",
        "as-child": s.asChild,
        as: s.as,
        "aria-orientation": d(n).orientation.value
      }, {
        default: b(() => [q(s.$slots, "default")]),
        _: 3
      }, 8, [
        "as-child",
        "as",
        "aria-orientation"
      ])]),
      _: 3
    }, 8, [
      "orientation",
      "dir",
      "loop"
    ]));
  }
}), Z_ = U_, K_ = /* @__PURE__ */ D({
  __name: "TabsTrigger",
  props: {
    value: {
      type: [String, Number],
      required: !0
    },
    disabled: {
      type: Boolean,
      required: !1,
      default: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "button"
    }
  },
  setup(e) {
    const t = e, { forwardRef: r } = be(), a = Xl(), o = L(() => Y0(a.baseId, t.value)), n = L(() => a.contentIds.value.has(t.value) ? X0(a.baseId, t.value) : void 0), s = L(() => t.value === a.modelValue.value);
    return (i, l) => (g(), N(d(p4), {
      "as-child": "",
      focusable: !i.disabled,
      active: s.value
    }, {
      default: b(() => [k(d(Re), {
        id: o.value,
        ref: d(r),
        role: "tab",
        type: i.as === "button" ? "button" : void 0,
        as: i.as,
        "as-child": i.asChild,
        "aria-selected": s.value ? "true" : "false",
        "aria-controls": n.value,
        "data-state": s.value ? "active" : "inactive",
        disabled: i.disabled,
        "data-disabled": i.disabled ? "" : void 0,
        "data-orientation": d(a).orientation.value,
        onMousedown: l[0] || (l[0] = ir((c) => {
          !i.disabled && c.ctrlKey === !1 ? d(a).changeModelValue(i.value) : c.preventDefault();
        }, ["left"])),
        onKeydown: l[1] || (l[1] = wl((c) => d(a).changeModelValue(i.value), ["enter", "space"])),
        onFocus: l[2] || (l[2] = () => {
          const c = d(a).activationMode !== "manual";
          !s.value && !i.disabled && c && d(a).changeModelValue(i.value);
        })
      }, {
        default: b(() => [q(i.$slots, "default")]),
        _: 3
      }, 8, [
        "id",
        "type",
        "as",
        "as-child",
        "aria-selected",
        "aria-controls",
        "data-state",
        "disabled",
        "data-disabled",
        "data-orientation"
      ])]),
      _: 3
    }, 8, ["focusable", "active"]));
  }
}), W_ = K_, G_ = /* @__PURE__ */ D({
  __name: "TooltipArrow",
  props: {
    width: {
      type: Number,
      required: !1,
      default: 10
    },
    height: {
      type: Number,
      required: !1,
      default: 5
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "svg"
    }
  },
  setup(e) {
    const t = e;
    return be(), (r, a) => (g(), N(d(Rx), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), J_ = G_;
const [Ql, Y_] = it("TooltipProvider");
var X_ = /* @__PURE__ */ D({
  inheritAttrs: !1,
  __name: "TooltipProvider",
  props: {
    delayDuration: {
      type: Number,
      required: !1,
      default: 700
    },
    skipDelayDuration: {
      type: Number,
      required: !1,
      default: 300
    },
    disableHoverableContent: {
      type: Boolean,
      required: !1,
      default: !1
    },
    disableClosingTrigger: {
      type: Boolean,
      required: !1
    },
    disabled: {
      type: Boolean,
      required: !1
    },
    ignoreNonKeyboardFocus: {
      type: Boolean,
      required: !1,
      default: !1
    }
  },
  setup(e) {
    const t = e, { delayDuration: r, skipDelayDuration: a, disableHoverableContent: o, disableClosingTrigger: n, ignoreNonKeyboardFocus: s, disabled: i } = ht(t);
    be();
    const l = K(!0), c = K(!1), { start: u, stop: f } = w0(() => {
      l.value = !0;
    }, a, { immediate: !1 });
    return Y_({
      isOpenDelayed: l,
      delayDuration: r,
      onOpen() {
        f(), l.value = !1;
      },
      onClose() {
        u();
      },
      isPointerInTransitRef: c,
      disableHoverableContent: o,
      disableClosingTrigger: n,
      disabled: i,
      ignoreNonKeyboardFocus: s
    }), (p, h) => q(p.$slots, "default");
  }
}), Q_ = X_;
const Q0 = "tooltip.open", [ds, e6] = it("TooltipRoot");
var t6 = /* @__PURE__ */ D({
  __name: "TooltipRoot",
  props: {
    defaultOpen: {
      type: Boolean,
      required: !1,
      default: !1
    },
    open: {
      type: Boolean,
      required: !1,
      default: void 0
    },
    delayDuration: {
      type: Number,
      required: !1,
      default: void 0
    },
    disableHoverableContent: {
      type: Boolean,
      required: !1,
      default: void 0
    },
    disableClosingTrigger: {
      type: Boolean,
      required: !1,
      default: void 0
    },
    disabled: {
      type: Boolean,
      required: !1,
      default: void 0
    },
    ignoreNonKeyboardFocus: {
      type: Boolean,
      required: !1,
      default: void 0
    }
  },
  emits: ["update:open"],
  setup(e, { emit: t }) {
    const r = e, a = t;
    be();
    const o = Ql(), n = L(() => r.disableHoverableContent ?? o.disableHoverableContent.value), s = L(() => r.disableClosingTrigger ?? o.disableClosingTrigger.value), i = L(() => r.disabled ?? o.disabled.value), l = L(() => r.delayDuration ?? o.delayDuration.value), c = L(() => r.ignoreNonKeyboardFocus ?? o.ignoreNonKeyboardFocus.value), u = /* @__PURE__ */ Gr(r, "open", a, {
      defaultValue: r.defaultOpen,
      passive: r.open === void 0
    });
    Ke(u, (E) => {
      o.onClose && (E ? (o.onOpen(), document.dispatchEvent(new CustomEvent(Q0))) : o.onClose());
    });
    const f = K(!1), p = K(), h = L(() => u.value ? f.value ? "delayed-open" : "instant-open" : "closed"), { start: m, stop: v } = w0(() => {
      f.value = !0, u.value = !0;
    }, l, { immediate: !1 });
    function x() {
      v(), f.value = !1, u.value = !0;
    }
    function C() {
      v(), u.value = !1;
    }
    function S() {
      m();
    }
    return e6({
      contentId: "",
      open: u,
      stateAttribute: h,
      trigger: p,
      onTriggerChange(E) {
        p.value = E;
      },
      onTriggerEnter() {
        o.isOpenDelayed.value ? S() : x();
      },
      onTriggerLeave() {
        n.value ? C() : v();
      },
      onOpen: x,
      onClose: C,
      disableHoverableContent: n,
      disableClosingTrigger: s,
      disabled: i,
      ignoreNonKeyboardFocus: c
    }), (E, T) => (g(), N(d(Vl), null, {
      default: b(() => [q(E.$slots, "default", { open: d(u) })]),
      _: 3
    }));
  }
}), r6 = t6, a6 = /* @__PURE__ */ D({
  __name: "TooltipContentImpl",
  props: {
    ariaLabel: {
      type: String,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    },
    side: {
      type: null,
      required: !1,
      default: "top"
    },
    sideOffset: {
      type: Number,
      required: !1,
      default: 0
    },
    align: {
      type: null,
      required: !1,
      default: "center"
    },
    alignOffset: {
      type: Number,
      required: !1
    },
    avoidCollisions: {
      type: Boolean,
      required: !1,
      default: !0
    },
    collisionBoundary: {
      type: null,
      required: !1,
      default: () => []
    },
    collisionPadding: {
      type: [Number, Object],
      required: !1,
      default: 0
    },
    arrowPadding: {
      type: Number,
      required: !1,
      default: 0
    },
    sticky: {
      type: String,
      required: !1,
      default: "partial"
    },
    hideWhenDetached: {
      type: Boolean,
      required: !1,
      default: !1
    },
    positionStrategy: {
      type: String,
      required: !1
    },
    updatePositionStrategy: {
      type: String,
      required: !1
    }
  },
  emits: ["escapeKeyDown", "pointerDownOutside"],
  setup(e, { emit: t }) {
    const r = e, a = t, o = ds(), { forwardRef: n, currentElement: s } = be(), i = L(() => r.ariaLabel || s.value?.textContent), l = L(() => {
      const { ariaLabel: c, ...u } = r;
      return u;
    });
    return at(() => {
      Ao(window, "scroll", (c) => {
        c.target?.contains(o.trigger.value) && o.onClose();
      }), Ao(window, Q0, o.onClose);
    }), (c, u) => (g(), N(d(ss), {
      "as-child": "",
      "disable-outside-pointer-events": !1,
      onEscapeKeyDown: u[0] || (u[0] = (f) => a("escapeKeyDown", f)),
      onPointerDownOutside: u[1] || (u[1] = (f) => {
        d(o).disableClosingTrigger.value && d(o).trigger.value?.contains(f.target) && f.preventDefault(), a("pointerDownOutside", f);
      }),
      onFocusOutside: u[2] || (u[2] = ir(() => {
      }, ["prevent"])),
      onDismiss: u[3] || (u[3] = (f) => d(o).onClose())
    }, {
      default: b(() => [k(d(Jl), re({
        ref: d(n),
        "data-state": d(o).stateAttribute.value
      }, {
        ...c.$attrs,
        ...l.value
      }, { style: {
        "--reka-tooltip-content-transform-origin": "var(--reka-popper-transform-origin)",
        "--reka-tooltip-content-available-width": "var(--reka-popper-available-width)",
        "--reka-tooltip-content-available-height": "var(--reka-popper-available-height)",
        "--reka-tooltip-trigger-width": "var(--reka-popper-anchor-width)",
        "--reka-tooltip-trigger-height": "var(--reka-popper-anchor-height)"
      } }), {
        default: b(() => [q(c.$slots, "default"), k(d(g4), {
          id: d(o).contentId,
          role: "tooltip"
        }, {
          default: b(() => [ne(ue(i.value), 1)]),
          _: 1
        }, 8, ["id"])]),
        _: 3
      }, 16, ["data-state"])]),
      _: 3
    }));
  }
}), eh = a6, o6 = /* @__PURE__ */ D({
  __name: "TooltipContentHoverable",
  props: {
    ariaLabel: {
      type: String,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    },
    side: {
      type: null,
      required: !1
    },
    sideOffset: {
      type: Number,
      required: !1
    },
    align: {
      type: null,
      required: !1
    },
    alignOffset: {
      type: Number,
      required: !1
    },
    avoidCollisions: {
      type: Boolean,
      required: !1
    },
    collisionBoundary: {
      type: null,
      required: !1
    },
    collisionPadding: {
      type: [Number, Object],
      required: !1
    },
    arrowPadding: {
      type: Number,
      required: !1
    },
    sticky: {
      type: String,
      required: !1
    },
    hideWhenDetached: {
      type: Boolean,
      required: !1
    },
    positionStrategy: {
      type: String,
      required: !1
    },
    updatePositionStrategy: {
      type: String,
      required: !1
    }
  },
  setup(e) {
    const r = da(e), { forwardRef: a, currentElement: o } = be(), { trigger: n, onClose: s } = ds(), i = Ql(), { isPointerInTransit: l, onPointerExit: c } = C2(n, o);
    return i.isPointerInTransitRef = l, c(() => {
      s();
    }), (u, f) => (g(), N(eh, re({ ref: d(a) }, d(r)), {
      default: b(() => [q(u.$slots, "default")]),
      _: 3
    }, 16));
  }
}), n6 = o6, s6 = /* @__PURE__ */ D({
  __name: "TooltipContent",
  props: {
    forceMount: {
      type: Boolean,
      required: !1
    },
    ariaLabel: {
      type: String,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1
    },
    side: {
      type: null,
      required: !1,
      default: "top"
    },
    sideOffset: {
      type: Number,
      required: !1
    },
    align: {
      type: null,
      required: !1
    },
    alignOffset: {
      type: Number,
      required: !1
    },
    avoidCollisions: {
      type: Boolean,
      required: !1
    },
    collisionBoundary: {
      type: null,
      required: !1
    },
    collisionPadding: {
      type: [Number, Object],
      required: !1
    },
    arrowPadding: {
      type: Number,
      required: !1
    },
    sticky: {
      type: String,
      required: !1
    },
    hideWhenDetached: {
      type: Boolean,
      required: !1
    },
    positionStrategy: {
      type: String,
      required: !1
    },
    updatePositionStrategy: {
      type: String,
      required: !1
    }
  },
  emits: ["escapeKeyDown", "pointerDownOutside"],
  setup(e, { emit: t }) {
    const r = e, a = t, o = ds(), n = rt(r, a), { forwardRef: s } = be();
    return (i, l) => (g(), N(d(Fa), { present: i.forceMount || d(o).open.value }, {
      default: b(() => [(g(), N(Qt(d(o).disableHoverableContent.value ? eh : n6), re({ ref: d(s) }, d(n)), {
        default: b(() => [q(i.$slots, "default")]),
        _: 3
      }, 16))]),
      _: 3
    }, 8, ["present"]));
  }
}), i6 = s6, l6 = /* @__PURE__ */ D({
  __name: "TooltipPortal",
  props: {
    to: {
      type: null,
      required: !1
    },
    disabled: {
      type: Boolean,
      required: !1
    },
    defer: {
      type: Boolean,
      required: !1
    },
    forceMount: {
      type: Boolean,
      required: !1
    }
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(Lo), De(Fe(t)), {
      default: b(() => [q(r.$slots, "default")]),
      _: 3
    }, 16));
  }
}), c6 = l6, u6 = /* @__PURE__ */ D({
  __name: "TooltipTrigger",
  props: {
    reference: {
      type: null,
      required: !1
    },
    asChild: {
      type: Boolean,
      required: !1
    },
    as: {
      type: null,
      required: !1,
      default: "button"
    }
  },
  setup(e) {
    const t = e, r = ds(), a = Ql();
    r.contentId ||= lr(void 0, "reka-tooltip-content");
    const { forwardRef: o, currentElement: n } = be(), s = K(!1), i = K(!1), l = L(() => r.disabled.value ? {} : {
      click: v,
      focus: h,
      pointermove: f,
      pointerleave: p,
      pointerdown: u,
      blur: m
    });
    at(() => {
      r.onTriggerChange(n.value);
    });
    function c() {
      setTimeout(() => {
        s.value = !1;
      }, 1);
    }
    function u() {
      r.open && !r.disableClosingTrigger.value && r.onClose(), s.value = !0, document.addEventListener("pointerup", c, { once: !0 });
    }
    function f(x) {
      x.pointerType !== "touch" && !i.value && !a.isPointerInTransitRef.value && (r.onTriggerEnter(), i.value = !0);
    }
    function p() {
      r.onTriggerLeave(), i.value = !1;
    }
    function h(x) {
      s.value || r.ignoreNonKeyboardFocus.value && !x.target.matches?.(":focus-visible") || r.onOpen();
    }
    function m() {
      r.onClose();
    }
    function v() {
      r.disableClosingTrigger.value || r.onClose();
    }
    return (x, C) => (g(), N(d(Hl), {
      "as-child": "",
      reference: x.reference
    }, {
      default: b(() => [k(d(Re), re({
        ref: d(o),
        "aria-describedby": d(r).open.value ? d(r).contentId : void 0,
        "data-state": d(r).stateAttribute.value,
        as: x.as,
        "as-child": t.asChild,
        "data-grace-area-trigger": ""
      }, yg(l.value)), {
        default: b(() => [q(x.$slots, "default")]),
        _: 3
      }, 16, [
        "aria-describedby",
        "data-state",
        "as",
        "as-child"
      ])]),
      _: 3
    }, 8, ["reference"]));
  }
}), d6 = u6;
const xr = /* @__PURE__ */ D({
  __name: "Button",
  props: {
    variant: {},
    size: {},
    class: {},
    asChild: { type: Boolean },
    as: { default: "button" }
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(Re), {
      "data-slot": "button",
      as: r.as,
      "as-child": r.asChild,
      class: ke(d(ve)(d(ec)({ variant: r.variant, size: r.size }), t.class))
    }, {
      default: b(() => [
        q(r.$slots, "default")
      ]),
      _: 3
    }, 8, ["as", "as-child", "class"]));
  }
}), ec = Rl(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
        outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-9 px-4 py-2 has-[>svg]:px-3",
        sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
        lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
        icon: "size-9",
        "icon-sm": "size-8",
        "icon-lg": "size-10"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const yd = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), f6 = (e) => e.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (t, r, a) => a ? a.toUpperCase() : r.toLowerCase()
), p6 = (e) => {
  const t = f6(e);
  return t.charAt(0).toUpperCase() + t.slice(1);
}, h6 = (...e) => e.filter((t, r, a) => !!t && t.trim() !== "" && a.indexOf(t) === r).join(" ").trim();
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
var Qo = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  "stroke-width": 2,
  "stroke-linecap": "round",
  "stroke-linejoin": "round"
};
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const g6 = ({ size: e, strokeWidth: t = 2, absoluteStrokeWidth: r, color: a, iconNode: o, name: n, class: s, ...i }, { slots: l }) => Nt(
  "svg",
  {
    ...Qo,
    width: e || Qo.width,
    height: e || Qo.height,
    stroke: a || Qo.stroke,
    "stroke-width": r ? Number(t) * 24 / Number(e) : t,
    class: h6(
      "lucide",
      ...n ? [`lucide-${yd(p6(n))}-icon`, `lucide-${yd(n)}`] : ["lucide-icon"]
    ),
    ...i
  },
  [...o.map((c) => Nt(...c)), ...l.default ? [l.default()] : []]
);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ge = (e, t) => (r, { slots: a }) => Nt(
  g6,
  {
    ...r,
    iconNode: t,
    name: e
  },
  a
);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const m6 = Ge("ban", [
  ["path", { d: "M4.929 4.929 19.07 19.071", key: "196cmz" }],
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const v6 = Ge("book-marked", [
  ["path", { d: "M10 2v8l3-3 3 3V2", key: "sqw3rj" }],
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const b6 = Ge("book", [
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const y6 = Ge("chevron-right", [
  ["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const w6 = Ge("circle-check-big", [
  ["path", { d: "M21.801 10A10 10 0 1 1 17 3.335", key: "yps3ct" }],
  ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const x6 = Ge("circle-question-mark", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3", key: "1u773s" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const _6 = Ge("circle-x", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  ["path", { d: "m9 9 6 6", key: "z0biqf" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const k6 = Ge("clock", [
  ["path", { d: "M12 6v6l4 2", key: "mmk7yg" }],
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const C6 = Ge("cloud-download", [
  ["path", { d: "M12 13v8l-4-4", key: "1f5nwf" }],
  ["path", { d: "m12 21 4-4", key: "1lfcce" }],
  ["path", { d: "M4.393 15.269A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.436 8.284", key: "ui1hmy" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const A6 = Ge("copy", [
  ["rect", { width: "14", height: "14", x: "8", y: "8", rx: "2", ry: "2", key: "17jyea" }],
  ["path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2", key: "zix9uf" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const S6 = Ge("download", [
  ["path", { d: "M12 15V3", key: "m9g1x1" }],
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["path", { d: "m7 10 5 5 5-5", key: "brsn70" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const E6 = Ge("gauge", [
  ["path", { d: "m12 14 4-4", key: "9kzdfg" }],
  ["path", { d: "M3.34 19a10 10 0 1 1 17.32 0", key: "19p75a" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const $6 = Ge("globe", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20", key: "13o1zl" }],
  ["path", { d: "M2 12h20", key: "9i4pu4" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const P6 = Ge("house", [
  ["path", { d: "M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8", key: "5wwlr5" }],
  [
    "path",
    {
      d: "M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
      key: "1d0kgt"
    }
  ]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const T6 = Ge("info", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 16v-4", key: "1dtifu" }],
  ["path", { d: "M12 8h.01", key: "e9boi3" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const M6 = Ge("link-2", [
  ["path", { d: "M9 17H7A5 5 0 0 1 7 7h2", key: "8i5ue5" }],
  ["path", { d: "M15 7h2a5 5 0 1 1 0 10h-2", key: "1b9ql8" }],
  ["line", { x1: "8", x2: "16", y1: "12", y2: "12", key: "1jonct" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const R6 = Ge("loader-circle", [
  ["path", { d: "M21 12a9 9 0 1 1-6.219-8.56", key: "13zald" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const O6 = Ge("log-out", [
  ["path", { d: "m16 17 5-5-5-5", key: "1bji2h" }],
  ["path", { d: "M21 12H9", key: "dn1m92" }],
  ["path", { d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", key: "1uf3rs" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const B6 = Ge("panel-left", [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M9 3v18", key: "fh3hqa" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const D6 = Ge("rotate-cw", [
  ["path", { d: "M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8", key: "1p45f6" }],
  ["path", { d: "M21 3v5h-5", key: "1q7to0" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const wd = Ge("server", [
  ["rect", { width: "20", height: "8", x: "2", y: "2", rx: "2", ry: "2", key: "ngkwjq" }],
  ["rect", { width: "20", height: "8", x: "2", y: "14", rx: "2", ry: "2", key: "iecqi9" }],
  ["line", { x1: "6", x2: "6.01", y1: "6", y2: "6", key: "16zg32" }],
  ["line", { x1: "6", x2: "6.01", y1: "18", y2: "18", key: "nzw8ys" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const I6 = Ge("train-front", [
  ["path", { d: "M8 3.1V7a4 4 0 0 0 8 0V3.1", key: "1v71zp" }],
  ["path", { d: "m9 15-1-1", key: "1yrq24" }],
  ["path", { d: "m15 15 1-1", key: "1t0d6s" }],
  ["path", { d: "M9 19c-2.8 0-5-2.2-5-5v-4a8 8 0 0 1 16 0v4c0 2.8-2.2 5-5 5Z", key: "1p0hjs" }],
  ["path", { d: "m8 19-2 3", key: "13i0xs" }],
  ["path", { d: "m16 19 2 3", key: "xo31yx" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const th = Ge("trash-2", [
  ["path", { d: "M10 11v6", key: "nco0om" }],
  ["path", { d: "M14 11v6", key: "outv1u" }],
  ["path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6", key: "miytrc" }],
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", key: "e791ji" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const q6 = Ge("video", [
  [
    "path",
    {
      d: "m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",
      key: "ftymec"
    }
  ],
  ["rect", { x: "2", y: "6", width: "14", height: "12", rx: "2", key: "158x01" }]
]);
/**
 * @license lucide-vue-next v0.528.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const L6 = Ge("x", [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
]), N6 = { class: "flex w-full items-center justify-center p-4 md:w-1/2" }, V6 = { class: "flex justify-center items-center" }, H6 = { class: "flex h-48 w-48 items-center justify-center rounded-md border border-dashed bg-gray-200" }, F6 = {
  key: 0,
  class: "flex flex-col items-center justify-center h-48"
}, z6 = {
  key: 1,
  class: "flex flex-col items-center justify-center h-full text-gray-500"
}, j6 = ["src"], U6 = /* @__PURE__ */ D({
  __name: "LoginView",
  setup(e) {
    const t = K(!1), r = K(), a = K(), o = K(), n = K(""), s = qa(), i = Cl(), l = L(() => Kb().mode === "desktop"), c = async (p) => {
      o.value = await hw(p), p !== o.value.sessionId && (clearTimeout(a.value), clearInterval(r.value), t.value = !1, n.value = await o.value.qrcodeBase64(), a.value = setTimeout(() => {
        t.value = !0;
      }, o.value.expireMilliseconds), r.value = setInterval(async () => {
        await s.login(o.value?.sessionId || "") && i.push({ name: "Home" }).then();
      }, 2e3));
    }, u = () => {
      c(o.value?.sessionId);
    }, f = () => {
      l.value && i.push({ name: "Home" }).then();
    };
    return at(async () => {
      await c(void 0);
    }), $r(() => {
      clearInterval(r.value);
    }), (p, h) => (g(), R("div", {
      class: "flex h-screen w-full items-center justify-center bg-gray-100 p-4",
      onClick: ir(f, ["self"])
    }, [
      w("div", {
        class: "flex h-[500px] w-full max-w-[900px] overflow-hidden rounded-lg bg-white shadow-xl",
        onClick: h[0] || (h[0] = ir(() => {
        }, ["stop"]))
      }, [
        h[6] || (h[6] = bl('<div class="flex-1 flex flex-col justify-center items-center text-center p-12 text-white bg-gradient-to-br to-blue-600 from-purple-800 relative"><div class="absolute top-8 left-8 flex items-center gap-3"><img src="' + r0 + '" alt="KSpeeder" width="48" height="48"><span class="text-3xl font-bold">KSpeeder</span></div><div class="mt-8"><h1 class="text-3xl font-extrabold leading-tight tracking-tight mb-4"> Docker镜像加速专家 </h1><p class="text-lg opacity-80 max-w-sm mx-auto"> 多镜像并发下载，动态负载均衡，断点续传支持，Docker镜像代理服务 </p></div></div>', 1)),
        w("div", N6, [
          k(d(yr), { class: "w-full max-w-[350px]" }, {
            default: b(() => [
              k(d(Ra), { class: "space-y-1 text-center" }, {
                default: b(() => [
                  k(d(Oa), { class: "text-2xl" }, {
                    default: b(() => h[1] || (h[1] = [
                      ne("微信扫码登录", -1)
                    ])),
                    _: 1,
                    __: [1]
                  }),
                  k(d(Co), null, {
                    default: b(() => h[2] || (h[2] = [
                      ne("打开微信，扫描下方二维码", -1)
                    ])),
                    _: 1,
                    __: [2]
                  })
                ]),
                _: 1
              }),
              k(d(wr), { class: "grid gap-4" }, {
                default: b(() => [
                  w("div", V6, [
                    w("div", H6, [
                      n.value ? t.value ? (g(), R("div", z6, [
                        h[5] || (h[5] = w("p", { class: "text-sm text-gray-500" }, "二维码已失效，请刷新", -1)),
                        k(d(xr), {
                          onClick: u,
                          class: "mt-4 w-full"
                        }, {
                          default: b(() => [
                            k(d(D6), { class: "mr-2 h-4 w-4" }),
                            h[4] || (h[4] = w("p", { class: "text-center text-sm" }, "刷新", -1))
                          ]),
                          _: 1,
                          __: [4]
                        })
                      ])) : (g(), R("img", {
                        key: 2,
                        src: n.value,
                        class: "h-48 w-48 rounded-md border border-dashed",
                        alt: "二维码加载中"
                      }, null, 8, j6)) : (g(), R("div", F6, [
                        k(d(R6), { class: "w-8 h-8 animate-spin text-gray-500" }),
                        h[3] || (h[3] = w("p", { class: "mt-2 text-sm text-gray-500" }, "二维码正在加载中...", -1))
                      ]))
                    ])
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ])
      ])
    ]));
  }
}), Z6 = /* @__PURE__ */ D({
  __name: "Sheet",
  props: {
    open: { type: Boolean },
    defaultOpen: { type: Boolean },
    modal: { type: Boolean }
  },
  emits: ["update:open"],
  setup(e, { emit: t }) {
    const o = rt(e, t);
    return (n, s) => (g(), N(d(k0), re({ "data-slot": "sheet" }, d(o)), {
      default: b((i) => [
        q(n.$slots, "default", De(Fe(i)))
      ]),
      _: 3
    }, 16));
  }
});
function K6(e) {
  return $o() ? (In(e), !0) : !1;
}
const li = /* @__PURE__ */ new WeakMap(), W6 = /* @__NO_SIDE_EFFECTS__ */ (...e) => {
  var t;
  const r = e[0], a = (t = bt()) == null ? void 0 : t.proxy;
  if (a == null && !hl())
    throw new Error("injectLocal must be called in setup");
  return a && li.has(a) && r in li.get(a) ? li.get(a)[r] : he(...e);
};
function G6(e) {
  if (!Ve(e))
    return Rt(e);
  const t = new Proxy({}, {
    get(r, a, o) {
      return d(Reflect.get(e.value, a, o));
    },
    set(r, a, o) {
      return Ve(e.value[a]) && !Ve(o) ? e.value[a].value = o : e.value[a] = o, !0;
    },
    deleteProperty(r, a) {
      return Reflect.deleteProperty(e.value, a);
    },
    has(r, a) {
      return Reflect.has(e.value, a);
    },
    ownKeys() {
      return Object.keys(e.value);
    },
    getOwnPropertyDescriptor() {
      return {
        enumerable: !0,
        configurable: !0
      };
    }
  });
  return Rt(t);
}
function J6(e) {
  return G6(L(e));
}
function Ye(e, ...t) {
  const r = t.flat(), a = r[0];
  return J6(() => Object.fromEntries(typeof a == "function" ? Object.entries(ht(e)).filter(([o, n]) => !a(Je(n), o)) : Object.entries(ht(e)).filter((o) => !r.includes(o[0]))));
}
const rh = typeof window < "u" && typeof document < "u";
typeof WorkerGlobalScope < "u" && globalThis instanceof WorkerGlobalScope;
const Y6 = (e) => typeof e < "u", X6 = Object.prototype.toString, Q6 = (e) => X6.call(e) === "[object Object]", xd = () => {
};
function e3(e, t) {
  function r(...a) {
    return new Promise((o, n) => {
      Promise.resolve(e(() => t.apply(this, a), { fn: t, thisArg: this, args: a })).then(o).catch(n);
    });
  }
  return r;
}
function t3(e, t = {}) {
  let r, a, o = xd;
  const n = (l) => {
    clearTimeout(l), o(), o = xd;
  };
  let s;
  return (l) => {
    const c = Je(e), u = Je(t.maxWait);
    return r && n(r), c <= 0 || u !== void 0 && u <= 0 ? (a && (n(a), a = void 0), Promise.resolve(l())) : new Promise((f, p) => {
      o = t.rejectOnCancel ? p : f, s = l, u && !a && (a = setTimeout(() => {
        r && n(r), a = void 0, f(s());
      }, u)), r = setTimeout(() => {
        a && n(a), a = void 0, f(l());
      }, c);
    });
  };
}
function _d(e) {
  return e.endsWith("rem") ? Number.parseFloat(e) * 16 : Number.parseFloat(e);
}
function ci(e) {
  return Array.isArray(e) ? e : [e];
}
// @__NO_SIDE_EFFECTS__
function r3(e, t = 200, r = {}) {
  return e3(
    t3(t, r),
    e
  );
}
function a3(e, t, r) {
  return Ke(
    e,
    t,
    {
      ...r,
      immediate: !0
    }
  );
}
const ah = rh ? window : void 0, o3 = rh ? window.document : void 0;
function n3(e) {
  var t;
  const r = Je(e);
  return (t = r?.$el) != null ? t : r;
}
function oh(...e) {
  const t = [], r = () => {
    t.forEach((i) => i()), t.length = 0;
  }, a = (i, l, c, u) => (i.addEventListener(l, c, u), () => i.removeEventListener(l, c, u)), o = L(() => {
    const i = ci(Je(e[0])).filter((l) => l != null);
    return i.every((l) => typeof l != "string") ? i : void 0;
  }), n = a3(
    () => {
      var i, l;
      return [
        (l = (i = o.value) == null ? void 0 : i.map((c) => n3(c))) != null ? l : [ah].filter((c) => c != null),
        ci(Je(o.value ? e[1] : e[0])),
        ci(d(o.value ? e[2] : e[1])),
        // @ts-expect-error - TypeScript gets the correct types, but somehow still complains
        Je(o.value ? e[3] : e[2])
      ];
    },
    ([i, l, c, u]) => {
      if (r(), !i?.length || !l?.length || !c?.length)
        return;
      const f = Q6(u) ? { ...u } : u;
      t.push(
        ...i.flatMap(
          (p) => l.flatMap(
            (h) => c.map((m) => a(p, h, m, f))
          )
        )
      );
    },
    { flush: "post" }
  ), s = () => {
    n(), r();
  };
  return K6(r), s;
}
// @__NO_SIDE_EFFECTS__
function s3() {
  const e = ar(!1), t = bt();
  return t && at(() => {
    e.value = !0;
  }, t), e;
}
// @__NO_SIDE_EFFECTS__
function i3(e) {
  const t = /* @__PURE__ */ s3();
  return L(() => (t.value, !!e()));
}
const l3 = Symbol("vueuse-ssr-width");
// @__NO_SIDE_EFFECTS__
function c3() {
  const e = hl() ? /* @__PURE__ */ W6(l3, null) : null;
  return typeof e == "number" ? e : void 0;
}
function u3(e, t = {}) {
  const { window: r = ah, ssrWidth: a = /* @__PURE__ */ c3() } = t, o = /* @__PURE__ */ i3(() => r && "matchMedia" in r && typeof r.matchMedia == "function"), n = ar(typeof a == "number"), s = ar(), i = ar(!1), l = (c) => {
    i.value = c.matches;
  };
  return Xe(() => {
    if (n.value) {
      n.value = !o.value;
      const c = Je(e).split(",");
      i.value = c.some((u) => {
        const f = u.includes("not all"), p = u.match(/\(\s*min-width:\s*(-?\d+(?:\.\d*)?[a-z]+\s*)\)/), h = u.match(/\(\s*max-width:\s*(-?\d+(?:\.\d*)?[a-z]+\s*)\)/);
        let m = !!(p || h);
        return p && m && (m = a >= _d(p[1])), h && m && (m = a <= _d(h[1])), f ? !m : m;
      });
      return;
    }
    o.value && (s.value = r.matchMedia(Je(e)), i.value = s.value.matches);
  }), oh(s, "change", l, { passive: !0 }), L(() => i.value);
}
function d3(e) {
  return JSON.parse(JSON.stringify(e));
}
// @__NO_SIDE_EFFECTS__
function nh(e, t, r, a = {}) {
  var o, n, s;
  const {
    clone: i = !1,
    passive: l = !1,
    eventName: c,
    deep: u = !1,
    defaultValue: f,
    shouldEmit: p
  } = a, h = bt(), m = r || h?.emit || ((o = h?.$emit) == null ? void 0 : o.bind(h)) || ((s = (n = h?.proxy) == null ? void 0 : n.$emit) == null ? void 0 : s.bind(h?.proxy));
  let v = c;
  t || (t = "modelValue"), v = v || `update:${t.toString()}`;
  const x = (E) => i ? typeof i == "function" ? i(E) : d3(E) : E, C = () => Y6(e[t]) ? x(e[t]) : f, S = (E) => {
    p ? p(E) && m(v, E) : m(v, E);
  };
  if (l) {
    const E = C(), T = K(E);
    let F = !1;
    return Ke(
      () => e[t],
      (j) => {
        F || (F = !0, T.value = x(j), et(() => F = !1));
      }
    ), Ke(
      T,
      (j) => {
        !F && (j !== e[t] || u) && S(j);
      },
      { deep: u }
    ), T;
  } else
    return L({
      get() {
        return C();
      },
      set(E) {
        S(E);
      }
    });
}
const f3 = /* @__PURE__ */ D({
  __name: "SheetOverlay",
  props: {
    forceMount: { type: Boolean },
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class");
    return (a, o) => (g(), N(d(M0), re({
      "data-slot": "sheet-overlay",
      class: d(ve)("data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/80", t.class)
    }, d(r)), {
      default: b(() => [
        q(a.$slots, "default")
      ]),
      _: 3
    }, 16, ["class"]));
  }
}), p3 = /* @__PURE__ */ D({
  inheritAttrs: !1,
  __name: "SheetContent",
  props: {
    class: {},
    side: { default: "right" },
    forceMount: { type: Boolean },
    disableOutsidePointerEvents: { type: Boolean },
    asChild: { type: Boolean },
    as: {}
  },
  emits: ["escapeKeyDown", "pointerDownOutside", "focusOutside", "interactOutside", "openAutoFocus", "closeAutoFocus"],
  setup(e, { emit: t }) {
    const r = e, a = t, o = Ye(r, "class", "side"), n = rt(o, a);
    return (s, i) => (g(), N(d(E8), null, {
      default: b(() => [
        k(f3),
        k(d(P0), re({
          "data-slot": "sheet-content",
          class: d(ve)(
            "bg-background data-[state=open]:animate-in data-[state=closed]:animate-out fixed z-50 flex flex-col gap-4 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500",
            s.side === "right" && "data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right inset-y-0 right-0 h-full w-3/4 border-l sm:max-w-sm",
            s.side === "left" && "data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left inset-y-0 left-0 h-full w-3/4 border-r sm:max-w-sm",
            s.side === "top" && "data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top inset-x-0 top-0 h-auto border-b",
            s.side === "bottom" && "data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom inset-x-0 bottom-0 h-auto border-t",
            r.class
          )
        }, { ...s.$attrs, ...d(n) }), {
          default: b(() => [
            q(s.$slots, "default"),
            k(d(ql), { class: "ring-offset-background focus:ring-ring data-[state=open]:bg-secondary absolute top-4 right-4 rounded-xs opacity-70 transition-opacity hover:opacity-100 focus:ring-2 focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none" }, {
              default: b(() => [
                k(d(L6), { class: "size-4" }),
                i[0] || (i[0] = w("span", { class: "sr-only" }, "Close", -1))
              ]),
              _: 1,
              __: [0]
            })
          ]),
          _: 3
        }, 16, ["class"])
      ]),
      _: 3
    }));
  }
}), h3 = /* @__PURE__ */ D({
  __name: "SheetDescription",
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class");
    return (a, o) => (g(), N(d(T0), re({
      "data-slot": "sheet-description",
      class: d(ve)("text-muted-foreground text-sm", t.class)
    }, d(r)), {
      default: b(() => [
        q(a.$slots, "default")
      ]),
      _: 3
    }, 16, ["class"]));
  }
}), g3 = /* @__PURE__ */ D({
  __name: "SheetHeader",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("div", {
      "data-slot": "sheet-header",
      class: ke(d(ve)("flex flex-col gap-1.5 p-4", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), m3 = /* @__PURE__ */ D({
  __name: "SheetTitle",
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class");
    return (a, o) => (g(), N(d(R0), re({
      "data-slot": "sheet-title",
      class: d(ve)("text-foreground font-semibold", t.class)
    }, d(r)), {
      default: b(() => [
        q(a.$slots, "default")
      ]),
      _: 3
    }, 16, ["class"]));
  }
}), kd = "sidebar_state", v3 = 3600 * 24 * 7, b3 = "16rem", y3 = "18rem", w3 = "3rem", x3 = "b", [fs, _3] = it("Sidebar"), k3 = { class: "flex h-full w-full flex-col" }, C3 = ["data-state", "data-collapsible", "data-variant", "data-side"], A3 = {
  "data-sidebar": "sidebar",
  class: "bg-sidebar group-data-[variant=floating]:border-sidebar-border flex h-full w-full flex-col group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:border group-data-[variant=floating]:shadow-sm"
}, S3 = /* @__PURE__ */ D({
  inheritAttrs: !1,
  __name: "Sidebar",
  props: {
    side: { default: "left" },
    variant: { default: "sidebar" },
    collapsible: { default: "offcanvas" },
    class: {}
  },
  setup(e) {
    const t = e, { isMobile: r, state: a, openMobile: o, setOpenMobile: n } = fs();
    return (s, i) => s.collapsible === "none" ? (g(), R("div", re({
      key: 0,
      "data-slot": "sidebar",
      class: d(ve)("bg-sidebar text-sidebar-foreground flex h-full w-(--sidebar-width) flex-col", t.class)
    }, s.$attrs), [
      q(s.$slots, "default")
    ], 16)) : d(r) ? (g(), N(d(Z6), re({
      key: 1,
      open: d(o)
    }, s.$attrs, { "onUpdate:open": d(n) }), {
      default: b(() => [
        k(d(p3), {
          "data-sidebar": "sidebar",
          "data-slot": "sidebar",
          "data-mobile": "true",
          side: s.side,
          class: "bg-sidebar text-sidebar-foreground w-(--sidebar-width) p-0 [&>button]:hidden",
          style: Tt({
            "--sidebar-width": d(y3)
          })
        }, {
          default: b(() => [
            k(g3, { class: "sr-only" }, {
              default: b(() => [
                k(m3, null, {
                  default: b(() => i[0] || (i[0] = [
                    ne("Sidebar", -1)
                  ])),
                  _: 1,
                  __: [0]
                }),
                k(h3, null, {
                  default: b(() => i[1] || (i[1] = [
                    ne("Displays the mobile sidebar.", -1)
                  ])),
                  _: 1,
                  __: [1]
                })
              ]),
              _: 1
            }),
            w("div", k3, [
              q(s.$slots, "default")
            ])
          ]),
          _: 3
        }, 8, ["side", "style"])
      ]),
      _: 3
    }, 16, ["open", "onUpdate:open"])) : (g(), R("div", {
      key: 2,
      class: "group peer text-sidebar-foreground hidden md:block",
      "data-slot": "sidebar",
      "data-state": d(a),
      "data-collapsible": d(a) === "collapsed" ? s.collapsible : "",
      "data-variant": s.variant,
      "data-side": s.side
    }, [
      w("div", {
        class: ke(d(ve)(
          "relative w-(--sidebar-width) bg-transparent transition-[width] duration-200 ease-linear",
          "group-data-[collapsible=offcanvas]:w-0",
          "group-data-[side=right]:rotate-180",
          s.variant === "floating" || s.variant === "inset" ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4)))]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)"
        ))
      }, null, 2),
      w("div", re({
        class: d(ve)(
          "fixed inset-y-0 z-10 hidden h-svh w-(--sidebar-width) transition-[left,right,width] duration-200 ease-linear md:flex",
          s.side === "left" ? "left-0 group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)]" : "right-0 group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)]",
          // Adjust the padding for floating and inset variants.
          s.variant === "floating" || s.variant === "inset" ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4))+2px)]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon) group-data-[side=left]:border-r group-data-[side=right]:border-l",
          t.class
        )
      }, s.$attrs), [
        w("div", A3, [
          q(s.$slots, "default")
        ])
      ], 16)
    ], 8, C3));
  }
}), E3 = /* @__PURE__ */ D({
  __name: "SidebarContent",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("div", {
      "data-slot": "sidebar-content",
      "data-sidebar": "content",
      class: ke(d(ve)("flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), $3 = /* @__PURE__ */ D({
  __name: "SidebarFooter",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("div", {
      "data-slot": "sidebar-footer",
      "data-sidebar": "footer",
      class: ke(d(ve)("flex flex-col gap-2 p-2", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), Gi = /* @__PURE__ */ D({
  __name: "SidebarGroup",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("div", {
      "data-slot": "sidebar-group",
      "data-sidebar": "group",
      class: ke(d(ve)("relative flex w-full min-w-0 flex-col p-2", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), Ji = /* @__PURE__ */ D({
  __name: "SidebarGroupLabel",
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(Re), {
      "data-slot": "sidebar-group-label",
      "data-sidebar": "group-label",
      as: r.as,
      "as-child": r.asChild,
      class: ke(d(ve)(
        "text-sidebar-foreground/70 ring-sidebar-ring flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium outline-hidden transition-[margin,opacity] duration-200 ease-linear focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0",
        "group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0",
        t.class
      ))
    }, {
      default: b(() => [
        q(r.$slots, "default")
      ]),
      _: 3
    }, 8, ["as", "as-child", "class"]));
  }
}), P3 = /* @__PURE__ */ D({
  __name: "SidebarHeader",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("div", {
      "data-slot": "sidebar-header",
      "data-sidebar": "header",
      class: ke(d(ve)("flex flex-col gap-2 p-2", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), T3 = /* @__PURE__ */ D({
  __name: "Input",
  props: {
    defaultValue: {},
    modelValue: {},
    class: {}
  },
  emits: ["update:modelValue"],
  setup(e, { emit: t }) {
    const r = e, o = /* @__PURE__ */ nh(r, "modelValue", t, {
      passive: !0,
      defaultValue: r.defaultValue
    });
    return (n, s) => og((g(), R("input", {
      "onUpdate:modelValue": s[0] || (s[0] = (i) => Ve(o) ? o.value = i : null),
      "data-slot": "input",
      class: ke(d(ve)(
        "file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
        "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]",
        "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
        r.class
      ))
    }, null, 2)), [
      [E1, d(o)]
    ]);
  }
}), M3 = /* @__PURE__ */ D({
  __name: "SidebarInset",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("main", {
      "data-slot": "sidebar-inset",
      class: ke(d(ve)(
        "bg-background relative flex w-full flex-1 flex-col",
        "md:peer-data-[variant=inset]:m-2 md:peer-data-[variant=inset]:ml-0 md:peer-data-[variant=inset]:rounded-xl md:peer-data-[variant=inset]:shadow-sm md:peer-data-[variant=inset]:peer-data-[state=collapsed]:ml-2",
        t.class
      ))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), En = /* @__PURE__ */ D({
  __name: "SidebarMenu",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("ul", {
      "data-slot": "sidebar-menu",
      "data-sidebar": "menu",
      class: ke(d(ve)("flex w-full min-w-0 flex-col gap-1", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), R3 = /* @__PURE__ */ D({
  __name: "Tooltip",
  props: {
    defaultOpen: { type: Boolean },
    open: { type: Boolean },
    delayDuration: {},
    disableHoverableContent: { type: Boolean },
    disableClosingTrigger: { type: Boolean },
    disabled: { type: Boolean },
    ignoreNonKeyboardFocus: { type: Boolean }
  },
  emits: ["update:open"],
  setup(e, { emit: t }) {
    const o = rt(e, t);
    return (n, s) => (g(), N(d(r6), re({ "data-slot": "tooltip" }, d(o)), {
      default: b((i) => [
        q(n.$slots, "default", De(Fe(i)))
      ]),
      _: 3
    }, 16));
  }
}), O3 = /* @__PURE__ */ D({
  inheritAttrs: !1,
  __name: "TooltipContent",
  props: {
    forceMount: { type: Boolean },
    ariaLabel: {},
    asChild: { type: Boolean },
    as: {},
    side: {},
    sideOffset: { default: 4 },
    align: {},
    alignOffset: {},
    avoidCollisions: { type: Boolean },
    collisionBoundary: {},
    collisionPadding: {},
    arrowPadding: {},
    sticky: {},
    hideWhenDetached: { type: Boolean },
    positionStrategy: {},
    updatePositionStrategy: {},
    class: {}
  },
  emits: ["escapeKeyDown", "pointerDownOutside"],
  setup(e, { emit: t }) {
    const r = e, a = t, o = Ye(r, "class"), n = rt(o, a);
    return (s, i) => (g(), N(d(c6), null, {
      default: b(() => [
        k(d(i6), re({ "data-slot": "tooltip-content" }, { ...d(n), ...s.$attrs }, {
          class: d(ve)("bg-foreground text-background animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 w-fit rounded-md px-3 py-1.5 text-xs text-balance", r.class)
        }), {
          default: b(() => [
            q(s.$slots, "default"),
            k(d(J_), { class: "bg-foreground fill-foreground z-50 size-2.5 translate-y-[calc(-50%_-_2px)] rotate-45 rounded-[2px]" })
          ]),
          _: 3
        }, 16, ["class"])
      ]),
      _: 3
    }));
  }
}), B3 = /* @__PURE__ */ D({
  __name: "TooltipTrigger",
  props: {
    reference: {},
    asChild: { type: Boolean },
    as: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(d6), re({ "data-slot": "tooltip-trigger" }, t), {
      default: b(() => [
        q(r.$slots, "default")
      ]),
      _: 3
    }, 16));
  }
}), Cd = /* @__PURE__ */ D({
  __name: "SidebarMenuButtonChild",
  props: {
    variant: { default: "default" },
    size: { default: "default" },
    isActive: { type: Boolean },
    class: {},
    asChild: { type: Boolean },
    as: { default: "button" }
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(Re), re({
      "data-slot": "sidebar-menu-button",
      "data-sidebar": "menu-button",
      "data-size": r.size,
      "data-active": r.isActive,
      class: d(ve)(d(L3)({ variant: r.variant, size: r.size }), t.class),
      as: r.as,
      "as-child": r.asChild
    }, r.$attrs), {
      default: b(() => [
        q(r.$slots, "default")
      ]),
      _: 3
    }, 16, ["data-size", "data-active", "class", "as", "as-child"]));
  }
}), po = /* @__PURE__ */ D({
  inheritAttrs: !1,
  __name: "SidebarMenuButton",
  props: {
    variant: { default: "default" },
    size: { default: "default" },
    isActive: { type: Boolean },
    class: {},
    asChild: { type: Boolean },
    as: { default: "button" },
    tooltip: {}
  },
  setup(e) {
    const t = e, { isMobile: r, state: a } = fs(), o = Ye(t, "tooltip");
    return (n, s) => n.tooltip ? (g(), N(d(R3), { key: 1 }, {
      default: b(() => [
        k(d(B3), { "as-child": "" }, {
          default: b(() => [
            k(Cd, De(Fe({ ...d(o), ...n.$attrs })), {
              default: b(() => [
                q(n.$slots, "default")
              ]),
              _: 3
            }, 16)
          ]),
          _: 3
        }),
        k(d(O3), {
          side: "right",
          align: "center",
          hidden: d(a) !== "collapsed" || d(r)
        }, {
          default: b(() => [
            typeof n.tooltip == "string" ? (g(), R(Be, { key: 0 }, [
              ne(ue(n.tooltip), 1)
            ], 64)) : (g(), N(Qt(n.tooltip), { key: 1 }))
          ]),
          _: 1
        }, 8, ["hidden"])
      ]),
      _: 3
    })) : (g(), N(Cd, De(re({ key: 0 }, { ...d(o), ...n.$attrs })), {
      default: b(() => [
        q(n.$slots, "default")
      ]),
      _: 3
    }, 16));
  }
}), ho = /* @__PURE__ */ D({
  __name: "SidebarMenuItem",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("li", {
      "data-slot": "sidebar-menu-item",
      "data-sidebar": "menu-item",
      class: ke(d(ve)("group/menu-item relative", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), D3 = /* @__PURE__ */ D({
  __name: "SidebarProvider",
  props: {
    defaultOpen: { type: Boolean, default: !o3?.cookie.includes(`${kd}=false`) },
    open: { type: Boolean, default: void 0 },
    class: {}
  },
  emits: ["update:open"],
  setup(e, { emit: t }) {
    const r = e, a = t, o = u3("(max-width: 768px)"), n = K(!1), s = /* @__PURE__ */ nh(r, "open", a, {
      defaultValue: r.defaultOpen ?? !1,
      passive: r.open === void 0
    });
    function i(f) {
      s.value = f, document.cookie = `${kd}=${s.value}; path=/; max-age=${v3}`;
    }
    function l(f) {
      n.value = f;
    }
    function c() {
      return o.value ? l(!n.value) : i(!s.value);
    }
    oh("keydown", (f) => {
      f.key === x3 && (f.metaKey || f.ctrlKey) && (f.preventDefault(), c());
    });
    const u = L(() => s.value ? "expanded" : "collapsed");
    return _3({
      state: u,
      open: s,
      setOpen: i,
      isMobile: o,
      openMobile: n,
      setOpenMobile: l,
      toggleSidebar: c
    }), (f, p) => (g(), N(d(Q_), { "delay-duration": 0 }, {
      default: b(() => [
        w("div", re({
          "data-slot": "sidebar-wrapper",
          style: {
            "--sidebar-width": d(b3),
            "--sidebar-width-icon": d(w3)
          },
          class: d(ve)("group/sidebar-wrapper has-data-[variant=inset]:bg-sidebar flex min-h-svh w-full", r.class)
        }, f.$attrs), [
          q(f.$slots, "default")
        ], 16)
      ]),
      _: 3
    }));
  }
}), I3 = /* @__PURE__ */ D({
  __name: "SidebarRail",
  props: {
    class: {}
  },
  setup(e) {
    const t = e, { toggleSidebar: r } = fs();
    return (a, o) => (g(), R("button", {
      "data-sidebar": "rail",
      "data-slot": "sidebar-rail",
      "aria-label": "Toggle Sidebar",
      tabindex: -1,
      title: "Toggle Sidebar",
      class: ke(d(ve)(
        "hover:after:bg-sidebar-border absolute inset-y-0 z-20 hidden w-4 -translate-x-1/2 transition-all ease-linear group-data-[side=left]:-right-4 group-data-[side=right]:left-0 after:absolute after:inset-y-0 after:left-1/2 after:w-[2px] sm:flex",
        "in-data-[side=left]:cursor-w-resize in-data-[side=right]:cursor-e-resize",
        "[[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize",
        "hover:group-data-[collapsible=offcanvas]:bg-sidebar group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full",
        "[[data-side=left][data-collapsible=offcanvas]_&]:-right-2",
        "[[data-side=right][data-collapsible=offcanvas]_&]:-left-2",
        t.class
      )),
      onClick: o[0] || (o[0] = //@ts-ignore
      (...n) => d(r) && d(r)(...n))
    }, [
      q(a.$slots, "default")
    ], 2));
  }
}), sh = /* @__PURE__ */ D({
  __name: "Separator",
  props: {
    orientation: { default: "horizontal" },
    decorative: { type: Boolean, default: !0 },
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class");
    return (a, o) => (g(), N(d(N_), re({ "data-slot": "separator" }, d(r), {
      class: d(ve)(
        "bg-border shrink-0 data-[orientation=horizontal]:h-px data-[orientation=horizontal]:w-full data-[orientation=vertical]:h-full data-[orientation=vertical]:w-px",
        t.class
      )
    }), null, 16, ["class"]));
  }
}), q3 = /* @__PURE__ */ D({
  __name: "SidebarTrigger",
  props: {
    class: {}
  },
  setup(e) {
    const t = e, { toggleSidebar: r } = fs();
    return (a, o) => (g(), N(d(xr), {
      "data-sidebar": "trigger",
      "data-slot": "sidebar-trigger",
      variant: "ghost",
      size: "icon",
      class: ke(d(ve)("h-7 w-7", t.class)),
      onClick: d(r)
    }, {
      default: b(() => [
        k(d(B6)),
        o[0] || (o[0] = w("span", { class: "sr-only" }, "Toggle Sidebar", -1))
      ]),
      _: 1,
      __: [0]
    }, 8, ["class", "onClick"]));
  }
}), L3 = Rl(
  "peer/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm outline-hidden ring-sidebar-ring transition-[width,height,padding] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 group-has-data-[sidebar=menu-action]/menu-item:pr-8 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium data-[active=true]:text-sidebar-accent-foreground data-[state=open]:hover:bg-sidebar-accent data-[state=open]:hover:text-sidebar-accent-foreground group-data-[collapsible=icon]:size-8! group-data-[collapsible=icon]:p-2! [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
        outline: "bg-background shadow-[0_0_0_1px_hsl(var(--sidebar-border))] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_hsl(var(--sidebar-accent))]"
      },
      size: {
        default: "h-8 text-sm",
        sm: "h-7 text-xs",
        lg: "h-12 text-sm group-data-[collapsible=icon]:p-0!"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
), N3 = ["href"], V3 = /* @__PURE__ */ D({
  __name: "NavProjects",
  props: {
    projects: {}
  },
  setup(e) {
    return (t, r) => (g(), N(d(Gi), { class: "group-data-[collapsible=icon]:hidden" }, {
      default: b(() => [
        k(d(Ji), null, {
          default: b(() => r[0] || (r[0] = [
            ne("推荐", -1)
          ])),
          _: 1,
          __: [0]
        }),
        k(d(En), null, {
          default: b(() => [
            (g(!0), R(Be, null, qt(t.projects, (a) => (g(), N(d(ho), {
              key: a.name
            }, {
              default: b(() => [
                k(d(po), { "as-child": "" }, {
                  default: b(() => [
                    w("a", {
                      href: a.url,
                      target: "_blank"
                    }, [
                      (g(), N(Qt(a.icon))),
                      w("span", null, ue(a.name), 1)
                    ], 8, N3)
                  ]),
                  _: 2
                }, 1024)
              ]),
              _: 2
            }, 1024))), 128))
          ]),
          _: 1
        })
      ]),
      _: 1
    }));
  }
}), H3 = /* @__PURE__ */ D({
  __name: "TeamSwitcher",
  setup(e) {
    return (t, r) => (g(), N(d(En), null, {
      default: b(() => [
        k(d(ho), null, {
          default: b(() => [
            k(d(po), {
              size: "lg",
              class: "data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
            }, {
              default: b(() => r[0] || (r[0] = [
                w("div", { class: "flex aspect-square size-8 items-center justify-center rounded-lg text-sidebar-primary-foreground" }, [
                  w("img", {
                    alt: "KSpeeder Logo",
                    src: r0,
                    class: "size-6"
                  })
                ], -1),
                w("div", { class: "grid flex-1 text-left text-sm leading-tight" }, [
                  w("span", { class: "truncate font-medium" }, " KSpeeder "),
                  w("span", { class: "truncate text-xs" }, "Docker 镜像拉取速度 10x！")
                ], -1)
              ])),
              _: 1,
              __: [0]
            })
          ]),
          _: 1
        })
      ]),
      _: 1
    }));
  }
}), Hr = /* @__PURE__ */ D({
  __name: "Badge",
  props: {
    asChild: { type: Boolean },
    as: {},
    variant: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class");
    return (a, o) => (g(), N(d(Re), re({
      "data-slot": "badge",
      class: d(ve)(d(F3)({ variant: a.variant }), t.class)
    }, d(r)), {
      default: b(() => [
        q(a.$slots, "default")
      ]),
      _: 3
    }, 16, ["class"]));
  }
}), F3 = Rl(
  "inline-flex items-center justify-center rounded-full border px-2 py-0.5 text-xs font-medium w-fit whitespace-nowrap shrink-0 [&>svg]:size-3 gap-1 [&>svg]:pointer-events-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive transition-[color,box-shadow] overflow-hidden",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground [a&]:hover:bg-primary/90",
        secondary: "border-transparent bg-secondary text-secondary-foreground [a&]:hover:bg-secondary/90",
        destructive: "border-transparent bg-destructive text-white [a&]:hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
        outline: "text-foreground [a&]:hover:bg-accent [a&]:hover:text-accent-foreground"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
), z3 = { class: "flex items-center gap-2" }, j3 = /* @__PURE__ */ D({
  __name: "AppSidebar",
  props: {
    side: {},
    variant: {},
    collapsible: { default: "icon" },
    class: {}
  },
  setup(e) {
    const t = e, r = pp(), a = {
      projects: [
        {
          name: "KSpeeder - 官方主页",
          url: "https://kspeeder.com/",
          icon: P6
        },
        {
          name: "KSpeeder - 视频教学",
          url: "https://www.bilibili.com/video/BV1GvQWYZEt9/",
          icon: q6
        },
        {
          name: "KSpeeder - 使用指南",
          url: "https://www.koolcenter.com/t/topic/5974",
          icon: b6
        },
        {
          name: "FAQ - 常见问题",
          url: "https://www.koolcenter.com/t/topic/5892",
          icon: x6
        }
      ]
    };
    return (o, n) => {
      const s = pl("router-link");
      return g(), N(d(S3), De(Fe(t)), {
        default: b(() => [
          k(d(P3), null, {
            default: b(() => [
              k(H3)
            ]),
            _: 1
          }),
          k(d(sh)),
          k(d(E3), null, {
            default: b(() => [
              k(d(Gi), null, {
                default: b(() => [
                  k(d(Ji), null, {
                    default: b(() => n[0] || (n[0] = [
                      ne("导航", -1)
                    ])),
                    _: 1,
                    __: [0]
                  }),
                  k(d(En), null, {
                    default: b(() => [
                      k(d(ho), null, {
                        default: b(() => [
                          k(d(po), {
                            "as-child": "",
                            "is-active": d(r).name === "Home",
                            tooltip: "仪表盘"
                          }, {
                            default: b(() => [
                              k(s, { to: "/" }, {
                                default: b(() => [
                                  k(d(E6)),
                                  n[1] || (n[1] = w("span", null, "仪表盘", -1))
                                ]),
                                _: 1,
                                __: [1]
                              })
                            ]),
                            _: 1
                          }, 8, ["is-active"])
                        ]),
                        _: 1
                      }),
                      k(d(ho), null, {
                        default: b(() => [
                          k(d(po), {
                            "as-child": "",
                            "is-active": d(r).name === "DomainAcceleration",
                            tooltip: "域名加速"
                          }, {
                            default: b(() => [
                              k(s, { to: "/domain-acceleration" }, {
                                default: b(() => [
                                  k(d($6)),
                                  w("span", z3, [
                                    n[3] || (n[3] = ne(" 域名加速 ", -1)),
                                    k(d(Hr), {
                                      variant: "secondary",
                                      class: "h-5 px-1.5 rounded-sm"
                                    }, {
                                      default: b(() => n[2] || (n[2] = [
                                        ne("Beta", -1)
                                      ])),
                                      _: 1,
                                      __: [2]
                                    })
                                  ])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["is-active"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              k(d(Gi), null, {
                default: b(() => [
                  k(d(Ji), null, {
                    default: b(() => n[4] || (n[4] = [
                      ne("工具", -1)
                    ])),
                    _: 1,
                    __: [4]
                  }),
                  k(d(En), null, {
                    default: b(() => [
                      k(d(ho), null, {
                        default: b(() => [
                          k(d(po), {
                            "as-child": "",
                            "is-active": d(r).name === "CacheCleanup",
                            tooltip: "强制清理缓存"
                          }, {
                            default: b(() => [
                              k(s, { to: "/tools/cache-cleanup" }, {
                                default: b(() => [
                                  k(d(th)),
                                  n[5] || (n[5] = w("span", null, "强制清理缓存", -1))
                                ]),
                                _: 1,
                                __: [5]
                              })
                            ]),
                            _: 1
                          }, 8, ["is-active"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              k(V3, {
                projects: a.projects
              }, null, 8, ["projects"])
            ]),
            _: 1
          }),
          k(d($3)),
          k(d(I3))
        ]),
        _: 1
      }, 16);
    };
  }
}), U3 = /* @__PURE__ */ D({
  __name: "Avatar",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(e4), {
      "data-slot": "avatar",
      class: ke(d(ve)("relative flex size-8 shrink-0 overflow-hidden rounded-full", t.class))
    }, {
      default: b(() => [
        q(r.$slots, "default")
      ]),
      _: 3
    }, 8, ["class"]));
  }
}), Z3 = /* @__PURE__ */ D({
  __name: "AvatarFallback",
  props: {
    delayMs: {},
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class");
    return (a, o) => (g(), N(d(r4), re({ "data-slot": "avatar-fallback" }, d(r), {
      class: d(ve)("bg-muted flex size-full items-center justify-center rounded-full", t.class)
    }), {
      default: b(() => [
        q(a.$slots, "default")
      ]),
      _: 3
    }, 16, ["class"]));
  }
}), K3 = /* @__PURE__ */ D({
  __name: "DropdownMenu",
  props: {
    defaultOpen: { type: Boolean },
    open: { type: Boolean },
    dir: {},
    modal: { type: Boolean }
  },
  emits: ["update:open"],
  setup(e, { emit: t }) {
    const o = rt(e, t);
    return (n, s) => (g(), N(d(x_), re({ "data-slot": "dropdown-menu" }, d(o)), {
      default: b((i) => [
        q(n.$slots, "default", De(Fe(i)))
      ]),
      _: 3
    }, 16));
  }
}), W3 = /* @__PURE__ */ D({
  inheritAttrs: !1,
  __name: "DropdownMenuContent",
  props: {
    forceMount: { type: Boolean },
    loop: { type: Boolean },
    side: {},
    sideOffset: { default: 4 },
    sideFlip: { type: Boolean },
    align: {},
    alignOffset: {},
    alignFlip: { type: Boolean },
    avoidCollisions: { type: Boolean },
    collisionBoundary: {},
    collisionPadding: {},
    arrowPadding: {},
    hideShiftedArrow: { type: Boolean },
    sticky: {},
    hideWhenDetached: { type: Boolean },
    positionStrategy: {},
    updatePositionStrategy: {},
    disableUpdateOnLayoutShift: { type: Boolean },
    prioritizePosition: { type: Boolean },
    reference: {},
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  emits: ["escapeKeyDown", "pointerDownOutside", "focusOutside", "interactOutside", "closeAutoFocus"],
  setup(e, { emit: t }) {
    const r = e, a = t, o = Ye(r, "class"), n = rt(o, a);
    return (s, i) => (g(), N(d(P_), null, {
      default: b(() => [
        k(d(k_), re({ "data-slot": "dropdown-menu-content" }, { ...s.$attrs, ...d(n) }, {
          class: d(ve)("bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 max-h-(--reka-dropdown-menu-content-available-height) min-w-[8rem] origin-(--reka-dropdown-menu-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-md border p-1 shadow-md", r.class)
        }), {
          default: b(() => [
            q(s.$slots, "default")
          ]),
          _: 3
        }, 16, ["class"])
      ]),
      _: 3
    }));
  }
}), G3 = /* @__PURE__ */ D({
  __name: "DropdownMenuItem",
  props: {
    disabled: { type: Boolean },
    textValue: {},
    asChild: { type: Boolean },
    as: {},
    class: {},
    inset: { type: Boolean },
    variant: { default: "default" }
  },
  setup(e) {
    const t = e, r = Ye(t, "inset", "variant", "class"), a = da(r);
    return (o, n) => (g(), N(d(A_), re({
      "data-slot": "dropdown-menu-item",
      "data-inset": o.inset ? "" : void 0,
      "data-variant": o.variant
    }, d(a), {
      class: d(ve)("focus:bg-accent focus:text-accent-foreground data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/10 dark:data-[variant=destructive]:focus:bg-destructive/20 data-[variant=destructive]:focus:text-destructive data-[variant=destructive]:*:[svg]:!text-destructive [&_svg:not([class*='text-'])]:text-muted-foreground relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 data-[inset]:pl-8 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", t.class)
    }), {
      default: b(() => [
        q(o.$slots, "default")
      ]),
      _: 3
    }, 16, ["data-inset", "data-variant", "class"]));
  }
}), J3 = /* @__PURE__ */ D({
  __name: "DropdownMenuLabel",
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {},
    inset: { type: Boolean }
  },
  setup(e) {
    const t = e, r = Ye(t, "class", "inset"), a = da(r);
    return (o, n) => (g(), N(d(E_), re({
      "data-slot": "dropdown-menu-label",
      "data-inset": o.inset ? "" : void 0
    }, d(a), {
      class: d(ve)("px-2 py-1.5 text-sm font-medium data-[inset]:pl-8", t.class)
    }), {
      default: b(() => [
        q(o.$slots, "default")
      ]),
      _: 3
    }, 16, ["data-inset", "class"]));
  }
}), Y3 = /* @__PURE__ */ D({
  __name: "DropdownMenuSeparator",
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class");
    return (a, o) => (g(), N(d(M_), re({ "data-slot": "dropdown-menu-separator" }, d(r), {
      class: d(ve)("bg-border -mx-1 my-1 h-px", t.class)
    }), null, 16, ["class"]));
  }
}), X3 = /* @__PURE__ */ D({
  __name: "DropdownMenuTrigger",
  props: {
    disabled: { type: Boolean },
    asChild: { type: Boolean },
    as: {}
  },
  setup(e) {
    const r = da(e);
    return (a, o) => (g(), N(d(O_), re({ "data-slot": "dropdown-menu-trigger" }, d(r)), {
      default: b(() => [
        q(a.$slots, "default")
      ]),
      _: 3
    }, 16));
  }
}), Q3 = { class: "relative w-max h-max cursor-pointer" }, e5 = {
  key: 0,
  class: "absolute bottom-2 right-0 transform translate-x-1/2 translate-y-1/2"
}, t5 = { class: "group flex items-center space-x-2" }, r5 = /* @__PURE__ */ D({
  __name: "UserAvatar",
  setup(e) {
    const t = qa(), r = Cl(), a = async (s) => {
      const i = t.user?.username;
      if (i)
        try {
          await navigator.clipboard.writeText(i), ut.success("用户名已复制");
        } catch {
          const l = s.currentTarget;
          if (l) {
            const c = document.createRange();
            c.selectNodeContents(l);
            const u = window.getSelection();
            u?.removeAllRanges(), u?.addRange(c);
          }
          ut.error("复制失败，请手动复制");
        }
    }, o = L(() => {
      if (!t.isLogin)
        return "未登录";
      const { username: s } = t.user;
      return s ? s.charAt(0).toUpperCase() : "K";
    }), n = async () => {
      mw().then(() => {
        ut.success("退出账号成功"), t.flush(), r.push("/").then();
      });
    };
    return (s, i) => (g(), N(d(K3), null, {
      default: b(() => [
        k(d(X3), { "as-child": "" }, {
          default: b(() => [
            w("div", Q3, [
              k(d(U3), { class: "h-10 w-10" }, {
                default: b(() => [
                  k(d(Z3), { class: "uppercase bg-gray-200 text-gray-700" }, {
                    default: b(() => [
                      ne(ue(o.value), 1)
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              d(t).isPlus ? (g(), R("div", e5, [
                k(d(Hr), {
                  variant: "default",
                  class: "bg-amber-400 text-white w-5 h-5 p-0 rounded-full flex items-center justify-center text-xs font-bold"
                }, {
                  default: b(() => i[0] || (i[0] = [
                    ne(" P ", -1)
                  ])),
                  _: 1,
                  __: [0]
                })
              ])) : $e("", !0)
            ])
          ]),
          _: 1
        }),
        k(d(W3), { class: "w-56" }, {
          default: b(() => [
            k(d(J3), null, {
              default: b(() => [
                w("div", t5, [
                  w("p", {
                    class: "flex items-center gap-1 text-xs text-muted-foreground cursor-pointer",
                    onClick: a
                  }, [
                    ne(ue(d(t).user?.username) + " ", 1),
                    k(d(A6), { class: "h-3 w-3 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" })
                  ]),
                  d(t).isPlus ? (g(), N(d(Hr), {
                    key: 0,
                    variant: "default",
                    class: "bg-amber-400 text-white text-xs font-bold"
                  }, {
                    default: b(() => i[1] || (i[1] = [
                      ne(" Plus 会员 ", -1)
                    ])),
                    _: 1,
                    __: [1]
                  })) : $e("", !0)
                ])
              ]),
              _: 1
            }),
            k(d(Y3)),
            k(d(G3), { onClick: n }, {
              default: b(() => [
                k(d(O6), { class: "w-4 h-4 mr-2" }),
                i[2] || (i[2] = w("span", null, "退出", -1))
              ]),
              _: 1,
              __: [2]
            })
          ]),
          _: 1
        })
      ]),
      _: 1
    }));
  }
}), a5 = /* @__PURE__ */ D({
  __name: "Breadcrumb",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("nav", {
      "aria-label": "breadcrumb",
      "data-slot": "breadcrumb",
      class: ke(t.class)
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), Ad = /* @__PURE__ */ D({
  __name: "BreadcrumbItem",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("li", {
      "data-slot": "breadcrumb-item",
      class: ke(d(ve)("inline-flex items-center gap-1.5", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), o5 = /* @__PURE__ */ D({
  __name: "BreadcrumbLink",
  props: {
    asChild: { type: Boolean },
    as: { default: "a" },
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(Re), {
      "data-slot": "breadcrumb-link",
      as: r.as,
      "as-child": r.asChild,
      class: ke(d(ve)("hover:text-foreground transition-colors", t.class))
    }, {
      default: b(() => [
        q(r.$slots, "default")
      ]),
      _: 3
    }, 8, ["as", "as-child", "class"]));
  }
}), n5 = /* @__PURE__ */ D({
  __name: "BreadcrumbList",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("ol", {
      "data-slot": "breadcrumb-list",
      class: ke(d(ve)("text-muted-foreground flex flex-wrap items-center gap-1.5 text-sm break-words sm:gap-2.5", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), s5 = /* @__PURE__ */ D({
  __name: "BreadcrumbPage",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("span", {
      "data-slot": "breadcrumb-page",
      role: "link",
      "aria-disabled": "true",
      "aria-current": "page",
      class: ke(d(ve)("text-foreground font-normal", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), i5 = /* @__PURE__ */ D({
  __name: "BreadcrumbSeparator",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("li", {
      "data-slot": "breadcrumb-separator",
      role: "presentation",
      "aria-hidden": "true",
      class: ke(d(ve)("[&>svg]:size-3.5", t.class))
    }, [
      q(r.$slots, "default", {}, () => [
        k(d(y6))
      ])
    ], 2));
  }
}), l5 = { class: "sticky top-0 z-10 bg-background/90 backdrop-blur box-content border-b-1 flex h-16 shrink-0 items-center gap-2 transition-[width,height] ease-linear group-has-[[data-collapsible=icon]]/sidebar-wrapper:h-12" }, c5 = { class: "w-full flex items-center gap-2 px-4" }, u5 = { class: "w-full flex justify-between items-center gap-4" }, d5 = {
  key: 1,
  class: "text-muted-foreground"
}, f5 = /* @__PURE__ */ D({
  __name: "AppTopHeader",
  setup(e) {
    const t = qa(), r = pp(), a = L(() => {
      const o = r.meta?.breadcrumb;
      return Array.isArray(o) && o.length > 0 ? o : r.name === "DomainAcceleration" ? [{ label: "KSpeeder", to: { name: "Home" } }, { label: "域名加速" }] : r.name === "CacheCleanup" ? [{ label: "KSpeeder", to: { name: "Home" } }, { label: "工具" }, { label: "强制清理缓存" }] : [{ label: "KSpeeder", to: { name: "Home" } }, { label: "仪表盘" }];
    });
    return (o, n) => {
      const s = pl("router-link");
      return g(), R("header", l5, [
        w("div", c5, [
          k(d(q3), { class: "-ml-1" }),
          k(d(sh), {
            orientation: "vertical",
            class: "mr-2 h-4"
          }),
          w("div", u5, [
            k(d(a5), null, {
              default: b(() => [
                k(d(n5), null, {
                  default: b(() => [
                    (g(!0), R(Be, null, qt(a.value, (i, l) => (g(), R(Be, {
                      key: `${l}-${i.label}`
                    }, [
                      l < a.value.length - 1 ? (g(), N(d(Ad), { key: 0 }, {
                        default: b(() => [
                          i.to ? (g(), N(d(o5), {
                            key: 0,
                            "as-child": ""
                          }, {
                            default: b(() => [
                              k(s, {
                                to: i.to
                              }, {
                                default: b(() => [
                                  ne(ue(i.label), 1)
                                ]),
                                _: 2
                              }, 1032, ["to"])
                            ]),
                            _: 2
                          }, 1024)) : (g(), R("span", d5, ue(i.label), 1))
                        ]),
                        _: 2
                      }, 1024)) : (g(), N(d(Ad), { key: 1 }, {
                        default: b(() => [
                          k(d(s5), null, {
                            default: b(() => [
                              ne(ue(i.label), 1)
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1024)),
                      l < a.value.length - 1 ? (g(), N(d(i5), { key: 2 })) : $e("", !0)
                    ], 64))), 128))
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            d(t).isLogin ? (g(), N(r5, { key: 0 })) : (g(), N(s, {
              key: 1,
              to: "/login"
            }, {
              default: b(() => [
                k(d(xr), { class: "cursor-pointer" }, {
                  default: b(() => n[0] || (n[0] = [
                    ne("登录", -1)
                  ])),
                  _: 1,
                  __: [0]
                })
              ]),
              _: 1
            }))
          ])
        ])
      ]);
    };
  }
}), p5 = /* @__PURE__ */ D({
  __name: "AppLayout",
  setup(e) {
    return (t, r) => (g(), N(d(D3), null, {
      default: b(() => [
        k(j3),
        k(d(M3), null, {
          default: b(() => [
            k(f5),
            k(d(kl))
          ]),
          _: 1
        })
      ]),
      _: 1
    }));
  }
}), h5 = ["width", "height", "fill", "transform"], g5 = { key: 0 }, m5 = /* @__PURE__ */ w("path", { d: "M227,168a12,12,0,0,0-4.21-5.09C207.25,152.22,204,133.68,204,120c0-16.17,12.68-30.6,20.25-37.76a12,12,0,0,0,0-17.43C210.89,52.17,188.81,44,168,44a76.29,76.29,0,0,0-40,11.37,75.59,75.59,0,0,0-93.58,11A78.64,78.64,0,0,0,12,123.51,131,131,0,0,0,53.43,216,43.81,43.81,0,0,0,83.6,228h87.69a43.87,43.87,0,0,0,32.05-13.85,127.63,127.63,0,0,0,18.4-25.39c1.57-2.88,3-5.71,4.14-8.41C227.47,176.67,229.12,172.87,227,168Zm-41.23,29.82A19.78,19.78,0,0,1,171.29,204H83.6a19.85,19.85,0,0,1-13.7-5.42A107.18,107.18,0,0,1,36,122.88,54.49,54.49,0,0,1,51.5,83.28,50.86,50.86,0,0,1,88,68h.72A51.5,51.5,0,0,1,120.48,79.4a12,12,0,0,0,15,0A51.41,51.41,0,0,1,168,68a67.24,67.24,0,0,1,29.88,7.4C186.26,89.66,180,105.13,180,120c0,23.33,7.47,42.89,21.25,56.19A103.3,103.3,0,0,1,185.76,197.81ZM128.75,13A43.83,43.83,0,0,1,142.17,1.51a12,12,0,0,1,11.64,21,19.84,19.84,0,0,0-6.11,5.24A12,12,0,0,1,128.75,13Z" }, null, -1), v5 = [
  m5
], b5 = { key: 1 }, y5 = /* @__PURE__ */ w("path", {
  d: "M216,73.52Zm0,99.26c-16.79-11.53-24-30.87-24-52.78,0-18.3,11.68-34.81,24-46.48C204.53,62.66,185,56,168,56a63.72,63.72,0,0,0-40,14h0A63.71,63.71,0,0,0,88.88,56C52,55.5,23.06,86.3,24,123.19a119.62,119.62,0,0,0,37.65,84.12A32,32,0,0,0,83.6,216h87.7a31.75,31.75,0,0,0,23.26-10c15.85-17,21.44-33.2,21.44-33.2Z",
  opacity: "0.2"
}, null, -1), w5 = /* @__PURE__ */ w("path", { d: "M223.3,169.59a8.07,8.07,0,0,0-2.8-3.4C203.53,154.53,200,134.64,200,120c0-17.67,13.47-33.06,21.5-40.67a8,8,0,0,0,0-11.62C208.82,55.74,187.82,48,168,48a72.23,72.23,0,0,0-40,12.13,71.56,71.56,0,0,0-90.71,9.09A74.63,74.63,0,0,0,16,123.4a127,127,0,0,0,40.14,89.73A39.8,39.8,0,0,0,83.59,224h87.68a39.84,39.84,0,0,0,29.12-12.57,125,125,0,0,0,17.82-24.6C225.23,174,224.33,172,223.3,169.59Zm-34.63,30.94a23.76,23.76,0,0,1-17.4,7.47H83.59a23.82,23.82,0,0,1-16.44-6.51A111.14,111.14,0,0,1,32,123,58.5,58.5,0,0,1,48.65,80.47,54.81,54.81,0,0,1,88,64h.78A55.45,55.45,0,0,1,123,76.28a8,8,0,0,0,10,0A55.39,55.39,0,0,1,168,64a70.64,70.64,0,0,1,36,10.35c-13,14.52-20,30.47-20,45.65,0,23.77,7.64,42.73,22.18,55.3A105.52,105.52,0,0,1,188.67,200.53ZM128.23,30A40,40,0,0,1,167,0h1a8,8,0,0,1,0,16h-1a24,24,0,0,0-23.24,18,8,8,0,1,1-15.5-4Z" }, null, -1), x5 = [
  y5,
  w5
], _5 = { key: 2 }, k5 = /* @__PURE__ */ w("path", { d: "M128.23,30A40,40,0,0,1,167,0h1a8,8,0,0,1,0,16h-1a24,24,0,0,0-23.24,18,8,8,0,1,1-15.5-4ZM223.3,169.59a8.07,8.07,0,0,0-2.8-3.4C203.53,154.53,200,134.64,200,120c0-17.67,13.47-33.06,21.5-40.67a8,8,0,0,0,0-11.62C208.82,55.74,187.82,48,168,48a72.23,72.23,0,0,0-40,12.13,71.56,71.56,0,0,0-90.71,9.09A74.63,74.63,0,0,0,16,123.4a127,127,0,0,0,40.14,89.73A39.8,39.8,0,0,0,83.59,224h87.68a39.84,39.84,0,0,0,29.12-12.57,125,125,0,0,0,17.82-24.6C225.23,174,224.33,172,223.3,169.59Z" }, null, -1), C5 = [
  k5
], A5 = { key: 3 }, S5 = /* @__PURE__ */ w("path", { d: "M219.4,167.84C201.71,155.69,198,135.12,198,120c0-18.42,13.86-34.29,22.12-42.12a6,6,0,0,0,0-8.71C208,57.7,187.07,50,168,50a70.23,70.23,0,0,0-40,12.55,69.6,69.6,0,0,0-89.31,8.08A72.63,72.63,0,0,0,18,123.35a125.11,125.11,0,0,0,39.53,88.33A37.85,37.85,0,0,0,83.6,222h87.7A37.83,37.83,0,0,0,199,210.07a122.6,122.6,0,0,0,17.54-24.2c6.55-12,5.77-13.75,5-15.48A6.07,6.07,0,0,0,219.4,167.84Zm-29.23,34A25.82,25.82,0,0,1,171.3,210H83.6A25.85,25.85,0,0,1,65.78,203,113.21,113.21,0,0,1,30,123a60.55,60.55,0,0,1,17.21-44A56.82,56.82,0,0,1,88,62h.81a57.35,57.35,0,0,1,35.44,12.71,6,6,0,0,0,7.5,0A57.39,57.39,0,0,1,168,62c13.89,0,28.81,4.68,39.11,12-9.44,10.14-21.1,26.59-21.1,46,0,23.78,7.81,42.6,22.66,54.77A107.33,107.33,0,0,1,190.17,201.89Zm-60-171.39A38,38,0,0,1,167,2h1a6,6,0,0,1,0,12h-1a26,26,0,0,0-25.18,19.5,6,6,0,1,1-11.62-3Z" }, null, -1), E5 = [
  S5
], $5 = { key: 4 }, P5 = /* @__PURE__ */ w("path", { d: "M223.3,169.59a8.07,8.07,0,0,0-2.8-3.4C203.53,154.53,200,134.64,200,120c0-17.67,13.47-33.06,21.5-40.67a8,8,0,0,0,0-11.62C208.82,55.74,187.82,48,168,48a72.2,72.2,0,0,0-40,12.13,71.56,71.56,0,0,0-90.71,9.09A74.63,74.63,0,0,0,16,123.4a127.06,127.06,0,0,0,40.14,89.73A39.8,39.8,0,0,0,83.59,224h87.68a39.84,39.84,0,0,0,29.12-12.57,125,125,0,0,0,17.82-24.6C225.23,174,224.33,172,223.3,169.59Zm-34.63,30.94a23.76,23.76,0,0,1-17.4,7.47H83.59a23.82,23.82,0,0,1-16.44-6.51A111.14,111.14,0,0,1,32,123,58.5,58.5,0,0,1,48.65,80.47,54.81,54.81,0,0,1,88,64h.78A55.45,55.45,0,0,1,123,76.28a8,8,0,0,0,10,0A55.44,55.44,0,0,1,168,64a70.64,70.64,0,0,1,36,10.35c-13,14.52-20,30.47-20,45.65,0,23.77,7.64,42.73,22.18,55.3A105.82,105.82,0,0,1,188.67,200.53ZM128.23,30A40,40,0,0,1,167,0h1a8,8,0,0,1,0,16h-1a24,24,0,0,0-23.24,18,8,8,0,1,1-15.5-4Z" }, null, -1), T5 = [
  P5
], M5 = { key: 5 }, R5 = /* @__PURE__ */ w("path", { d: "M218.27,169.49C199.86,156.84,196,135.6,196,120c0-19.17,14.25-35.53,22.75-43.57a4,4,0,0,0,0-5.81C207,59.48,186.59,52,168,52a68.3,68.3,0,0,0-40,13,67.61,67.61,0,0,0-87.88,7A70.65,70.65,0,0,0,20,123.3a123.11,123.11,0,0,0,38.9,86.92A35.81,35.81,0,0,0,83.6,220h87.7a35.84,35.84,0,0,0,26.19-11.3,119.93,119.93,0,0,0,17.24-23.79c6.08-11.1,5.42-12.62,4.94-13.72A4,4,0,0,0,218.27,169.49Zm-26.64,33.77A27.83,27.83,0,0,1,171.3,212H83.6a27.84,27.84,0,0,1-19.19-7.6A115.15,115.15,0,0,1,28,123.09,62.55,62.55,0,0,1,45.81,77.66,58.78,58.78,0,0,1,88,60h.84a59.37,59.37,0,0,1,36.66,13.15,4,4,0,0,0,5,0A59.35,59.35,0,0,1,168,60c15.12,0,31.45,5.41,42.11,13.73C200.68,83.42,188,100.16,188,120c0,23.79,8,42.44,23.12,54.17A107.64,107.64,0,0,1,191.63,203.26ZM132.13,31A36,36,0,0,1,167,4h1a4,4,0,0,1,0,8h-1a28,28,0,0,0-27.12,21A4,4,0,0,1,136,36a3.87,3.87,0,0,1-1-.13A4,4,0,0,1,132.13,31Z" }, null, -1), O5 = [
  R5
], B5 = {
  name: "PhAppleLogo"
}, D5 = /* @__PURE__ */ D({
  ...B5,
  props: {
    weight: {
      type: String
    },
    size: {
      type: [String, Number]
    },
    color: {
      type: String
    },
    mirrored: {
      type: Boolean
    }
  },
  setup(e) {
    const t = e, r = he("weight", "regular"), a = he("size", "1em"), o = he("color", "currentColor"), n = he("mirrored", !1), s = L(() => t.weight ?? r), i = L(() => t.size ?? a), l = L(() => t.color ?? o), c = L(() => t.mirrored !== void 0 ? t.mirrored ? "scale(-1, 1)" : void 0 : n ? "scale(-1, 1)" : void 0);
    return (u, f) => (g(), R("svg", re({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 256 256",
      width: i.value,
      height: i.value,
      fill: l.value,
      transform: c.value
    }, u.$attrs), [
      q(u.$slots, "default"),
      s.value === "bold" ? (g(), R("g", g5, v5)) : s.value === "duotone" ? (g(), R("g", b5, x5)) : s.value === "fill" ? (g(), R("g", _5, C5)) : s.value === "light" ? (g(), R("g", A5, E5)) : s.value === "regular" ? (g(), R("g", $5, T5)) : s.value === "thin" ? (g(), R("g", M5, O5)) : $e("", !0)
    ], 16, h5));
  }
}), I5 = ["width", "height", "fill", "transform"], q5 = { key: 0 }, L5 = /* @__PURE__ */ w("path", { d: "M228,48V96a12,12,0,0,1-12,12H168a12,12,0,0,1,0-24h19l-7.8-7.8a75.55,75.55,0,0,0-53.32-22.26h-.43A75.49,75.49,0,0,0,72.39,75.57,12,12,0,1,1,55.61,58.41a99.38,99.38,0,0,1,69.87-28.47H126A99.42,99.42,0,0,1,196.2,59.23L204,67V48a12,12,0,0,1,24,0ZM183.61,180.43a75.49,75.49,0,0,1-53.09,21.63h-.43A75.55,75.55,0,0,1,76.77,179.8L69,172H88a12,12,0,0,0,0-24H40a12,12,0,0,0-12,12v48a12,12,0,0,0,24,0V189l7.8,7.8A99.42,99.42,0,0,0,130,226.06h.56a99.38,99.38,0,0,0,69.87-28.47,12,12,0,0,0-16.78-17.16Z" }, null, -1), N5 = [
  L5
], V5 = { key: 1 }, H5 = /* @__PURE__ */ w("path", {
  d: "M216,128a88,88,0,1,1-88-88A88,88,0,0,1,216,128Z",
  opacity: "0.2"
}, null, -1), F5 = /* @__PURE__ */ w("path", { d: "M224,48V96a8,8,0,0,1-8,8H168a8,8,0,0,1,0-16h28.69L182.06,73.37a79.56,79.56,0,0,0-56.13-23.43h-.45A79.52,79.52,0,0,0,69.59,72.71,8,8,0,0,1,58.41,61.27a96,96,0,0,1,135,.79L208,76.69V48a8,8,0,0,1,16,0ZM186.41,183.29a80,80,0,0,1-112.47-.66L59.31,168H88a8,8,0,0,0,0-16H40a8,8,0,0,0-8,8v48a8,8,0,0,0,16,0V179.31l14.63,14.63A95.43,95.43,0,0,0,130,222.06h.53a95.36,95.36,0,0,0,67.07-27.33,8,8,0,0,0-11.18-11.44Z" }, null, -1), z5 = [
  H5,
  F5
], j5 = { key: 2 }, U5 = /* @__PURE__ */ w("path", { d: "M224,48V96a8,8,0,0,1-8,8H168a8,8,0,0,1-5.66-13.66L180.65,72a79.48,79.48,0,0,0-54.72-22.09h-.45A79.52,79.52,0,0,0,69.59,72.71,8,8,0,0,1,58.41,61.27,96,96,0,0,1,192,60.7l18.36-18.36A8,8,0,0,1,224,48ZM186.41,183.29A80,80,0,0,1,75.35,184l18.31-18.31A8,8,0,0,0,88,152H40a8,8,0,0,0-8,8v48a8,8,0,0,0,13.66,5.66L64,195.3a95.42,95.42,0,0,0,66,26.76h.53a95.36,95.36,0,0,0,67.07-27.33,8,8,0,0,0-11.18-11.44Z" }, null, -1), Z5 = [
  U5
], K5 = { key: 3 }, W5 = /* @__PURE__ */ w("path", { d: "M222,48V96a6,6,0,0,1-6,6H168a6,6,0,0,1,0-12h33.52L183.47,72a81.51,81.51,0,0,0-57.53-24h-.46A81.5,81.5,0,0,0,68.19,71.28a6,6,0,1,1-8.38-8.58,93.38,93.38,0,0,1,65.67-26.76H126a93.45,93.45,0,0,1,66,27.53l18,18V48a6,6,0,0,1,12,0ZM187.81,184.72a81.5,81.5,0,0,1-57.29,23.34h-.46a81.51,81.51,0,0,1-57.53-24L54.48,166H88a6,6,0,0,0,0-12H40a6,6,0,0,0-6,6v48a6,6,0,0,0,12,0V174.48l18,18.05a93.45,93.45,0,0,0,66,27.53h.52a93.38,93.38,0,0,0,65.67-26.76,6,6,0,1,0-8.38-8.58Z" }, null, -1), G5 = [
  W5
], J5 = { key: 4 }, Y5 = /* @__PURE__ */ w("path", { d: "M224,48V96a8,8,0,0,1-8,8H168a8,8,0,0,1,0-16h28.69L182.06,73.37a79.56,79.56,0,0,0-56.13-23.43h-.45A79.52,79.52,0,0,0,69.59,72.71,8,8,0,0,1,58.41,61.27a96,96,0,0,1,135,.79L208,76.69V48a8,8,0,0,1,16,0ZM186.41,183.29a80,80,0,0,1-112.47-.66L59.31,168H88a8,8,0,0,0,0-16H40a8,8,0,0,0-8,8v48a8,8,0,0,0,16,0V179.31l14.63,14.63A95.43,95.43,0,0,0,130,222.06h.53a95.36,95.36,0,0,0,67.07-27.33,8,8,0,0,0-11.18-11.44Z" }, null, -1), X5 = [
  Y5
], Q5 = { key: 5 }, ek = /* @__PURE__ */ w("path", { d: "M220,48V96a4,4,0,0,1-4,4H168a4,4,0,0,1,0-8h38.34L184.89,70.54A84,84,0,0,0,66.8,69.85a4,4,0,1,1-5.6-5.72,92,92,0,0,1,129.34.76L212,86.34V48a4,4,0,0,1,8,0ZM189.2,186.15a83.44,83.44,0,0,1-58.68,23.91h-.47a83.52,83.52,0,0,1-58.94-24.6L49.66,164H88a4,4,0,0,0,0-8H40a4,4,0,0,0-4,4v48a4,4,0,0,0,8,0V169.66l21.46,21.45A91.43,91.43,0,0,0,130,218.06h.51a91.45,91.45,0,0,0,64.28-26.19,4,4,0,1,0-5.6-5.72Z" }, null, -1), tk = [
  ek
], rk = {
  name: "PhArrowsClockwise"
}, ak = /* @__PURE__ */ D({
  ...rk,
  props: {
    weight: {
      type: String
    },
    size: {
      type: [String, Number]
    },
    color: {
      type: String
    },
    mirrored: {
      type: Boolean
    }
  },
  setup(e) {
    const t = e, r = he("weight", "regular"), a = he("size", "1em"), o = he("color", "currentColor"), n = he("mirrored", !1), s = L(() => t.weight ?? r), i = L(() => t.size ?? a), l = L(() => t.color ?? o), c = L(() => t.mirrored !== void 0 ? t.mirrored ? "scale(-1, 1)" : void 0 : n ? "scale(-1, 1)" : void 0);
    return (u, f) => (g(), R("svg", re({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 256 256",
      width: i.value,
      height: i.value,
      fill: l.value,
      transform: c.value
    }, u.$attrs), [
      q(u.$slots, "default"),
      s.value === "bold" ? (g(), R("g", q5, N5)) : s.value === "duotone" ? (g(), R("g", V5, z5)) : s.value === "fill" ? (g(), R("g", j5, Z5)) : s.value === "light" ? (g(), R("g", K5, G5)) : s.value === "regular" ? (g(), R("g", J5, X5)) : s.value === "thin" ? (g(), R("g", Q5, tk)) : $e("", !0)
    ], 16, I5));
  }
}), ok = ["width", "height", "fill", "transform"], nk = { key: 0 }, sk = /* @__PURE__ */ w("path", { d: "M223.65,29.53a20,20,0,0,0-21.79,4.34c-.2.2-.39.4-.57.61l-15,17.3a115.34,115.34,0,0,0-116.5,0l-15-17.3c-.18-.21-.37-.41-.57-.61A20,20,0,0,0,20,48v88c0,55.14,48.45,100,108,100s108-44.86,108-100V48A20,20,0,0,0,223.65,29.53ZM212,136c0,38.22-31.35,69.93-72,75.21V197l12.49-12.49a12,12,0,0,0-17-17L128,175l-7.51-7.52a12,12,0,0,0-17,17L116,197v14.24c-40.65-5.28-72-37-72-75.21V58.74L58.54,75.47a12,12,0,0,0,16.21,1.76A86,86,0,0,1,96,65.74V88a12,12,0,0,0,24,0V60.35q4-.35,8-.35t8,.35V88a12,12,0,0,0,24,0V65.74a86.2,86.2,0,0,1,21.25,11.49,12,12,0,0,0,16.21-1.76L212,58.74Zm-112,4a16,16,0,1,1-16-16A16,16,0,0,1,100,140Zm88,0a16,16,0,1,1-16-16A16,16,0,0,1,188,140Z" }, null, -1), ik = [
  sk
], lk = { key: 1 }, ck = /* @__PURE__ */ w("path", {
  d: "M224,48v88c0,48.6-43,88-96,88s-96-39.4-96-88V48a8,8,0,0,1,13.66-5.66L67.6,67.6h0a102.87,102.87,0,0,1,120.8,0h0l21.94-25.24A8,8,0,0,1,224,48Z",
  opacity: "0.2"
}, null, -1), uk = /* @__PURE__ */ w("path", { d: "M96,140a12,12,0,1,1-12-12A12,12,0,0,1,96,140Zm76-12a12,12,0,1,0,12,12A12,12,0,0,0,172,128Zm60-80v88c0,52.93-46.65,96-104,96S24,188.93,24,136V48A16,16,0,0,1,51.31,36.69c.14.14.26.27.38.41L69,57a111.22,111.22,0,0,1,118.1,0L204.31,37.1c.12-.14.24-.27.38-.41A16,16,0,0,1,232,48Zm-16,0-21.56,24.8A8,8,0,0,1,183.63,74,88.86,88.86,0,0,0,168,64.75V88a8,8,0,1,1-16,0V59.05a97.43,97.43,0,0,0-16-2.72V88a8,8,0,1,1-16,0V56.33a97.43,97.43,0,0,0-16,2.72V88a8,8,0,1,1-16,0V64.75A88.86,88.86,0,0,0,72.37,74a8,8,0,0,1-10.81-1.17L40,48v88c0,41.66,35.21,76,80,79.67V195.31l-13.66-13.66a8,8,0,0,1,11.32-11.31L128,180.68l10.34-10.34a8,8,0,0,1,11.32,11.31L136,195.31v20.36c44.79-3.69,80-38,80-79.67Z" }, null, -1), dk = [
  ck,
  uk
], fk = { key: 2 }, pk = /* @__PURE__ */ w("path", { d: "M222.83,33.54a16,16,0,0,0-18.14,3.15c-.14.14-.26.27-.38.41L187.05,57A111.28,111.28,0,0,0,69,57L51.69,37.1c-.12-.14-.24-.27-.38-.41a16,16,0,0,0-18.14-3.15A16.4,16.4,0,0,0,24,48.46V136c0,49,40.06,89.63,91.56,95.32a4,4,0,0,0,4.44-4v-32l-13.42-13.43a8.22,8.22,0,0,1-.41-11.37,8,8,0,0,1,11.49-.18L128,180.68l10.34-10.35a8,8,0,0,1,11.49.18,8.22,8.22,0,0,1-.41,11.37L136,195.31v32a4,4,0,0,0,4.44,4C191.94,225.62,232,185,232,136V48.46A16.4,16.4,0,0,0,222.83,33.54ZM84,152a12,12,0,1,1,12-12A12,12,0,0,1,84,152Zm20-64a8,8,0,1,1-16,0V69a8,8,0,0,1,16,0Zm32,0a8,8,0,1,1-16,0V64a8,8,0,0,1,16,0Zm16,0V69a8,8,0,0,1,16,0V88a8,8,0,1,1-16,0Zm20,64a12,12,0,1,1,12-12A12,12,0,0,1,172,152Z" }, null, -1), hk = [
  pk
], gk = { key: 3 }, mk = /* @__PURE__ */ w("path", { d: "M221.36,35.07a14,14,0,0,0-15.26,3l-.29.3L187.42,59.58a109.16,109.16,0,0,0-118.84,0L50.19,38.41l-.29-.3A14,14,0,0,0,26,48v88c0,51.83,45.76,94,102,94s102-42.17,102-94V48A14,14,0,0,0,221.36,35.07ZM218,136c0,43.38-37.16,79-84,81.81V194.48l14.24-14.24a6,6,0,0,0-8.48-8.49L128,183.51l-11.76-11.76a6,6,0,0,0-8.48,8.49L122,194.48v23.33C75.16,215,38,179.38,38,136V48a1.91,1.91,0,0,1,1.23-1.85,2.28,2.28,0,0,1,.82-.17,1.87,1.87,0,0,1,1.26.5l21.76,25a6,6,0,0,0,8.11.88A91.52,91.52,0,0,1,90,61.68V88a6,6,0,1,0,12,0V57.51a97.85,97.85,0,0,1,20-3.32V88a6,6,0,1,0,12,0V54.19a97.85,97.85,0,0,1,20,3.32V88a6,6,0,1,0,12,0V61.68a91.52,91.52,0,0,1,18.82,10.73,6,6,0,0,0,8.11-.88l21.76-25A2,2,0,0,1,218,48ZM94,140a10,10,0,1,1-10-10A10,10,0,0,1,94,140Zm88,0a10,10,0,1,1-10-10A10,10,0,0,1,182,140Z" }, null, -1), vk = [
  mk
], bk = { key: 4 }, yk = /* @__PURE__ */ w("path", { d: "M96,140a12,12,0,1,1-12-12A12,12,0,0,1,96,140Zm76-12a12,12,0,1,0,12,12A12,12,0,0,0,172,128Zm60-80v88c0,52.93-46.65,96-104,96S24,188.93,24,136V48A16,16,0,0,1,51.31,36.69c.14.14.26.27.38.41L69,57a111.22,111.22,0,0,1,118.1,0L204.31,37.1c.12-.14.24-.27.38-.41A16,16,0,0,1,232,48Zm-16,0-21.56,24.8A8,8,0,0,1,183.63,74,88.86,88.86,0,0,0,168,64.75V88a8,8,0,1,1-16,0V59.05a97.43,97.43,0,0,0-16-2.72V88a8,8,0,1,1-16,0V56.33a97.43,97.43,0,0,0-16,2.72V88a8,8,0,1,1-16,0V64.75A88.86,88.86,0,0,0,72.37,74a8,8,0,0,1-10.81-1.17L40,48v88c0,41.66,35.21,76,80,79.67V195.31l-13.66-13.66a8,8,0,0,1,11.32-11.31L128,180.68l10.34-10.34a8,8,0,0,1,11.32,11.31L136,195.31v20.36c44.79-3.69,80-38,80-79.67Z" }, null, -1), wk = [
  yk
], xk = { key: 5 }, _k = /* @__PURE__ */ w("path", { d: "M220.59,36.94a11.83,11.83,0,0,0-13.08,2.61l-.19.2L187.77,62.24a107.1,107.1,0,0,0-119.54,0L48.68,39.75l-.19-.2A12,12,0,0,0,28,48v88c0,50.72,44.86,92,100,92s100-41.27,100-92V48A11.82,11.82,0,0,0,220.59,36.94ZM220,136c0,45.09-39.12,82-88,83.91V193.66l14.83-14.83a4,4,0,1,0-5.66-5.65L128,186.35l-13.17-13.17a4,4,0,1,0-5.66,5.65L124,193.66v26.26C75.12,218,36,181.1,36,136V48a3.93,3.93,0,0,1,2.47-3.7,4.39,4.39,0,0,1,1.6-.31,3.77,3.77,0,0,1,2.67,1.1L64.58,70.23a4,4,0,0,0,5.4.59A94,94,0,0,1,92,58.74V88a4,4,0,0,0,8,0V56a100.07,100.07,0,0,1,24-3.93V88a4,4,0,0,0,8,0V52.09A100.07,100.07,0,0,1,156,56V88a4,4,0,0,0,8,0V58.74a94,94,0,0,1,22,12.08,4,4,0,0,0,5.4-.59l21.84-25.11A4,4,0,0,1,220,48ZM92,140a8,8,0,1,1-8-8A8,8,0,0,1,92,140Zm88,0a8,8,0,1,1-8-8A8,8,0,0,1,180,140Z" }, null, -1), kk = [
  _k
], Ck = {
  name: "PhCat"
}, Ak = /* @__PURE__ */ D({
  ...Ck,
  props: {
    weight: {
      type: String
    },
    size: {
      type: [String, Number]
    },
    color: {
      type: String
    },
    mirrored: {
      type: Boolean
    }
  },
  setup(e) {
    const t = e, r = he("weight", "regular"), a = he("size", "1em"), o = he("color", "currentColor"), n = he("mirrored", !1), s = L(() => t.weight ?? r), i = L(() => t.size ?? a), l = L(() => t.color ?? o), c = L(() => t.mirrored !== void 0 ? t.mirrored ? "scale(-1, 1)" : void 0 : n ? "scale(-1, 1)" : void 0);
    return (u, f) => (g(), R("svg", re({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 256 256",
      width: i.value,
      height: i.value,
      fill: l.value,
      transform: c.value
    }, u.$attrs), [
      q(u.$slots, "default"),
      s.value === "bold" ? (g(), R("g", nk, ik)) : s.value === "duotone" ? (g(), R("g", lk, dk)) : s.value === "fill" ? (g(), R("g", fk, hk)) : s.value === "light" ? (g(), R("g", gk, vk)) : s.value === "regular" ? (g(), R("g", bk, wk)) : s.value === "thin" ? (g(), R("g", xk, kk)) : $e("", !0)
    ], 16, ok));
  }
}), Sk = ["width", "height", "fill", "transform"], Ek = { key: 0 }, $k = /* @__PURE__ */ w("path", { d: "M231.49,217.38a12,12,0,0,1-16.89-1.9C213.19,213.72,180,171.24,180,88A52,52,0,1,0,76,88c0,83.24-33.21,125.72-34.62,127.48A12,12,0,0,1,22.6,200.53C23,200,52,162.06,52,88a76,76,0,1,1,152,0c0,74.19,29.1,112.16,29.4,112.54A12,12,0,0,1,231.49,217.38ZM104,120a16,16,0,1,0-16-16A16,16,0,0,0,104,120Zm64-16a16,16,0,1,0-16,16A16,16,0,0,0,168,104ZM95.26,155l28,12a12,12,0,0,0,9.45,0l28-12A12,12,0,0,0,151.26,133l-23.27,10-23.27-10A12,12,0,0,0,95.26,155ZM128,184a57.12,57.12,0,0,0-38.66,15.15,12,12,0,0,0,16.23,17.69,32.86,32.86,0,0,1,44.85,0,12,12,0,1,0,16.23-17.69A57.1,57.1,0,0,0,128,184Z" }, null, -1), Pk = [
  $k
], Tk = { key: 1 }, Mk = /* @__PURE__ */ w("path", {
  d: "M224,208H168c-8-14.35-22.91-24-40-24s-32,9.65-40,24H32S64,168,64,88a64,64,0,0,1,128,0C192,168,224,208,224,208Z",
  opacity: "0.2"
}, null, -1), Rk = /* @__PURE__ */ w("path", { d: "M229,214.25A8,8,0,0,1,217.76,213C216.39,211.27,184,169.86,184,88A56,56,0,0,0,72,88c0,81.86-32.37,123.27-33.75,125a8,8,0,0,1-12.51-10c.15-.2,7.69-9.9,15.13-28.74C47.77,156.8,56,127.64,56,88a72,72,0,0,1,144,0c0,39.64,8.23,68.8,15.13,86.28,7.48,18.94,15.06,28.64,15.14,28.74A8,8,0,0,1,229,214.25ZM100,88a12,12,0,1,0,12,12A12,12,0,0,0,100,88Zm68,12a12,12,0,1,0-12,12A12,12,0,0,0,168,100ZM99.58,128.84a8,8,0,0,0-7.15,14.31l32,16a7.94,7.94,0,0,0,7.15,0l32-16a8,8,0,0,0-7.16-14.31L128,143.05ZM128,176a54.07,54.07,0,0,0-47,28.11,8,8,0,1,0,14,7.78,37.35,37.35,0,0,1,66,0,8,8,0,0,0,14-7.78A54.07,54.07,0,0,0,128,176Z" }, null, -1), Ok = [
  Mk,
  Rk
], Bk = { key: 2 }, Dk = /* @__PURE__ */ w("path", { d: "M161.22,209.74a4,4,0,0,1-3.31,6.26H98.1a4,4,0,0,1-3.31-6.26,40,40,0,0,1,66.43,0Zm68.93,3.37a8.29,8.29,0,0,1-6.43,2.89H184.56a4,4,0,0,1-3.76-2.65,56,56,0,0,0-105.59,0A4,4,0,0,1,71.45,216H32.23a8.2,8.2,0,0,1-6.42-2.93A8,8,0,0,1,25.75,203c.06-.07,7.64-9.78,15.12-28.72C47.77,156.8,56,127.64,56,88a72,72,0,0,1,144,0c0,39.64,8.23,68.8,15.13,86.28,7.48,18.94,15.06,28.65,15.13,28.74A8,8,0,0,1,230.15,213.11ZM88,100a12,12,0,1,0,12-12A12,12,0,0,0,88,100Zm79.16,32.42a8,8,0,0,0-10.73-3.58L128,143.06,99.58,128.84a8,8,0,0,0-7.15,14.32l32,16a8,8,0,0,0,7.15,0l32-16A8,8,0,0,0,167.16,132.42ZM168,100a12,12,0,1,0-12,12A12,12,0,0,0,168,100Z" }, null, -1), Ik = [
  Dk
], qk = { key: 3 }, Lk = /* @__PURE__ */ w("path", { d: "M227.74,212.69a6,6,0,0,1-8.42-.94C218,210.05,186,169.17,186,88A58,58,0,0,0,70,88c0,81.17-31.95,122.05-33.31,123.75a6,6,0,0,1-9.38-7.49C27.68,203.79,58,164.56,58,88a70,70,0,0,1,140,0c0,76.63,30.38,115.87,30.69,116.26A6,6,0,0,1,227.74,212.69ZM100,90a10,10,0,1,0,10,10A10,10,0,0,0,100,90Zm66,10a10,10,0,1,0-10,10A10,10,0,0,0,166,100ZM98.69,130.63a6,6,0,0,0-5.37,10.74l32,16A6,6,0,0,0,128,158a6.07,6.07,0,0,0,2.69-.63l32-16a6,6,0,0,0-5.37-10.74L128,145.29ZM128,178a52.07,52.07,0,0,0-45.24,27.08,6,6,0,0,0,10.49,5.84,39.33,39.33,0,0,1,69.51,0A6,6,0,0,0,168,214a5.89,5.89,0,0,0,2.91-.76,6,6,0,0,0,2.33-8.16A52.09,52.09,0,0,0,128,178Z" }, null, -1), Nk = [
  Lk
], Vk = { key: 4 }, Hk = /* @__PURE__ */ w("path", { d: "M229,214.25A8,8,0,0,1,217.76,213C216.39,211.27,184,169.86,184,88A56,56,0,0,0,72,88c0,81.86-32.37,123.27-33.75,125a8,8,0,0,1-12.51-10c.15-.2,7.69-9.9,15.13-28.74C47.77,156.8,56,127.64,56,88a72,72,0,0,1,144,0c0,39.64,8.23,68.8,15.13,86.28,7.48,18.94,15.06,28.64,15.14,28.74A8,8,0,0,1,229,214.25ZM100,88a12,12,0,1,0,12,12A12,12,0,0,0,100,88Zm68,12a12,12,0,1,0-12,12A12,12,0,0,0,168,100ZM99.58,128.84a8,8,0,0,0-7.15,14.31l32,16a7.94,7.94,0,0,0,7.15,0l32-16a8,8,0,0,0-7.16-14.31L128,143.05ZM128,176a54.07,54.07,0,0,0-47,28.11,8,8,0,1,0,14,7.78,37.35,37.35,0,0,1,66,0,8,8,0,0,0,14-7.78A54.07,54.07,0,0,0,128,176Z" }, null, -1), Fk = [
  Hk
], zk = { key: 5 }, jk = /* @__PURE__ */ w("path", { d: "M226.49,211.12a4,4,0,0,1-5.61-.62C219.54,208.82,188,168.48,188,88A60,60,0,0,0,68,88c0,80.48-31.53,120.82-32.88,122.5a4,4,0,0,1-6.25-5C29.18,205.11,60,165.45,60,88a68,68,0,0,1,136,0c0,40.48,8.47,70.27,15.57,88.14,7.69,19.35,15.48,29.27,15.56,29.36A4,4,0,0,1,226.49,211.12ZM100,92a8,8,0,1,0,8,8A8,8,0,0,0,100,92Zm64,8a8,8,0,1,0-8,8A8,8,0,0,0,164,100ZM97.79,132.42a4,4,0,1,0-3.58,7.16l32,16a4,4,0,0,0,3.58,0l32-16a4,4,0,0,0-3.58-7.16L128,147.53ZM128,180a50.05,50.05,0,0,0-43.49,26.05,4,4,0,1,0,7,3.89,41.34,41.34,0,0,1,73,0A4,4,0,0,0,168,212a3.94,3.94,0,0,0,1.94-.51,4,4,0,0,0,1.55-5.44A50.07,50.07,0,0,0,128,180Z" }, null, -1), Uk = [
  jk
], Zk = {
  name: "PhLinuxLogo"
}, Kk = /* @__PURE__ */ D({
  ...Zk,
  props: {
    weight: {
      type: String
    },
    size: {
      type: [String, Number]
    },
    color: {
      type: String
    },
    mirrored: {
      type: Boolean
    }
  },
  setup(e) {
    const t = e, r = he("weight", "regular"), a = he("size", "1em"), o = he("color", "currentColor"), n = he("mirrored", !1), s = L(() => t.weight ?? r), i = L(() => t.size ?? a), l = L(() => t.color ?? o), c = L(() => t.mirrored !== void 0 ? t.mirrored ? "scale(-1, 1)" : void 0 : n ? "scale(-1, 1)" : void 0);
    return (u, f) => (g(), R("svg", re({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 256 256",
      width: i.value,
      height: i.value,
      fill: l.value,
      transform: c.value
    }, u.$attrs), [
      q(u.$slots, "default"),
      s.value === "bold" ? (g(), R("g", Ek, Pk)) : s.value === "duotone" ? (g(), R("g", Tk, Ok)) : s.value === "fill" ? (g(), R("g", Bk, Ik)) : s.value === "light" ? (g(), R("g", qk, Nk)) : s.value === "regular" ? (g(), R("g", Vk, Fk)) : s.value === "thin" ? (g(), R("g", zk, Uk)) : $e("", !0)
    ], 16, Sk));
  }
}), Wk = ["width", "height", "fill", "transform"], Gk = { key: 0 }, Jk = /* @__PURE__ */ w("path", { d: "M232,108H140V92h4a20,20,0,0,0,20-20V40a20,20,0,0,0-20-20H112A20,20,0,0,0,92,40V72a20,20,0,0,0,20,20h4v16H24a12,12,0,0,0,0,24H52v24H48a20,20,0,0,0-20,20v32a20,20,0,0,0,20,20H80a20,20,0,0,0,20-20V176a20,20,0,0,0-20-20H76V132H180v24h-4a20,20,0,0,0-20,20v32a20,20,0,0,0,20,20h32a20,20,0,0,0,20-20V176a20,20,0,0,0-20-20h-4V132h28a12,12,0,0,0,0-24ZM116,44h24V68H116ZM76,204H52V180H76Zm128,0H180V180h24Z" }, null, -1), Yk = [
  Jk
], Xk = { key: 1 }, Qk = /* @__PURE__ */ w("path", {
  d: "M152,40V72a8,8,0,0,1-8,8H112a8,8,0,0,1-8-8V40a8,8,0,0,1,8-8h32A8,8,0,0,1,152,40ZM80,168H48a8,8,0,0,0-8,8v32a8,8,0,0,0,8,8H80a8,8,0,0,0,8-8V176A8,8,0,0,0,80,168Zm128,0H176a8,8,0,0,0-8,8v32a8,8,0,0,0,8,8h32a8,8,0,0,0,8-8V176A8,8,0,0,0,208,168Z",
  opacity: "0.2"
}, null, -1), eC = /* @__PURE__ */ w("path", { d: "M232,112H136V88h8a16,16,0,0,0,16-16V40a16,16,0,0,0-16-16H112A16,16,0,0,0,96,40V72a16,16,0,0,0,16,16h8v24H24a8,8,0,0,0,0,16H56v32H48a16,16,0,0,0-16,16v32a16,16,0,0,0,16,16H80a16,16,0,0,0,16-16V176a16,16,0,0,0-16-16H72V128H184v32h-8a16,16,0,0,0-16,16v32a16,16,0,0,0,16,16h32a16,16,0,0,0,16-16V176a16,16,0,0,0-16-16h-8V128h32a8,8,0,0,0,0-16ZM112,40h32V72H112ZM80,208H48V176H80Zm128,0H176V176h32Z" }, null, -1), tC = [
  Qk,
  eC
], rC = { key: 2 }, aC = /* @__PURE__ */ w("path", { d: "M240,120a8,8,0,0,1-8,8H200v32h8a16,16,0,0,1,16,16v32a16,16,0,0,1-16,16H176a16,16,0,0,1-16-16V176a16,16,0,0,1,16-16h8V128H72v32h8a16,16,0,0,1,16,16v32a16,16,0,0,1-16,16H48a16,16,0,0,1-16-16V176a16,16,0,0,1,16-16h8V128H24a8,8,0,0,1,0-16h96V88h-8A16,16,0,0,1,96,72V40a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V72a16,16,0,0,1-16,16h-8v24h96A8,8,0,0,1,240,120Z" }, null, -1), oC = [
  aC
], nC = { key: 3 }, sC = /* @__PURE__ */ w("path", { d: "M232,114H134V86h10a14,14,0,0,0,14-14V40a14,14,0,0,0-14-14H112A14,14,0,0,0,98,40V72a14,14,0,0,0,14,14h10v28H24a6,6,0,0,0,0,12H58v36H48a14,14,0,0,0-14,14v32a14,14,0,0,0,14,14H80a14,14,0,0,0,14-14V176a14,14,0,0,0-14-14H70V126H186v36H176a14,14,0,0,0-14,14v32a14,14,0,0,0,14,14h32a14,14,0,0,0,14-14V176a14,14,0,0,0-14-14H198V126h34a6,6,0,0,0,0-12ZM110,72V40a2,2,0,0,1,2-2h32a2,2,0,0,1,2,2V72a2,2,0,0,1-2,2H112A2,2,0,0,1,110,72ZM82,176v32a2,2,0,0,1-2,2H48a2,2,0,0,1-2-2V176a2,2,0,0,1,2-2H80A2,2,0,0,1,82,176Zm128,0v32a2,2,0,0,1-2,2H176a2,2,0,0,1-2-2V176a2,2,0,0,1,2-2h32A2,2,0,0,1,210,176Z" }, null, -1), iC = [
  sC
], lC = { key: 4 }, cC = /* @__PURE__ */ w("path", { d: "M232,112H136V88h8a16,16,0,0,0,16-16V40a16,16,0,0,0-16-16H112A16,16,0,0,0,96,40V72a16,16,0,0,0,16,16h8v24H24a8,8,0,0,0,0,16H56v32H48a16,16,0,0,0-16,16v32a16,16,0,0,0,16,16H80a16,16,0,0,0,16-16V176a16,16,0,0,0-16-16H72V128H184v32h-8a16,16,0,0,0-16,16v32a16,16,0,0,0,16,16h32a16,16,0,0,0,16-16V176a16,16,0,0,0-16-16h-8V128h32a8,8,0,0,0,0-16ZM112,40h32V72H112ZM80,208H48V176H80Zm128,0H176V176h32Z" }, null, -1), uC = [
  cC
], dC = { key: 5 }, fC = /* @__PURE__ */ w("path", { d: "M232,116H132V84h12a12,12,0,0,0,12-12V40a12,12,0,0,0-12-12H112a12,12,0,0,0-12,12V72a12,12,0,0,0,12,12h12v32H24a4,4,0,0,0,0,8H60v40H48a12,12,0,0,0-12,12v32a12,12,0,0,0,12,12H80a12,12,0,0,0,12-12V176a12,12,0,0,0-12-12H68V124H188v40H176a12,12,0,0,0-12,12v32a12,12,0,0,0,12,12h32a12,12,0,0,0,12-12V176a12,12,0,0,0-12-12H196V124h36a4,4,0,0,0,0-8ZM108,72V40a4,4,0,0,1,4-4h32a4,4,0,0,1,4,4V72a4,4,0,0,1-4,4H112A4,4,0,0,1,108,72ZM84,176v32a4,4,0,0,1-4,4H48a4,4,0,0,1-4-4V176a4,4,0,0,1,4-4H80A4,4,0,0,1,84,176Zm128,0v32a4,4,0,0,1-4,4H176a4,4,0,0,1-4-4V176a4,4,0,0,1,4-4h32A4,4,0,0,1,212,176Z" }, null, -1), pC = [
  fC
], hC = {
  name: "PhNetwork"
}, gC = /* @__PURE__ */ D({
  ...hC,
  props: {
    weight: {
      type: String
    },
    size: {
      type: [String, Number]
    },
    color: {
      type: String
    },
    mirrored: {
      type: Boolean
    }
  },
  setup(e) {
    const t = e, r = he("weight", "regular"), a = he("size", "1em"), o = he("color", "currentColor"), n = he("mirrored", !1), s = L(() => t.weight ?? r), i = L(() => t.size ?? a), l = L(() => t.color ?? o), c = L(() => t.mirrored !== void 0 ? t.mirrored ? "scale(-1, 1)" : void 0 : n ? "scale(-1, 1)" : void 0);
    return (u, f) => (g(), R("svg", re({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 256 256",
      width: i.value,
      height: i.value,
      fill: l.value,
      transform: c.value
    }, u.$attrs), [
      q(u.$slots, "default"),
      s.value === "bold" ? (g(), R("g", Gk, Yk)) : s.value === "duotone" ? (g(), R("g", Xk, tC)) : s.value === "fill" ? (g(), R("g", rC, oC)) : s.value === "light" ? (g(), R("g", nC, iC)) : s.value === "regular" ? (g(), R("g", lC, uC)) : s.value === "thin" ? (g(), R("g", dC, pC)) : $e("", !0)
    ], 16, Wk));
  }
}), mC = ["width", "height", "fill", "transform"], vC = { key: 0 }, bC = /* @__PURE__ */ w("path", { d: "M208,28H48A20,20,0,0,0,28,48V208a20,20,0,0,0,20,20H208a20,20,0,0,0,20-20V48A20,20,0,0,0,208,28Zm-4,176H52V52H204ZM88,164h44v12a12,12,0,0,0,24,0V164h4a12,12,0,0,0,0-24h-4V80a12,12,0,0,0-21.47-7.37l-56,72A12,12,0,0,0,88,164Zm44-49v25H112.54Z" }, null, -1), yC = [
  bC
], wC = { key: 1 }, xC = /* @__PURE__ */ w("path", {
  d: "M216,48V208a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V48a8,8,0,0,1,8-8H208A8,8,0,0,1,216,48Z",
  opacity: "0.2"
}, null, -1), _C = /* @__PURE__ */ w("path", { d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm0,176H48V48H208V208Zm-48-64h-8V80a8,8,0,0,0-14.31-4.91l-56,72A8,8,0,0,0,88,160h48v16a8,8,0,0,0,16,0V160h8a8,8,0,0,0,0-16Zm-24,0H104.36L136,103.32Z" }, null, -1), kC = [
  xC,
  _C
], CC = { key: 2 }, AC = /* @__PURE__ */ w("path", { d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM160,160h-8v16a8,8,0,0,1-16,0V160H88a8,8,0,0,1-6.31-12.91l56-72A8,8,0,0,1,152,80v64h8a8,8,0,0,1,0,16Zm-55.64-16L136,103.32V144Z" }, null, -1), SC = [
  AC
], EC = { key: 3 }, $C = /* @__PURE__ */ w("path", { d: "M208,34H48A14,14,0,0,0,34,48V208a14,14,0,0,0,14,14H208a14,14,0,0,0,14-14V48A14,14,0,0,0,208,34Zm2,174a2,2,0,0,1-2,2H48a2,2,0,0,1-2-2V48a2,2,0,0,1,2-2H208a2,2,0,0,1,2,2Zm-50-62H150V80a6,6,0,0,0-10.74-3.68l-56,72A6,6,0,0,0,88,158h50v18a6,6,0,0,0,12,0V158h10a6,6,0,0,0,0-12Zm-22,0H100.27L138,97.49Z" }, null, -1), PC = [
  $C
], TC = { key: 4 }, MC = /* @__PURE__ */ w("path", { d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm0,176H48V48H208V208Zm-48-64h-8V80a8,8,0,0,0-14.31-4.91l-56,72A8,8,0,0,0,88,160h48v16a8,8,0,0,0,16,0V160h8a8,8,0,0,0,0-16Zm-24,0H104.36L136,103.32Z" }, null, -1), RC = [
  MC
], OC = { key: 5 }, BC = /* @__PURE__ */ w("path", { d: "M208,36H48A12,12,0,0,0,36,48V208a12,12,0,0,0,12,12H208a12,12,0,0,0,12-12V48A12,12,0,0,0,208,36Zm4,172a4,4,0,0,1-4,4H48a4,4,0,0,1-4-4V48a4,4,0,0,1,4-4H208a4,4,0,0,1,4,4Zm-52-60H148V80a4,4,0,0,0-7.16-2.46l-56,72A4,4,0,0,0,88,156h52v20a4,4,0,0,0,8,0V156h12a4,4,0,0,0,0-8Zm-20,0H96.18L140,91.66Z" }, null, -1), DC = [
  BC
], IC = {
  name: "PhNumberSquareFour"
}, qC = /* @__PURE__ */ D({
  ...IC,
  props: {
    weight: {
      type: String
    },
    size: {
      type: [String, Number]
    },
    color: {
      type: String
    },
    mirrored: {
      type: Boolean
    }
  },
  setup(e) {
    const t = e, r = he("weight", "regular"), a = he("size", "1em"), o = he("color", "currentColor"), n = he("mirrored", !1), s = L(() => t.weight ?? r), i = L(() => t.size ?? a), l = L(() => t.color ?? o), c = L(() => t.mirrored !== void 0 ? t.mirrored ? "scale(-1, 1)" : void 0 : n ? "scale(-1, 1)" : void 0);
    return (u, f) => (g(), R("svg", re({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 256 256",
      width: i.value,
      height: i.value,
      fill: l.value,
      transform: c.value
    }, u.$attrs), [
      q(u.$slots, "default"),
      s.value === "bold" ? (g(), R("g", vC, yC)) : s.value === "duotone" ? (g(), R("g", wC, kC)) : s.value === "fill" ? (g(), R("g", CC, SC)) : s.value === "light" ? (g(), R("g", EC, PC)) : s.value === "regular" ? (g(), R("g", TC, RC)) : s.value === "thin" ? (g(), R("g", OC, DC)) : $e("", !0)
    ], 16, mC));
  }
}), LC = ["width", "height", "fill", "transform"], NC = { key: 0 }, VC = /* @__PURE__ */ w("path", { d: "M208,28H48A20,20,0,0,0,28,48V208a20,20,0,0,0,20,20H208a20,20,0,0,0,20-20V48A20,20,0,0,0,208,28Zm-4,176H52V52H204ZM98,102.66A12,12,0,0,1,101.34,86l24-16A12,12,0,0,1,144,80v96a12,12,0,0,1-24,0V102.42L114.66,106A12,12,0,0,1,98,102.66Z" }, null, -1), HC = [
  VC
], FC = { key: 1 }, zC = /* @__PURE__ */ w("path", {
  d: "M216,48V208a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V48a8,8,0,0,1,8-8H208A8,8,0,0,1,216,48Z",
  opacity: "0.2"
}, null, -1), jC = /* @__PURE__ */ w("path", { d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm0,176H48V48H208V208ZM140,80v96a8,8,0,0,1-16,0V95l-11.56,7.71a8,8,0,1,1-8.88-13.32l24-16A8,8,0,0,1,140,80Z" }, null, -1), UC = [
  zC,
  jC
], ZC = { key: 2 }, KC = /* @__PURE__ */ w("path", { d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM140,176a8,8,0,0,1-16,0V95l-11.56,7.71a8,8,0,1,1-8.88-13.32l24-16A8,8,0,0,1,140,80Z" }, null, -1), WC = [
  KC
], GC = { key: 3 }, JC = /* @__PURE__ */ w("path", { d: "M208,34H48A14,14,0,0,0,34,48V208a14,14,0,0,0,14,14H208a14,14,0,0,0,14-14V48A14,14,0,0,0,208,34Zm2,174a2,2,0,0,1-2,2H48a2,2,0,0,1-2-2V48a2,2,0,0,1,2-2H208a2,2,0,0,1,2,2ZM138,80v96a6,6,0,0,1-12,0V91.21L111.33,101a6,6,0,0,1-6.66-10l24-16A6,6,0,0,1,138,80Z" }, null, -1), YC = [
  JC
], XC = { key: 4 }, QC = /* @__PURE__ */ w("path", { d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm0,176H48V48H208V208ZM140,80v96a8,8,0,0,1-16,0V95l-11.56,7.71a8,8,0,1,1-8.88-13.32l24-16A8,8,0,0,1,140,80Z" }, null, -1), eA = [
  QC
], tA = { key: 5 }, rA = /* @__PURE__ */ w("path", { d: "M208,36H48A12,12,0,0,0,36,48V208a12,12,0,0,0,12,12H208a12,12,0,0,0,12-12V48A12,12,0,0,0,208,36Zm4,172a4,4,0,0,1-4,4H48a4,4,0,0,1-4-4V48a4,4,0,0,1,4-4H208a4,4,0,0,1,4,4ZM136,80v96a4,4,0,0,1-8,0V87.47L110.22,99.33a4,4,0,1,1-4.44-6.66l24-16A4,4,0,0,1,136,80Z" }, null, -1), aA = [
  rA
], oA = {
  name: "PhNumberSquareOne"
}, nA = /* @__PURE__ */ D({
  ...oA,
  props: {
    weight: {
      type: String
    },
    size: {
      type: [String, Number]
    },
    color: {
      type: String
    },
    mirrored: {
      type: Boolean
    }
  },
  setup(e) {
    const t = e, r = he("weight", "regular"), a = he("size", "1em"), o = he("color", "currentColor"), n = he("mirrored", !1), s = L(() => t.weight ?? r), i = L(() => t.size ?? a), l = L(() => t.color ?? o), c = L(() => t.mirrored !== void 0 ? t.mirrored ? "scale(-1, 1)" : void 0 : n ? "scale(-1, 1)" : void 0);
    return (u, f) => (g(), R("svg", re({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 256 256",
      width: i.value,
      height: i.value,
      fill: l.value,
      transform: c.value
    }, u.$attrs), [
      q(u.$slots, "default"),
      s.value === "bold" ? (g(), R("g", NC, HC)) : s.value === "duotone" ? (g(), R("g", FC, UC)) : s.value === "fill" ? (g(), R("g", ZC, WC)) : s.value === "light" ? (g(), R("g", GC, YC)) : s.value === "regular" ? (g(), R("g", XC, eA)) : s.value === "thin" ? (g(), R("g", tA, aA)) : $e("", !0)
    ], 16, LC));
  }
}), sA = ["width", "height", "fill", "transform"], iA = { key: 0 }, lA = /* @__PURE__ */ w("path", { d: "M208,28H48A20,20,0,0,0,28,48V208a20,20,0,0,0,20,20H208a20,20,0,0,0,20-20V48A20,20,0,0,0,208,28Zm-4,176H52V52H204ZM92,80a12,12,0,0,1,12-12h48a12,12,0,0,1,9.83,18.88l-18.34,26.2A40,40,0,1,1,95.43,176a12,12,0,1,1,17.14-16.79A16,16,0,1,0,124,132a12,12,0,0,1-9.83-18.88L129,92H104A12,12,0,0,1,92,80Z" }, null, -1), cA = [
  lA
], uA = { key: 1 }, dA = /* @__PURE__ */ w("path", {
  d: "M216,48V208a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V48a8,8,0,0,1,8-8H208A8,8,0,0,1,216,48Z",
  opacity: "0.2"
}, null, -1), fA = /* @__PURE__ */ w("path", { d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm0,176H48V48H208V208Zm-48-60a36,36,0,0,1-61.71,25.19A8,8,0,1,1,109.71,162,20,20,0,1,0,124,128a8,8,0,0,1-6.55-12.59L136.63,88H104a8,8,0,0,1,0-16h48a8,8,0,0,1,6.55,12.59l-21,30A36.07,36.07,0,0,1,160,148Z" }, null, -1), pA = [
  dA,
  fA
], hA = { key: 2 }, gA = /* @__PURE__ */ w("path", { d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM124,184a35.71,35.71,0,0,1-25.71-10.81A8,8,0,1,1,109.71,162,20,20,0,1,0,124,128a8,8,0,0,1-6.55-12.59L136.63,88H104a8,8,0,0,1,0-16h48a8,8,0,0,1,6.55,12.59l-21,30A36,36,0,0,1,124,184Z" }, null, -1), mA = [
  gA
], vA = { key: 3 }, bA = /* @__PURE__ */ w("path", { d: "M208,34H48A14,14,0,0,0,34,48V208a14,14,0,0,0,14,14H208a14,14,0,0,0,14-14V48A14,14,0,0,0,208,34Zm2,174a2,2,0,0,1-2,2H48a2,2,0,0,1-2-2V48a2,2,0,0,1,2-2H208a2,2,0,0,1,2,2Zm-52-60a34,34,0,0,1-58.29,23.79,6,6,0,0,1,8.58-8.39A22,22,0,1,0,124,126a6,6,0,0,1-4.92-9.44L140.48,86H104a6,6,0,0,1,0-12h48a6,6,0,0,1,4.92,9.44l-22.53,32.18A34.06,34.06,0,0,1,158,148Z" }, null, -1), yA = [
  bA
], wA = { key: 4 }, xA = /* @__PURE__ */ w("path", { d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm0,176H48V48H208V208Zm-48-60a36,36,0,0,1-61.71,25.19A8,8,0,1,1,109.71,162,20,20,0,1,0,124,128a8,8,0,0,1-6.55-12.59L136.63,88H104a8,8,0,0,1,0-16h48a8,8,0,0,1,6.55,12.59l-21,30A36.07,36.07,0,0,1,160,148Z" }, null, -1), _A = [
  xA
], kA = { key: 5 }, CA = /* @__PURE__ */ w("path", { d: "M208,36H48A12,12,0,0,0,36,48V208a12,12,0,0,0,12,12H208a12,12,0,0,0,12-12V48A12,12,0,0,0,208,36Zm4,172a4,4,0,0,1-4,4H48a4,4,0,0,1-4-4V48a4,4,0,0,1,4-4H208a4,4,0,0,1,4,4Zm-56-60a32,32,0,0,1-54.86,22.4,4,4,0,1,1,5.72-5.6A24,24,0,1,0,124,124a4,4,0,0,1-3.28-6.29L144.32,84H104a4,4,0,0,1,0-8h48a4,4,0,0,1,3.28,6.29L131.12,116.8A32.06,32.06,0,0,1,156,148Z" }, null, -1), AA = [
  CA
], SA = {
  name: "PhNumberSquareThree"
}, EA = /* @__PURE__ */ D({
  ...SA,
  props: {
    weight: {
      type: String
    },
    size: {
      type: [String, Number]
    },
    color: {
      type: String
    },
    mirrored: {
      type: Boolean
    }
  },
  setup(e) {
    const t = e, r = he("weight", "regular"), a = he("size", "1em"), o = he("color", "currentColor"), n = he("mirrored", !1), s = L(() => t.weight ?? r), i = L(() => t.size ?? a), l = L(() => t.color ?? o), c = L(() => t.mirrored !== void 0 ? t.mirrored ? "scale(-1, 1)" : void 0 : n ? "scale(-1, 1)" : void 0);
    return (u, f) => (g(), R("svg", re({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 256 256",
      width: i.value,
      height: i.value,
      fill: l.value,
      transform: c.value
    }, u.$attrs), [
      q(u.$slots, "default"),
      s.value === "bold" ? (g(), R("g", iA, cA)) : s.value === "duotone" ? (g(), R("g", uA, pA)) : s.value === "fill" ? (g(), R("g", hA, mA)) : s.value === "light" ? (g(), R("g", vA, yA)) : s.value === "regular" ? (g(), R("g", wA, _A)) : s.value === "thin" ? (g(), R("g", kA, AA)) : $e("", !0)
    ], 16, sA));
  }
}), $A = ["width", "height", "fill", "transform"], PA = { key: 0 }, TA = /* @__PURE__ */ w("path", { d: "M208,28H48A20,20,0,0,0,28,48V208a20,20,0,0,0,20,20H208a20,20,0,0,0,20-20V48A20,20,0,0,0,208,28Zm-4,176H52V52H204Zm-66.43-92.76a12,12,0,0,0-2.35-16.82,12,12,0,0,0-16.8,2.36,11.7,11.7,0,0,0-1.74,3.22,12,12,0,0,1-22.63-8,36.45,36.45,0,0,1,5.2-9.67,36,36,0,0,1,57.5,43.34L128,164h24a12,12,0,0,1,0,24H104a12,12,0,0,1-9.6-19.2Z" }, null, -1), MA = [
  TA
], RA = { key: 1 }, OA = /* @__PURE__ */ w("path", {
  d: "M216,48V208a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V48a8,8,0,0,1,8-8H208A8,8,0,0,1,216,48Z",
  opacity: "0.2"
}, null, -1), BA = /* @__PURE__ */ w("path", { d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm0,176H48V48H208V208Zm-48-32a8,8,0,0,1-8,8H104a8,8,0,0,1-6.4-12.8l43.17-57.56a16,16,0,1,0-27.86-15,8,8,0,0,1-15.09-5.34,32.43,32.43,0,0,1,4.62-8.59,32,32,0,1,1,51.11,38.52L120,168h32A8,8,0,0,1,160,176Z" }, null, -1), DA = [
  OA,
  BA
], IA = { key: 2 }, qA = /* @__PURE__ */ w("path", { d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM152,168a8,8,0,0,1,0,16H104a8,8,0,0,1-6.4-12.8l43.17-57.56a16,16,0,1,0-27.86-15,8,8,0,0,1-15.09-5.34,32,32,0,1,1,55.74,29.93L120,168Z" }, null, -1), LA = [
  qA
], NA = { key: 3 }, VA = /* @__PURE__ */ w("path", { d: "M208,34H48A14,14,0,0,0,34,48V208a14,14,0,0,0,14,14H208a14,14,0,0,0,14-14V48A14,14,0,0,0,208,34Zm2,174a2,2,0,0,1-2,2H48a2,2,0,0,1-2-2V48a2,2,0,0,1,2-2H208a2,2,0,0,1,2,2Zm-52-32a6,6,0,0,1-6,6H104a6,6,0,0,1-4.8-9.6l43.17-57.56A18,18,0,1,0,111,98a6,6,0,1,1-11.31-4A30,30,0,1,1,152,122.06L116,170h36A6,6,0,0,1,158,176Z" }, null, -1), HA = [
  VA
], FA = { key: 4 }, zA = /* @__PURE__ */ w("path", { d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm0,176H48V48H208V208Zm-48-32a8,8,0,0,1-8,8H104a8,8,0,0,1-6.4-12.8l43.17-57.56a16,16,0,1,0-27.86-15,8,8,0,0,1-15.09-5.34,32.43,32.43,0,0,1,4.62-8.59,32,32,0,1,1,51.11,38.52L120,168h32A8,8,0,0,1,160,176Z" }, null, -1), jA = [
  zA
], UA = { key: 5 }, ZA = /* @__PURE__ */ w("path", { d: "M208,36H48A12,12,0,0,0,36,48V208a12,12,0,0,0,12,12H208a12,12,0,0,0,12-12V48A12,12,0,0,0,208,36Zm4,172a4,4,0,0,1-4,4H48a4,4,0,0,1-4-4V48a4,4,0,0,1,4-4H208a4,4,0,0,1,4,4Zm-56-32a4,4,0,0,1-4,4H104a4,4,0,0,1-3.2-6.4L144,116A20,20,0,0,0,140,88,20,20,0,0,0,112,92a20.23,20.23,0,0,0-2.89,5.37,4,4,0,0,1-7.55-2.66,28.34,28.34,0,0,1,4-7.52,28,28,0,1,1,44.72,33.7L112,172h40A4,4,0,0,1,156,176Z" }, null, -1), KA = [
  ZA
], WA = {
  name: "PhNumberSquareTwo"
}, GA = /* @__PURE__ */ D({
  ...WA,
  props: {
    weight: {
      type: String
    },
    size: {
      type: [String, Number]
    },
    color: {
      type: String
    },
    mirrored: {
      type: Boolean
    }
  },
  setup(e) {
    const t = e, r = he("weight", "regular"), a = he("size", "1em"), o = he("color", "currentColor"), n = he("mirrored", !1), s = L(() => t.weight ?? r), i = L(() => t.size ?? a), l = L(() => t.color ?? o), c = L(() => t.mirrored !== void 0 ? t.mirrored ? "scale(-1, 1)" : void 0 : n ? "scale(-1, 1)" : void 0);
    return (u, f) => (g(), R("svg", re({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 256 256",
      width: i.value,
      height: i.value,
      fill: l.value,
      transform: c.value
    }, u.$attrs), [
      q(u.$slots, "default"),
      s.value === "bold" ? (g(), R("g", PA, MA)) : s.value === "duotone" ? (g(), R("g", RA, DA)) : s.value === "fill" ? (g(), R("g", IA, LA)) : s.value === "light" ? (g(), R("g", NA, HA)) : s.value === "regular" ? (g(), R("g", FA, jA)) : s.value === "thin" ? (g(), R("g", UA, KA)) : $e("", !0)
    ], 16, $A));
  }
}), JA = ["width", "height", "fill", "transform"], YA = { key: 0 }, XA = /* @__PURE__ */ w("path", { d: "M140,32V64a12,12,0,0,1-24,0V32a12,12,0,0,1,24,0Zm33.25,62.75a12,12,0,0,0,8.49-3.52L204.37,68.6a12,12,0,0,0-17-17L164.77,74.26a12,12,0,0,0,8.48,20.49ZM224,116H192a12,12,0,0,0,0,24h32a12,12,0,0,0,0-24Zm-42.26,48.77a12,12,0,1,0-17,17l22.63,22.63a12,12,0,0,0,17-17ZM128,180a12,12,0,0,0-12,12v32a12,12,0,0,0,24,0V192A12,12,0,0,0,128,180ZM74.26,164.77,51.63,187.4a12,12,0,0,0,17,17l22.63-22.63a12,12,0,1,0-17-17ZM76,128a12,12,0,0,0-12-12H32a12,12,0,0,0,0,24H64A12,12,0,0,0,76,128ZM68.6,51.63a12,12,0,1,0-17,17L74.26,91.23a12,12,0,0,0,17-17Z" }, null, -1), QA = [
  XA
], e7 = { key: 1 }, t7 = /* @__PURE__ */ w("path", {
  d: "M224,128a96,96,0,1,1-96-96A96,96,0,0,1,224,128Z",
  opacity: "0.2"
}, null, -1), r7 = /* @__PURE__ */ w("path", { d: "M136,32V64a8,8,0,0,1-16,0V32a8,8,0,0,1,16,0Zm37.25,58.75a8,8,0,0,0,5.66-2.35l22.63-22.62a8,8,0,0,0-11.32-11.32L167.6,77.09a8,8,0,0,0,5.65,13.66ZM224,120H192a8,8,0,0,0,0,16h32a8,8,0,0,0,0-16Zm-45.09,47.6a8,8,0,0,0-11.31,11.31l22.62,22.63a8,8,0,0,0,11.32-11.32ZM128,184a8,8,0,0,0-8,8v32a8,8,0,0,0,16,0V192A8,8,0,0,0,128,184ZM77.09,167.6,54.46,190.22a8,8,0,0,0,11.32,11.32L88.4,178.91A8,8,0,0,0,77.09,167.6ZM72,128a8,8,0,0,0-8-8H32a8,8,0,0,0,0,16H64A8,8,0,0,0,72,128ZM65.78,54.46A8,8,0,0,0,54.46,65.78L77.09,88.4A8,8,0,0,0,88.4,77.09Z" }, null, -1), a7 = [
  t7,
  r7
], o7 = { key: 2 }, n7 = /* @__PURE__ */ w("path", { d: "M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm33.94,58.75,17-17a8,8,0,0,1,11.32,11.32l-17,17a8,8,0,0,1-11.31-11.31ZM48,136a8,8,0,0,1,0-16H72a8,8,0,0,1,0,16Zm46.06,37.25-17,17a8,8,0,0,1-11.32-11.32l17-17a8,8,0,0,1,11.31,11.31Zm0-79.19a8,8,0,0,1-11.31,0l-17-17A8,8,0,0,1,77.09,65.77l17,17A8,8,0,0,1,94.06,94.06ZM136,208a8,8,0,0,1-16,0V184a8,8,0,0,1,16,0Zm0-136a8,8,0,0,1-16,0V48a8,8,0,0,1,16,0Zm54.23,118.23a8,8,0,0,1-11.32,0l-17-17a8,8,0,0,1,11.31-11.31l17,17A8,8,0,0,1,190.23,190.23ZM208,136H184a8,8,0,0,1,0-16h24a8,8,0,0,1,0,16Z" }, null, -1), s7 = [
  n7
], i7 = { key: 3 }, l7 = /* @__PURE__ */ w("path", { d: "M134,32V64a6,6,0,0,1-12,0V32a6,6,0,0,1,12,0Zm39.25,56.75A6,6,0,0,0,177.5,87l22.62-22.63a6,6,0,0,0-8.48-8.48L169,78.5a6,6,0,0,0,4.24,10.25ZM224,122H192a6,6,0,0,0,0,12h32a6,6,0,0,0,0-12Zm-46.5,47A6,6,0,0,0,169,177.5l22.63,22.62a6,6,0,0,0,8.48-8.48ZM128,186a6,6,0,0,0-6,6v32a6,6,0,0,0,12,0V192A6,6,0,0,0,128,186ZM78.5,169,55.88,191.64a6,6,0,1,0,8.48,8.48L87,177.5A6,6,0,1,0,78.5,169ZM70,128a6,6,0,0,0-6-6H32a6,6,0,0,0,0,12H64A6,6,0,0,0,70,128ZM64.36,55.88a6,6,0,0,0-8.48,8.48L78.5,87A6,6,0,1,0,87,78.5Z" }, null, -1), c7 = [
  l7
], u7 = { key: 4 }, d7 = /* @__PURE__ */ w("path", { d: "M136,32V64a8,8,0,0,1-16,0V32a8,8,0,0,1,16,0Zm37.25,58.75a8,8,0,0,0,5.66-2.35l22.63-22.62a8,8,0,0,0-11.32-11.32L167.6,77.09a8,8,0,0,0,5.65,13.66ZM224,120H192a8,8,0,0,0,0,16h32a8,8,0,0,0,0-16Zm-45.09,47.6a8,8,0,0,0-11.31,11.31l22.62,22.63a8,8,0,0,0,11.32-11.32ZM128,184a8,8,0,0,0-8,8v32a8,8,0,0,0,16,0V192A8,8,0,0,0,128,184ZM77.09,167.6,54.46,190.22a8,8,0,0,0,11.32,11.32L88.4,178.91A8,8,0,0,0,77.09,167.6ZM72,128a8,8,0,0,0-8-8H32a8,8,0,0,0,0,16H64A8,8,0,0,0,72,128ZM65.78,54.46A8,8,0,0,0,54.46,65.78L77.09,88.4A8,8,0,0,0,88.4,77.09Z" }, null, -1), f7 = [
  d7
], p7 = { key: 5 }, h7 = /* @__PURE__ */ w("path", { d: "M132,32V64a4,4,0,0,1-8,0V32a4,4,0,0,1,8,0Zm41.25,54.75a4,4,0,0,0,2.83-1.18L198.71,63a4,4,0,0,0-5.66-5.66L170.43,79.92a4,4,0,0,0,2.82,6.83ZM224,124H192a4,4,0,0,0,0,8h32a4,4,0,0,0,0-8Zm-47.92,46.43a4,4,0,1,0-5.65,5.65l22.62,22.63a4,4,0,0,0,5.66-5.66ZM128,188a4,4,0,0,0-4,4v32a4,4,0,0,0,8,0V192A4,4,0,0,0,128,188ZM79.92,170.43,57.29,193.05A4,4,0,0,0,63,198.71l22.62-22.63a4,4,0,1,0-5.65-5.65ZM68,128a4,4,0,0,0-4-4H32a4,4,0,0,0,0,8H64A4,4,0,0,0,68,128ZM63,57.29A4,4,0,0,0,57.29,63L79.92,85.57a4,4,0,1,0,5.65-5.65Z" }, null, -1), g7 = [
  h7
], m7 = {
  name: "PhSpinner"
}, v7 = /* @__PURE__ */ D({
  ...m7,
  props: {
    weight: {
      type: String
    },
    size: {
      type: [String, Number]
    },
    color: {
      type: String
    },
    mirrored: {
      type: Boolean
    }
  },
  setup(e) {
    const t = e, r = he("weight", "regular"), a = he("size", "1em"), o = he("color", "currentColor"), n = he("mirrored", !1), s = L(() => t.weight ?? r), i = L(() => t.size ?? a), l = L(() => t.color ?? o), c = L(() => t.mirrored !== void 0 ? t.mirrored ? "scale(-1, 1)" : void 0 : n ? "scale(-1, 1)" : void 0);
    return (u, f) => (g(), R("svg", re({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 256 256",
      width: i.value,
      height: i.value,
      fill: l.value,
      transform: c.value
    }, u.$attrs), [
      q(u.$slots, "default"),
      s.value === "bold" ? (g(), R("g", YA, QA)) : s.value === "duotone" ? (g(), R("g", e7, a7)) : s.value === "fill" ? (g(), R("g", o7, s7)) : s.value === "light" ? (g(), R("g", i7, c7)) : s.value === "regular" ? (g(), R("g", u7, f7)) : s.value === "thin" ? (g(), R("g", p7, g7)) : $e("", !0)
    ], 16, JA));
  }
}), b7 = ["width", "height", "fill", "transform"], y7 = { key: 0 }, w7 = /* @__PURE__ */ w("path", { d: "M99.69,51.88a12,12,0,0,0-9.84-2.6l-60,10.91A12,12,0,0,0,20,72v36a12,12,0,0,0,12,12H92a12,12,0,0,0,12-12V61.09A12,12,0,0,0,99.69,51.88ZM80,96H44V82l36-6.54ZM215.69,30.79a12,12,0,0,0-9.84-2.6L129.85,42A12,12,0,0,0,120,53.82V108a12,12,0,0,0,12,12h76a12,12,0,0,0,12-12V40A12,12,0,0,0,215.69,30.79ZM196,96H144V63.83l52-9.45ZM92,136H32a12,12,0,0,0-12,12v36a12,12,0,0,0,9.85,11.81l60,10.91A12,12,0,0,0,104,194.91V148A12,12,0,0,0,92,136ZM80,180.53,44,174V160H80ZM208,136H132a12,12,0,0,0-12,12v54.18A12,12,0,0,0,129.85,214l76,13.82A12,12,0,0,0,220,216V148A12,12,0,0,0,208,136Zm-12,65.62-52-9.45V160h52Z" }, null, -1), x7 = [
  w7
], _7 = { key: 1 }, k7 = /* @__PURE__ */ w("path", {
  d: "M128,144h80v72l-80-14.55ZM32,184l64,11.64V144H32ZM128,54.55V112h80V40ZM32,112H96V60.36L32,72Z",
  opacity: "0.2"
}, null, -1), C7 = /* @__PURE__ */ w("path", { d: "M208,136H128a8,8,0,0,0-8,8v57.45a8,8,0,0,0,6.57,7.88l80,14.54A7.61,7.61,0,0,0,208,224a8,8,0,0,0,8-8V144A8,8,0,0,0,208,136Zm-8,70.41-64-11.63V152h64ZM96,136H32a8,8,0,0,0-8,8v40a8,8,0,0,0,6.57,7.87l64,11.64a8.54,8.54,0,0,0,1.43.13,8,8,0,0,0,8-8V144A8,8,0,0,0,96,136Zm-8,50.05-48-8.73V152H88ZM213.13,33.86a8,8,0,0,0-6.56-1.73l-80,14.55A8,8,0,0,0,120,54.55V112a8,8,0,0,0,8,8h80a8,8,0,0,0,8-8V40A8,8,0,0,0,213.13,33.86ZM200,104H136V61.22l64-11.63ZM101.13,54.22a8,8,0,0,0-6.56-1.73l-64,11.64A8,8,0,0,0,24,72v40a8,8,0,0,0,8,8H96a8,8,0,0,0,8-8V60.36A8,8,0,0,0,101.13,54.22ZM88,104H40V78.68L88,70Z" }, null, -1), A7 = [
  k7,
  C7
], S7 = { key: 2 }, E7 = /* @__PURE__ */ w("path", { d: "M104,144v51.64a8,8,0,0,1-8,8,8.54,8.54,0,0,1-1.43-.13l-64-11.64A8,8,0,0,1,24,184V144a8,8,0,0,1,8-8H96A8,8,0,0,1,104,144Zm-2.87-89.78a8,8,0,0,0-6.56-1.73l-64,11.64A8,8,0,0,0,24,72v40a8,8,0,0,0,8,8H96a8,8,0,0,0,8-8V60.36A8,8,0,0,0,101.13,54.22ZM208,136H128a8,8,0,0,0-8,8v57.45a8,8,0,0,0,6.57,7.88l80,14.54A7.61,7.61,0,0,0,208,224a8,8,0,0,0,8-8V144A8,8,0,0,0,208,136Zm5.13-102.14a8,8,0,0,0-6.56-1.73l-80,14.55A8,8,0,0,0,120,54.55V112a8,8,0,0,0,8,8h80a8,8,0,0,0,8-8V40A8,8,0,0,0,213.13,33.86Z" }, null, -1), $7 = [
  E7
], P7 = { key: 3 }, T7 = /* @__PURE__ */ w("path", { d: "M208,138H128a6,6,0,0,0-6,6v57.45a6,6,0,0,0,4.93,5.91l80,14.54a5.46,5.46,0,0,0,1.07.1,6,6,0,0,0,6-6V144A6,6,0,0,0,208,138Zm-6,70.81-68-12.36V150h68ZM96,138H32a6,6,0,0,0-6,6v40a6,6,0,0,0,4.93,5.9l64,11.64a6.36,6.36,0,0,0,1.07.1,6,6,0,0,0,6-6V144A6,6,0,0,0,96,138Zm-6,50.45L38,179V150H90ZM211.84,35.39a6,6,0,0,0-4.91-1.29l-80,14.54A6,6,0,0,0,122,54.55V112a6,6,0,0,0,6,6h80a6,6,0,0,0,6-6V40A6,6,0,0,0,211.84,35.39ZM202,106H134V59.55l68-12.36ZM99.84,55.76a6,6,0,0,0-4.91-1.3l-64,11.64A6,6,0,0,0,26,72v40a6,6,0,0,0,6,6H96a6,6,0,0,0,6-6V60.36A6,6,0,0,0,99.84,55.76ZM90,106H38V77l52-9.46Z" }, null, -1), M7 = [
  T7
], R7 = { key: 4 }, O7 = /* @__PURE__ */ w("path", { d: "M208,136H128a8,8,0,0,0-8,8v57.45a8,8,0,0,0,6.57,7.88l80,14.54A7.61,7.61,0,0,0,208,224a8,8,0,0,0,8-8V144A8,8,0,0,0,208,136Zm-8,70.41-64-11.63V152h64ZM96,136H32a8,8,0,0,0-8,8v40a8,8,0,0,0,6.57,7.87l64,11.64a8.54,8.54,0,0,0,1.43.13,8,8,0,0,0,8-8V144A8,8,0,0,0,96,136Zm-8,50.05-48-8.73V152H88ZM213.13,33.86a8,8,0,0,0-6.56-1.73l-80,14.55A8,8,0,0,0,120,54.55V112a8,8,0,0,0,8,8h80a8,8,0,0,0,8-8V40A8,8,0,0,0,213.13,33.86ZM200,104H136V61.22l64-11.63ZM101.13,54.22a8,8,0,0,0-6.56-1.73l-64,11.64A8,8,0,0,0,24,72v40a8,8,0,0,0,8,8H96a8,8,0,0,0,8-8V60.36A8,8,0,0,0,101.13,54.22ZM88,104H40V78.68L88,70Z" }, null, -1), B7 = [
  O7
], D7 = { key: 5 }, I7 = /* @__PURE__ */ w("path", { d: "M208,140H128a4,4,0,0,0-4,4v57.45a4,4,0,0,0,3.28,3.94l80,14.55a4.37,4.37,0,0,0,.72.06,4,4,0,0,0,2.56-.93A4,4,0,0,0,212,216V144A4,4,0,0,0,208,140Zm-4,71.21-72-13.09V148h72ZM96,140H32a4,4,0,0,0-4,4v40a4,4,0,0,0,3.28,3.94l64,11.63a3.51,3.51,0,0,0,.72.07,4,4,0,0,0,4-4V144A4,4,0,0,0,96,140Zm-4,50.84L36,180.66V148H92ZM210.56,36.93a4,4,0,0,0-3.28-.87l-80,14.55A4,4,0,0,0,124,54.55V112a4,4,0,0,0,4,4h80a4,4,0,0,0,4-4V40A4,4,0,0,0,210.56,36.93ZM204,108H132V57.88l72-13.09ZM95.28,56.43l-64,11.63A4,4,0,0,0,28,72v40a4,4,0,0,0,4,4H96a4,4,0,0,0,4-4V60.36a4,4,0,0,0-4.72-3.93ZM92,108H36V75.34L92,65.16Z" }, null, -1), q7 = [
  I7
], L7 = {
  name: "PhWindowsLogo"
}, N7 = /* @__PURE__ */ D({
  ...L7,
  props: {
    weight: {
      type: String
    },
    size: {
      type: [String, Number]
    },
    color: {
      type: String
    },
    mirrored: {
      type: Boolean
    }
  },
  setup(e) {
    const t = e, r = he("weight", "regular"), a = he("size", "1em"), o = he("color", "currentColor"), n = he("mirrored", !1), s = L(() => t.weight ?? r), i = L(() => t.size ?? a), l = L(() => t.color ?? o), c = L(() => t.mirrored !== void 0 ? t.mirrored ? "scale(-1, 1)" : void 0 : n ? "scale(-1, 1)" : void 0);
    return (u, f) => (g(), R("svg", re({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 256 256",
      width: i.value,
      height: i.value,
      fill: l.value,
      transform: c.value
    }, u.$attrs), [
      q(u.$slots, "default"),
      s.value === "bold" ? (g(), R("g", y7, x7)) : s.value === "duotone" ? (g(), R("g", _7, A7)) : s.value === "fill" ? (g(), R("g", S7, $7)) : s.value === "light" ? (g(), R("g", P7, M7)) : s.value === "regular" ? (g(), R("g", R7, B7)) : s.value === "thin" ? (g(), R("g", D7, q7)) : $e("", !0)
    ], 16, b7));
  }
}), Sd = /* @__PURE__ */ D({
  __name: "Tabs",
  props: {
    defaultValue: {},
    orientation: {},
    dir: {},
    activationMode: {},
    modelValue: {},
    unmountOnHide: { type: Boolean },
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  emits: ["update:modelValue"],
  setup(e, { emit: t }) {
    const r = e, a = t, o = Ye(r, "class"), n = rt(o, a);
    return (s, i) => (g(), N(d(F_), re({ "data-slot": "tabs" }, d(n), {
      class: d(ve)("flex flex-col gap-2", r.class)
    }), {
      default: b((l) => [
        q(s.$slots, "default", De(Fe(l)))
      ]),
      _: 3
    }, 16, ["class"]));
  }
}), Or = /* @__PURE__ */ D({
  __name: "TabsContent",
  props: {
    value: {},
    forceMount: { type: Boolean },
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class");
    return (a, o) => (g(), N(d(j_), re({
      "data-slot": "tabs-content",
      class: d(ve)("flex-1 outline-none", t.class)
    }, d(r)), {
      default: b(() => [
        q(a.$slots, "default")
      ]),
      _: 3
    }, 16, ["class"]));
  }
}), Ed = /* @__PURE__ */ D({
  __name: "TabsList",
  props: {
    loop: { type: Boolean },
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class");
    return (a, o) => (g(), N(d(Z_), re({ "data-slot": "tabs-list" }, d(r), {
      class: d(ve)(
        "bg-muted text-muted-foreground inline-flex h-9 w-fit items-center justify-center rounded-lg p-[3px]",
        t.class
      )
    }), {
      default: b(() => [
        q(a.$slots, "default")
      ]),
      _: 3
    }, 16, ["class"]));
  }
}), Br = /* @__PURE__ */ D({
  __name: "TabsTrigger",
  props: {
    value: {},
    disabled: { type: Boolean },
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class"), a = da(r);
    return (o, n) => (g(), N(d(W_), re({
      "data-slot": "tabs-trigger",
      class: d(ve)(
        "data-[state=active]:bg-background dark:data-[state=active]:text-foreground focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring dark:data-[state=active]:border-input dark:data-[state=active]:bg-input/30 text-foreground dark:text-muted-foreground inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium whitespace-nowrap transition-[color,box-shadow] focus-visible:ring-[3px] focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:shadow-sm [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        t.class
      )
    }, d(a)), {
      default: b(() => [
        q(o.$slots, "default")
      ]),
      _: 3
    }, 16, ["class"]));
  }
}), V7 = /* @__PURE__ */ D({
  __name: "UnraidLogo",
  props: {
    class: { default: "w-8 h-8" }
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("svg", {
      viewBox: "0 0 100 100",
      xmlns: "http://www.w3.org/2000/svg",
      class: ke(t.class)
    }, a[0] || (a[0] = [
      bl('<defs><linearGradient id="unraidGradient" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" style="stop-color:currentColor;stop-opacity:0.8;"></stop><stop offset="100%" style="stop-color:currentColor;stop-opacity:1;"></stop></linearGradient></defs><circle cx="50" cy="50" r="48" fill="none" stroke="currentColor" stroke-width="3"></circle><rect x="30" y="25" width="40" height="50" rx="4" fill="none" stroke="currentColor" stroke-width="2.5"></rect><rect x="35" y="30" width="30" height="6" rx="2" fill="currentColor" opacity="0.6"></rect><rect x="35" y="40" width="30" height="6" rx="2" fill="currentColor" opacity="0.6"></rect><rect x="35" y="50" width="30" height="6" rx="2" fill="currentColor" opacity="0.6"></rect><rect x="35" y="60" width="30" height="6" rx="2" fill="currentColor" opacity="0.6"></rect><circle cx="55" cy="70" r="2" fill="currentColor"></circle><text x="50" y="85" text-anchor="middle" font-family="Arial, sans-serif" font-size="8" font-weight="bold" fill="currentColor"> UNRAID </text>', 9)
    ]), 2));
  }
}), jr = (e, t, r) => {
  const a = document.createElement(e), [o, n] = Array.isArray(t) ? [void 0, t] : [t, r];
  return o && Object.assign(a, o), n?.forEach((s) => a.appendChild(s)), a;
}, H7 = (e, t) => {
  var r;
  return t === "left" ? e.offsetLeft : (((r = e.offsetParent instanceof HTMLElement ? e.offsetParent : null) == null ? void 0 : r.offsetWidth) ?? 0) - e.offsetWidth - e.offsetLeft;
}, F7 = (e) => e.offsetWidth > 0 && e.offsetHeight > 0, z7 = (e, t) => {
  !customElements.get(e) && customElements.define(e, t);
};
function j7(e, t, { reverse: r = !1 } = {}) {
  const a = e.length;
  for (let o = r ? a - 1 : 0; r ? o >= 0 : o < a; r ? o-- : o++)
    t(e[o], o);
}
function U7(e, t, r, a) {
  const o = t.formatToParts(e);
  r && o.unshift({ type: "prefix", value: r }), a && o.push({ type: "suffix", value: a });
  const n = [], s = [], i = [], l = [], c = {}, u = (v) => `${v}:${c[v] = (c[v] ?? -1) + 1}`;
  let f = "", p = !1, h = !1;
  for (const v of o) {
    f += v.value;
    const x = v.type === "minusSign" || v.type === "plusSign" ? "sign" : v.type;
    x === "integer" ? (p = !0, s.push(...v.value.split("").map((C) => ({ type: x, value: parseInt(C) })))) : x === "group" ? s.push({ type: x, value: v.value }) : x === "decimal" ? (h = !0, i.push({ type: x, value: v.value, key: u(x) })) : x === "fraction" ? i.push(...v.value.split("").map((C) => ({
      type: x,
      value: parseInt(C),
      key: u(x),
      pos: -1 - c[x]
    }))) : (p || h ? l : n).push({
      type: x,
      value: v.value,
      key: u(x)
    });
  }
  const m = [];
  for (let v = s.length - 1; v >= 0; v--) {
    const x = s[v];
    m.unshift(x.type === "integer" ? {
      ...x,
      key: u(x.type),
      pos: c[x.type]
    } : {
      ...x,
      key: u(x.type)
    });
  }
  return {
    pre: n,
    integer: m,
    fraction: i,
    post: l,
    valueAsString: f,
    value: typeof e == "string" ? parseFloat(e) : e
  };
}
const Z7 = String.raw, K7 = (() => {
  try {
    document.createElement("div").animate({ opacity: 0 }, { easing: "linear(0, 1)" });
  } catch {
    return !1;
  }
  return !0;
})(), W7 = typeof CSS < "u" && CSS.supports && CSS.supports("line-height", "mod(1,1)"), $d = typeof matchMedia < "u" ? matchMedia("(prefers-reduced-motion: reduce)") : null, $n = "--_number-flow-d-opacity", tc = "--_number-flow-d-width", Pn = "--_number-flow-dx", rc = "--_number-flow-d", G7 = (() => {
  try {
    return CSS.registerProperty({
      name: $n,
      syntax: "<number>",
      inherits: !1,
      initialValue: "0"
    }), CSS.registerProperty({
      name: Pn,
      syntax: "<length>",
      inherits: !0,
      initialValue: "0px"
    }), CSS.registerProperty({
      name: tc,
      syntax: "<number>",
      inherits: !1,
      initialValue: "0"
    }), CSS.registerProperty({
      name: rc,
      syntax: "<number>",
      inherits: !0,
      initialValue: "0"
    }), !0;
  } catch {
    return !1;
  }
})(), J7 = "var(--number-flow-char-height, 1em)", qr = "var(--number-flow-mask-height, 0.25em)", Pd = `calc(${qr} / 2)`, Yi = "var(--number-flow-mask-width, 0.5em)", Qr = `calc(${Yi} / var(--scale-x))`, en = "#000 0, transparent 71%", Td = Z7`:host{display:inline-block;direction:ltr;white-space:nowrap;isolation:isolate;line-height:${J7} !important}.number,.number__inner{display:inline-block;transform-origin:left top}:host([data-will-change]) :is(.number,.number__inner,.section,.digit,.digit__num,.symbol){will-change:transform}.number{--scale-x:calc(1 + var(${tc}) / var(--width));transform:translateX(var(${Pn})) scaleX(var(--scale-x));margin:0 calc(-1 * ${Yi});position:relative;-webkit-mask-image:linear-gradient(to right,transparent 0,#000 ${Qr},#000 calc(100% - ${Qr}),transparent ),linear-gradient(to bottom,transparent 0,#000 ${qr},#000 calc(100% - ${qr}),transparent 100% ),radial-gradient(at bottom right,${en}),radial-gradient(at bottom left,${en}),radial-gradient(at top left,${en}),radial-gradient(at top right,${en});-webkit-mask-size:100% calc(100% - ${qr} * 2),calc(100% - ${Qr} * 2) 100%,${Qr} ${qr},${Qr} ${qr},${Qr} ${qr},${Qr} ${qr};-webkit-mask-position:center,center,top left,top right,bottom right,bottom left;-webkit-mask-repeat:no-repeat}.number__inner{padding:${Pd} ${Yi};transform:scaleX(calc(1 / var(--scale-x))) translateX(calc(-1 * var(${Pn})))}:host > :not(.number){z-index:5}.section,.symbol{display:inline-block;position:relative;isolation:isolate}.section::after{content:'\200b';display:inline-block}.section--justify-left{transform-origin:center left}.section--justify-right{transform-origin:center right}.section > [inert],.symbol > [inert]{margin:0 !important;position:absolute !important;z-index:-1}.digit{display:inline-block;position:relative;--c:var(--current) + var(${rc})}.digit__num,.number .section::after{padding:${Pd} 0}.digit__num{display:inline-block;--offset-raw:mod(var(--length) + var(--n) - mod(var(--c),var(--length)),var(--length));--offset:calc( var(--offset-raw) - var(--length) * round(down,var(--offset-raw) / (var(--length) / 2),1) );--y:clamp(-100%,var(--offset) * 100%,100%);transform:translateY(var(--y))}.digit__num[inert]{position:absolute;top:0;left:50%;transform:translateX(-50%) translateY(var(--y))}.digit:not(.is-spinning) .digit__num[inert]{display:none}.symbol__value{display:inline-block;mix-blend-mode:plus-lighter;white-space:pre}.section--justify-left .symbol > [inert]{left:0}.section--justify-right .symbol > [inert]{right:0}.animate-presence{opacity:calc(1 + var(${$n}))}`, Y7 = HTMLElement, X7 = W7 && K7 && G7;
let tn;
class Yt extends Y7 {
  constructor() {
    super(), this.created = !1, this.batched = !1;
    const { animated: t, ...r } = this.constructor.defaultProps;
    this._animated = this.computedAnimated = t, Object.assign(this, r);
  }
  get animated() {
    return this._animated;
  }
  set animated(t) {
    var r;
    this.animated !== t && (this._animated = t, (r = this.shadowRoot) == null || r.getAnimations().forEach((a) => a.finish()));
  }
  /**
   * @internal
   */
  set data(t) {
    var r;
    if (t == null)
      return;
    const { pre: a, integer: o, fraction: n, post: s, value: i } = t;
    if (this.created) {
      const l = this._data;
      this._data = t, this.computedTrend = typeof this.trend == "function" ? this.trend(l.value, i) : this.trend, this.computedAnimated = X7 && this._animated && (!this.respectMotionPreference || !($d != null && $d.matches)) && // https://github.com/barvian/number-flow/issues/9
      F7(this), (r = this.plugins) == null || r.forEach((c) => {
        var u;
        return (u = c.onUpdate) == null ? void 0 : u.call(c, t, l, this);
      }), this.batched || this.willUpdate(), this._pre.update(a), this._num.update({ integer: o, fraction: n }), this._post.update(s), this.batched || this.didUpdate();
    } else {
      this._data = t, this.attachShadow({ mode: "open" });
      try {
        this._internals ?? (this._internals = this.attachInternals()), this._internals.role = "img";
      } catch {
      }
      if (typeof CSSStyleSheet < "u" && this.shadowRoot.adoptedStyleSheets)
        tn || (tn = new CSSStyleSheet(), tn.replaceSync(Td)), this.shadowRoot.adoptedStyleSheets = [tn];
      else {
        const l = document.createElement("style");
        l.textContent = Td, this.shadowRoot.appendChild(l);
      }
      this._pre = new Rd(this, a, {
        justify: "right",
        part: "left"
      }), this.shadowRoot.appendChild(this._pre.el), this._num = new Q7(this, o, n), this.shadowRoot.appendChild(this._num.el), this._post = new Rd(this, s, {
        justify: "left",
        part: "right"
      }), this.shadowRoot.appendChild(this._post.el), this.created = !0;
    }
    try {
      this._internals.ariaLabel = t.valueAsString;
    } catch {
    }
  }
  /**
   * @internal
   */
  willUpdate() {
    this._pre.willUpdate(), this._num.willUpdate(), this._post.willUpdate();
  }
  /**
   * @internal
   */
  didUpdate() {
    if (!this.computedAnimated)
      return;
    this._abortAnimationsFinish ? this._abortAnimationsFinish.abort() : this.dispatchEvent(new Event("animationsstart")), this._pre.didUpdate(), this._num.didUpdate(), this._post.didUpdate();
    const t = new AbortController();
    Promise.all(this.shadowRoot.getAnimations().map((r) => r.finished)).then(() => {
      t.signal.aborted || (this.dispatchEvent(new Event("animationsfinish")), this._abortAnimationsFinish = void 0);
    }), this._abortAnimationsFinish = t;
  }
}
Yt.defaultProps = {
  transformTiming: {
    duration: 900,
    // Make sure to keep this minified:
    easing: "linear(0,.005,.019,.039,.066,.096,.129,.165,.202,.24,.278,.316,.354,.39,.426,.461,.494,.526,.557,.586,.614,.64,.665,.689,.711,.731,.751,.769,.786,.802,.817,.831,.844,.856,.867,.877,.887,.896,.904,.912,.919,.925,.931,.937,.942,.947,.951,.955,.959,.962,.965,.968,.971,.973,.976,.978,.98,.981,.983,.984,.986,.987,.988,.989,.99,.991,.992,.992,.993,.994,.994,.995,.995,.996,.996,.9963,.9967,.9969,.9972,.9975,.9977,.9979,.9981,.9982,.9984,.9985,.9987,.9988,.9989,1)"
  },
  spinTiming: void 0,
  opacityTiming: { duration: 450, easing: "ease-out" },
  animated: !0,
  trend: (e, t) => Math.sign(t - e),
  respectMotionPreference: !0,
  plugins: void 0,
  digits: void 0
};
class Q7 {
  constructor(t, r, a, { className: o, ...n } = {}) {
    this.flow = t, this._integer = new Md(t, r, {
      justify: "right",
      part: "integer"
    }), this._fraction = new Md(t, a, {
      justify: "left",
      part: "fraction"
    }), this._inner = jr("span", {
      className: "number__inner"
    }, [this._integer.el, this._fraction.el]), this.el = jr("span", {
      ...n,
      part: "number",
      className: `number ${o ?? ""}`
    }, [this._inner]);
  }
  willUpdate() {
    this._prevWidth = this.el.offsetWidth, this._prevLeft = this.el.getBoundingClientRect().left, this._integer.willUpdate(), this._fraction.willUpdate();
  }
  update({ integer: t, fraction: r }) {
    this._integer.update(t), this._fraction.update(r);
  }
  didUpdate() {
    const t = this.el.getBoundingClientRect();
    this._integer.didUpdate(), this._fraction.didUpdate();
    const r = this._prevLeft - t.left, a = this.el.offsetWidth, o = this._prevWidth - a;
    this.el.style.setProperty("--width", String(a)), this.el.animate({
      [Pn]: [`${r}px`, "0px"],
      [tc]: [o, 0]
    }, {
      ...this.flow.transformTiming,
      composite: "accumulate"
    });
  }
}
class ih {
  constructor(t, r, { justify: a, className: o, ...n }, s) {
    this.flow = t, this.children = /* @__PURE__ */ new Map(), this.onCharRemove = (l) => () => {
      this.children.delete(l);
    }, this.justify = a;
    const i = r.map((l) => this.addChar(l).el);
    this.el = jr("span", {
      ...n,
      className: `section section--justify-${a} ${o ?? ""}`
    }, s ? s(i) : i);
  }
  addChar(t, { startDigitsAtZero: r = !1, ...a } = {}) {
    const o = t.type === "integer" || t.type === "fraction" ? new ch(this, t.type, r ? 0 : t.value, t.pos, {
      ...a,
      onRemove: this.onCharRemove(t.key)
    }) : new eS(this, t.type, t.value, {
      ...a,
      onRemove: this.onCharRemove(t.key)
    });
    return this.children.set(t.key, o), o;
  }
  unpop(t) {
    t.el.removeAttribute("inert"), t.el.style.top = "", t.el.style[this.justify] = "";
  }
  pop(t) {
    t.forEach((r) => {
      r.el.style.top = `${r.el.offsetTop}px`, r.el.style[this.justify] = `${H7(r.el, this.justify)}px`;
    }), t.forEach((r) => {
      r.el.setAttribute("inert", ""), r.present = !1;
    });
  }
  addNewAndUpdateExisting(t) {
    const r = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = this.justify === "left", n = o ? "prepend" : "append";
    if (j7(t, (s) => {
      let i;
      this.children.has(s.key) ? (i = this.children.get(s.key), a.set(s, i), this.unpop(i), i.present = !0) : (i = this.addChar(s, { startDigitsAtZero: !0, animateIn: !0 }), r.set(s, i)), this.el[n](i.el);
    }, { reverse: o }), this.flow.computedAnimated) {
      const s = this.el.getBoundingClientRect();
      r.forEach((i) => {
        i.willUpdate(s);
      });
    }
    r.forEach((s, i) => {
      s.update(i.value);
    }), a.forEach((s, i) => {
      s.update(i.value);
    });
  }
  willUpdate() {
    const t = this.el.getBoundingClientRect();
    this._prevOffset = t[this.justify], this.children.forEach((r) => r.willUpdate(t));
  }
  didUpdate() {
    const t = this.el.getBoundingClientRect();
    this.children.forEach((o) => o.didUpdate(t));
    const r = t[this.justify], a = this._prevOffset - r;
    a && this.children.size && this.el.animate({
      transform: [`translateX(${a}px)`, "none"]
    }, {
      ...this.flow.transformTiming,
      composite: "accumulate"
    });
  }
}
class Md extends ih {
  update(t) {
    const r = /* @__PURE__ */ new Map();
    this.children.forEach((a, o) => {
      t.find((n) => n.key === o) || r.set(o, a), this.unpop(a);
    }), this.addNewAndUpdateExisting(t), r.forEach((a) => {
      a instanceof ch && a.update(0);
    }), this.pop(r);
  }
}
class Rd extends ih {
  update(t) {
    const r = /* @__PURE__ */ new Map();
    this.children.forEach((a, o) => {
      t.find((n) => n.key === o) || r.set(o, a);
    }), this.pop(r), this.addNewAndUpdateExisting(t);
  }
}
let Xi = class {
  constructor(t, r, { onRemove: a, animateIn: o = !1 } = {}) {
    this.flow = t, this.el = r, this._present = !0, this._remove = () => {
      var n;
      this.el.remove(), (n = this._onRemove) == null || n.call(this);
    }, this.el.classList.add("animate-presence"), this.flow.computedAnimated && o && this.el.animate({
      [$n]: [-0.9999, 0]
    }, {
      ...this.flow.opacityTiming,
      composite: "accumulate"
    }), this._onRemove = a;
  }
  get present() {
    return this._present;
  }
  set present(t) {
    if (this._present !== t) {
      if (this._present = t, t ? this.el.removeAttribute("inert") : this.el.setAttribute("inert", ""), !this.flow.computedAnimated) {
        t || this._remove();
        return;
      }
      this.el.style.setProperty("--_number-flow-d-opacity", t ? "0" : "-.999"), this.el.animate({
        [$n]: t ? [-0.9999, 0] : [0.999, 0]
      }, {
        ...this.flow.opacityTiming,
        composite: "accumulate"
      }), t ? this.flow.removeEventListener("animationsfinish", this._remove) : this.flow.addEventListener("animationsfinish", this._remove, {
        once: !0
      });
    }
  }
};
class lh extends Xi {
  constructor(t, r, a, o) {
    super(t.flow, a, o), this.section = t, this.value = r, this.el = a;
  }
}
class ch extends lh {
  constructor(t, r, a, o, n) {
    var s, i;
    const l = (((i = (s = t.flow.digits) == null ? void 0 : s[o]) == null ? void 0 : i.max) ?? 9) + 1, c = Array.from({ length: l }).map((f, p) => {
      const h = jr("span", { className: "digit__num" }, [
        document.createTextNode(String(p))
      ]);
      return p !== a && h.setAttribute("inert", ""), h.style.setProperty("--n", String(p)), h;
    }), u = jr("span", {
      part: `digit ${r}-digit`,
      className: "digit"
    }, c);
    u.style.setProperty("--current", String(a)), u.style.setProperty("--length", String(l)), super(t, a, u, n), this.pos = o, this._onAnimationsFinish = () => {
      this.el.classList.remove("is-spinning");
    }, this._numbers = c, this.length = l;
  }
  willUpdate(t) {
    const r = this.el.getBoundingClientRect();
    this._prevValue = this.value;
    const a = r[this.section.justify] - t[this.section.justify], o = r.width / 2;
    this._prevCenter = this.section.justify === "left" ? a + o : a - o;
  }
  update(t) {
    this.el.style.setProperty("--current", String(t)), this._numbers.forEach((r, a) => a === t ? r.removeAttribute("inert") : r.setAttribute("inert", "")), this.value = t;
  }
  didUpdate(t) {
    const r = this.el.getBoundingClientRect(), a = r[this.section.justify] - t[this.section.justify], o = r.width / 2, n = this.section.justify === "left" ? a + o : a - o, s = this._prevCenter - n;
    s && this.el.animate({
      transform: [`translateX(${s}px)`, "none"]
    }, {
      ...this.flow.transformTiming,
      composite: "accumulate"
    });
    const i = this.getDelta();
    i && (this.el.classList.add("is-spinning"), this.el.animate({
      [rc]: [-i, 0]
    }, {
      ...this.flow.spinTiming ?? this.flow.transformTiming,
      composite: "accumulate"
    }), this.flow.addEventListener("animationsfinish", this._onAnimationsFinish, { once: !0 }));
  }
  getDelta() {
    var t;
    if (this.flow.plugins)
      for (const o of this.flow.plugins) {
        const n = (t = o.getDelta) == null ? void 0 : t.call(o, this.value, this._prevValue, this);
        if (n != null)
          return n;
      }
    const r = this.value - this._prevValue, a = this.flow.computedTrend || Math.sign(r);
    return a < 0 && this.value > this._prevValue ? this.value - this.length - this._prevValue : a > 0 && this.value < this._prevValue ? this.length - this._prevValue + this.value : r;
  }
}
class eS extends lh {
  constructor(t, r, a, o) {
    const n = jr("span", {
      className: "symbol__value",
      textContent: a
    });
    super(t, a, jr("span", {
      part: `symbol ${r}`,
      className: "symbol"
    }, [n]), o), this.type = r, this._children = /* @__PURE__ */ new Map(), this._onChildRemove = (s) => () => {
      this._children.delete(s);
    }, this._children.set(a, new Xi(this.flow, n, {
      onRemove: this._onChildRemove(a)
    }));
  }
  willUpdate(t) {
    if (this.type === "decimal")
      return;
    const r = this.el.getBoundingClientRect();
    this._prevOffset = r[this.section.justify] - t[this.section.justify];
  }
  update(t) {
    if (this.value !== t) {
      const r = this._children.get(this.value);
      r && (r.present = !1);
      const a = this._children.get(t);
      if (a)
        a.present = !0;
      else {
        const o = jr("span", {
          className: "symbol__value",
          textContent: t
        });
        this.el.appendChild(o), this._children.set(t, new Xi(this.flow, o, {
          animateIn: !0,
          onRemove: this._onChildRemove(t)
        }));
      }
    }
    this.value = t;
  }
  didUpdate(t) {
    if (this.type === "decimal")
      return;
    const r = this.el.getBoundingClientRect()[this.section.justify] - t[this.section.justify], a = this._prevOffset - r;
    a && this.el.animate({
      transform: [`translateX(${a}px)`, "none"]
    }, { ...this.flow.transformTiming, composite: "accumulate" });
  }
}
const tS = Symbol(), rS = ["batched", "trend", "plugins", "animated", "transformTiming", "spinTiming", "opacityTiming", "respectMotionPreference", "data-will-change", "digits", "innerHTML", "data"], Ya = /* @__PURE__ */ D({
  inheritAttrs: !1,
  __name: "index",
  props: {
    transformTiming: { default: () => Yt.defaultProps.transformTiming },
    spinTiming: { default: () => Yt.defaultProps.spinTiming },
    opacityTiming: { default: () => Yt.defaultProps.opacityTiming },
    animated: { type: Boolean, default: () => Yt.defaultProps.animated },
    respectMotionPreference: { type: Boolean, default: () => Yt.defaultProps.respectMotionPreference },
    trend: { type: [Number, Function], default: () => Yt.defaultProps.trend },
    plugins: { default: () => Yt.defaultProps.plugins },
    digits: { default: () => Yt.defaultProps.digits },
    locales: {},
    format: {},
    value: {},
    prefix: {},
    suffix: {},
    willChange: { type: Boolean, default: !1 }
  },
  emits: ["animationsstart", "animationsfinish"],
  setup(e, { expose: t, emit: r }) {
    const a = K();
    t({ el: a });
    const o = r, n = L(() => new Intl.NumberFormat(e.locales, e.format)), s = L(() => U7(e.value, n.value, e.prefix, e.suffix)), i = void 0, l = he(tS, void 0);
    return l?.(a, s), (c, u) => (g(), R("number-flow-vue", re({
      ref_key: "el",
      ref: a
    }, c.$attrs, {
      batched: !!d(l),
      trend: c.trend,
      plugins: c.plugins,
      animated: c.animated,
      transformTiming: c.transformTiming,
      spinTiming: c.spinTiming,
      opacityTiming: c.opacityTiming,
      respectMotionPreference: c.respectMotionPreference,
      "data-will-change": c.willChange ? "" : void 0,
      digits: c.digits,
      innerHTML: d(i),
      "data-allow-mismatch": "",
      onAnimationsstart: u[0] || (u[0] = (f) => o("animationsstart")),
      onAnimationsfinish: u[1] || (u[1] = (f) => o("animationsfinish")),
      data: s.value
    }), null, 16, rS));
  }
});
z7("number-flow-vue", Yt);
function ba(e = "") {
  const t = e?.trim() ?? "";
  if (!t)
    return { value: 0, unit: "" };
  const r = t.match(/(\d+(\.\d+)?)/), a = t.replace(/(\d+(\.\d+)?)/, "").trim();
  return {
    value: parseFloat(r?.[0] || "0"),
    unit: a
  };
}
function Qi(e) {
  return e.trim().toLowerCase();
}
const eo = {
  b: 1,
  kb: 1024,
  k: 1024,
  kib: 1024,
  mb: 1024 * 1024,
  m: 1024 * 1024,
  mib: 1024 * 1024,
  gb: 1024 * 1024 * 1024,
  g: 1024 * 1024 * 1024,
  gib: 1024 * 1024 * 1024
};
function uh(e) {
  const t = Qi(e).replace(/\/s(ec(ond)?)?$/, ""), r = t.endsWith("b") ? t : `${t}b`;
  return eo[r] ?? 1;
}
function Od(e) {
  if (e.length === 0)
    return { value: 0, unit: "MB/s" };
  const t = e.reduce((a, o) => {
    const n = uh(o.unit);
    return a + o.value * n;
  }, 0), r = [
    { unit: "GB/s", multiplier: eo.gb },
    { unit: "MB/s", multiplier: eo.mb },
    { unit: "KB/s", multiplier: eo.kb },
    { unit: "B/s", multiplier: eo.b }
  ];
  for (const { unit: a, multiplier: o } of r)
    if (t >= o)
      return { value: parseFloat((t / o).toFixed(2)), unit: a };
  return { value: t, unit: "B/s" };
}
function Bd(e) {
  const t = e?.value ?? 0;
  if (!Number.isFinite(t) || t <= 0)
    return 0;
  const r = uh(e?.unit ?? "");
  return t * r;
}
function aS(e) {
  if (e.length === 0)
    return { value: 0, unit: "" };
  const t = e[0].unit.trim(), r = Qi(t);
  return { value: e.reduce((o, n) => Qi(n.unit) === r ? o + n.value : o, 0), unit: t };
}
const oS = { class: "relative bg-slate-900 rounded-lg p-4 font-mono text-sm" }, nS = { class: "text-green-400 whitespace-pre-wrap break-words" }, sS = { class: "text-white ml-2 select-text" }, dn = /* @__PURE__ */ D({
  __name: "terminal-window",
  props: {
    title: {
      type: String,
      default: "Terminal"
    },
    commandText: {
      type: String
    }
  },
  setup(e) {
    return (t, r) => (g(), R("div", oS, [
      r[1] || (r[1] = bl('<div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-700"><div class="flex items-center gap-2"><div class="flex gap-1.5"><div class="w-3 h-3 rounded-full bg-red-500"></div><div class="w-3 h-3 rounded-full bg-yellow-500"></div><div class="w-3 h-3 rounded-full bg-green-500"></div></div><span class="text-slate-400 text-xs ml-2">Terminal</span></div></div>', 1)),
      w("div", nS, [
        r[0] || (r[0] = w("span", { class: "text-blue-400 select-none" }, "$", -1)),
        w("span", sS, ue(e.commandText), 1)
      ])
    ]));
  }
}), iS = async (e) => (await St.post("/api/domainfold/remap", { url: e })).data, lS = async () => (await St.get("/api/domainfold/routes")).data, cS = async () => (await St.get("/api/domainfold/traffic")).data, fn = /* @__PURE__ */ D({
  __name: "Popover",
  props: {
    defaultOpen: { type: Boolean },
    open: { type: Boolean },
    modal: { type: Boolean }
  },
  emits: ["update:open"],
  setup(e, { emit: t }) {
    const o = rt(e, t);
    return (n, s) => (g(), N(d(i_), re({ "data-slot": "popover" }, d(o)), {
      default: b((i) => [
        q(n.$slots, "default", De(Fe(i)))
      ]),
      _: 3
    }, 16));
  }
}), pn = /* @__PURE__ */ D({
  inheritAttrs: !1,
  __name: "PopoverContent",
  props: {
    forceMount: { type: Boolean },
    side: {},
    sideOffset: { default: 4 },
    sideFlip: { type: Boolean },
    align: { default: "center" },
    alignOffset: {},
    alignFlip: { type: Boolean },
    avoidCollisions: { type: Boolean },
    collisionBoundary: {},
    collisionPadding: {},
    arrowPadding: {},
    hideShiftedArrow: { type: Boolean },
    sticky: {},
    hideWhenDetached: { type: Boolean },
    positionStrategy: {},
    updatePositionStrategy: {},
    disableUpdateOnLayoutShift: { type: Boolean },
    prioritizePosition: { type: Boolean },
    reference: {},
    asChild: { type: Boolean },
    as: {},
    disableOutsidePointerEvents: { type: Boolean },
    class: {}
  },
  emits: ["escapeKeyDown", "pointerDownOutside", "focusOutside", "interactOutside", "openAutoFocus", "closeAutoFocus"],
  setup(e, { emit: t }) {
    const r = e, a = t, o = Ye(r, "class"), n = rt(o, a);
    return (s, i) => (g(), N(d(m_), null, {
      default: b(() => [
        k(d(h_), re({ "data-slot": "popover-content" }, { ...s.$attrs, ...d(n) }, {
          class: d(ve)(
            "bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 w-72 rounded-md border p-4 shadow-md origin-(--reka-popover-content-transform-origin) outline-hidden",
            r.class
          )
        }), {
          default: b(() => [
            q(s.$slots, "default")
          ]),
          _: 3
        }, 16, ["class"])
      ]),
      _: 3
    }));
  }
}), hn = /* @__PURE__ */ D({
  __name: "PopoverTrigger",
  props: {
    asChild: { type: Boolean },
    as: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(b_), re({ "data-slot": "popover-trigger" }, t), {
      default: b(() => [
        q(r.$slots, "default")
      ]),
      _: 3
    }, 16));
  }
}), uS = { class: "space-y-4 flex items-center justify-center w-full" }, dS = { class: "flex flex-col items-center" }, fS = { class: "text-muted-foreground flex-shrink-0" }, pS = /* @__PURE__ */ D({
  __name: "empty-state",
  props: {
    description: {
      type: String,
      default: "No Content"
    }
  },
  setup(e) {
    return (t, r) => (g(), R("div", uS, [
      w("div", dS, [
        k(d(Ak), {
          size: 64,
          class: "flex-shrink-0 my-2"
        }),
        w("h1", fS, ue(e.description), 1)
      ])
    ]));
  }
}), hS = { class: "space-y-4" }, gS = { class: "flex flex-col gap-4 md:flex-row md:items-center" }, mS = { class: "flex-1 space-y-3" }, vS = { class: "flex flex-col gap-2 md:flex-row md:items-end md:justify-between" }, bS = ["title"], yS = { class: "flex flex-wrap gap-2 mt-2 text-xs" }, wS = { class: "flex items-center gap-2" }, xS = { class: "text-xs text-muted-foreground" }, _S = { class: "grid gap-3 sm:grid-cols-3" }, kS = { class: "rounded-xl border border-dashed border-muted/40 bg-muted/30 p-3" }, CS = { class: "text-base font-semibold text-foreground" }, AS = { class: "rounded-xl border border-dashed border-muted/40 bg-muted/30 p-3" }, SS = { class: "text-base font-semibold text-foreground" }, ES = { class: "rounded-xl border border-dashed border-muted/40 bg-muted/30 p-3" }, $S = { class: "text-base font-semibold text-foreground" }, PS = { class: "flex flex-wrap items-center gap-3 text-xs text-muted-foreground" }, TS = {
  key: 0,
  class: "flex items-center gap-1"
}, MS = { class: "truncate max-w-[200px]" }, RS = {
  key: 1,
  class: "text-neutral-400"
}, OS = {
  key: 2,
  class: "text-red-600 font-medium"
}, BS = { class: "flex items-center gap-1 px-3 py-1 rounded-full border text-xs text-muted-foreground hover:bg-muted/60 transition" }, DS = { class: "space-y-2 text-[11px]" }, IS = {
  key: 0,
  class: "text-red-500"
}, Xa = /* @__PURE__ */ D({
  __name: "MirrorList",
  props: {
    mirrors: {},
    emptyDescription: {}
  },
  setup(e) {
    const t = (a) => {
      if (!a) return "未知";
      const o = new Date(a.replace(" ", "T"));
      if (Number.isNaN(o.getTime())) return "未知";
      const n = Date.now() - o.getTime();
      if (n < 6e4)
        return "刚刚";
      const s = Math.floor(n / (60 * 1e3));
      if (s < 60)
        return `${s} 分钟前`;
      const i = Math.floor(s / 60);
      return i < 24 ? `${i} 小时前` : `${Math.floor(i / 24)} 天前`;
    }, r = (a) => `docker pull ${a.url ? a.url.replace(/^https?:\/\//, "").replace(/\/$/, "") : "registry.linkease.net:5443"}/library/alpine`;
    return (a, o) => (g(), R("div", hS, [
      a.mirrors.length > 0 ? (g(!0), R(Be, { key: 0 }, qt(a.mirrors, (n) => (g(), R("div", {
        key: n.name,
        class: "border bg-card/80 rounded-2xl p-4 shadow-sm transition hover:shadow-lg"
      }, [
        w("div", gS, [
          w("div", {
            class: ke(["w-12 h-12 flex items-center justify-center rounded-full shrink-0", {
              "bg-gray-100 text-gray-400": n.status === "disabled",
              "bg-green-100 text-green-600": n.status === "online",
              "bg-red-100 text-red-600": n.status === "offline",
              "bg-amber-100 text-amber-600": n.status === "checking"
            }])
          }, [
            n.isChecking ? (g(), N(d(v7), {
              key: 0,
              class: "w-5 h-5 animate-spin"
            })) : (g(), R(Be, { key: 1 }, [
              n.status === "disabled" ? (g(), N(d(m6), {
                key: 0,
                class: "w-5 h-5"
              })) : n.status === "online" ? (g(), N(d(w6), {
                key: 1,
                class: "w-5 h-5"
              })) : (g(), N(d(_6), {
                key: 2,
                class: "w-5 h-5"
              }))
            ], 64))
          ], 2),
          w("div", mS, [
            w("div", vS, [
              w("div", null, [
                w("p", {
                  class: "text-sm font-semibold text-foreground truncate",
                  title: n.name
                }, ue(n.name), 9, bS),
                w("div", yS, [
                  n.status !== "disabled" ? (g(), N(d(Hr), {
                    key: 0,
                    variant: "outline",
                    class: "px-2 py-0.5 text-xs"
                  }, {
                    default: b(() => [
                      ne(ue(n.status === "online" ? "在线" : "离线"), 1)
                    ]),
                    _: 2
                  }, 1024)) : $e("", !0),
                  n.isFastChannel ? (g(), N(d(Hr), {
                    key: 1,
                    variant: "default",
                    class: "px-2 py-0.5"
                  }, {
                    default: b(() => o[0] || (o[0] = [
                      ne(" Plus 专享 ", -1)
                    ])),
                    _: 1,
                    __: [0]
                  })) : $e("", !0),
                  k(d(Hr), {
                    variant: "secondary",
                    class: "px-2 py-0.5"
                  }, {
                    default: b(() => [
                      ne(ue(n.isInternal ? "内置节点" : "外部节点"), 1)
                    ]),
                    _: 2
                  }, 1024),
                  n.cfipEnabled ? (g(), N(d(Hr), {
                    key: 2,
                    variant: "outline",
                    class: "px-2 py-0.5 text-xs text-amber-600 border-amber-200"
                  }, {
                    default: b(() => o[1] || (o[1] = [
                      ne(" CFIP 优选 ", -1)
                    ])),
                    _: 1,
                    __: [1]
                  })) : $e("", !0)
                ])
              ]),
              w("div", wS, [
                k(d(k6), { class: "w-4 h-4 text-muted-foreground" }),
                w("p", xS, ue(t(n.lastCheckAt)), 1)
              ])
            ]),
            w("div", _S, [
              w("div", kS, [
                o[2] || (o[2] = w("p", { class: "text-[10px] tracking-[0.3em] text-muted-foreground" }, "当前速率", -1)),
                w("p", CS, ue(n.currentSpeed.value) + " " + ue(n.currentSpeed.unit), 1)
              ]),
              w("div", AS, [
                o[3] || (o[3] = w("p", { class: "text-[10px] tracking-[0.3em] text-muted-foreground" }, "测速速率", -1)),
                w("p", SS, ue(n.testSpeed.value) + " " + ue(n.testSpeed.unit), 1)
              ]),
              w("div", ES, [
                o[4] || (o[4] = w("p", { class: "text-[10px] tracking-[0.3em] text-muted-foreground" }, "累计下载", -1)),
                w("p", $S, ue(n.totalDownloaded.value) + " " + ue(n.totalDownloaded.unit), 1)
              ])
            ]),
            w("div", PS, [
              n.url ? (g(), R("span", TS, [
                k(d(M6), { class: "w-3 h-3" }),
                w("span", MS, ue(n.url), 1)
              ])) : (g(), R("span", RS, "暂无外部地址")),
              n.errorInfo ? (g(), R("span", OS, "错误: " + ue(n.errorInfo), 1)) : $e("", !0),
              k(d(fn), null, {
                default: b(() => [
                  k(d(hn), { asChild: "" }, {
                    default: b(() => [
                      w("button", BS, [
                        k(d(T6), { class: "w-3 h-3" }),
                        o[5] || (o[5] = ne(" 详细信息 ", -1))
                      ])
                    ]),
                    _: 1
                  }),
                  k(d(pn), {
                    side: "bottom",
                    align: "center",
                    class: "max-w-xs"
                  }, {
                    default: b(() => [
                      w("div", DS, [
                        w("p", null, [
                          o[6] || (o[6] = w("strong", null, "上次测速", -1)),
                          ne("： " + ue(t(n.lastCheckAt)), 1)
                        ]),
                        w("p", null, [
                          o[7] || (o[7] = w("strong", null, "测速速率", -1)),
                          ne("： " + ue(n.testSpeed.value) + " " + ue(n.testSpeed.unit), 1)
                        ]),
                        w("p", null, [
                          o[8] || (o[8] = w("strong", null, "累计下载", -1)),
                          ne("： " + ue(n.totalDownloaded.value) + " " + ue(n.totalDownloaded.unit), 1)
                        ]),
                        w("p", null, [
                          o[9] || (o[9] = w("strong", null, "节点链接", -1)),
                          ne("： " + ue(n.url || "暂无"), 1)
                        ]),
                        w("p", null, [
                          o[10] || (o[10] = w("strong", null, "CFIP 优选", -1)),
                          ne("： " + ue(n.cfipEnabled ? "使用中" : "未启用"), 1)
                        ]),
                        n.errorInfo ? (g(), R("p", IS, [
                          o[11] || (o[11] = w("strong", null, "错误描述", -1)),
                          ne("：" + ue(n.errorInfo), 1)
                        ])) : $e("", !0),
                        o[12] || (o[12] = w("p", { class: "text-muted-foreground" }, "也可以复制下面的命令直接拉取镜像", -1)),
                        k(dn, {
                          "command-text": r(n)
                        }, null, 8, ["command-text"])
                      ])
                    ]),
                    _: 2
                  }, 1024)
                ]),
                _: 2
              }, 1024)
            ])
          ])
        ])
      ]))), 128)) : (g(), N(pS, {
        key: 1,
        description: a.emptyDescription || "可能你喂我一点猫粮服务器就会出现"
      }, null, 8, ["description"]))
    ]));
  }
}), qS = { class: "min-h-screen bg-background px-16 mt-3 max-w-[100rem]" }, LS = { class: "mb-8" }, NS = { class: "text-4xl font-bold text-foreground mb-4" }, VS = {
  key: 0,
  class: "text-sm font-normal text-muted-foreground"
}, HS = {
  key: 0,
  class: "mt-4 text-sm text-muted-foreground max-w-2xl"
}, FS = {
  key: 1,
  class: "mt-4 text-sm font-bold max-w-2xl"
}, zS = { class: "mt-4 text-sm text-muted-foreground max-w-2xl" }, jS = { class: "space-y-6" }, US = { class: "grid grid-cols-1 md:grid-cols-3 gap-6" }, ZS = { class: "flex items-center justify-between mb-2" }, KS = { class: "w-8 h-8 rounded-lg flex items-center justify-center" }, WS = { class: "text-2xl font-bold mb-2" }, GS = { class: "flex items-center justify-between gap-2" }, JS = { class: "flex items-center gap-1 text-xs text-muted-foreground" }, YS = { class: "flex items-center justify-between mb-2" }, XS = { class: "w-8 h-8 rounded-lg flex items-center justify-center" }, QS = { class: "text-2xl font-bold mb-2" }, e9 = { class: "flex items-center justify-between mb-2" }, t9 = { key: 0 }, r9 = {
  key: 0,
  class: "ml-4 text-sm text-muted-foreground"
}, a9 = { key: 1 }, o9 = { class: "w-8 h-8 rounded-lg flex items-center justify-center" }, n9 = { key: 0 }, s9 = { class: "text-2xl font-bold mb-2" }, i9 = { class: "text-sm" }, l9 = {
  key: 1,
  class: "text-2xl font-bold mb-2 text-muted-foreground"
}, c9 = { class: "grid grid-cols-1" }, u9 = { class: "w-8 h-8 rounded-lg flex items-center justify-center" }, d9 = { class: "space-between flex items-center" }, f9 = { class: "flex gap-6 overflow-x-auto pb-4" }, p9 = ["href"], h9 = { class: "w-16 h-16 flex items-center justify-center" }, g9 = { class: "text-sm text-muted-foreground" }, m9 = { class: "grid grid-cols-1" }, v9 = { class: "flex items-center justify-center" }, b9 = { class: "w-8 h-8 rounded-lg flex items-center justify-center" }, y9 = { class: "text-muted-foreground" }, w9 = ["title"], x9 = {
  key: 0,
  class: "text-xs text-amber-500 mt-1"
}, _9 = {
  key: 1,
  class: "text-xs text-sky-500/90 mt-1"
}, k9 = { class: "flex items-center justify-between" }, C9 = {
  key: 0,
  class: "absolute inset-0 flex items-center justify-center bg-background/40 backdrop-blur-xs"
}, A9 = {
  key: 0,
  class: "rounded-full border px-6 py-3 text-sm font-medium text-muted-foreground bg-card/70"
}, S9 = {
  key: 0,
  class: "absolute inset-0 flex items-center justify-center bg-background/40 backdrop-blur-xs"
}, E9 = { class: "rounded-full border px-6 py-3 text-sm font-medium text-muted-foreground bg-card/70" }, $9 = "https://www.koolcenter.com/t/topic/7365", P9 = /* @__PURE__ */ D({
  __name: "Dashboard",
  setup(e) {
    const t = qa(), r = L(() => !t.isLogin || !t.isPlus), a = L(() => !t.isLogin), o = [
      {
        name: "macOS",
        logo: D5,
        url: "https://www.koolcenter.com/t/topic/5887"
      },
      {
        name: "Linux",
        logo: Kk,
        url: "https://www.koolcenter.com/t/topic/5888"
      },
      {
        name: "Windows",
        logo: N7,
        url: "https://www.koolcenter.com/t/topic/5889"
      },
      {
        name: "局域网",
        logo: gC,
        url: "https://www.koolcenter.com/t/topic/5891"
      },
      {
        name: "Unraid",
        logo: V7,
        url: "https://www.koolcenter.com/t/topic/5890"
      }
    ], n = Rt({
      stats: {
        downloadSpeed: { value: 0, unit: "MB/s" },
        upstreamDownloadSpeed: { value: 0, unit: "MB/s" },
        totalAccelerated: { value: 0, unit: "GB" }
      },
      mirrors: {
        dockerHub: [],
        ghcr: []
      },
      proxies: [],
      domainfoldProxies: [],
      domainfold: []
    }), s = K("检测中"), i = K(""), l = K(""), c = L(() => i.value ? `探测来源：${i.value}` : "探测来源：未知"), u = L(() => s.value === "直连优化" ? "text-emerald-500" : s.value === "国际优化" ? "text-sky-500" : "text-foreground");
    let f = null;
    const p = (ae) => ae.map((O) => {
      const Ae = O.test_speed || O.last_speed || "";
      return {
        name: O.name,
        status: O.status,
        currentSpeed: ba(O.current_speed),
        totalDownloaded: ba(O.total_download),
        testSpeed: ba(Ae),
        lastCheckAt: O.last_check_time,
        errorInfo: O.error_info || "",
        isFastChannel: O.is_fast_channel,
        isInternal: O.is_internal,
        isChecking: O.is_checking,
        url: O.url,
        cfipEnabled: O.cfip_enabled
      };
    }), h = (ae = 0) => {
      const O = Math.max(0, ae ?? 0);
      if (O === 0)
        return { value: 0, unit: "B/s" };
      const Ae = [
        { unit: "GB/s", multiplier: 1024 ** 3 },
        { unit: "MB/s", multiplier: 1024 ** 2 },
        { unit: "KB/s", multiplier: 1024 }
      ];
      for (const _e of Ae)
        if (O >= _e.multiplier)
          return { value: parseFloat((O / _e.multiplier).toFixed(2)), unit: _e.unit };
      return { value: parseFloat(O.toFixed(2)), unit: "B/s" };
    }, m = (ae) => {
      if (ae.Checking)
        return "checking";
      switch (ae.State) {
        case "healthy":
          return "online";
        case "disabled":
          return "disabled";
        default:
          return "offline";
      }
    }, v = (ae, O, Ae) => {
      const _e = ae.DisplayName?.trim() || ae.NodeID, y = Ae ?? ae.OutboundProxyURL ?? ae.URL ?? "", Q = O.LiveBytesTotal ?? 0;
      return {
        nodeId: ae.NodeID,
        name: _e,
        status: m(O),
        currentSpeed: h(O.LiveSpeed),
        totalDownloaded: x(Q),
        testSpeed: h(O.TestSpeed),
        lastCheckAt: O.LastTestAt || "",
        errorInfo: O.LastErr || "",
        isFastChannel: !!ae.IsFastChannel,
        isInternal: !!ae.IsInternal,
        isChecking: O.Checking,
        url: y,
        cfipEnabled: !!O.Runtime?.CFIPEnabled
      };
    }, x = (ae) => {
      const O = Math.max(0, ae || 0), Ae = [
        { unit: "GB", div: 1024 * 1024 * 1024 },
        { unit: "MB", div: 1024 * 1024 },
        { unit: "KB", div: 1024 },
        { unit: "B", div: 1 }
      ];
      for (const { unit: _e, div: y } of Ae)
        if (O >= y || _e === "B")
          return { value: y === 1 ? O : parseFloat((O / y).toFixed(2)), unit: _e };
      return { value: 0, unit: "B" };
    }, C = (ae) => (ae.NodeType ?? "").toLowerCase().includes("proxy") ? !0 : (ae.NodeID?.trim() || "").startsWith("proxy|"), S = (ae) => {
      const O = (ae.NodeType ?? "").toLowerCase();
      return O === "domainfold_upstream" || O === "domainfold_upstream_speed";
    }, E = (ae) => C(ae) ? (ae.SupportedProfiles || []).includes("domainfold") : !1, T = (ae, O, Ae) => {
      if (!ae)
        return [];
      const _e = /* @__PURE__ */ new Map();
      return ae.status.States.forEach((y) => {
        y.NodeID && _e.set(y.NodeID, y);
      }), ae.plan.Slots.reduce((y, Q) => {
        const Z = Q.Node;
        if (!Z || !O(Z))
          return y;
        const te = _e.get(Z.NodeID);
        if (!te)
          return y;
        const we = Ae ? Ae(Z) : void 0;
        return y.push(v(Z, te, we)), y;
      }, []);
    }, F = (ae) => T(ae, C, (O) => O.OutboundProxyURL ?? O.URL), j = (ae) => T(ae, E, (O) => O.OutboundProxyURL ?? O.URL), H = (ae) => T(ae, S, (O) => O.URL), B = (ae, O) => {
      if (!O || O.length === 0)
        return ae;
      const Ae = /* @__PURE__ */ new Map(), _e = /* @__PURE__ */ new Map();
      return O.forEach((y) => {
        const Q = y.node_id?.trim() || "";
        Q && Ae.set(Q, y);
        const Z = y.url?.trim() || "";
        Z && _e.set(Z, y);
      }), ae.map((y) => {
        const Q = y.nodeId?.trim() || "", Z = Q && Ae.get(Q) || _e.get(y.url);
        if (!Z)
          return y;
        const te = Z.effective_speed_bps ?? Z.speed_bps ?? 0;
        return {
          ...y,
          currentSpeed: h(te),
          totalDownloaded: x(Z.bytes_total ?? 0)
        };
      });
    }, P = (ae, O, Ae) => B(H(O || ae), Ae), $ = (ae) => {
      const O = /* @__PURE__ */ new Map();
      return ae.forEach((Ae) => {
        const _e = Ae.nodeId ? Ae.nodeId : `${Ae.name}:${Ae.url}`;
        O.has(_e) || O.set(_e, Ae);
      }), Array.from(O.values());
    }, V = K(!1), z = K(!1), G = K({ running: !1, profiles: [], force: !1 }), ee = L(() => G.value.running || z.value), xe = K(), de = Rt({
      version: ""
    }), W = () => {
      bw().then((ae) => {
        de.version = ae.version;
      });
    }, M = async () => {
      if (!t.isLogin) {
        ut.error("该功能仅登录后可用");
        return;
      }
      if (!(z.value && G.value.running)) {
        z.value = !0;
        try {
          if (await t0({ forceSpeedTest: !0, includeCfipTest: !0 })) {
            ut.success("已刷新镜像服务器状态，测速中..."), Me();
            return;
          }
          ut.error("刷新镜像服务器状态失败，请稍后重试"), z.value = !1;
        } catch {
          ut.error("刷新镜像服务器状态失败，请稍后重试"), z.value = !1;
        }
      }
    }, ge = (ae) => {
      ae.isCN === !0 ? s.value = "直连优化" : ae.isCN === !1 ? s.value = "国际优化" : s.value = "检测中", i.value = ae.source ?? "";
      const O = ae.error ?? "";
      l.value = ae.isCN === !0 ? "" : O;
    }, Me = async () => {
      try {
        const [ae, O] = await Promise.all([
          vw(),
          cS().catch(() => null)
        ]);
        ge(ae);
        const Ae = ae.mirrors.dockerhub || null, _e = ae.mirrors.ghcr || null, y = ae.snapshots["docker:dockerhub"] || null, Q = ae.snapshots["docker:ghcr"] || null, Z = ae.snapshots.domainfold || null, te = ae.snapshots.domainfold || null, we = ae.snapshots.__proxy_speed__ || null;
        G.value = ae.session, ae.session.running || (z.value = !1);
        const _ = [Ae, _e].filter(Boolean);
        n.stats.upstreamDownloadSpeed = Od(
          _.map((Y) => ba(Y.total_speed))
        );
        const A = Od(
          _.map((Y) => ba(Y.served_speed || Y.total_speed))
        );
        n.stats.downloadSpeed = Bd(A) < Bd(n.stats.upstreamDownloadSpeed) ? n.stats.upstreamDownloadSpeed : A, n.stats.upstreamDownloadSpeed.value > 0 && !V.value && (V.value = !0), n.stats.upstreamDownloadSpeed.value <= 0 && V.value && (V.value = !1, Ie()), n.stats.totalAccelerated = aS(
          _.map((Y) => ba(Y.total_download))
        ), n.mirrors.dockerHub = p(Ae?.mirrors || []), n.mirrors.ghcr = p(_e?.mirrors || []), n.proxies = $([
          ...F(y),
          ...F(Q),
          ...F(we)
        ]);
        const I = O?.upstreams ?? null, J = O?.proxies ?? null;
        n.domainfoldProxies = B(
          $([
            ...j(Z),
            ...j(we)
          ]),
          J
        ), n.domainfold = P(Z, te, I);
      } catch {
        z.value = !1;
      }
    };
    function Ie() {
      xe.value = setTimeout(
        async () => await t.refreshTrafficBalance(),
        120 * 1e3
      );
    }
    function ze() {
      Mo("click-wechat-group", { method: "client-dashboard" });
    }
    return $r(() => {
      f && clearInterval(f), xe.value && clearTimeout(xe.value);
    }), at(() => {
      W(), Me(), f = setInterval(() => {
        Me();
      }, 3e3);
    }), (ae, O) => {
      const Ae = pl("router-link");
      return g(), R("div", qS, [
        w("div", LS, [
          w("h1", NS, [
            ne(" KSpeeder " + ue(d(t).userLevelText) + " ", 1),
            de.version ? (g(), R("span", VS, " v" + ue(de.version), 1)) : $e("", !0)
          ]),
          O[14] || (O[14] = w("p", { class: "mt-4 text-sm text-muted-foreground max-w-2xl" }, [
            ne(" KSpeeder 使用 "),
            w("span", { class: "font-bold" }, " 多镜像并发下载 "),
            ne(", "),
            w("span", { class: "font-bold" }, " 动态负载均衡 "),
            ne(", "),
            w("span", { class: "font-bold" }, " 断点续传支持 "),
            ne(" 等技术帮你高速下载 Docker 镜像 ")
          ], -1)),
          d(t).isPlus ? (g(), R("p", HS, [
            O[4] || (O[4] = ne(" 感谢您支持 KSpeeder Plus，可以添加 ", -1)),
            k(d(fn), null, {
              default: b(() => [
                k(d(hn), null, {
                  default: b(() => [
                    w("p", {
                      class: "underline accent-green-200 cursor-pointer",
                      onClick: O[0] || (O[0] = (_e) => ze())
                    }, "会员群")
                  ]),
                  _: 1
                }),
                k(d(pn), null, {
                  default: b(() => O[3] || (O[3] = [
                    w("img", {
                      src: "https://delivery.limblimb.com/kspeeder/wechat-plus-group-1.png",
                      alt: "wechat-plus-group-1-qrcode"
                    }, null, -1)
                  ])),
                  _: 1,
                  __: [3]
                })
              ]),
              _: 1
            }),
            O[5] || (O[5] = ne(" 获取技术支持 ", -1))
          ])) : (g(), R("p", FS, [
            O[7] || (O[7] = ne(" 加入 ", -1)),
            k(d(fn), null, {
              default: b(() => [
                k(d(hn), null, {
                  default: b(() => [
                    w("p", {
                      class: "underline cursor-pointer text-",
                      onClick: O[1] || (O[1] = (_e) => ze())
                    }, "用户群")
                  ]),
                  _: 1
                }),
                k(d(pn), null, {
                  default: b(() => O[6] || (O[6] = [
                    w("img", {
                      src: "https://delivery.limblimb.com/kspeeder/wechat-group-1.png",
                      alt: "wechat-group-1-qrcode"
                    }, null, -1)
                  ])),
                  _: 1,
                  __: [6]
                })
              ]),
              _: 1
            }),
            O[8] || (O[8] = ne(" 参与 ", -1)),
            O[9] || (O[9] = w("a", {
              target: "_blank",
              href: "https://www.koolcenter.com/t/topic/7365",
              class: "underline"
            }, "KSpeeder Plus", -1)),
            O[10] || (O[10] = ne(" 内测，解锁高速通道 & 技术支持, 并支持我们持续开发新特性 ", -1))
          ])),
          w("p", zS, [
            O[12] || (O[12] = ne(" 关注 ", -1)),
            k(d(fn), null, {
              default: b(() => [
                k(d(hn), null, {
                  default: b(() => [
                    w("p", {
                      class: "underline accent-green-200 cursor-pointer",
                      onClick: O[2] || (O[2] = (_e) => ze())
                    }, " KSpeeder 服务号 ")
                  ]),
                  _: 1
                }),
                k(d(pn), null, {
                  default: b(() => O[11] || (O[11] = [
                    w("img", {
                      src: "https://delivery.limblimb.com/kspeeder/wechat-service-qrcode.jpg",
                      alt: "wechat-service-qrcode"
                    }, null, -1)
                  ])),
                  _: 1,
                  __: [11]
                })
              ]),
              _: 1
            }),
            O[13] || (O[13] = ne(" 获取最新动态 ", -1))
          ])
        ]),
        w("div", jS, [
          w("div", US, [
            k(d(yr), { class: "hover:shadow-lg transition-shadow" }, {
              default: b(() => [
                k(d(wr), null, {
                  default: b(() => [
                    w("div", ZS, [
                      O[15] || (O[15] = w("span", { class: "font-bold text-sm" }, "下载速度", -1)),
                      w("div", KS, [
                        k(d(S6), { class: "w-4 h-4 text-muted-foreground" })
                      ])
                    ]),
                    w("div", WS, [
                      k(d(Ya), {
                        value: n.stats.downloadSpeed.value
                      }, null, 8, ["value"]),
                      ne(" " + ue(n.stats.downloadSpeed.unit), 1)
                    ]),
                    w("div", GS, [
                      O[17] || (O[17] = w("p", { class: "text-sm text-muted-foreground" }, "业务侧下发速度（含缓存）", -1)),
                      w("div", JS, [
                        k(d(wd), { class: "w-3 h-3" }),
                        O[16] || (O[16] = w("span", null, "外网", -1)),
                        k(d(Ya), {
                          value: n.stats.upstreamDownloadSpeed.value
                        }, null, 8, ["value"]),
                        w("span", null, ue(n.stats.upstreamDownloadSpeed.unit), 1)
                      ])
                    ])
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            k(d(yr), { class: "hover:shadow-lg transition-shadow" }, {
              default: b(() => [
                k(d(wr), null, {
                  default: b(() => [
                    w("div", YS, [
                      O[18] || (O[18] = w("span", { class: "font-bold text-sm" }, "总计加速", -1)),
                      w("div", XS, [
                        k(d(C6), { class: "w-4 h-4 text-muted-foreground" })
                      ])
                    ]),
                    w("div", QS, [
                      k(d(Ya), {
                        value: n.stats.totalAccelerated.value
                      }, null, 8, ["value"]),
                      ne(" " + ue(n.stats.totalAccelerated.unit), 1)
                    ]),
                    O[19] || (O[19] = w("p", { class: "text-sm text-muted-foreground" }, "总加速流量", -1))
                  ]),
                  _: 1,
                  __: [19]
                })
              ]),
              _: 1
            }),
            k(d(yr), { class: "hover:shadow-lg transition-shadow" }, {
              default: b(() => [
                k(d(wr), null, {
                  default: b(() => [
                    w("div", e9, [
                      d(t).isPlus ? (g(), R("div", t9, [
                        O[20] || (O[20] = w("span", { class: "font-bold text-sm" }, " 高速通道已加速 ", -1)),
                        d(t).roleExpiredAt ? (g(), R("span", r9, "Plus 到期时间: " + ue(d(t).roleExpiredAt), 1)) : $e("", !0)
                      ])) : (g(), R("div", a9, O[21] || (O[21] = [
                        w("span", { class: "font-bold text-sm" }, " 高速通道 ", -1)
                      ]))),
                      w("div", o9, [
                        k(d(I6), { class: "w-4 h-4 text-muted-foreground" })
                      ])
                    ]),
                    d(t).isPlus ? (g(), R("div", n9, [
                      w("div", s9, [
                        k(d(Ya), {
                          value: d(t).usageTrafficWithUnit.value
                        }, null, 8, ["value"]),
                        ne(" " + ue(d(t).usageTrafficWithUnit.unit), 1)
                      ]),
                      w("div", i9, [
                        O[22] || (O[22] = ne(" 剩余流量: ", -1)),
                        k(d(Ya), {
                          value: d(t).balanceTrafficWithUnit.value
                        }, null, 8, ["value"]),
                        ne(" " + ue(d(t).balanceTrafficWithUnit.unit), 1)
                      ])
                    ])) : (g(), R("div", l9, [
                      O[24] || (O[24] = ne(" Plus专享，", -1)),
                      k(Ae, { to: "/login" }, {
                        default: b(() => O[23] || (O[23] = [
                          ne("登录", -1)
                        ])),
                        _: 1,
                        __: [23]
                      }),
                      O[25] || (O[25] = ne("查看 ", -1))
                    ]))
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          w("div", c9, [
            k(d(yr), { class: "hover:shadow-lg transition-shadow" }, {
              default: b(() => [
                k(d(Ra), null, {
                  default: b(() => [
                    k(d(Oa), { class: "flex items-center justify-between" }, {
                      default: b(() => [
                        O[26] || (O[26] = ne(" Docker 加速配置指南 ", -1)),
                        w("div", u9, [
                          k(d(v6), { class: "w-4 h-4 text-muted-foreground" })
                        ])
                      ]),
                      _: 1,
                      __: [26]
                    }),
                    k(d(Co), null, {
                      default: b(() => O[27] || (O[27] = [
                        ne(" 将 KSpeeder 加速服务地址配置到 docker daemon -> 正常使用 ", -1)
                      ])),
                      _: 1,
                      __: [27]
                    })
                  ]),
                  _: 1
                }),
                k(d(wr), null, {
                  default: b(() => [
                    k(d(Sd), {
                      "default-value": "docker-pull-test",
                      class: "h-full space-y-6"
                    }, {
                      default: b(() => [
                        w("div", d9, [
                          k(d(Ed), null, {
                            default: b(() => [
                              k(d(Br), {
                                value: "docker-pull-test",
                                class: "text-sm px-2"
                              }, {
                                default: b(() => [
                                  k(d(nA)),
                                  O[28] || (O[28] = ne(" 测试拉取 ", -1))
                                ]),
                                _: 1,
                                __: [28]
                              }),
                              k(d(Br), {
                                value: "docker-daemon-setup",
                                class: "relative text-sm px-4"
                              }, {
                                default: b(() => [
                                  k(d(GA)),
                                  O[29] || (O[29] = ne(" 配置加速地址 ", -1))
                                ]),
                                _: 1,
                                __: [29]
                              }),
                              k(d(Br), {
                                value: "docker-pull-real-world",
                                class: "text-sm px-2"
                              }, {
                                default: b(() => [
                                  k(d(EA)),
                                  O[30] || (O[30] = ne(" 拉取 docker.io 镜像 ", -1))
                                ]),
                                _: 1,
                                __: [30]
                              }),
                              k(d(Br), {
                                value: "ghcr-real-world",
                                class: "text-sm px-2"
                              }, {
                                default: b(() => [
                                  k(d(qC)),
                                  O[31] || (O[31] = ne(" 拉取 ghcr.io 镜像 ", -1))
                                ]),
                                _: 1,
                                __: [31]
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        k(d(Or), {
                          value: "docker-pull-test",
                          class: "border-none p-0 outline-none"
                        }, {
                          default: b(() => [
                            O[32] || (O[32] = w("div", null, [
                              w("p", { class: "text-xm text-muted-foreground pb-6" }, " 您可以直接用此命令拉取镜像获得加速 ( 必须在安装 KSpeeder 的机器执行 ) ")
                            ], -1)),
                            k(dn, { "command-text": "docker pull registry.linkease.net:5443/library/alpine" })
                          ]),
                          _: 1,
                          __: [32]
                        }),
                        k(d(Or), {
                          value: "docker-daemon-setup",
                          class: "border-none p-0 outline-none"
                        }, {
                          default: b(() => [
                            O[33] || (O[33] = w("div", null, [
                              w("p", { class: "text-xm text-muted-foreground" }, " 配置加速镜像让你直接使用镜像拉取命令而无需修改域名 ")
                            ], -1)),
                            w("div", f9, [
                              (g(), R(Be, null, qt(o, (_e) => w("a", {
                                key: _e.url,
                                href: _e.url,
                                target: "_blank",
                                class: "flex flex-col hover:bg-muted rounded-full py-2 items-center text-center w-[100px] cursor-pointer"
                              }, [
                                w("div", h9, [
                                  (g(), N(Qt(_e.logo), { class: "w-8 h-8 text-muted-foreground" }))
                                ]),
                                w("div", null, [
                                  w("p", g9, ue(_e.name), 1)
                                ])
                              ], 8, p9)), 64))
                            ])
                          ]),
                          _: 1,
                          __: [33]
                        }),
                        k(d(Or), {
                          value: "docker-pull-real-world",
                          class: "border-none p-0 outline-none"
                        }, {
                          default: b(() => [
                            O[34] || (O[34] = w("div", null, [
                              w("p", { class: "text-xm text-muted-foreground pb-6" }, [
                                ne(" 配置加速镜像后, "),
                                w("code", null, "docker.io"),
                                ne(" 的镜像直接拉取也会被加速, 例如: ")
                              ])
                            ], -1)),
                            k(dn, { "command-text": "docker pull mysql" })
                          ]),
                          _: 1,
                          __: [34]
                        }),
                        k(d(Or), {
                          value: "ghcr-real-world",
                          class: "border-none p-0 outline-none"
                        }, {
                          default: b(() => [
                            O[35] || (O[35] = w("div", null, [
                              w("p", { class: "text-xm text-muted-foreground pb-6" }, " GHCR 同样支持加速，将 ghcr.io 域名替换为 ghcr.linkease.net:5443 即可，例如: ")
                            ], -1)),
                            k(dn, { "command-text": "docker pull ghcr.linkease.net:5443/n8n-io/n8n:latest" })
                          ]),
                          _: 1,
                          __: [35]
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          w("div", m9, [
            k(d(yr), { class: "hover:shadow-lg transition-shadow" }, {
              default: b(() => [
                k(d(Ra), null, {
                  default: b(() => [
                    k(d(Oa), { class: "flex items-center justify-between" }, {
                      default: b(() => [
                        O[36] || (O[36] = ne(" 镜像服务器列表 ", -1)),
                        w("div", v9, [
                          w("div", {
                            class: ke(["w-8 h-8 rounded-lg flex items-center justify-center cursor-pointer", [
                              d(t).isLogin ? "" : "opacity-60",
                              ee.value ? "pointer-events-none bg-muted/20" : ""
                            ]]),
                            onClick: M
                          }, [
                            k(d(ak), {
                              class: ke([
                                "w-4 h-4 text-muted-foreground transition-colors",
                                ee.value ? "animate-spin text-primary" : "hover:text-blue-400"
                              ])
                            }, null, 8, ["class"])
                          ], 2),
                          w("div", b9, [
                            k(d(wd), { class: "w-4 h-4 text-muted-foreground" })
                          ])
                        ])
                      ]),
                      _: 1,
                      __: [36]
                    }),
                    k(d(Co), { class: "flex flex-wrap items-center gap-2" }, {
                      default: b(() => [
                        O[38] || (O[38] = ne(" 实时监控加速服务器状态和性能指标 ", -1)),
                        w("span", y9, [
                          O[37] || (O[37] = ne(" 当前使用： ", -1)),
                          w("span", {
                            class: ke(["font-medium", [u.value]]),
                            title: c.value
                          }, " 【" + ue(s.value) + "】 ", 11, w9)
                        ])
                      ]),
                      _: 1,
                      __: [38]
                    }),
                    l.value ? (g(), R("div", x9, " 探测失败：" + ue(l.value), 1)) : $e("", !0),
                    G.value.cfip_running ? (g(), R("div", _9, " 正在获取 CFIP 优选 IP（计算中，可能需要几十秒）… ")) : $e("", !0)
                  ]),
                  _: 1
                }),
                k(d(wr), null, {
                  default: b(() => [
                    k(d(Sd), {
                      "default-value": "dockerhub",
                      class: "h-full space-y-4"
                    }, {
                      default: b(() => [
                        w("div", k9, [
                          k(d(Ed), null, {
                            default: b(() => [
                              k(d(Br), {
                                value: "dockerhub",
                                class: "text-sm px-2"
                              }, {
                                default: b(() => O[39] || (O[39] = [
                                  ne("DockerHub", -1)
                                ])),
                                _: 1,
                                __: [39]
                              }),
                              k(d(Br), {
                                value: "ghcr",
                                class: "text-sm px-2"
                              }, {
                                default: b(() => O[40] || (O[40] = [
                                  ne("GHCR", -1)
                                ])),
                                _: 1,
                                __: [40]
                              }),
                              k(d(Br), {
                                value: "domainfold",
                                class: "text-sm px-2"
                              }, {
                                default: b(() => O[41] || (O[41] = [
                                  ne("域名", -1)
                                ])),
                                _: 1,
                                __: [41]
                              }),
                              k(d(Br), {
                                value: "socks5",
                                class: "text-sm px-2"
                              }, {
                                default: b(() => O[42] || (O[42] = [
                                  ne("通用", -1)
                                ])),
                                _: 1,
                                __: [42]
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        k(d(Or), {
                          value: "dockerhub",
                          class: "border-none p-0 outline-none"
                        }, {
                          default: b(() => [
                            k(Xa, {
                              mirrors: n.mirrors.dockerHub
                            }, null, 8, ["mirrors"])
                          ]),
                          _: 1
                        }),
                        k(d(Or), {
                          value: "ghcr",
                          class: "relative border-none p-0 outline-none"
                        }, {
                          default: b(() => [
                            w("div", {
                              class: ke([
                                "relative",
                                r.value ? "pointer-events-none select-none blur-[2px]" : ""
                              ])
                            }, [
                              k(Xa, {
                                mirrors: n.mirrors.ghcr,
                                "empty-description": "暂无 ghcr.io 镜像服务器"
                              }, null, 8, ["mirrors"])
                            ], 2),
                            r.value ? (g(), R("div", C9, [
                              d(t).isLogin ? (g(), R("a", {
                                key: 1,
                                href: $9,
                                target: "_blank",
                                class: "rounded-full border px-6 py-3 text-sm font-medium text-primary underline bg-card/70"
                              }, " 升级 Plus 用户，解锁 GHCR 镜像功能 ")) : (g(), R("p", A9, [
                                O[44] || (O[44] = ne(" 该功能仅供 Plus 用户使用， ", -1)),
                                k(Ae, {
                                  class: "underline text-primary",
                                  to: "/login"
                                }, {
                                  default: b(() => O[43] || (O[43] = [
                                    ne("登录", -1)
                                  ])),
                                  _: 1,
                                  __: [43]
                                }),
                                O[45] || (O[45] = ne(" 查看 ", -1))
                              ]))
                            ])) : $e("", !0)
                          ]),
                          _: 1
                        }),
                        k(d(Or), {
                          value: "domainfold",
                          class: "relative border-none p-0 outline-none"
                        }, {
                          default: b(() => [
                            w("div", {
                              class: ke([
                                "relative",
                                a.value ? "pointer-events-none select-none blur-[2px]" : ""
                              ])
                            }, [
                              O[46] || (O[46] = w("div", { class: "px-2 py-2 text-xs text-muted-foreground" }, "域名代理", -1)),
                              k(Xa, {
                                mirrors: n.domainfoldProxies,
                                "empty-description": "暂无域名代理节点"
                              }, null, 8, ["mirrors"]),
                              O[47] || (O[47] = w("div", { class: "px-2 py-2 text-xs text-muted-foreground" }, "上游节点", -1)),
                              k(Xa, {
                                mirrors: n.domainfold,
                                "empty-description": "暂无域名节点"
                              }, null, 8, ["mirrors"])
                            ], 2),
                            a.value ? (g(), R("div", S9, [
                              w("p", E9, [
                                O[49] || (O[49] = ne(" 该功能仅登录后可用， ", -1)),
                                k(Ae, {
                                  class: "underline text-primary",
                                  to: "/login"
                                }, {
                                  default: b(() => O[48] || (O[48] = [
                                    ne("登录", -1)
                                  ])),
                                  _: 1,
                                  __: [48]
                                }),
                                O[50] || (O[50] = ne(" 查看 ", -1))
                              ])
                            ])) : $e("", !0)
                          ]),
                          _: 1
                        }),
                        k(d(Or), {
                          value: "socks5",
                          class: "border-none p-0 outline-none"
                        }, {
                          default: b(() => [
                            k(Xa, {
                              mirrors: n.proxies,
                              "empty-description": "暂无通用代理节点"
                            }, null, 8, ["mirrors"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ])
        ])
      ]);
    };
  }
}), T9 = /* @__PURE__ */ D({
  __name: "HomeView",
  setup(e) {
    return (t, r) => (g(), N(P9));
  }
}), Dd = /* @__PURE__ */ D({
  __name: "Label",
  props: {
    for: {},
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class");
    return (a, o) => (g(), N(d(D_), re({ "data-slot": "label" }, d(r), {
      class: d(ve)(
        "flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50",
        t.class
      )
    }), {
      default: b(() => [
        q(a.$slots, "default")
      ]),
      _: 3
    }, 16, ["class"]));
  }
}), M9 = /* @__PURE__ */ D({
  __name: "Collapsible",
  props: {
    defaultOpen: { type: Boolean },
    open: { type: Boolean },
    disabled: { type: Boolean },
    unmountOnHide: { type: Boolean },
    asChild: { type: Boolean },
    as: {}
  },
  emits: ["update:open"],
  setup(e, { emit: t }) {
    const o = rt(e, t);
    return (n, s) => (g(), N(d(U2), re({ "data-slot": "collapsible" }, d(o)), {
      default: b((i) => [
        q(n.$slots, "default", De(Fe(i)))
      ]),
      _: 3
    }, 16));
  }
}), R9 = /* @__PURE__ */ D({
  __name: "CollapsibleTrigger",
  props: {
    asChild: { type: Boolean },
    as: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(K2), re({ "data-slot": "collapsible-trigger" }, t), {
      default: b(() => [
        q(r.$slots, "default")
      ]),
      _: 3
    }, 16));
  }
}), O9 = { class: "min-h-screen bg-background px-16 mt-3 max-w-[100rem]" }, B9 = { class: "mb-8" }, D9 = { class: "text-4xl font-bold text-foreground mb-4 flex items-center gap-3" }, I9 = { class: "space-y-2" }, q9 = { class: "flex gap-2" }, L9 = {
  key: 0,
  class: "text-xs text-destructive"
}, N9 = {
  key: 0,
  class: "space-y-3"
}, V9 = { class: "space-y-2" }, H9 = { class: "flex items-center gap-2" }, F9 = ["value"], z9 = {
  key: 0,
  class: "space-y-2"
}, j9 = { class: "flex items-center gap-2" }, U9 = {
  key: 0,
  class: "text-sm text-muted-foreground"
}, Z9 = {
  key: 1,
  class: "text-sm text-destructive"
}, K9 = {
  key: 2,
  class: "space-y-6"
}, W9 = { class: "space-y-2" }, G9 = { class: "text-xs text-muted-foreground px-1" }, J9 = {
  key: 0,
  class: "text-sm text-muted-foreground px-1"
}, Y9 = {
  key: 1,
  class: "space-y-2"
}, X9 = { class: "text-sm break-all" }, Q9 = { class: "font-mono" }, eE = { class: "font-mono" }, tE = { class: "space-y-2" }, rE = { class: "text-xs text-muted-foreground px-1" }, aE = {
  key: 0,
  class: "text-sm text-muted-foreground px-1"
}, oE = {
  key: 1,
  class: "space-y-2"
}, nE = { class: "text-sm break-all" }, sE = { class: "font-mono" }, iE = { class: "font-mono" }, lE = {
  key: 0,
  class: "text-xs text-muted-foreground px-1"
}, cE = { class: "space-y-3" }, uE = { class: "flex items-center justify-between gap-4" }, dE = { class: "text-xs text-muted-foreground px-1" }, fE = {
  key: 0,
  class: "space-y-6"
}, pE = { class: "text-xs text-muted-foreground px-1" }, hE = { class: "space-y-2" }, gE = { class: "text-sm break-all" }, mE = { class: "font-mono" }, vE = { class: "font-mono" }, bE = /* @__PURE__ */ D({
  __name: "DomainAccelerationView",
  setup(e) {
    const r = K("https://github.com/linkease/istore-repo/raw/refs/heads/main/bin/packages/x86_64/nas/linkease_1.7.5-8664-4_all.ipk"), a = K(!1), o = K(""), n = K(""), s = K(!1);
    let i = null;
    const l = K(""), c = K(""), u = K(null), f = K(!1), p = K(""), h = K([]), m = (W) => {
      const M = (W || "").trim();
      return M ? M.startsWith("/") ? M : `/${M}` : "";
    }, v = (W) => {
      const M = m(W.prefix);
      return M === "/gh" || M === "/gist" || M === "/homebrew" ? "github" : M.startsWith("/ip-") ? "ai_api" : M.startsWith("/cr-") || M === "/homebrew-bottles" ? "container_registry" : M === "/npm" || M === "/pypi" || M === "/pypi-files" || M === "/conda" || M === "/conda-community" || M === "/maven" || M === "/gradle" || M === "/apache" || M === "/homebrew-api" || M === "/rubygems" || M === "/cran" || M === "/cpan" || M === "/ctan" || M === "/golang" || M === "/nuget" || M === "/crates" || M === "/packagist" ? "package_registry" : M === "/debian" || M === "/ubuntu" || M === "/fedora" || M === "/rocky" || M === "/opensuse" || M === "/arch" || M === "/fdroid" ? "linux_mirrors" : M === "/gl" || M === "/gitea" || M === "/codeberg" || M === "/sf" || M === "/aosp" ? "code_hosting" : M === "/hf" || M === "/civitai" ? "models_data" : M === "/jenkins" ? "tools_updates" : M === "/arxiv" ? "academic" : "other";
    }, x = L(() => {
      const W = {
        github: [],
        ai_api: [],
        container_registry: [],
        package_registry: [],
        linux_mirrors: [],
        code_hosting: [],
        models_data: [],
        tools_updates: [],
        academic: [],
        other: []
      };
      return h.value.forEach((M) => {
        W[v(M)].push(M);
      }), [
        { key: "github", label: "GitHub", items: W.github },
        { key: "ai_api", label: "AI API", items: W.ai_api },
        { key: "container_registry", label: "容器镜像仓库", items: W.container_registry },
        { key: "package_registry", label: "包管理/依赖仓库", items: W.package_registry },
        { key: "linux_mirrors", label: "Linux/软件源", items: W.linux_mirrors },
        { key: "code_hosting", label: "代码托管（其他）", items: W.code_hosting },
        { key: "models_data", label: "模型与数据", items: W.models_data },
        { key: "tools_updates", label: "工具更新", items: W.tools_updates },
        { key: "academic", label: "学术", items: W.academic },
        { key: "other", label: "其他", items: W.other }
      ];
    }), C = L(() => x.value.find((W) => W.key === "github")), S = L(() => x.value.find((W) => W.key === "ai_api")), E = L(() => S.value.items.slice(0, 3)), T = L(() => S.value.items.slice(3)), F = L(() => T.value.length), j = L(() => {
      const W = x.value.filter((M) => M.key !== "github" && M.key !== "ai_api" && M.items.length > 0);
      return T.value.length === 0 ? W : [{ key: "ai_api", label: "AI API（更多）", items: T.value }, ...W];
    }), H = L(
      () => j.value.reduce((W, M) => W + M.items.length, 0)
    ), B = qa(), P = Cl();
    let $ = null;
    const V = L(() => c.value ? `${window.location.origin}${c.value}` : ""), z = async ({ auto: W }) => {
      const M = r.value.trim();
      if (M) {
        a.value = !0, o.value = "";
        try {
          const ge = await iS(M);
          if (l.value = ge.output || "", c.value = ge.admin_path || "", !l.value) {
            const Me = "转换失败：返回结果为空";
            o.value = Me, W || ut.error(Me);
            return;
          }
          n.value = M, s.value = !0, i && window.clearTimeout(i), i = window.setTimeout(() => {
            s.value = !1, i = null;
          }, 1200), W || ut.success("转换成功");
        } catch (ge) {
          l.value = "", c.value = "";
          const Me = ge instanceof Error ? ge.message : !ge || typeof ge != "object" ? "未知错误" : ge.response?.data?.error || "未知错误";
          o.value = `转换失败：${Me}`, W || ut.error(o.value);
        } finally {
          a.value = !1;
        }
      }
    }, G = /* @__PURE__ */ r3(async () => {
      const W = r.value.trim();
      if (!W) {
        l.value = "", c.value = "", o.value = "", n.value = "";
        return;
      }
      W !== n.value && (a.value || await z({ auto: !0 }));
    }, 500);
    Ke(
      r,
      () => {
        G();
      },
      { immediate: !0 }
    );
    const ee = () => {
      const W = u.value;
      W && (W.focus(), W.select());
    }, xe = async () => {
      const W = l.value.trim();
      if (W)
        try {
          await navigator.clipboard.writeText(W), ut.success("已复制加速链接");
        } catch {
          ee(), ut.error("复制失败，请手动复制（已全选）");
        }
    }, de = () => {
      if (!B.isLogin) {
        ut.error("该功能仅登录后可用，3 秒后跳转登录页"), $ && window.clearTimeout($), $ = window.setTimeout(() => {
          $ = null, P.push("/login");
        }, 3e3);
        return;
      }
      const W = V.value;
      W && window.open(W, "_blank", "noreferrer");
    };
    return $r(() => {
      $ && (window.clearTimeout($), $ = null);
    }), at(async () => {
      f.value = !0, p.value = "";
      try {
        const W = await lS();
        h.value = W.routes || [];
      } catch (W) {
        const M = W instanceof Error ? W.message : !W || typeof W != "object" ? "加载失败" : W.response?.data?.error || "加载失败";
        p.value = M;
      } finally {
        f.value = !1;
      }
    }), (W, M) => (g(), R("div", O9, [
      w("div", B9, [
        w("h1", D9, [
          M[6] || (M[6] = ne(" 域名加速 ", -1)),
          k(d(Hr), {
            variant: "secondary",
            class: "h-6 px-2 rounded-sm"
          }, {
            default: b(() => M[5] || (M[5] = [
              ne("Beta", -1)
            ])),
            _: 1,
            __: [5]
          })
        ]),
        M[7] || (M[7] = w("p", { class: "mt-4 text-sm text-muted-foreground max-w-2xl" }, " 加速 github raw/release 等等常见域名，自动转换为 KSpeeder DomainFold 加速链接 ", -1))
      ]),
      k(d(yr), { class: "max-w-[72rem]" }, {
        default: b(() => [
          k(d(Ra), null, {
            default: b(() => [
              k(d(Oa), null, {
                default: b(() => M[8] || (M[8] = [
                  ne("链接转换", -1)
                ])),
                _: 1,
                __: [8]
              }),
              k(d(Co), null, {
                default: b(() => M[9] || (M[9] = [
                  ne("复制加速链接，或使用浏览器通过管理端口立即下载。", -1)
                ])),
                _: 1,
                __: [9]
              })
            ]),
            _: 1
          }),
          k(d(wr), { class: "space-y-4" }, {
            default: b(() => [
              w("div", I9, [
                k(d(Dd), { for: "origin-url" }, {
                  default: b(() => M[10] || (M[10] = [
                    ne("原始链接", -1)
                  ])),
                  _: 1,
                  __: [10]
                }),
                w("div", q9, [
                  k(d(T3), {
                    id: "origin-url",
                    modelValue: r.value,
                    "onUpdate:modelValue": M[0] || (M[0] = (ge) => r.value = ge),
                    placeholder: "https://github.com/...",
                    class: "flex-1",
                    onKeydown: M[1] || (M[1] = wl(ir((ge) => z({ auto: !1 }), ["prevent"]), ["enter"]))
                  }, null, 8, ["modelValue"]),
                  k(d(xr), {
                    disabled: a.value || !r.value.trim(),
                    onClick: M[2] || (M[2] = (ge) => z({ auto: !1 }))
                  }, {
                    default: b(() => [
                      ne(ue(a.value ? "转换中..." : "转换"), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled"])
                ]),
                o.value ? (g(), R("p", L9, ue(o.value), 1)) : $e("", !0)
              ]),
              l.value ? (g(), R("div", N9, [
                w("div", V9, [
                  k(d(Dd), null, {
                    default: b(() => M[11] || (M[11] = [
                      ne("加速链接（TLS）", -1)
                    ])),
                    _: 1,
                    __: [11]
                  }),
                  w("div", H9, [
                    w("input", {
                      ref_key: "tlsInputEl",
                      ref: u,
                      value: l.value,
                      readonly: "",
                      class: ke([
                        "file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input flex h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-sm shadow-xs transition-[color,box-shadow,background-color,border-color] outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]",
                        s.value ? "border-emerald-400/60 bg-emerald-50/60 ring-2 ring-emerald-400/40 ring-offset-2 ring-offset-background dark:border-emerald-400/30 dark:bg-emerald-950/20" : ""
                      ]),
                      onFocus: ee,
                      onClick: ee
                    }, null, 42, F9),
                    k(d(xr), {
                      variant: "secondary",
                      size: "sm",
                      onClick: M[3] || (M[3] = (ge) => xe())
                    }, {
                      default: b(() => M[12] || (M[12] = [
                        ne("复制", -1)
                      ])),
                      _: 1,
                      __: [12]
                    })
                  ])
                ]),
                V.value ? (g(), R("div", z9, [
                  w("div", j9, [
                    k(d(xr), {
                      size: "sm",
                      onClick: M[4] || (M[4] = (ge) => de())
                    }, {
                      default: b(() => M[13] || (M[13] = [
                        ne("浏览器直接下载", -1)
                      ])),
                      _: 1,
                      __: [13]
                    })
                  ])
                ])) : $e("", !0)
              ])) : $e("", !0)
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      k(d(yr), { class: "max-w-[72rem] mt-6" }, {
        default: b(() => [
          k(d(Ra), null, {
            default: b(() => [
              k(d(Oa), null, {
                default: b(() => M[14] || (M[14] = [
                  ne("支持加速的所有域名", -1)
                ])),
                _: 1,
                __: [14]
              })
            ]),
            _: 1
          }),
          k(d(wr), null, {
            default: b(() => [
              f.value ? (g(), R("div", U9, "加载中...")) : p.value ? (g(), R("div", Z9, ue(p.value), 1)) : (g(), R("div", K9, [
                w("div", W9, [
                  w("div", G9, " GitHub（共 " + ue(C.value.items.length) + " 条） ", 1),
                  C.value.items.length === 0 ? (g(), R("div", J9, " 暂无 GitHub 相关域名 ")) : (g(), R("div", Y9, [
                    (g(!0), R(Be, null, qt(C.value.items, (ge) => (g(), R("div", {
                      key: ge.alias_host
                    }, [
                      w("p", X9, [
                        w("span", Q9, ue(ge.origin_url), 1),
                        M[15] || (M[15] = w("span", { class: "mx-2 text-muted-foreground" }, "→", -1)),
                        w("span", eE, ue(ge.alias_url), 1)
                      ])
                    ]))), 128))
                  ]))
                ]),
                w("div", tE, [
                  w("div", rE, " AI API（共 " + ue(S.value.items.length) + " 条） ", 1),
                  S.value.items.length === 0 ? (g(), R("div", aE, " 暂无 AI API 相关域名 ")) : (g(), R("div", oE, [
                    (g(!0), R(Be, null, qt(E.value, (ge) => (g(), R("div", {
                      key: ge.alias_host
                    }, [
                      w("p", nE, [
                        w("span", sE, ue(ge.origin_url), 1),
                        M[16] || (M[16] = w("span", { class: "mx-2 text-muted-foreground" }, "→", -1)),
                        w("span", iE, ue(ge.alias_url), 1)
                      ])
                    ]))), 128)),
                    F.value > 0 ? (g(), R("div", lE, " 还有 " + ue(F.value) + " 条已折叠，点击下方“查看更多”查看 ", 1)) : $e("", !0)
                  ]))
                ]),
                k(d(M9), null, {
                  default: b(({ open: ge }) => [
                    w("div", cE, [
                      w("div", uE, [
                        w("div", dE, " 其他分组（共 " + ue(H.value) + " 条） ", 1),
                        k(d(R9), { "as-child": "" }, {
                          default: b(() => [
                            k(d(xr), {
                              variant: "secondary",
                              size: "sm"
                            }, {
                              default: b(() => [
                                ne(ue(ge ? "收起" : "查看更多"), 1)
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      ge ? (g(), R("div", fE, [
                        (g(!0), R(Be, null, qt(j.value, (Me) => (g(), R("div", {
                          key: Me.key,
                          class: "space-y-2"
                        }, [
                          w("div", pE, ue(Me.label) + "（共 " + ue(Me.items.length) + " 条） ", 1),
                          w("div", hE, [
                            (g(!0), R(Be, null, qt(Me.items, (Ie) => (g(), R("div", {
                              key: Ie.alias_host
                            }, [
                              w("p", gE, [
                                w("span", mE, ue(Ie.origin_url), 1),
                                M[17] || (M[17] = w("span", { class: "mx-2 text-muted-foreground" }, "→", -1)),
                                w("span", vE, ue(Ie.alias_url), 1)
                              ])
                            ]))), 128))
                          ])
                        ]))), 128))
                      ])) : $e("", !0)
                    ])
                  ]),
                  _: 1
                })
              ]))
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]));
  }
}), yE = /* @__PURE__ */ D({
  __name: "AlertDialog",
  props: {
    open: { type: Boolean },
    defaultOpen: { type: Boolean }
  },
  emits: ["update:open"],
  setup(e, { emit: t }) {
    const o = rt(e, t);
    return (n, s) => (g(), N(d(Z8), re({ "data-slot": "alert-dialog" }, d(o)), {
      default: b((i) => [
        q(n.$slots, "default", De(Fe(i)))
      ]),
      _: 3
    }, 16));
  }
}), wE = /* @__PURE__ */ D({
  __name: "AlertDialogAction",
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class");
    return (a, o) => (g(), N(d(R8), re(d(r), {
      class: d(ve)(d(ec)(), t.class)
    }), {
      default: b(() => [
        q(a.$slots, "default")
      ]),
      _: 3
    }, 16, ["class"]));
  }
}), xE = /* @__PURE__ */ D({
  __name: "AlertDialogCancel",
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class");
    return (a, o) => (g(), N(d(L8), re(d(r), {
      class: d(ve)(
        d(ec)({ variant: "outline" }),
        "mt-2 sm:mt-0",
        t.class
      )
    }), {
      default: b(() => [
        q(a.$slots, "default")
      ]),
      _: 3
    }, 16, ["class"]));
  }
}), _E = /* @__PURE__ */ D({
  inheritAttrs: !1,
  __name: "AlertDialogContent",
  props: {
    forceMount: { type: Boolean },
    disableOutsidePointerEvents: { type: Boolean },
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  emits: ["escapeKeyDown", "pointerDownOutside", "focusOutside", "interactOutside", "openAutoFocus", "closeAutoFocus"],
  setup(e, { emit: t }) {
    const r = e, a = t, o = Ye(r, "class"), n = rt(o, a);
    return (s, i) => (g(), N(d(j8), null, {
      default: b(() => [
        k(d(F8), {
          "data-slot": "alert-dialog-overlay",
          class: "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/80"
        }),
        k(d(I8), re({ "data-slot": "alert-dialog-content" }, { ...s.$attrs, ...d(n) }, {
          class: d(ve)(
            "bg-background data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border p-6 shadow-lg duration-200 sm:max-w-lg",
            r.class
          )
        }), {
          default: b(() => [
            q(s.$slots, "default")
          ]),
          _: 3
        }, 16, ["class"])
      ]),
      _: 3
    }));
  }
}), kE = /* @__PURE__ */ D({
  __name: "AlertDialogDescription",
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class");
    return (a, o) => (g(), N(d(V8), re({ "data-slot": "alert-dialog-description" }, d(r), {
      class: d(ve)("text-muted-foreground text-sm", t.class)
    }), {
      default: b(() => [
        q(a.$slots, "default")
      ]),
      _: 3
    }, 16, ["class"]));
  }
}), CE = /* @__PURE__ */ D({
  __name: "AlertDialogFooter",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("div", {
      "data-slot": "alert-dialog-footer",
      class: ke(
        d(ve)(
          "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
          t.class
        )
      )
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), AE = /* @__PURE__ */ D({
  __name: "AlertDialogHeader",
  props: {
    class: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), R("div", {
      "data-slot": "alert-dialog-header",
      class: ke(d(ve)("flex flex-col gap-2 text-center sm:text-left", t.class))
    }, [
      q(r.$slots, "default")
    ], 2));
  }
}), SE = /* @__PURE__ */ D({
  __name: "AlertDialogTitle",
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(e) {
    const t = e, r = Ye(t, "class");
    return (a, o) => (g(), N(d(W8), re({ "data-slot": "alert-dialog-title" }, d(r), {
      class: d(ve)("text-lg font-semibold", t.class)
    }), {
      default: b(() => [
        q(a.$slots, "default")
      ]),
      _: 3
    }, 16, ["class"]));
  }
}), EE = /* @__PURE__ */ D({
  __name: "AlertDialogTrigger",
  props: {
    asChild: { type: Boolean },
    as: {}
  },
  setup(e) {
    const t = e;
    return (r, a) => (g(), N(d(J8), re({ "data-slot": "alert-dialog-trigger" }, t), {
      default: b(() => [
        q(r.$slots, "default")
      ]),
      _: 3
    }, 16));
  }
}), $E = async () => {
  const t = (await St.post("/api/cache/cleanup")).data;
  return {
    status: t.status,
    cachePath: t.cache_path,
    deletedEntries: t.deleted_entries,
    skippedEntries: t.skipped_entries,
    errors: t.errors,
    errorDetails: t.error_details,
    tookMs: t.took_ms
  };
}, PE = { class: "min-h-screen bg-background px-16 mt-3 max-w-[100rem]" }, TE = { class: "grid grid-cols-1 gap-6" }, ME = { class: "space-y-4" }, RE = {
  key: 0,
  class: "text-sm rounded-md border p-4 bg-card"
}, OE = { key: 0 }, BE = {
  key: 1,
  class: "mt-2 text-xs text-muted-foreground whitespace-pre-wrap"
}, DE = {
  key: 1,
  class: "text-sm rounded-md border p-4 bg-card text-destructive"
}, IE = { class: "mt-auto space-y-3" }, qE = { class: "flex items-center gap-3" }, LE = /* @__PURE__ */ D({
  __name: "CacheCleanupView",
  setup(e) {
    const t = K(!1), r = K(null), a = K(""), o = K(""), n = L(() => !t.value), s = () => (/* @__PURE__ */ new Date()).toLocaleString(), i = async () => {
      if (!t.value) {
        t.value = !0, o.value = "";
        try {
          const l = await $E();
          r.value = l, a.value = s(), l.errors > 0 ? ut.error(`清理完成，但有 ${l.errors} 个错误`) : ut.success("已清理全部缓存");
        } catch (l) {
          const c = l instanceof Error ? l.message : !l || typeof l != "object" ? "" : l.response?.data?.error || "";
          o.value = c || "清理失败，请稍后重试", ut.error(c ? `清理失败：${c}` : "清理失败，请稍后重试");
        } finally {
          t.value = !1;
        }
      }
    };
    return (l, c) => (g(), R("div", PE, [
      c[7] || (c[7] = w("div", { class: "mb-8" }, [
        w("h1", { class: "text-4xl font-bold text-foreground mb-4" }, "工具")
      ], -1)),
      w("div", TE, [
        k(d(yr), null, {
          default: b(() => [
            k(d(Ra), null, {
              default: b(() => [
                k(d(Oa), { class: "flex items-center justify-between" }, {
                  default: b(() => [
                    c[0] || (c[0] = ne(" 强制清理缓存 ", -1)),
                    k(d(th), { class: "w-4 h-4 text-muted-foreground" })
                  ]),
                  _: 1,
                  __: [0]
                }),
                k(d(Co), null, {
                  default: b(() => c[1] || (c[1] = [
                    w("div", { class: "text-sm text-muted-foreground max-w-3xl space-y-2" }, [
                      w("div", { class: "font-medium text-foreground/90" }, "用途说明"),
                      w("p", null, [
                        ne(" 如果出现 docker 镜像反复拉取失败，或者下载的镜像 hash 校验失败，清理缓存大概率能帮你解决此问题； 如果还有问题，请 "),
                        w("a", {
                          class: "underline underline-offset-4 text-primary",
                          href: "https://www.koolcenter.com/c/soft-guides/kspeeder/19",
                          target: "_blank",
                          rel: "noreferrer"
                        }, "联系我们"),
                        ne(" 。 ")
                      ]),
                      w("div", { class: "font-medium text-foreground/90" }, "影响"),
                      w("ul", { class: "list-disc pl-5 space-y-1" }, [
                        w("li", null, "可能影响正在进行的下载"),
                        w("li", null, "可能影响断点续传"),
                        w("li", null, "可能需要重新下载或重新测速")
                      ])
                    ], -1)
                  ])),
                  _: 1,
                  __: [1]
                })
              ]),
              _: 1
            }),
            k(d(wr), { class: "flex flex-col gap-4" }, {
              default: b(() => [
                w("div", ME, [
                  r.value ? (g(), R("div", RE, [
                    c[2] || (c[2] = w("div", { class: "font-medium mb-2" }, "最近一次结果", -1)),
                    a.value ? (g(), R("div", OE, "执行时间：" + ue(a.value), 1)) : $e("", !0),
                    w("div", null, "缓存目录：" + ue(r.value.cachePath), 1),
                    w("div", null, "删除条目：" + ue(r.value.deletedEntries), 1),
                    w("div", null, "跳过条目：" + ue(r.value.skippedEntries), 1),
                    w("div", null, "错误数：" + ue(r.value.errors), 1),
                    w("div", null, "耗时：" + ue(r.value.tookMs) + " ms", 1),
                    r.value.errorDetails?.length ? (g(), R("div", BE, ue(r.value.errorDetails.join(`
`)), 1)) : $e("", !0)
                  ])) : o.value ? (g(), R("div", DE, " 清理错误：" + ue(o.value), 1)) : $e("", !0)
                ]),
                w("div", IE, [
                  w("div", qE, [
                    k(d(yE), null, {
                      default: b(() => [
                        k(d(EE), { "as-child": "" }, {
                          default: b(() => [
                            k(d(xr), {
                              disabled: !n.value,
                              variant: "destructive"
                            }, {
                              default: b(() => [
                                ne(ue(t.value ? "清理中..." : "强制清理全部缓存"), 1)
                              ]),
                              _: 1
                            }, 8, ["disabled"])
                          ]),
                          _: 1
                        }),
                        k(d(_E), null, {
                          default: b(() => [
                            k(d(AE), null, {
                              default: b(() => [
                                k(d(SE), null, {
                                  default: b(() => c[3] || (c[3] = [
                                    ne("再次确认", -1)
                                  ])),
                                  _: 1,
                                  __: [3]
                                }),
                                k(d(kE), null, {
                                  default: b(() => c[4] || (c[4] = [
                                    ne(" 将删除缓存数据，且不可恢复。确定继续？ ", -1)
                                  ])),
                                  _: 1,
                                  __: [4]
                                })
                              ]),
                              _: 1
                            }),
                            k(d(CE), null, {
                              default: b(() => [
                                k(d(xE), null, {
                                  default: b(() => c[5] || (c[5] = [
                                    ne("取消", -1)
                                  ])),
                                  _: 1,
                                  __: [5]
                                }),
                                k(d(wE), { "as-child": "" }, {
                                  default: b(() => [
                                    k(d(xr), {
                                      variant: "destructive",
                                      disabled: t.value,
                                      onClick: i
                                    }, {
                                      default: b(() => c[6] || (c[6] = [
                                        ne(" 确定清理 ", -1)
                                      ])),
                                      _: 1,
                                      __: [6]
                                    }, 8, ["disabled"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ])
                ])
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ])
    ]));
  }
});
function dh(e) {
  return zm({
    // Hash mode: works well when served from an embedded/static file server (no server-side route rewrites needed).
    history: ym(e || "/"),
    routes: [
      {
        path: "/",
        component: p5,
        children: [
          {
            path: "",
            name: "Home",
            component: T9,
            meta: {
              breadcrumb: [{ label: "KSpeeder", to: { name: "Home" } }, { label: "仪表盘" }]
            }
          },
          {
            path: "domain-acceleration",
            name: "DomainAcceleration",
            component: bE,
            meta: {
              breadcrumb: [{ label: "KSpeeder", to: { name: "Home" } }, { label: "域名加速" }]
            }
          },
          {
            path: "tools/cache-cleanup",
            name: "CacheCleanup",
            component: LE,
            meta: {
              breadcrumb: [{ label: "KSpeeder", to: { name: "Home" } }, { label: "工具" }, { label: "强制清理缓存" }]
            }
          }
        ]
      },
      {
        path: "/login",
        name: "Login",
        component: U6
      }
    ]
  });
}
dh();
const el = /* @__PURE__ */ new WeakMap();
function NE(e, t = {}) {
  if (!e)
    throw new Error("KSpeeder mount target is missing");
  fh(e), Zb(t);
  const r = O1(xw);
  r.use(I1()), r.use(dh(t.basePath)), r.mount(e), el.set(e, r);
}
function fh(e) {
  if (!e)
    return;
  const t = el.get(e);
  t && (t.unmount(), el.delete(e));
}
const VE = "html[dir=ltr],[data-sonner-toaster][dir=ltr]{--toast-icon-margin-start: -3px;--toast-icon-margin-end: 4px;--toast-svg-margin-start: -1px;--toast-svg-margin-end: 0px;--toast-button-margin-start: auto;--toast-button-margin-end: 0}html[dir=rtl],[data-sonner-toaster][dir=rtl]{--toast-icon-margin-start: 4px;--toast-icon-margin-end: -3px;--toast-svg-margin-start: 0px;--toast-svg-margin-end: -1px;--toast-button-margin-start: 0;--toast-button-margin-end: auto}[data-sonner-toaster]{position:fixed;width:var(--width);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;--gray1: hsl(0, 0%, 99%);--gray2: hsl(0, 0%, 97.3%);--gray3: hsl(0, 0%, 95.1%);--gray4: hsl(0, 0%, 93%);--gray5: hsl(0, 0%, 90.9%);--gray6: hsl(0, 0%, 88.7%);--gray7: hsl(0, 0%, 85.8%);--gray8: hsl(0, 0%, 78%);--gray9: hsl(0, 0%, 56.1%);--gray10: hsl(0, 0%, 52.3%);--gray11: hsl(0, 0%, 43.5%);--gray12: hsl(0, 0%, 9%);--border-radius: 8px;box-sizing:border-box;padding:0;margin:0;list-style:none;outline:none;z-index:999999999;transition:transform .4s ease}@media (hover: none) and (pointer: coarse){[data-sonner-toaster][data-lifted=true]{transform:none}}[data-sonner-toaster][data-x-position=right]{right:var(--offset-right)}[data-sonner-toaster][data-x-position=left]{left:var(--offset-left)}[data-sonner-toaster][data-x-position=center]{left:50%;transform:translate(-50%)}[data-sonner-toaster][data-y-position=top]{top:var(--offset-top)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--offset-bottom)}[data-sonner-toast]{--y: translateY(100%);--lift-amount: calc(var(--lift) * var(--gap));z-index:var(--z-index);position:absolute;opacity:0;transform:var(--y);touch-action:none;transition:transform .4s,opacity .4s,height .4s,box-shadow .2s;box-sizing:border-box;outline:none;overflow-wrap:anywhere}[data-sonner-toast][data-styled=true]{padding:16px;background:var(--normal-bg);border:1px solid var(--normal-border);color:var(--normal-text);border-radius:var(--border-radius);box-shadow:0 4px 12px #0000001a;width:var(--width);font-size:13px;display:flex;align-items:center;gap:6px}[data-sonner-toast]:focus-visible{box-shadow:0 4px 12px #0000001a,0 0 0 2px #0003}[data-sonner-toast][data-y-position=top]{top:0;--y: translateY(-100%);--lift: 1;--lift-amount: calc(1 * var(--gap))}[data-sonner-toast][data-y-position=bottom]{bottom:0;--y: translateY(100%);--lift: -1;--lift-amount: calc(var(--lift) * var(--gap))}[data-sonner-toast][data-styled=true] [data-description]{font-weight:400;line-height:1.4;color:#3f3f3f}[data-rich-colors=true][data-sonner-toast][data-styled=true] [data-description]{color:inherit}[data-sonner-toaster][data-sonner-theme=dark] [data-description]{color:#e8e8e8}[data-sonner-toast][data-styled=true] [data-title]{font-weight:500;line-height:1.5;color:inherit}[data-sonner-toast][data-styled=true] [data-icon]{display:flex;height:16px;width:16px;position:relative;justify-content:flex-start;align-items:center;flex-shrink:0;margin-left:var(--toast-icon-margin-start);margin-right:var(--toast-icon-margin-end)}[data-sonner-toast][data-promise=true] [data-icon]>svg{opacity:0;transform:scale(.8);transform-origin:center;animation:sonner-fade-in .3s ease forwards}[data-sonner-toast][data-styled=true] [data-icon]>*{flex-shrink:0}[data-sonner-toast][data-styled=true] [data-icon] svg{margin-left:var(--toast-svg-margin-start);margin-right:var(--toast-svg-margin-end)}[data-sonner-toast][data-styled=true] [data-content]{display:flex;flex-direction:column;gap:2px}[data-sonner-toast][data-styled=true] [data-button]{border-radius:4px;padding-left:8px;padding-right:8px;height:24px;font-size:12px;color:var(--normal-bg);background:var(--normal-text);margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end);border:none;font-weight:500;cursor:pointer;outline:none;display:flex;align-items:center;flex-shrink:0;transition:opacity .4s,box-shadow .2s}[data-sonner-toast][data-styled=true] [data-button]:focus-visible{box-shadow:0 0 0 2px #0006}[data-sonner-toast][data-styled=true] [data-button]:first-of-type{margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end)}[data-sonner-toast][data-styled=true] [data-cancel]{color:var(--normal-text);background:#00000014}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast][data-styled=true] [data-cancel]{background:#ffffff4d}[data-sonner-toaster] [data-close-button-position=top-left]{--toast-close-button-left: 0;--toast-close-button-right: unset;--toast-close-button-top: 0;--toast-close-button-bottom: unset;--toast-close-button-transform: translate(-35%, -35%)}[data-sonner-toaster] [data-close-button-position=top-right]{--toast-close-button-left: unset;--toast-close-button-right: 0;--toast-close-button-top: 0;--toast-close-button-bottom: unset;--toast-close-button-transform: translate(35%, -35%)}[data-sonner-toaster] [data-close-button-position=bottom-left]{--toast-close-button-left: 0;--toast-close-button-right: unset;--toast-close-button-top: unset;--toast-close-button-bottom: 0;--toast-close-button-transform: translate(-35%, 35%)}[data-sonner-toaster] [data-close-button-position=bottom-right]{--toast-close-button-left: unset;--toast-close-button-right: 0;--toast-close-button-top: unset;--toast-close-button-bottom: 0;--toast-close-button-transform: translate(35%, 35%)}[data-sonner-toast][data-styled=true] [data-close-button]{position:absolute;left:var(--toast-close-button-left);right:var(--toast-close-button-right);top:var(--toast-close-button-top);bottom:var(--toast-close-button-bottom);height:20px;width:20px;display:flex;justify-content:center;align-items:center;padding:0;color:var(--gray12);background:var(--normal-bg);border:1px solid var(--gray4);transform:var(--toast-close-button-transform);border-radius:50%;cursor:pointer;z-index:1;transition:opacity .1s,background .2s,border-color .2s}[data-sonner-toast][data-styled=true] [data-close-button]:focus-visible{box-shadow:0 4px 12px #0000001a,0 0 0 2px #0003}[data-sonner-toast][data-styled=true] [data-disabled=true]{cursor:not-allowed}[data-sonner-toast][data-styled=true]:hover [data-close-button]:hover{background:var(--gray2);border-color:var(--gray5)}[data-sonner-toast][data-swiping=true]:before{content:\"\";position:absolute;left:-100%;right:-100%;height:100%;z-index:-1}[data-sonner-toast][data-y-position=top][data-swiping=true]:before{bottom:50%;transform:scaleY(3) translateY(50%)}[data-sonner-toast][data-y-position=bottom][data-swiping=true]:before{top:50%;transform:scaleY(3) translateY(-50%)}[data-sonner-toast][data-swiping=false][data-removed=true]:before{content:\"\";position:absolute;inset:0;transform:scaleY(2)}[data-sonner-toast][data-expanded=true]:after{content:\"\";position:absolute;left:0;height:calc(var(--gap) + 1px);bottom:100%;width:100%}[data-sonner-toast][data-mounted=true]{--y: translateY(0);opacity:1}[data-sonner-toast][data-expanded=false][data-front=false]{--scale: var(--toasts-before) * .05 + 1;--y: translateY(calc(var(--lift-amount) * var(--toasts-before))) scale(calc(-1 * var(--toasts-before) * .05 + 1));height:var(--front-toast-height)}[data-sonner-toast]>*{transition:opacity .4s}[data-sonner-toast][data-x-position=right]{right:0}[data-sonner-toast][data-x-position=left]{left:0}[data-sonner-toast][data-expanded=false][data-front=false][data-styled=true]>*{opacity:0}[data-sonner-toast][data-visible=false]{opacity:0;pointer-events:none}[data-sonner-toast][data-mounted=true][data-expanded=true]{--y: translateY(calc(var(--lift) * var(--offset)));height:var(--initial-height)}[data-sonner-toast][data-removed=true][data-front=true][data-swipe-out=false]{--y: translateY(calc(var(--lift) * -100%));opacity:0}[data-sonner-toast][data-removed=true][data-front=false][data-swipe-out=false][data-expanded=true]{--y: translateY(calc(var(--lift) * var(--offset) + var(--lift) * -100%));opacity:0}[data-sonner-toast][data-removed=true][data-front=false][data-swipe-out=false][data-expanded=false]{--y: translateY(40%);opacity:0;transition:transform .5s,opacity .2s}[data-sonner-toast][data-removed=true][data-front=false]:before{height:calc(var(--initial-height) + 20%)}[data-sonner-toast][data-swiping=true]{transform:var(--y) translateY(var(--swipe-amount-y, 0px)) translate(var(--swipe-amount-x, 0px));transition:none}[data-sonner-toast][data-swiped=true]{-webkit-user-select:none;-moz-user-select:none;user-select:none}[data-sonner-toast][data-swipe-out=true][data-y-position=bottom],[data-sonner-toast][data-swipe-out=true][data-y-position=top]{animation-duration:.2s;animation-timing-function:ease-out;animation-fill-mode:forwards}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=left]{animation-name:swipe-out-left}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=right]{animation-name:swipe-out-right}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=up]{animation-name:swipe-out-up}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=down]{animation-name:swipe-out-down}@keyframes swipe-out-left{0%{transform:var(--y) translate(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translate(calc(var(--swipe-amount-x) - 100%));opacity:0}}@keyframes swipe-out-right{0%{transform:var(--y) translate(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translate(calc(var(--swipe-amount-x) + 100%));opacity:0}}@keyframes swipe-out-up{0%{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) - 100%));opacity:0}}@keyframes swipe-out-down{0%{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) + 100%));opacity:0}}@media (max-width: 600px){[data-sonner-toaster]{position:fixed;right:var(--mobile-offset-right);left:var(--mobile-offset-left);width:100%}[data-sonner-toaster][dir=rtl]{left:calc(var(--mobile-offset-left) * -1)}[data-sonner-toaster] [data-sonner-toast]{left:0;right:0;width:calc(100% - var(--mobile-offset-left) * 2)}[data-sonner-toaster][data-x-position=left]{left:var(--mobile-offset-left)}[data-sonner-toaster][data-y-position=bottom]{bottom:calc(var(--mobile-offset-bottom) + max(env(safe-area-inset-bottom),0px))}[data-sonner-toaster][data-y-position=top]{top:calc(var(--mobile-offset-top) + max(env(safe-area-inset-top),0px))}[data-sonner-toaster][data-x-position=center]{left:var(--mobile-offset-left);right:var(--mobile-offset-right);transform:none}}[data-sonner-toaster][data-sonner-theme=light]{--normal-bg: #fff;--normal-border: var(--gray4);--normal-text: var(--gray12);--success-bg: hsl(143, 85%, 96%);--success-border: hsl(145, 92%, 87%);--success-text: hsl(140, 100%, 27%);--info-bg: hsl(208, 100%, 97%);--info-border: hsl(221, 91%, 93%);--info-text: hsl(210, 92%, 45%);--warning-bg: hsl(49, 100%, 97%);--warning-border: hsl(49, 91%, 84%);--warning-text: hsl(31, 92%, 45%);--error-bg: hsl(359, 100%, 97%);--error-border: hsl(359, 100%, 94%);--error-text: hsl(360, 100%, 45%)}[data-sonner-toaster][data-sonner-theme=light] [data-sonner-toast][data-invert=true]{--normal-bg: #000;--normal-border: hsl(0, 0%, 20%);--normal-text: var(--gray1)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast][data-invert=true]{--normal-bg: #fff;--normal-border: var(--gray3);--normal-text: var(--gray12)}[data-sonner-toaster][data-sonner-theme=dark]{--normal-bg: #000;--normal-bg-hover: hsl(0, 0%, 12%);--normal-border: hsl(0, 0%, 20%);--normal-border-hover: hsl(0, 0%, 25%);--normal-text: var(--gray1);--success-bg: hsl(150, 100%, 6%);--success-border: hsl(147, 100%, 12%);--success-text: hsl(150, 86%, 65%);--info-bg: hsl(215, 100%, 6%);--info-border: hsl(223, 43%, 17%);--info-text: hsl(216, 87%, 65%);--warning-bg: hsl(64, 100%, 6%);--warning-border: hsl(60, 100%, 9%);--warning-text: hsl(46, 87%, 65%);--error-bg: hsl(358, 76%, 10%);--error-border: hsl(357, 89%, 16%);--error-text: hsl(358, 100%, 81%)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast] [data-close-button]{background:var(--normal-bg);border-color:var(--normal-border);color:var(--normal-text)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast] [data-close-button]:hover{background:var(--normal-bg-hover);border-color:var(--normal-border-hover)}[data-rich-colors=true][data-sonner-toast][data-type=success],[data-rich-colors=true][data-sonner-toast][data-type=success] [data-close-button]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=info],[data-rich-colors=true][data-sonner-toast][data-type=info] [data-close-button]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning],[data-rich-colors=true][data-sonner-toast][data-type=warning] [data-close-button]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=error],[data-rich-colors=true][data-sonner-toast][data-type=error] [data-close-button]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}.sonner-loading-wrapper{--size: 16px;height:var(--size);width:var(--size);position:absolute;inset:0;z-index:10}.sonner-loading-wrapper[data-visible=false]{transform-origin:center;animation:sonner-fade-out .2s ease forwards}.sonner-spinner{position:relative;top:50%;left:50%;height:var(--size);width:var(--size)}.sonner-loading-bar{animation:sonner-spin 1.2s linear infinite;background:var(--gray11);border-radius:6px;height:8%;left:-10%;position:absolute;top:-3.9%;width:24%}.sonner-loading-bar:nth-child(1){animation-delay:-1.2s;transform:rotate(.0001deg) translate(146%)}.sonner-loading-bar:nth-child(2){animation-delay:-1.1s;transform:rotate(30deg) translate(146%)}.sonner-loading-bar:nth-child(3){animation-delay:-1s;transform:rotate(60deg) translate(146%)}.sonner-loading-bar:nth-child(4){animation-delay:-.9s;transform:rotate(90deg) translate(146%)}.sonner-loading-bar:nth-child(5){animation-delay:-.8s;transform:rotate(120deg) translate(146%)}.sonner-loading-bar:nth-child(6){animation-delay:-.7s;transform:rotate(150deg) translate(146%)}.sonner-loading-bar:nth-child(7){animation-delay:-.6s;transform:rotate(180deg) translate(146%)}.sonner-loading-bar:nth-child(8){animation-delay:-.5s;transform:rotate(210deg) translate(146%)}.sonner-loading-bar:nth-child(9){animation-delay:-.4s;transform:rotate(240deg) translate(146%)}.sonner-loading-bar:nth-child(10){animation-delay:-.3s;transform:rotate(270deg) translate(146%)}.sonner-loading-bar:nth-child(11){animation-delay:-.2s;transform:rotate(300deg) translate(146%)}.sonner-loading-bar:nth-child(12){animation-delay:-.1s;transform:rotate(330deg) translate(146%)}@keyframes sonner-fade-in{0%{opacity:0;transform:scale(.8)}to{opacity:1;transform:scale(1)}}@keyframes sonner-fade-out{0%{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(.8)}}@keyframes sonner-spin{0%{opacity:1}to{opacity:.15}}@media (prefers-reduced-motion){[data-sonner-toast],[data-sonner-toast]>*,.sonner-loading-bar{transition:none!important;animation:none!important}}.sonner-loader{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);transform-origin:center;transition:opacity .2s,transform .2s}.sonner-loader[data-visible=false]{opacity:0;transform:scale(.8) translate(-50%,-50%)}\n\n", tl = /* @__PURE__ */ new WeakMap();
function Id(e) {
  return e.replace(/(^|[}\s]):root\s*{/g, "$1:host, .kspeeder-desktop-root {").replace(/(^|[}\s])\.dark\s*{/g, "$1:host(.dark), .kspeeder-desktop-root.dark {");
}
function HE(e) {
  const t = document.createElement("style");
  t.textContent = `${Id(ph)}
${Id(VE)}

:host {
  display: block;
  width: 100%;
  height: 100%;
  background: var(--background);
  color: var(--foreground);
}

.kspeeder-desktop-root {
  box-sizing: border-box;
  position: relative;
  width: 100%;
  height: 100%;
  min-height: 100%;
  overflow: auto;
  background: var(--background);
  color: var(--foreground);
}

.kspeeder-desktop-root *,
.kspeeder-desktop-root *::before,
.kspeeder-desktop-root *::after {
  box-sizing: border-box;
}

.kspeeder-desktop-root .h-screen {
  height: 100%;
}

.kspeeder-desktop-root .min-h-screen {
  min-height: 100%;
}

.kspeeder-desktop-root .h-svh {
  height: 100%;
}

.kspeeder-desktop-root .min-h-svh {
  min-height: 100%;
}

.kspeeder-desktop-root [data-slot="sidebar-wrapper"] {
  position: relative;
  min-height: 100%;
}

.kspeeder-desktop-root [data-slot="sidebar"][data-state] > [data-slot="sidebar"][data-sidebar="sidebar"] {
  position: absolute;
  height: 100%;
  min-height: 100%;
  max-height: 100%;
}
`;
  const r = document.createElement("div");
  r.className = "kspeeder-desktop-root", e.replaceChildren(t, r);
  const a = { appRoot: r };
  return tl.set(e, a), a;
}
async function FE() {
}
async function zE(e) {
  const t = e.domElement;
  if (!t)
    throw new Error("KSpeeder desktop mount target is missing");
  const r = HE(t);
  NE(r.appRoot, {
    basePath: e.context?.basePath || "/apps/kspeeder/",
    apiBase: e.context?.apiBase || "/apps/kspeeder/api/",
    mode: "desktop",
    hostAdapter: e.hostAdapter
  });
}
async function jE(e) {
  const t = e.domElement;
  if (!t)
    return;
  const r = tl.get(t);
  r && fh(r.appRoot), t.replaceChildren(), tl.delete(t);
}
const d$ = { bootstrap: FE, mount: zE, unmount: jE };
export {
  FE as bootstrap,
  d$ as default,
  zE as mount,
  jE as unmount
};
