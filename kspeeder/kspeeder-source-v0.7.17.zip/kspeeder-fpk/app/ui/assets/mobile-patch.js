console.log('mobile-patch.js loaded');
(function() {
  if (window.innerWidth > 640) return;

  // 页面标题映射
  var pageTitles = {
    '': '仪表盘',
    'domain-acceleration': '域名加速',
    'tools/cache-cleanup': '强制清理缓存'
  };

  function updateHeaderTitle() {
    var header = document.querySelector('header');
    if (!header) return;

    // 移除旧的标题元素
    var oldTitle = document.getElementById('kspeeder-mobile-title');
    if (oldTitle) {
      oldTitle.remove();
    }

    // 获取当前路由
    var hash = window.location.hash || '#/';
    var route = hash.replace('#/', '').split('?')[0];
    var titleText = pageTitles[route] || 'KSpeeder';

    // 创建标题元素
    var titleElement = document.createElement('span');
    titleElement.id = 'kspeeder-mobile-title';
    titleElement.textContent = titleText;
    titleElement.style.cssText = 'position:absolute;left:50%;transform:translateX(-50%);font-weight:600;font-size:1rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:60%;';
    
    // 插入到header中
    header.appendChild(titleElement);
  }

  function patchSidebar(sidebar) {
    if (!sidebar || sidebar.dataset.kspeederPatched === '1') return;
    sidebar.dataset.kspeederPatched = '1';
    sidebar.style.width = '50vw';
    sidebar.style.maxWidth = '300px';
    sidebar.style.minWidth = '260px';

    function closeSidebar() {
      sidebar.style.transform = 'translateX(-100%)';
      sidebar.setAttribute('data-state', 'closed');
      var overlay = document.getElementById('kspeeder-sidebar-overlay');
      if (overlay) {
        overlay.style.opacity = '0';
        setTimeout(function() { overlay.remove(); }, 300);
      }
    }

    function addOverlay() {
      var overlay = document.getElementById('kspeeder-sidebar-overlay');
      if (overlay) return;
      overlay = document.createElement('div');
      overlay.id = 'kspeeder-sidebar-overlay';
      overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:40;opacity:0;transition:opacity .3s';
      document.body.appendChild(overlay);
      overlay.addEventListener('click', closeSidebar);
    }

    var trigger = document.querySelector('[data-slot="sidebar-trigger"]');
    if (trigger) {
      trigger.addEventListener('click', function() {
        setTimeout(addOverlay, 10);
      });
    }

    var menuItems = sidebar.querySelectorAll('a, button[data-sidebar="menu-button"]');
    menuItems.forEach(function(item) {
      item.addEventListener('click', function(e) {
        setTimeout(closeSidebar, 150);
      });
    });
  }

  function tryPatch() {
    var sidebar = document.querySelector('[data-slot="sidebar"]');
    if (sidebar) {
      patchSidebar(sidebar);
    }
    updateHeaderTitle();
  }

  // 监听路由变化
  window.addEventListener('hashchange', function() {
    setTimeout(updateHeaderTitle, 100);
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      tryPatch();
      setInterval(tryPatch, 500);
    });
  } else {
    tryPatch();
    setInterval(tryPatch, 500);
  }
})();
